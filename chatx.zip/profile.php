<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
$current_user = [
    'id' => $_SESSION['user_id'],
    'username' => $_SESSION['username'],
    'nickname' => $_SESSION['nickname'] ?? $_SESSION['username'],
    'avatar' => $_SESSION['avatar'] ?? 'default.png'
];
if (isset($_SESSION['chatx_token']) && empty($_SESSION['chatx_token'])) {
    $_SESSION['chatx_token'] = create_token($_SESSION['user_id']);
}
$frontend_token = $_SESSION['chatx_token'] ?? '';
$view_user_id = isset($_GET['user_id']) ? (int)$_GET['user_id'] : 0;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatX - 个人主页</title>
    <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .profile-wrap { max-width: 720px; margin: 0 auto; padding: 24px; }
        .profile-hero { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 20px; padding: 32px; color: #fff; position: relative; overflow: hidden; }
        .profile-hero .avatar { width: 96px; height: 96px; border-radius: 50%; border: 4px solid rgba(255,255,255,0.3); }
        .profile-hero .nick { font-size: 24px; font-weight: 700; margin-top: 16px; }
        .profile-hero .uname { opacity: 0.85; font-size: 14px; margin-top: 4px; }
        .profile-hero .sig { margin-top: 12px; opacity: 0.95; font-size: 14px; font-style: italic; }
        .profile-body { background: #fff; border-radius: 16px; padding: 24px; margin-top: 16px; box-shadow: var(--shadow); }
        .profile-section { margin-bottom: 24px; }
        .profile-section h3 { font-size: 16px; color: var(--text-secondary); margin-bottom: 12px; text-transform: uppercase; letter-spacing: 0.5px; }
        .profile-row { display: flex; align-items: center; gap: 16px; padding: 12px 0; border-bottom: 1px solid var(--border); }
        .profile-row:last-child { border-bottom: none; }
        .profile-row label { width: 80px; color: var(--text-secondary); font-size: 14px; }
        .profile-row .val { flex: 1; font-size: 14px; word-break: break-all; }
        .profile-actions { display: flex; gap: 12px; margin-top: 20px; }
        .profile-actions .btn { flex: 1; text-align: center; }
        .empty-hint { color: var(--text-secondary); font-style: italic; }
        .back-bar { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
        .back-bar .btn { width: auto; padding: 8px 16px; }
    </style>
</head>
<body>
    <div class="profile-wrap">
        <div class="back-bar">
            <a href="chat.php" class="btn btn-secondary">&larr; 返回聊天</a>
        </div>
        <div id="profileContent">
            <div class="loading">加载中...</div>
        </div>
    </div>

    <script>
    window.ChatX = {
        user: <?php echo json_encode($current_user, JSON_UNESCAPED_UNICODE); ?>,
        token: '<?php echo $frontend_token; ?>'
    };
    </script>
    <script src="js/main.js"></script>
    <script>
    (function() {
        const viewUserId = <?php echo $view_user_id; ?>;
        if (!viewUserId) {
            document.getElementById('profileContent').innerHTML = '<div class="loading">无效的用户ID</div>';
            return;
        }

        async function loadProfile() {
            try {
                const data = await fetch('api/features.php?action=full_profile&user_id=' + viewUserId, {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                }).then(r => r.json());
                if (data.error) throw new Error(data.error);
                renderProfile(data.user);
            } catch (e) {
                document.getElementById('profileContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderProfile(u) {
            const isMe = u.id === window.ChatX.user.id;
            const sig = u.signature || '<span class="empty-hint">暂无签名</span>';
            const bio = u.bio || '<span class="empty-hint">暂无简介</span>';

            let actionsHtml = '';
            if (isMe) {
                actionsHtml = `<button class="btn btn-primary" id="btnEditMine">修改个人资料</button>`;
            } else {
                if (u.is_friend) {
                    actionsHtml = `<button class="btn btn-primary" id="btnMsg">发送消息</button>`;
                } else if (u.request_sent) {
                    actionsHtml = `<button class="btn btn-secondary" disabled>好友请求已发送</button>`;
                } else {
                    actionsHtml = `<button class="btn btn-primary" id="btnAddFriend">添加为好友</button>`;
                }
            }

            document.getElementById('profileContent').innerHTML = `
                <div class="profile-hero">
                    <div style="text-align:center;">
                        <div class="avatar-frame ${u.avatar_frame ? 'frame-' + u.avatar_frame : ''}" style="margin:0 auto;"><div class="avatar" style="margin:0 auto;">${u.nickname.charAt(0)}</div></div>
                        <div class="nick">${escapeHtml(u.nickname)}</div>
                        <div class="uname">@${escapeHtml(u.username)}</div>
                        <div class="sig">${escapeHtml(sig)}</div>
                    </div>
                </div>
                <div class="profile-body">
                    <div class="profile-section">
                        <h3>基本信息</h3>
                        <div class="profile-row"><label>用户名</label><div class="val">${escapeHtml(u.username)}</div></div>
                        <div class="profile-row"><label>昵称</label><div class="val">${escapeHtml(u.nickname)}</div></div>
                        <div class="profile-row"><label>等级</label><div class="val">Lv.${u.level || 1} (${u.xp_current || 0}/${u.xp_needed || 150} XP)</div></div>
                        <div class="profile-row"><label>状态</label><div class="val">${u.status === 'online' ? '在线' : '离线'}</div></div>
                        <div class="profile-row"><label>注册时间</label><div class="val">${u.created_at || ''}</div></div>
                    </div>
                    <div class="profile-section">
                        <h3>简介</h3>
                        <div class="profile-row"><label>个人简介</label><div class="val">${bio}</div></div>
                        <div class="profile-row"><label>个性签名</label><div class="val">${sig}</div></div>
                    </div>
                    <div class="profile-actions">${actionsHtml}</div>
                    </div>
                    <div class="profile-section" id="profilePostsSection">
                        <h3>论坛文章</h3>
                        <div id="profilePosts" class="loading">加载中...</div>
                    </div>
                </div>
            `;

            if (isMe) return;

            const btnAdd = document.getElementById('btnAddFriend');
            if (btnAdd) {
                btnAdd.addEventListener('click', async () => {
                    try {
                        const res = await fetch('api/users.php?action=add', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                            body: JSON.stringify({ friend_id: u.id })
                        }).then(r => r.json());
                        if (res.error) throw new Error(res.error);
                        btnAdd.textContent = '已发送';
                        btnAdd.disabled = true;
                        btnAdd.classList.remove('btn-primary');
                        btnAdd.classList.add('btn-secondary');
                    } catch (e) { alert(e.message); }
                });
            }

            const btnMsg = document.getElementById('btnMsg');
            if (btnMsg) {
                btnMsg.addEventListener('click', () => {
                    window.location.href = 'chat.php?open=' + u.id;
                });
            }

            const btnEdit = document.getElementById('btnEditMine');
            if (btnEdit) {
                btnEdit.addEventListener('click', () => {
                    if (window.ChatX.showEditProfile) window.ChatX.showEditProfile();
                    else window.location.href = 'chat.php';
                });
            }
        }

        function escapeHtml(str) {
            if (!str) return '';
            return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        }

        async function loadProfilePosts() {
            const container = document.getElementById('profilePosts');
            if (!container) return;
            try {
                const data = await fetch('api/forum.php?action=user_posts&user_id=' + viewUserId, {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                }).then(r => r.json());
                const posts = data.posts || [];
                if (!posts.length) {
                    container.innerHTML = '<div style="color:var(--text-secondary);font-style:italic;">暂无文章</div>';
                    return;
                }
                container.innerHTML = posts.map(p => `
                    <div style="padding:12px 0;border-bottom:1px solid var(--border);cursor:pointer;" onclick="window.location.href='forum.php?post=${p.id}'">
                        <div style="font-size:14px;font-weight:500;margin-bottom:4px;">${p.is_pinned ? '📌 ' : ''}${p.is_archived ? '📦 ' : ''}${escapeHtml(p.title)}</div>
                        <div style="font-size:12px;color:var(--text-secondary);">${(p.category_icon || '📁') + ' ' + escapeHtml(p.category_name)} · 👍 ${p.likes_count} · 💬 ${p.replies_count} · 👁 ${p.view_count || 0}</div>
                    </div>
                `).join('');
            } catch (e) {
                container.innerHTML = '<div style="color:red;">加载失败</div>';
            }
        }

        loadProfile();
        loadProfilePosts();
    })();
    </script>
</body>
</html>
