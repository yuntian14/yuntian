<?php
session_start();
require_once __DIR__ . '/functions.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
$pdo = db_connect();
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user_row = $stmt->fetch();
if (!$user_row) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
$current_user = [
    'id' => $user_row['id'],
    'username' => $user_row['username'],
    'nickname' => $user_row['nickname'] ?? $user_row['username'],
    'avatar' => $user_row['avatar'] ?? 'default.png',
    'role' => $user_row['role'] ?? 'user',
    'avatar_frame' => $user_row['avatar_frame'] ?? null
];

// Generate API token for frontend and persist it
// 登录会刷新 token 并删旧 session 行，所以每次访问都要校验有效性
$frontend_token = $_SESSION['chatx_token'] ?? '';
if (!empty($frontend_token) && !get_user_by_token($frontend_token)) {
    $frontend_token = '';
    unset($_SESSION['chatx_token']);
}
if (isset($_SESSION['user_id']) && empty($frontend_token)) {
    $_SESSION['chatx_token'] = create_token($_SESSION['user_id']);
    $frontend_token = $_SESSION['chatx_token'];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatX - 即时聊天</title>
    <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
    <link rel="stylesheet" href="css/style.css?v=20260825u">
</head>
<body>
    <div class="app">
        <!-- Mobile Header -->
        <div class="mobile-header" id="mobileHeader">
            <button class="icon-btn" id="btnMenu" title="菜单" data-icon="menu">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
            </button>
            <span style="font-weight:600;" id="mobileTitle">ChatX</span>
            <div style="width:36px;"></div>
        </div>

        <!-- Sidebar Navigation -->
        <nav class="sidebar" id="sidebar">
            <div class="sidebar-logo" title="ChatX">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
            </div>
            <div class="nav-item active" data-tab="chat" title="消息">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
            </div>
            <div class="nav-item" data-tab="contacts" title="联系人">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
            </div>
            <div class="nav-item" data-tab="groups" title="群组">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
            </div>
            <div class="nav-item" data-tab="games" title="游戏">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><line x1="6" y1="11" x2="10" y2="11"></line><line x1="8" y1="9" x2="8" y2="13"></line><line x1="15" y1="12" x2="15.01" y2="12"></line><line x1="18" y1="10" x2="18.01" y2="10"></line><rect x="2" y="6" width="20" height="12" rx="2"></rect></svg>
            </div>
            <div class="nav-item" data-tab="casino" title="赌场">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="4"></rect><circle cx="8" cy="8" r="1.5"></circle><circle cx="16" cy="16" r="1.5"></circle><circle cx="16" cy="8" r="1.5"></circle><circle cx="8" cy="16" r="1.5"></circle><circle cx="12" cy="12" r="2"></circle></svg>
            </div>
            <div class="nav-item" onclick="window.ChatX.showNotifications && window.ChatX.showNotifications()" title="通知" style="position:relative;">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                <span id="notifBadge" style="display:none;position:absolute;top:2px;right:2px;background:#f56c6c;color:#fff;font-size:10px;border-radius:8px;padding:0 4px;line-height:16px;min-width:16px;text-align:center;"></span>
                <span id="notifDot" style="display:none;position:absolute;top:6px;right:6px;width:8px;height:8px;background:#f56c6c;border-radius:50%;"></span>
            </div>
            <div class="nav-item" onclick="window.ChatX.showMoments && window.ChatX.showMoments()" title="动态">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" y1="9" x2="9.01" y2="9"></line><line x1="15" y1="9" x2="15.01" y2="9"></line></svg>
            </div>
            <div class="nav-item" onclick="window.ChatX.showSearch && window.ChatX.showSearch()" title="搜索">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
            </div>
            <div class="nav-item" data-tab="ai" title="AI 助手">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" y1="9" x2="9.01" y2="9"></line><line x1="15" y1="9" x2="15.01" y2="9"></line></svg>
            </div>
            <div class="nav-item" id="navForum" title="论坛" style="cursor:pointer;">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path><line x1="8" y1="10" x2="16" y2="10"></line><line x1="8" y1="14" x2="12" y2="14"></line></svg>
            </div>
            <div class="nav-bottom">
                <?php if (($current_user['role'] ?? 'user') === 'admin' || ($current_user['role'] ?? 'user') === 'super_admin'): ?>
                <div class="nav-item" id="navAdmin" title="管理员后台" style="cursor:pointer;">
                    <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
                </div>
                <?php endif; ?>
                <div class="nav-item" data-tab="settings" title="设置">
                    <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>
                </div>
                <div class="nav-item logout" data-tab="logout" title="退出">
                    <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                </div>
            </div>
        </nav>

        <!-- List Panel -->
        <div class="list-panel">
            <div class="list-header">
                <h2 id="listTitle">消息</h2>
                <div class="list-actions" id="listActions">
                    <button class="icon-btn" id="btnSearch" title="搜索" data-icon="search">
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    </button>
                    <button class="icon-btn" id="btnAdd" title="新建" style="display:none;" data-icon="add">
                        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                    </button>
                </div>
            </div>
            <div id="announcementBanner" style="display:none;padding:10px 16px;background:#fff3cd;color:#856404;border-bottom:1px solid #ffe69c;cursor:pointer;"></div>
            <div class="search-box" id="searchBox" style="display:none;">
                <input type="text" id="searchInput" placeholder="搜索用户...">
            </div>
            <div class="list-content" id="listContent">
                <div class="loading">加载中...</div>
            </div>
        </div>

        <!-- Chat Area -->
        <div class="chat-area" id="chatArea">
            <div class="chat-placeholder">
                <img src="assets/empty-chat.svg" alt="开始聊天" style="width:200px;height:auto;margin:0 auto 20px;display:block;">
                <p>选择一个联系人开始聊天</p>
            </div>
        </div>
    </div>

    <!-- 游戏面板 -->
    <div id="gamePanel" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;z-index:200;background:var(--bg-page,#f5f7fa);flex-direction:column;overflow:hidden;">
        <div style="display:flex;align-items:center;padding:14px 20px;background:var(--bg-white,#fff);border-bottom:1px solid var(--border,#e4e7ed);">
            <button class="icon-btn" id="btnCloseGames" title="关闭" style="margin-right:8px;">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
            <h2 style="font-size:18px;font-weight:700;">游戏大厅</h2>
        </div>
        <div id="gameContent" style="flex:1;overflow-y:auto;padding:20px;"></div>
    </div>

    <!-- 赌场面板 -->
    <div id="casinoPanel" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;z-index:200;background:#1a1a2e;flex-direction:column;overflow:hidden;">
        <div style="display:flex;align-items:center;padding:14px 20px;background:#16213e;border-bottom:1px solid #0f3460;">
            <button class="icon-btn" id="btnCloseCasino" title="关闭" style="margin-right:8px;color:#fff;">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
            <h2 style="font-size:18px;font-weight:700;color:#e94560;">🎰 赌场</h2>
            <div style="margin-left:auto;display:flex;gap:8px;">
                <button class="btn-mini" style="color:#fff;border-color:#444;" onclick="document.getElementById('lbPanel').style.display='flex'">🏆 排行榜</button>
                <button class="btn-mini" style="color:#ffd700;border-color:#ffd700;" onclick="document.getElementById('luckyDrawModal').style.display='flex'">🎰 抽奖</button>
            </div>
        </div>
        <div id="casinoContent" style="flex:1;overflow-y:auto;padding:20px;"></div>
    </div>

    <!-- Notifications Panel -->
    <div id="notifPanel" style="display:none;position:fixed;top:0;right:0;bottom:0;width:400px;z-index:300;background:var(--bg-white,#fff);border-left:1px solid var(--border,#e0e0e0);flex-direction:column;">
        <div style="padding:16px;border-bottom:1px solid var(--border,#e0e0e0);display:flex;justify-content:space-between;align-items:center;">
            <h3 style="margin:0;">通知</h3>
            <div>
                <button class="btn-mini btn-primary" onclick="window.ChatX.markAllRead()">全部已读</button>
                <button class="btn-mini" onclick="window.ChatX.closeNotifications()">关闭</button>
            </div>
        </div>
        <div id="notifList" style="flex:1;overflow-y:auto;"></div>
    </div>

    <!-- Moments Panel -->
    <div id="momentsPanel" style="display:none;position:fixed;top:0;right:0;bottom:0;width:450px;z-index:300;background:var(--bg-page,#f5f7fa);border-left:1px solid var(--border,#e0e0e0);flex-direction:column;">
        <div style="padding:16px;border-bottom:1px solid var(--border,#e0e0e0);display:flex;justify-content:space-between;align-items:center;">
            <h3 style="margin:0;">动态</h3>
            <div>
                <button class="btn-mini btn-primary" onclick="window.ChatX.showPostMoment && window.ChatX.showPostMoment()">发布</button>
                <button class="btn-mini" onclick="window.ChatX.showMoments && window.ChatX.showMoments()">关闭</button>
            </div>
        </div>
        <div id="momentsList" style="flex:1;overflow-y:auto;padding:16px;"></div>
    </div>

    <!-- Blacklist Panel -->
    <div id="blacklistPanel" style="display:none;position:fixed;top:0;right:0;bottom:0;width:350px;z-index:300;background:var(--bg-white,#fff);border-left:1px solid var(--border,#e0e0e0);flex-direction:column;">
        <div style="padding:16px;border-bottom:1px solid var(--border,#e0e0e0);display:flex;justify-content:space-between;align-items:center;">
            <h3 style="margin:0;">黑名单</h3>
            <button class="btn-mini" onclick="document.getElementById('blacklistPanel').style.display='none'">关闭</button>
        </div>
        <div id="blacklistList" style="flex:1;overflow-y:auto;"></div>
    </div>

    <!-- Search Modal -->
    <div id="searchModal" style="display:none;position:fixed;inset:0;z-index:400;background:rgba(0,0,0,0.5);align-items:center;justify-content:center;">
        <div style="background:var(--bg-white,#fff);border-radius:12px;width:600px;max-width:90vw;max-height:80vh;display:flex;flex-direction:column;">
            <div style="padding:16px;border-bottom:1px solid var(--border,#e0e0e0);display:flex;justify-content:space-between;align-items:center;">
                <h3 style="margin:0;">消息搜索</h3>
                <button class="btn-mini" onclick="window.ChatX.closeSearch()">关闭</button>
            </div>
            <div style="padding:16px;display:flex;gap:8px;">
                <input type="text" id="msgSearchInput" placeholder="搜索消息内容..." style="flex:1;padding:8px 12px;border:1px solid var(--border,#e0e0e0);border-radius:8px;font-size:14px;">
                <select id="msgSearchScope" style="padding:8px 12px;border:1px solid var(--border,#e0e0e0);border-radius:8px;">
                    <option value="all">全部</option>
                    <option value="private">私聊</option>
                    <option value="group">群聊</option>
                </select>
                <button class="btn btn-primary" id="msgSearchBtn" onclick="window.ChatX.doSearch()">搜索</button>
            </div>
            <div id="searchResults" style="flex:1;overflow-y:auto;padding:16px;"></div>
        </div>
    </div>

    <!-- Level Info Modal -->
    <div id="levelModal" style="display:none;position:fixed;inset:0;z-index:400;background:rgba(0,0,0,0.5);align-items:center;justify-content:center;">
        <div style="background:var(--bg-white,#fff);border-radius:16px;padding:32px;text-align:center;min-width:320px;">
            <h2 style="margin:0 0 16px;">等级 <span id="levelNum" style="color:#4f46e5;">1</span></h2>
            <div style="width:200px;height:12px;background:#e0e0e0;border-radius:6px;margin:0 auto 8px;">
                <div id="xpBar" style="height:100%;background:linear-gradient(90deg,#4f46e5,#7c3aed);border-radius:6px;width:0%;transition:width 0.3s;"></div>
            </div>
            <div style="font-size:14px;color:#666;"><span id="xpCurrent">0</span> / <span id="xpNeeded">150</span> XP</div>
            <button class="btn btn-primary" style="margin-top:20px;" onclick="window.ChatX.closeLevelInfo()">关闭</button>
        </div>
    </div>

    <!-- Casino Leaderboard Panel -->
    <div id="lbPanel" style="display:none;position:fixed;top:0;right:0;bottom:0;width:400px;z-index:300;background:#1a1a2e;border-left:1px solid #2a2a4a;flex-direction:column;">
        <div style="padding:16px;border-bottom:1px solid #2a2a4a;display:flex;justify-content:space-between;align-items:center;">
            <h3 style="margin:0;color:#fff;">排行榜</h3>
            <div>
                <select id="lbPeriod" style="padding:4px 8px;border-radius:4px;border:1px solid #444;background:#2a2a4a;color:#fff;margin-right:8px;">
                    <option value="all">全部</option>
                    <option value="today">今日</option>
                    <option value="week">本周</option>
                </select>
                <button class="btn-mini" style="color:#fff;border-color:#444;" onclick="document.getElementById('lbPanel').style.display='none'">关闭</button>
            </div>
        </div>
        <div id="lbList" style="flex:1;overflow-y:auto;padding:8px;"></div>
    </div>

    <!-- Lucky Draw Modal -->
    <div id="luckyDrawModal" style="display:none;position:fixed;inset:0;z-index:400;background:rgba(0,0,0,0.7);align-items:center;justify-content:center;">
        <div style="background:linear-gradient(135deg,#1a1a2e,#16213e);border-radius:16px;padding:32px;text-align:center;min-width:360px;border:2px solid #ffd700;">
            <h2 style="color:#ffd700;margin:0 0 16px;">🎰 幸运抽奖</h2>
            <div style="display:flex;gap:8px;margin-bottom:16px;justify-content:center;">
                <input type="number" id="luckyAmount" value="100" min="1" max="10000" style="width:100px;padding:8px;border-radius:8px;border:1px solid #444;background:#2a2a4a;color:#fff;text-align:center;">
                <button class="btn btn-primary" onclick="window.ChatX.luckyDraw(document.getElementById('luckyAmount').value)">抽奖</button>
            </div>
            <div id="luckyResult" style="min-height:80px;"></div>
            <div style="margin-top:16px;font-size:12px;color:#888;">最高 Jackpot 50x！</div>
            <button class="btn-mini" style="color:#fff;border-color:#444;margin-top:12px;" onclick="document.getElementById('luckyDrawModal').style.display='none'">关闭</button>
        </div>
    </div>

    <!-- Post Moment Modal -->
    <div id="postMomentModal" style="display:none;position:fixed;inset:0;z-index:400;background:rgba(0,0,0,0.5);align-items:center;justify-content:center;">
        <div style="background:var(--bg-white,#fff);border-radius:12px;width:500px;max-width:90vw;padding:24px;">
            <h3 style="margin:0 0 16px;">发布动态</h3>
            <textarea id="momentInput" placeholder="分享你的想法..." maxlength="1000" style="width:100%;height:120px;padding:12px;border:1px solid var(--border,#e0e0e0);border-radius:8px;resize:vertical;font-size:14px;"></textarea>
            <div style="display:flex;justify-content:flex-end;gap:8px;margin-top:12px;">
                <button class="btn" onclick="window.ChatX.closePostMoment()">取消</button>
                <button class="btn btn-primary" onclick="window.ChatX.submitMoment()">发布</button>
            </div>
        </div>
    </div>

    <!-- Daily Tasks Modal -->
    <div id="tasksModal" style="display:none;position:fixed;inset:0;z-index:400;background:rgba(0,0,0,0.5);align-items:center;justify-content:center;">
        <div style="background:var(--bg-white,#fff);border-radius:16px;width:420px;max-width:90vw;padding:24px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
                <h3 style="margin:0;">每日任务</h3>
                <button class="btn-mini" onclick="window.ChatX.closeTasks()">关闭</button>
            </div>
            <div style="text-align:center;padding:12px;background:linear-gradient(135deg,#f0f9ff,#e0f2fe);border-radius:8px;margin-bottom:16px;">
                <div style="font-size:13px;color:#666;">今日奖励</div>
                <div id="taskReward" style="font-size:20px;font-weight:bold;color:#4f46e5;">0 / 0 XP</div>
            </div>
            <div id="tasksList" style="max-height:300px;overflow-y:auto;margin-bottom:16px;"></div>
            <button class="btn btn-primary" id="taskClaimBtn" style="width:100%;" onclick="window.ChatX.claimTasks()">领取奖励</button>
        </div>
    </div>

    <div id="aiPanel" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;z-index:200;background:#0d1117;flex-direction:column;overflow:hidden;">
        <div style="display:flex;align-items:center;padding:14px 20px;background:#161b22;border-bottom:1px solid #30363d;">
            <button class="icon-btn" id="btnCloseAI" title="关闭" style="margin-right:8px;color:#fff;">
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
            <h2 style="font-size:18px;font-weight:700;color:#f59e0b;">🏀 我，科比</h2>
            <span id="aiBalance" style="margin-left:auto;font-size:12px;color:#67c23a;">积分: --</span>
        </div>
        <div id="aiContent" style="flex:1;overflow:hidden;"></div>
    </div>
    <div class="modal" id="modalOverlay" style="display:none;">
        <div class="modal-box" id="modalBox">
            <div class="modal-header">
                <h3 id="modalTitle">标题</h3>
                <button class="modal-close" id="modalClose">&times;</button>
            </div>
            <div class="modal-body" id="modalBody"></div>
        </div>
    </div>
    <div class="sidebar-overlay" id="sidebarOverlay"></div>
    <div class="toast" id="toast"></div>

    <script>
    window.ChatX = {
        user: <?php echo json_encode($current_user, JSON_UNESCAPED_UNICODE); ?>,
        token: '<?php echo $frontend_token; ?>'
    };
    </script>
    <script src="js/main.js?v=20260825u"></script>
    <script src="js/games.js?v=20260825u"></script>
    <script src="js/casino.js?v=20260825u"></script>
    <script src="js/features.js?v=20260825u"></script>
    <script src="js/ai.js?v=20260825u"></script>
    <script src="js/theme-icons.js?v=20260825u"></script>
    <script>
        // 页面加载时初始化图标
        document.addEventListener('DOMContentLoaded', function() {
            if (typeof initThemeIcons === 'function') initThemeIcons();
        });
    </script>
</body>
</html>
