<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
require_once __DIR__ . '/functions.php';
$pdo = db_connect();
$current_user = [
    'id' => $_SESSION['user_id'],
    'username' => $_SESSION['username'],
    'nickname' => $_SESSION['nickname'] ?? $_SESSION['username'],
    'avatar' => $_SESSION['avatar'] ?? 'default.png',
    'role' => $_SESSION['role'] ?? 'user'
];
$frontend_token = $_SESSION['chatx_token'] ?? '';
if (!empty($frontend_token) && !get_user_by_token($frontend_token)) {
    $frontend_token = '';
    unset($_SESSION['chatx_token']);
}
if (isset($_SESSION['user_id']) && empty($frontend_token)) {
    $_SESSION['chatx_token'] = create_token($_SESSION['user_id']);
    $frontend_token = $_SESSION['chatx_token'];
}
$role = $current_user['role'] ?? 'user';
if (!in_array($role, ['admin', 'super_admin'], true)) {
    header("Location: chat.php");
    exit;
}
$permissions = [];
if (in_array($role, ['admin', 'super_admin'], true)) {
    $stmt = $pdo->prepare("SELECT permission FROM admin_permissions WHERE user_id = ?");
    $stmt->execute([$current_user['id']]);
    while ($row = $stmt->fetch()) {
        $permissions[] = $row['permission'];
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatX - 管理员后台</title>
    <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
    <link rel="stylesheet" href="css/style.css">
    <style>
        .admin-wrap { max-width: 1100px; margin: 0 auto; padding: 24px; }
        .admin-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; }
        .admin-header h1 { font-size: 22px; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 24px; }
        .stat-card { background: #fff; border-radius: 14px; padding: 20px; box-shadow: var(--shadow); text-align: center; }
        .stat-card .num { font-size: 28px; font-weight: 700; color: var(--primary); }
        .stat-card .label { font-size: 13px; color: var(--text-secondary); margin-top: 4px; }
        .data-card { background: #fff; border-radius: 14px; padding: 20px; box-shadow: var(--shadow); }
        .data-card h3 { font-size: 16px; margin-bottom: 16px; }
        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        th, td { text-align: left; padding: 10px 12px; border-bottom: 1px solid var(--border); }
        th { color: var(--text-secondary); font-weight: 600; font-size: 13px; }
        .badge { display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 12px; }
        .badge-admin { background: #fff3cd; color: #856404; }
        .badge-user { background: #e2e3e5; color: #383d41; }
        .badge-online { background: #d4edda; color: #155724; }
        .badge-offline { background: #f8d7da; color: #721c24; }
        .btn-danger { background: var(--danger); color: #fff; border-color: var(--danger); }
        .btn-warning { background: #ffc107; color: #212529; border-color: #ffc107; }
        .btn-sm { padding: 4px 10px; font-size: 12px; border-radius: 6px; cursor: pointer; border: 1px solid transparent; }
        .toolbar { display: flex; gap: 12px; margin-bottom: 16px; }
        .tabs { display: flex; gap: 8px; margin-bottom: 16px; }
        .tab { padding: 8px 14px; border-radius: 8px; cursor: pointer; border: 1px solid var(--border); background: #fff; }
        .tab.active { background: var(--primary); color: #fff; border-color: var(--primary); }
    </style>
</head>
<body>
    <div class="admin-wrap">
        <div class="admin-header">
            <h1>ChatX 管理员后台</h1>
            <a href="chat.php" class="btn btn-secondary">返回聊天</a>
        </div>
        <div class="tabs" id="adminTabs">
            <div class="tab active" data-tab="users">用户管理</div>
            <div class="tab" data-tab="points">积分管理</div>
            <div class="tab" data-tab="groups">群组管理</div>
            <div class="tab" data-tab="friendships">好友关系</div>
            <div class="tab" data-tab="messages">消息记录</div>
            <div class="tab" data-tab="feedbacks">用户反馈</div>
            <div class="tab" data-tab="sensitive_words">敏感词</div>
            <div class="tab" data-tab="login_logs">登录日志</div>
            <div class="tab" data-tab="sessions">会话管理</div>
            <div class="tab" data-tab="reports">数据统计</div>
            <div class="tab" data-tab="roles">角色权限</div>
            <div class="tab" data-tab="announcements">公告管理</div>
            <div class="tab" data-tab="forum">论坛管理</div>
            <div class="tab" data-tab="logs">系统日志</div>
            <div class="tab" data-tab="settings">系统设置</div>
            <div class="tab" data-tab="backup" id="tabBackup" style="display:none;">数据备份</div>
        </div>
        <div id="adminContent">
            <div class="loading">加载中...</div>
        </div>
    </div>

    <script>
    window.ChatX = {
        user: <?php echo json_encode($current_user, JSON_UNESCAPED_UNICODE); ?>,
        token: '<?php echo $frontend_token; ?>',
        role: '<?php echo $current_user['role']; ?>',
        permissions: <?php echo json_encode($permissions, JSON_UNESCAPED_UNICODE); ?>
    };
    </script>
    <script src="js/main.js"></script>
    <script>
    (function() {
        let currentTab = 'users';
        async function adminFetch(url, options) {
            const r = await fetch(url, Object.assign({
                headers: { 'X-Auth-Token': window.ChatX.token, 'Content-Type': 'application/json' }
            }, options || {}));
            const text = await r.text();
            try { return JSON.parse(text); }
            catch (e) { throw new Error('登录已过期或服务器错误，请刷新页面重试'); }
        }

        function attrEscape(str) {
            if (typeof str !== 'string') str = String(str);
            return JSON.stringify(str).replace(/&/g, '&amp;').replace(/"/g, '&quot;');
        }
        function hasPermission(permission) {
            if (!permission) return true;
            if (window.ChatX.role === 'super_admin') return true;
            return (window.ChatX.permissions || []).includes(permission);
        }
        function applyTabPermissions() {
            const mapping = {
                users: 'manage_users',
                points: 'manage_users',
                groups: 'manage_groups',
                friendships: 'manage_users',
                messages: 'view_messages',
                feedbacks: 'manage_feedbacks',
                sensitive_words: 'manage_sensitive_words',
                login_logs: 'view_login_logs',
                sessions: 'manage_sessions',
                reports: 'view_reports',
                roles: 'manage_roles',
                announcements: 'manage_settings',
                forum: 'manage_forum',
                logs: 'view_messages',
                settings: 'manage_settings'
            };
            document.querySelectorAll('#adminTabs .tab').forEach(tab => {
                // 数据备份仅超级管理员可见
                if (tab.dataset.tab === 'backup') {
                    tab.style.display = window.ChatX.role === 'super_admin' ? '' : 'none';
                    return;
                }
                const perm = mapping[tab.dataset.tab];
                tab.style.display = hasPermission(perm) ? '' : 'none';
            });
        }
        function initTabs() {
            document.querySelectorAll('.tab').forEach(tab => {
                tab.addEventListener('click', () => {
                    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
                    tab.classList.add('active');
                    currentTab = tab.dataset.tab;
                    if (currentTab === 'users') loadStats();
                    else if (currentTab === 'points') loadPoints();
                    else if (currentTab === 'groups') loadGroups();
                    else if (currentTab === 'friendships') loadFriendships();
                    else if (currentTab === 'messages') loadMessages();
                    else if (currentTab === 'feedbacks') loadFeedbacks();
                    else if (currentTab === 'sensitive_words') loadSensitiveWords();
                    else if (currentTab === 'login_logs') loadLoginLogs();
                    else if (currentTab === 'sessions') loadSessions();
                    else if (currentTab === 'reports') loadReports();
                    else if (currentTab === 'roles') loadRoles();
                    else if (currentTab === 'announcements') loadAnnouncements();
                    else if (currentTab === 'forum') loadForum();
                    else if (currentTab === 'logs') loadLogs();
                    else if (currentTab === 'settings') loadSettings();
                    else if (currentTab === 'backup') loadBackup();
                });
            });
        }
        initTabs();
        applyTabPermissions();

        async function loadStats() {
            try {
                const data = await adminFetch('api/users.php?action=admin_stats', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderStats(data.stats);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderStats(stats) {
            const html = `
                <div class="stats-grid">
                    <div class="stat-card"><div class="num">${stats.users || 0}</div><div class="label">总用户数</div></div>
                    <div class="stat-card"><div class="num">${stats.groups || 0}</div><div class="label">群组数</div></div>
                    <div class="stat-card"><div class="num">${stats.messages || 0}</div><div class="label">消息数</div></div>
                    <div class="stat-card"><div class="num">${stats.online || 0}</div><div class="label">在线用户</div></div>
                    <div class="stat-card"><div class="num">${stats.friendships || 0}</div><div class="label">好友关系</div></div>
                </div>
                <div class="data-card">
                    <div class="toolbar"><h3 style="flex:1;">用户管理</h3></div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>用户名</th><th>昵称</th><th>角色</th><th>状态</th><th>注册时间</th><th>操作</th></tr></thead>
                            <tbody id="userTableBody"><tr><td colspan="7" style="text-align:center;">加载中...</td></tr></tbody>
                        </table>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
            loadUsers();
        }

        async function loadPoints() {
            try {
                const data = await adminFetch('api/casino.php?action=admin_points', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderPoints(data.users, data.totals);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderPoints(users, totals) {
            const curName = { points: '积分', gomoku: '五子币', casino: '筹码' };
            document.getElementById('adminContent').innerHTML = `
                <div class="stats-grid">
                    ${Object.keys(curName).map(c => `<div class="stat-card"><div class="num">${(totals && totals[c] || 0).toLocaleString()}</div><div class="label">总${curName[c]}</div></div>`).join('')}
                </div>
                <div class="data-card">
                    <div class="toolbar"><h3 style="flex:1;">积分管理</h3><input type="text" id="pointsSearch" class="chat-input" placeholder="搜索用户名..." style="width:180px;" oninput="filterPoints(this.value)"></div>
                    <div style="overflow-x:auto;">
                        <table id="pointsTable">
                            <thead><tr><th>ID</th><th>用户名</th><th>昵称</th><th>积分</th><th>五子币</th><th>筹码</th><th>操作</th></tr></thead>
                            <tbody id="pointsTableBody">
                                ${users.map(u => `
                                    <tr data-username="${escapeHtml(u.username)}">
                                        <td>${u.id}</td>
                                        <td>${escapeHtml(u.username)}</td>
                                        <td>${escapeHtml(u.nickname || '')}</td>
                                        <td>${(u.points || 0).toLocaleString()}</td>
                                        <td>${(u.gomoku || 0).toLocaleString()}</td>
                                        <td>${(u.casino || 0).toLocaleString()}</td>
                                        <td>
                                            <select id="ptCur_${u.id}" class="chat-input" style="width:auto;padding:4px 8px;font-size:12px;">
                                                <option value="points">积分</option>
                                                <option value="gomoku">五子币</option>
                                                <option value="casino">筹码</option>
                                            </select>
                                            <input type="number" id="ptAmount_${u.id}" class="chat-input" style="width:80px;padding:4px 8px;font-size:12px;" placeholder="数量" value="100">
                                            <button class="btn-sm btn-primary" onclick="ChatX.adminAddPoints(${u.id}, ${attrEscape(u.username)})">增加</button>
                                            <button class="btn-sm btn-warning" onclick="ChatX.adminSetPoints(${u.id}, ${attrEscape(u.username)})">扣除</button>
                                        </td>
                                    </tr>`).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
        }

        function filterPoints(q) {
            q = q.trim().toLowerCase();
            document.querySelectorAll('#pointsTableBody tr').forEach(tr => {
                tr.style.display = (!q || (tr.dataset.username || '').toLowerCase().includes(q)) ? '' : 'none';
            });
        }

        async function loadUsers() {
            try {
                const data = await adminFetch('api/users.php?action=admin_users', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderUsers(data.users);
            } catch (e) {
                document.getElementById('userTableBody').innerHTML = '<tr><td colspan="7" style="text-align:center;color:red;">加载失败: ' + e.message + '</td></tr>';
            }
        }

        function renderUsers(users) {
            const tbody = document.getElementById('userTableBody');
            if (!users.length) {
                tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;">暂无用户</td></tr>';
                return;
            }
            const roleLabel = { user: '用户', admin: '管理员', super_admin: '超级管理员' };
            const roleBadge = { user: 'badge-user', admin: 'badge-admin', super_admin: 'badge-admin' };
            tbody.innerHTML = users.map(u => `
                <tr>
                    <td>${u.id}</td>
                    <td>${escapeHtml(u.username)}</td>
                    <td>${escapeHtml(u.nickname)}</td>
                    <td><span class="badge ${roleBadge[u.role] || 'badge-user'}">${roleLabel[u.role] || u.role}</span></td>
                    <td><span class="badge ${u.status === 'online' ? 'badge-online' : 'badge-offline'}">${u.status}</span></td>
                    <td>${u.last_seen || ''}</td>
                    <td>${u.created_at || ''}</td>
                    <td>
                        ${u.id != window.ChatX.user.id ? `
                            ${hasPermission('manage_roles') ? `
                                <select id="roleSelect_${u.id}" class="chat-input" style="width:auto;padding:4px 8px;font-size:12px;">
                                    <option value="user" ${u.role === 'user' ? 'selected' : ''}>用户</option>
                                    <option value="admin" ${u.role === 'admin' ? 'selected' : ''}>管理员</option>
                                    ${window.ChatX.role === 'super_admin' ? '<option value="super_admin" ' + (u.role === 'super_admin' ? 'selected' : '') + '>超级管理员</option>' : ''}
                                </select>
                                <button class="btn-sm btn-primary" onclick="ChatX.saveRole(${u.id})">保存</button>
                            ` : ''}
                            ${u.status === 'banned' ?
                                `<button class="btn-sm btn-primary" onclick="ChatX.unbanUser(${u.id})">解封</button>` :
                                `<button class="btn-sm btn-warning" onclick="ChatX.banUser(${u.id})">封禁</button>`
                            }
                            <button class="btn-sm btn-primary" onclick="ChatX.editUserProfilePrompt(${u.id}, ${attrEscape(u.nickname || '')}, ${attrEscape(u.signature || '')}, ${attrEscape(u.bio || '')})">编辑资料</button>
                            <button class="btn-sm btn-danger" onclick="ChatX.deleteUser(${u.id})" data-icon="delete">删除</button>
                        ` : '<span style="color:#999;font-size:12px;">当前账号</span>'}
                    </td>
                </tr>
            `).join('');
        }

        async function loadGroups() {
            try {
                const data = await adminFetch('api/users.php?action=admin_groups', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderGroups(data.groups || []);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderGroups(groups) {
            if (!groups.length) {
                document.getElementById('adminContent').innerHTML = '<div class="data-card"><h3>群组管理</h3><div style="text-align:center;color:#999;">暂无群组</div></div>';
                return;
            }
            const html = `
                <div class="data-card">
                    <div class="toolbar"><h3 style="flex:1;">群组管理</h3></div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>群名称</th><th>群主ID</th><th>成员数</th><th>最后消息</th><th>最后活跃</th><th>操作</th></tr></thead>
                            <tbody>
                                ${groups.map(g => `
                                    <tr>
                                        <td>${g.id}</td>
                                        <td>${escapeHtml(g.name)}</td>
                                        <td>${g.owner_id}</td>
                                        <td>${g.member_count || 0}</td>
                                        <td>${escapeHtml(g.last_message || '')}</td>
                                        <td>${g.last_time || ''}</td>
                                        <td>
                                            <button class="btn-sm btn-primary" onclick="ChatX.updateGroupPrompt(${g.id}, ${attrEscape(g.name)}, ${attrEscape(g.description || '')})">编辑</button>
                                            <button class="btn-sm btn-primary" onclick="ChatX.loadGroupMembers(${g.id})">成员管理</button>
                                            <button class="btn-sm btn-danger" onclick="ChatX.adminDeleteGroup(${g.id})" data-icon="delete">解散群组</button>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
        }

        window.ChatX.updateGroupPrompt = async function(groupId, name, description) {
            const newName = prompt('群组名称', name);
            if (newName === null) return;
            const trimmedName = newName.trim();
            if (!trimmedName) { alert('群组名称不能为空'); return; }
            const newDesc = prompt('群组描述', description || '');
            const isPrivate = confirm('是否设为私有群组？');
            try {
                const res = await adminFetch('api/users.php?action=admin_update_group', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ group_id: groupId, name: trimmedName, description: (newDesc || '').trim(), is_private: isPrivate ? 1 : 0 })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                loadGroups();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.loadGroupMembers = async function(groupId) {
            try {
                const data = await adminFetch('api/users.php?action=admin_group_members&group_id=' + groupId, {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderGroupMembers(groupId, data.members || []);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        };

        function renderGroupMembers(groupId, members) {
            const html = `
                <div class="data-card">
                    <div class="toolbar"><h3 style="flex:1;">群组成员</h3><button class="btn btn-primary" onclick="loadGroups()">返回群组列表</button></div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>用户名</th><th>昵称</th><th>角色</th><th>状态</th><th>禁言至</th><th>加入时间</th><th>操作</th></tr></thead>
                            <tbody>
                                ${members.map(m => `
                                    <tr>
                                        <td>${m.user_id}</td>
                                        <td>${escapeHtml(m.username)}</td>
                                        <td>${escapeHtml(m.nickname)}</td>
                                        <td><span class="badge ${m.role === 'owner' ? 'badge-admin' : 'badge-user'}">${m.role}</span></td>
                                        <td><span class="badge ${m.status === 'online' ? 'badge-online' : 'badge-offline'}">${m.status}</span></td>
                                        <td>${m.muted_until || ''}</td>
                                        <td>${m.joined_at || ''}</td>
                                        <td>
                                            ${m.role !== 'owner' ? `<button class="btn-sm btn-danger" onclick="ChatX.removeGroupMember(${groupId}, ${m.user_id})" data-icon="delete">移除</button>` : '群主'}
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
        }

        window.ChatX.removeGroupMember = async function(groupId, userId) {
            if (!confirm('确定移除该成员？')) return;
            try {
                const res = await adminFetch('api/users.php?action=admin_remove_group_member', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ group_id: groupId, user_id: userId })
                });
                if (res.error) throw new Error(res.error);
                ChatX.loadGroupMembers(groupId);
                loadGroups();
            } catch (e) { alert(e.message); }
        };

        async function loadFriendships() {
            try {
                const data = await adminFetch('api/users.php?action=admin_friendships', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderFriendships(data.friendships || []);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderFriendships(friendships) {
            if (!friendships.length) {
                document.getElementById('adminContent').innerHTML = '<div class="data-card"><h3>好友关系</h3><div style="text-align:center;color:#999;">暂无好友关系</div></div>';
                return;
            }
            const html = `
                <div class="data-card">
                    <div class="toolbar"><h3 style="flex:1;">好友关系</h3></div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>用户A</th><th>用户B</th><th>状态</th><th>创建时间</th><th>操作</th></tr></thead>
                            <tbody>
                                ${friendships.map(f => `
                                    <tr>
                                        <td>${f.id}</td>
                                        <td>${escapeHtml(f.user_nickname || f.user_name)}</td>
                                        <td>${escapeHtml(f.friend_nickname || f.friend_name)}</td>
                                        <td><span class="badge ${f.status === 'accepted' ? 'badge-online' : 'badge-offline'}">${f.status}</span></td>
                                        <td>${f.created_at || ''}</td>
                                        <td>
                                            ${f.status === 'pending' ? `
                                                <button class="btn-sm btn-primary" onclick="ChatX.approveFriendship(${f.id})">通过</button>
                                                <button class="btn-sm btn-warning" onclick="ChatX.rejectFriendship(${f.id})">拒绝</button>
                                            ` : `<button class="btn-sm btn-danger" onclick="ChatX.adminDeleteFriendship(${f.id})" data-icon="delete">删除关系</button>`}
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
        }

        async function loadMessages() {
            const keyword = document.getElementById('messageKeyword')?.value || '';
            try {
                const url = 'api/users.php?action=admin_messages&limit=200&offset=0' + (keyword ? '&keyword=' + encodeURIComponent(keyword) : '');
                const data = await adminFetch(url, {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderMessages(data.messages || [], data.total || 0);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderMessages(messages, total) {
            const html = `
                <div class="data-card">
                    <div class="toolbar">
                        <h3 style="flex:1;">消息记录</h3>
                        <input id="messageKeyword" class="chat-input" style="width:240px;" placeholder="搜索发送人/接收人/内容" value="${escapeHtml(document.getElementById('messageKeyword')?.value || '')}">
                        <button class="btn btn-primary" onclick="loadMessages()">搜索</button>
                    </div>
                    <div style="color:#666;font-size:12px;margin-bottom:8px;">共 ${total} 条消息</div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>发送人</th><th>接收人/群组</th><th>类型</th><th>内容</th><th>时间</th><th>状态</th><th>操作</th></tr></thead>
                            <tbody>
                                ${messages.map(m => `
                                    <tr>
                                        <td>${m.id}</td>
                                        <td>${escapeHtml(m.sender_name || ('#' + m.sender_id))}</td>
                                        <td>${escapeHtml(m.target_label || (m.group_name ? ('群组:' + m.group_name) : (m.receiver_name || ('#' + m.receiver_id))))}</td>
                                        <td>${escapeHtml(m.type || 'text')}</td>
                                        <td style="max-width:320px;word-break:break-all;">${escapeHtml(m.content || '')}</td>
                                        <td style="white-space:nowrap;">${escapeHtml(m.created_at || '')}</td>
                                        <td>${m.is_recall ? '<span class="badge badge-offline">已撤回</span>' : '<span class="badge badge-online">正常</span>'}</td>
                                        <td>
                                            <button class="btn-sm btn-warning" onclick="ChatX.recallMessage(${m.id})">撤回</button>
                                            <button class="btn-sm btn-danger" onclick="ChatX.deleteMessage(${m.id})" data-icon="delete">删除</button>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
        }

        window.ChatX.deleteMessage = async function(messageId) {
            if (!confirm('确定删除该消息？')) return;
            try {
                const res = await adminFetch('api/users.php?action=admin_delete_message', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ message_id: messageId })
                });
                if (res.error) throw new Error(res.error);
                loadMessages();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.recallMessage = async function(messageId) {
            if (!confirm('确定撤回该消息？')) return;
            try {
                const res = await adminFetch('api/users.php?action=admin_recall_message', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ message_id: messageId })
                });
                if (res.error) throw new Error(res.error);
                loadMessages();
            } catch (e) { alert(e.message); }
        };

        async function loadSettings() {
            try {
                const data = await adminFetch('api/users.php?action=admin_settings', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderSettings(data.settings || {});
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderSettings(settings) {
            const html = `
                <div class="data-card">
                    <div class="toolbar"><h3 style="flex:1;">系统设置</h3></div>
                    <div style="max-width:600px;">
                        <div class="form-group"><label>站点名称</label><input id="settingSiteName" class="chat-input" style="width:100%" value="${escapeHtml(settings.site_name || 'ChatX')}"></div>
                        <div class="form-group"><label>开放注册</label><input type="checkbox" id="settingAllowRegister" ${settings.allow_register ? 'checked' : ''}> 允许新用户注册</div>
                        <div class="form-group"><label>MySQL 版本</label><div style="padding:8px 0;color:#666;">${escapeHtml(settings.mysql_version || '')}</div></div>
                        <button class="btn btn-primary" style="width:100%;" onclick="ChatX.saveSettings()">保存设置</button>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
        }

        window.ChatX.saveSettings = async function() {
            const siteName = document.getElementById('settingSiteName')?.value || 'ChatX';
            const allowRegister = !!document.getElementById('settingAllowRegister')?.checked;
            try {
                const res = await adminFetch('api/users.php?action=admin_save_settings', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ site_name: siteName, allow_register: allowRegister ? 1 : 0 })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
            } catch (e) { alert(e.message); }
        };

        function escapeHtml(str) {
            if (!str) return '';
            return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        }

        window.ChatX.saveRole = async function(userId) {
            const select = document.getElementById('roleSelect_' + userId);
            if (!select) return;
            const newRole = select.value;
            if (!confirm('确定要将该用户角色设置为 ' + newRole + ' 吗？')) return;
            try {
                const res = await adminFetch('api/users.php?action=admin_set_role', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ user_id: userId, role: newRole })
                });
                if (res.error) throw new Error(res.error);
                loadUsers();
                loadStats();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.editUserProfilePrompt = async function(userId, nickname, signature, bio) {
            const newNickname = prompt('昵称', nickname);
            if (newNickname === null) return;
            const trimmedNickname = newNickname.trim();
            if (!trimmedNickname) { alert('昵称不能为空'); return; }
            const newSignature = prompt('签名', signature || '');
            const newBio = prompt('简介', bio || '');
            try {
                const res = await adminFetch('api/users.php?action=admin_update_user_profile', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ user_id: userId, nickname: trimmedNickname, signature: (newSignature || '').trim(), bio: (newBio || '').trim() })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                loadUsers();
                loadStats();
            } catch (e) { alert(e.message); }
        };

        window.filterPoints = filterPoints;

        window.ChatX.adminAddPoints = async function(userId, username) {
            await adminAdjustPoints(userId, username, 'add');
        };
        window.ChatX.adminSetPoints = async function(userId, username) {
            await adminAdjustPoints(userId, username, 'deduct');
        };

        async function adminAdjustPoints(userId, username, mode) {
            const currency = document.getElementById('ptCur_' + userId).value;
            const amount = parseInt(document.getElementById('ptAmount_' + userId).value) || 0;
            if (amount <= 0) { alert('请输入大于 0 的数量'); return; }
            const label = { points: '积分', gomoku: '五子币', casino: '筹码' }[currency];
            if (!confirm(`确认${mode === 'add' ? '增加' : '扣除'} ${username} 的 ${amount} ${label}？`)) return;
            try {
                const data = await adminFetch('api/casino.php?action=admin_adjust_points', {
                    method: 'POST',
                    headers: { 'X-Auth-Token': window.ChatX.token, 'Content-Type': 'application/json' },
                    body: JSON.stringify({ user_id: userId, currency, amount, mode })
                });
                if (data.error) { alert(data.error); return; }
                alert('操作成功');
                loadPoints();
            } catch (e) { alert('操作失败: ' + e.message); }
        }

        window.ChatX.savePermissions = async function(userId) {
            const checked = Array.from(document.querySelectorAll('.perm-check-' + userId + ':checked')).map(el => el.value);
            try {
                const res = await adminFetch('api/users.php?action=admin_save_permissions', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ user_id: userId, permissions: checked })
                });
                if (res.error) throw new Error(res.error);
                alert('权限已保存');
            } catch (e) { alert(e.message); }
        };

        window.ChatX.applyPreset = async function(userId) {
            const select = document.getElementById('presetSelect_' + userId);
            const preset = select ? select.value : '';
            if (!preset) { alert('请选择预设'); return; }
            try {
                const res = await adminFetch('api/users.php?action=admin_apply_preset', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ user_id: userId, preset })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                loadRoles();
            } catch (e) { alert(e.message); }
        };


        async function loadFeedbacks() {
            try {
                const data = await adminFetch('api/users.php?action=admin_feedbacks', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderFeedbacks(data.feedbacks || []);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderFeedbacks(feedbacks) {
            const html = `
                <div class="data-card">
                    <div class="toolbar"><h3 style="flex:1;">用户反馈</h3></div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>用户</th><th>类型</th><th>内容</th><th>状态</th><th>回复</th><th>时间</th><th>操作</th></tr></thead>
                            <tbody>
                                ${feedbacks.map(f => `
                                    <tr>
                                        <td>${f.id}</td>
                                        <td>${escapeHtml(f.nickname || f.username)}</td>
                                        <td><span class="badge badge-user">${f.type}</span></td>
                                        <td style="max-width:320px;word-break:break-all;">${escapeHtml(f.content)}</td>
                                        <td><span class="badge ${f.status === 'pending' ? 'badge-offline' : 'badge-online'}">${f.status}</span></td>
                                        <td style="max-width:260px;word-break:break-all;">${escapeHtml(f.reply || '')}</td>
                                        <td>${f.created_at || ''}</td>
                                        <td>
                                            <button class="btn-sm btn-primary" onclick="ChatX.replyFeedback(${f.id})">回复</button>
                                            <select onchange="ChatX.updateFeedbackStatus(${f.id}, this.value)" class="chat-input" style="width:auto;padding:4px 8px;font-size:12px;">
                                                <option value="pending" ${f.status === 'pending' ? 'selected' : ''}>待处理</option>
                                                <option value="processing" ${f.status === 'processing' ? 'selected' : ''}>处理中</option>
                                                <option value="resolved" ${f.status === 'resolved' ? 'selected' : ''}>已解决</option>
                                                <option value="closed" ${f.status === 'closed' ? 'selected' : ''}>已关闭</option>
                                            </select>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
        }

        window.ChatX.replyFeedback = async function(id) {
            const reply = prompt('请输入回复内容：');
            if (!reply) return;
            const status = confirm('是否将状态标记为已解决？') ? 'resolved' : 'processing';
            try {
                const res = await adminFetch('api/users.php?action=admin_reply_feedback', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ id, reply, status })
                });
                if (res.error) throw new Error(res.error);
                loadFeedbacks();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.updateFeedbackStatus = async function(id, status) {
            try {
                const res = await adminFetch('api/users.php?action=admin_update_feedback_status', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ id, status })
                });
                if (res.error) throw new Error(res.error);
                loadFeedbacks();
            } catch (e) { alert(e.message); }
        };

        async function loadSensitiveWords() {
            try {
                const data = await adminFetch('api/users.php?action=admin_sensitive_words', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderSensitiveWords(data.words || []);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderSensitiveWords(words) {
            const html = `
                <div class="data-card">
                    <div class="toolbar">
                        <h3 style="flex:1;">敏感词</h3>
                        <input id="sensitiveWordInput" class="chat-input" style="width:180px;" placeholder="输入敏感词">
                        <input id="sensitiveWordCategory" class="chat-input" style="width:120px;" placeholder="分类(可选)">
                        <button class="btn btn-primary" onclick="ChatX.addSensitiveWord()">添加</button>
                        <textarea id="sensitiveWordBatch" class="chat-input" style="width:220px;height:60px;" placeholder="批量导入，每行一个词"></textarea>
                        <button class="btn btn-primary" onclick="ChatX.importSensitiveWords()">批量导入</button>
                    </div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>敏感词</th><th>分类</th><th>添加人</th><th>时间</th><th>操作</th></tr></thead>
                            <tbody>
                                ${words.map(w => `
                                    <tr>
                                        <td>${w.id}</td>
                                        <td>${escapeHtml(w.word)}</td>
                                        <td><span class="badge badge-user">${escapeHtml(w.category)}</span></td>
                                        <td>${escapeHtml(w.creator)}</td>
                                        <td>${w.created_at || ''}</td>
                                        <td><button class="btn-sm btn-danger" onclick="ChatX.deleteSensitiveWord(${w.id})" data-icon="delete">删除</button></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
        }

        window.ChatX.addSensitiveWord = async function() {
            const word = document.getElementById('sensitiveWordInput')?.value || '';
            const category = document.getElementById('sensitiveWordCategory')?.value || 'custom';
            if (!word.trim()) { alert('请输入敏感词'); return; }
            try {
                const res = await adminFetch('api/users.php?action=admin_add_sensitive_word', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ word: word.trim(), category: category.trim() || 'custom' })
                });
                if (res.error) throw new Error(res.error);
                document.getElementById('sensitiveWordInput').value = '';
                loadSensitiveWords();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.deleteSensitiveWord = async function(id) {
            if (!confirm('确定删除该敏感词？')) return;
            try {
                const res = await adminFetch('api/users.php?action=admin_delete_sensitive_word', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ id })
                });
                if (res.error) throw new Error(res.error);
                loadSensitiveWords();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.importSensitiveWords = async function() {
            const words = document.getElementById('sensitiveWordBatch')?.value || '';
            const category = document.getElementById('sensitiveWordCategory')?.value || 'custom';
            if (!words.trim()) { alert('请输入敏感词'); return; }
            try {
                const res = await adminFetch('api/users.php?action=admin_import_sensitive_words', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ words, category: category.trim() || 'custom' })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                document.getElementById('sensitiveWordBatch').value = '';
                loadSensitiveWords();
            } catch (e) { alert(e.message); }
        };

        async function loadLoginLogs() {
            try {
                const data = await adminFetch('api/users.php?action=admin_login_logs', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderLoginLogs(data.logs || []);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderLoginLogs(logs) {
            const html = `
                <div class="data-card">
                    <div class="toolbar"><h3 style="flex:1;">登录日志</h3></div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>用户</th><th>IP</th><th>User-Agent</th><th>状态</th><th>时间</th></tr></thead>
                            <tbody>
                                ${logs.map(log => `
                                    <tr>
                                        <td>${log.id}</td>
                                        <td>${escapeHtml(log.username)}</td>
                                        <td>${escapeHtml(log.ip || '')}</td>
                                        <td style="max-width:260px;word-break:break-all;">${escapeHtml(log.user_agent || '')}</td>
                                        <td><span class="badge ${log.status === 'success' ? 'badge-online' : 'badge-offline'}">${log.status}</span></td>
                                        <td>${log.created_at || ''}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
        }

        async function loadSessions() {
            try {
                const data = await adminFetch('api/users.php?action=admin_sessions', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderSessions(data.sessions || []);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderSessions(sessions) {
            const html = `
                <div class="data-card">
                    <div class="toolbar"><h3 style="flex:1;">会话管理</h3></div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>用户</th><th>IP</th><th>User-Agent</th><th>最后活动</th><th>过期时间</th><th>操作</th></tr></thead>
                            <tbody>
                                ${sessions.map(s => `
                                    <tr>
                                        <td>${s.id}</td>
                                        <td>${escapeHtml(s.nickname || s.username)}</td>
                                        <td>${escapeHtml(s.ip || '')}</td>
                                        <td style="max-width:260px;word-break:break-all;">${escapeHtml(s.user_agent || '')}</td>
                                        <td>${s.last_activity || ''}</td>
                                        <td>${s.expires_at || ''}</td>
                                        <td><button class="btn-sm btn-danger" onclick="ChatX.kickSession(${s.id})" data-icon="delete">踢下线</button></td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
        }

        window.ChatX.kickSession = async function(sessionId) {
            if (!confirm('确定踢掉该会话？')) return;
            try {
                const res = await adminFetch('api/users.php?action=admin_kick_session', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ session_id: sessionId })
                });
                if (res.error) throw new Error(res.error);
                loadSessions();
            } catch (e) { alert(e.message); }
        };

        async function loadReports() {
            try {
                const data = await adminFetch('api/users.php?action=admin_reports', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderReports(data.stats || {}, data.daily || []);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderReports(stats, daily) {
            const html = `
                <div class="data-card">
                    <div class="toolbar">
                        <h3 style="flex:1;">数据统计</h3>
                        <select id="exportType" class="chat-input" style="width:auto;padding:4px 8px;font-size:12px;">
                            <option value="users">用户</option>
                            <option value="groups">群组</option>
                            <option value="messages">消息</option>
                            <option value="feedbacks">反馈</option>
                        </select>
                        <button class="btn btn-primary" onclick="ChatX.exportData()">导出 CSV</button>
                    </div>
                    <div class="stats-grid">
                        <div class="stat-card"><div class="num">${stats.users || 0}</div><div class="label">总用户数</div></div>
                        <div class="stat-card"><div class="num">${stats.groups || 0}</div><div class="label">群组数</div></div>
                        <div class="stat-card"><div class="num">${stats.messages || 0}</div><div class="label">消息数</div></div>
                        <div class="stat-card"><div class="num">${stats.online || 0}</div><div class="label">在线用户</div></div>
                        <div class="stat-card"><div class="num">${stats.friendships || 0}</div><div class="label">好友关系</div></div>
                        <div class="stat-card"><div class="num">${stats.feedbacks || 0}</div><div class="label">反馈数</div></div>
                        <div class="stat-card"><div class="num">${stats.pending_feedbacks || 0}</div><div class="label">待处理反馈</div></div>
                        <div class="stat-card"><div class="num">${stats.sensitive_words || 0}</div><div class="label">敏感词数</div></div>
                        <div class="stat-card"><div class="num">${stats.active_sessions || 0}</div><div class="label">活跃会话</div></div>
                        <div class="stat-card"><div class="num">${stats.forum_posts || 0}</div><div class="label">论坛文章</div></div>
                        <div class="stat-card"><div class="num">${stats.forum_comments || 0}</div><div class="label">论坛评论</div></div>
                    </div>
                    <div class="data-card" style="margin-top:16px;">
                        <h3>近7日消息趋势</h3>
                        <div style="display:flex;align-items:flex-end;gap:8px;height:160px;margin-top:12px;">
                            ${daily.map(d => `
                                <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px;">
                                    <div style="width:100%;background:var(--primary);border-radius:6px;height:${Math.max(4, (d.messages || 0))}px;min-height:4px;opacity:0.85;"></div>
                                    <div style="font-size:10px;color:var(--text-secondary);transform:rotate(-25deg);transform-origin:center;">${d.date}</div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
        }

        window.ChatX.deleteUser = async function(userId) {
            if (!confirm('确定删除该用户？此操作不可恢复。')) return;
            try {
                const res = await adminFetch('api/users.php?action=admin_delete_user', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ user_id: userId })
                });
                if (res.error) throw new Error(res.error);
                loadUsers();
                loadStats();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.exportData = async function() {
            const type = document.getElementById('exportType')?.value || 'users';
            try {
                const res = await adminFetch('api/users.php?action=admin_export&type=' + encodeURIComponent(type) + '&format=csv', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (!res.ok) {
                    const data = await res.json().catch(() => ({}));
                    if (data.error) throw new Error(data.error);
                    throw new Error('导出失败');
                }
                const blob = await res.blob();
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = type + '.csv';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            } catch (e) { alert(e.message); }
        };

        window.ChatX.banUser = async function(userId) {
            const days = prompt('封禁天数（7）：', '7');
            if (days === null) return;
            const num = parseInt(days, 10);
            if (isNaN(num) || num <= 0) { alert('请输入有效天数'); return; }
            try {
                const res = await adminFetch('api/users.php?action=admin_ban_user', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ user_id: userId, days: num })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                loadUsers();
                loadStats();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.unbanUser = async function(userId) {
            if (!confirm('确定解封该用户？')) return;
            try {
                const res = await adminFetch('api/users.php?action=admin_unban_user', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ user_id: userId })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                loadUsers();
                loadStats();
            } catch (e) { alert(e.message); }
        };

        async function loadRoles() {
            try {
                const data = await adminFetch('api/users.php?action=admin_roles', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderRoles(data.users || [], data.permissions || {}, data.presets || [], data.presetMap || {});
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderRoles(users, permissions, presets, presetMap) {
            const html = `
                <div class="data-card">
                    <div class="toolbar"><h3 style="flex:1;">角色权限</h3></div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>用户名</th><th>昵称</th><th>角色</th><th>权限配置</th></tr></thead>
                            <tbody>
                                ${users.map(u => `
                                    <tr>
                                        <td>${u.id}</td>
                                        <td>${escapeHtml(u.username)}</td>
                                        <td>${escapeHtml(u.nickname)}</td>
                                        <td><span class="badge ${u.role === 'super_admin' ? 'badge-admin' : (u.role === 'admin' ? 'badge-admin' : 'badge-user')}">${u.role}</span></td>
                                        <td>
                                            ${u.role === 'admin' ? `
                                                <div style="margin-bottom:8px;">
                                                    <select id="presetSelect_${u.id}" class="chat-input" style="width:auto;padding:4px 8px;font-size:12px;">
                                                        <option value="">选择预设...</option>
                                                        ${(presets || []).map(p => `<option value="${escapeHtml(p[0])}">${escapeHtml(p[1])}</option>`).join('')}
                                                    </select>
                                                    <button class="btn-sm btn-primary" onclick="ChatX.applyPreset(${u.id})">应用预设</button>
                                                </div>
                                                ${Object.entries(permissions).map(([category, perms]) => `
                                                <div style="margin-bottom:10px;">
                                                    <div style="font-weight:600;font-size:12px;color:var(--text-secondary);margin-bottom:4px;">${escapeHtml(category)}</div>
                                                    <div style="display:flex;flex-wrap:wrap;gap:8px 16px;">
                                                        ${Object.entries(perms).map(([key, label]) => `
                                                            <label style="font-size:12px;">
                                                                <input type="checkbox" class="perm-check-${u.id}" value="${escapeHtml(key)}" onclick="ChatX.savePermissions(${u.id})"> ${escapeHtml(label)}
                                                            </label>
                                                        `).join('')}
                                                    </div>
                                                </div>
                                            `).join('')}
                                            ` : (u.role === 'super_admin' ? '<span style="color:#999;font-size:12px;">超级管理员拥有全部权限</span>' : '<span style="color:#999;font-size:12px;">普通用户无后台权限</span>')}
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
            if (window.ChatX.role === 'super_admin') {
                const promises = users
                    .filter(u => u.role === 'admin')
                    .map(u => adminFetch('api/users.php?action=admin_permissions&user_id=' + u.id, {
                        headers: { 'X-Auth-Token': window.ChatX.token }
                    }).then(data => ({ userId: u.id, permissions: data.permissions || [] })));
                Promise.all(promises).then(results => {
                    results.forEach(({ userId, permissions }) => {
                        permissions.forEach(pid => {
                            const el = document.querySelector('.perm-check-' + userId + '[value="' + pid + '"]');
                            if (el) el.checked = true;
                        });
                    });
                }).catch(() => {});
            }
        }

        async function loadAnnouncements() {
            try {
                const data = await adminFetch('api/users.php?action=admin_announcements', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderAnnouncements(data.announcements || []);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderAnnouncements(announcements) {
            const html = `
                <div class="data-card">
                    <div class="toolbar">
                        <h3 style="flex:1;">公告管理</h3>
                        <input id="announcementTitle" class="chat-input" style="width:220px;" placeholder="公告标题">
                        <textarea id="announcementContent" class="chat-input" style="width:260px;height:60px;" placeholder="公告内容"></textarea>
                        <button class="btn btn-primary" onclick="ChatX.createAnnouncement()">发布公告</button>
                    </div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>标题</th><th>内容</th><th>发布时间</th><th>操作</th></tr></thead>
                            <tbody>
                                ${announcements.map(a => `
                                    <tr>
                                        <td>${a.id}</td>
                                        <td>${escapeHtml(a.title)}</td>
                                        <td style="max-width:320px;word-break:break-all;">${escapeHtml(a.content)}</td>
                                        <td>${a.created_at || ''}</td>
                                        <td>
                                            <button class="btn-sm btn-primary" onclick="ChatX.editAnnouncementPrompt(${a.id}, ${attrEscape(a.title)}, ${attrEscape(a.content)})">编辑</button>
                                            <button class="btn-sm btn-danger" onclick="ChatX.deleteAnnouncement(${a.id})" data-icon="delete">删除</button>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
        }

        window.ChatX.createAnnouncement = async function() {
            const title = document.getElementById('announcementTitle')?.value || '';
            const content = document.getElementById('announcementContent')?.value || '';
            if (!title.trim() || !content.trim()) {
                alert('请填写标题和内容');
                return;
            }
            try {
                const res = await adminFetch('api/users.php?action=admin_create_announcement', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ title: title.trim(), content: content.trim() })
                });
                if (res.error) throw new Error(res.error);
                document.getElementById('announcementTitle').value = '';
                document.getElementById('announcementContent').value = '';
                loadAnnouncements();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.deleteAnnouncement = async function(id) {
            if (!confirm('确定删除该公告？')) return;
            try {
                const res = await adminFetch('api/users.php?action=admin_delete_announcement', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ id })
                });
                if (res.error) throw new Error(res.error);
                loadAnnouncements();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.editAnnouncementPrompt = async function(id, title, content) {
            const newTitle = prompt('公告标题', title);
            if (newTitle === null) return;
            const trimmedTitle = newTitle.trim();
            if (!trimmedTitle) { alert('标题不能为空'); return; }
            const newContent = prompt('公告内容', content);
            if (newContent === null) return;
            const trimmedContent = newContent.trim();
            if (!trimmedContent) { alert('内容不能为空'); return; }
            try {
                const res = await adminFetch('api/users.php?action=admin_update_announcement', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ id, title: trimmedTitle, content: trimmedContent })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                loadAnnouncements();
            } catch (e) { alert(e.message); }
        };

        async function loadLogs() {
            try {
                const data = await adminFetch('api/users.php?action=admin_logs', {
                    headers: { 'X-Auth-Token': window.ChatX.token }
                });
                if (data.error) throw new Error(data.error);
                renderLogs(data.logs || []);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderLogs(logs) {
            const html = `
                <div class="data-card">
                    <div class="toolbar"><h3 style="flex:1;">系统日志</h3></div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>发送人</th><th>群组</th><th>内容</th><th>时间</th></tr></thead>
                            <tbody>
                                ${logs.map(log => `
                                    <tr>
                                        <td>${log.id}</td>
                                        <td>${escapeHtml(log.sender_name || '系统')}</td>
                                        <td>${escapeHtml(log.group_name || '')}</td>
                                        <td style="max-width:360px;word-break:break-all;">${escapeHtml(log.content || '')}</td>
                                        <td style="white-space:nowrap;">${escapeHtml(log.created_at || '')}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            `;
            document.getElementById('adminContent').innerHTML = html;
        }

        // ============ 论坛管理 ============
        let forumSubTab = 'posts';

        async function loadForum() {
            try {
                const [statsData, categoriesData] = await Promise.all([
                    adminFetch('api/forum.php?action=admin_stats', { headers: { 'X-Auth-Token': window.ChatX.token } }),
                    adminFetch('api/forum.php?action=admin_categories', { headers: { 'X-Auth-Token': window.ChatX.token } })
                ]);
                if (statsData.error) throw new Error(statsData.error);
                renderForum(statsData.stats, categoriesData.categories || []);
            } catch (e) {
                document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red">加载失败: ' + e.message + '</div>';
            }
        }

        function renderForum(stats, categories) {
            document.getElementById('adminContent').innerHTML = `
                <div class="stats-grid">
                    <div class="stat-card"><div class="num">${stats.posts || 0}</div><div class="label">总文章数</div></div>
                    <div class="stat-card"><div class="num">${stats.comments || 0}</div><div class="label">总评论数</div></div>
                    <div class="stat-card"><div class="num">${stats.categories || 0}</div><div class="label">分类数</div></div>
                    <div class="stat-card"><div class="num">${stats.tags || 0}</div><div class="label">标签数</div></div>
                    <div class="stat-card"><div class="num">${stats.pinned || 0}</div><div class="label">已置顶</div></div>
                    <div class="stat-card"><div class="num">${stats.archived || 0}</div><div class="label">已归档</div></div>
                    <div class="stat-card"><div class="num">${(stats.total_reactions || 0).toLocaleString()}</div><div class="label">总反应数</div></div>
                    <div class="stat-card"><div class="num">${stats.posts_today || 0}</div><div class="label">今日发文</div></div>
                    <div class="stat-card"><div class="num">${stats.posts_week || 0}</div><div class="label">近7日发文</div></div>
                </div>
                <div class="tabs" style="margin-top:16px;">
                    <div class="tab ${forumSubTab === 'posts' ? 'active' : ''}" onclick="ChatX.forumSubTab('posts')">文章管理</div>
                    <div class="tab ${forumSubTab === 'comments' ? 'active' : ''}" onclick="ChatX.forumSubTab('comments')">评论管理</div>
                    <div class="tab ${forumSubTab === 'categories' ? 'active' : ''}" onclick="ChatX.forumSubTab('categories')">分类管理</div>
                    <div class="tab ${forumSubTab === 'tags' ? 'active' : ''}" onclick="ChatX.forumSubTab('tags')">标签管理</div>
                    <div class="tab ${forumSubTab === 'reports' ? 'active' : ''}" onclick="ChatX.forumSubTab('reports')">举报管理</div>
                    <div class="tab ${forumSubTab === 'analytics' ? 'active' : ''}" onclick="ChatX.forumSubTab('analytics')">数据分析</div>
                </div>
                <div id="forumSubContent"></div>
            `;
            ChatX.renderForumSubTab();
        }

        window.ChatX.forumSubTab = function(tab) {
            forumSubTab = tab;
            document.querySelectorAll('#adminContent .tabs .tab').forEach(t => t.classList.remove('active'));
            event.target.classList.add('active');
            ChatX.renderForumSubTab();
        };

        window.ChatX.renderForumSubTab = function() {
            const container = document.getElementById('forumSubContent');
            if (!container) return;
            if (forumSubTab === 'posts') ChatX.renderForumPosts(container);
            else if (forumSubTab === 'comments') ChatX.renderForumComments(container);
            else if (forumSubTab === 'categories') ChatX.renderForumCategories(container);
            else if (forumSubTab === 'tags') ChatX.renderForumTags(container);
            else if (forumSubTab === 'reports') ChatX.renderForumReports(container);
            else if (forumSubTab === 'analytics') ChatX.renderForumAnalytics(container);
        };

        window.ChatX.renderForumPosts = async function(container) {
            container.innerHTML = '<div class="loading">加载中...</div>';
            try {
                let url = 'api/forum.php?action=admin_posts&page=1';
                if (ChatX._forumPostsFilter) url += '&filter=' + ChatX._forumPostsFilter;
                const data = await adminFetch(url, { headers: { 'X-Auth-Token': window.ChatX.token } });
                if (data.error) throw new Error(data.error);
                ChatX._forumPostsData = data;
                ChatX._forumPostsPage = 1;
                ChatX._renderForumPostsTable(container, data);
            } catch (e) {
                container.innerHTML = '<div style="color:red;">加载失败: ' + e.message + '</div>';
            }
        };

        window.ChatX._renderForumPostsTable = function(container, data) {
            const posts = data.posts || [];
            const filter = ChatX._forumPostsFilter || '';
            container.innerHTML = `
                <div class="data-card">
                    <div class="toolbar">
                        <h3 style="flex:1;">文章管理 (${data.total})</h3>
                        <select class="chat-input" style="width:110px;" onchange="ChatX._forumPostsFilter=this.value;ChatX.searchForumPosts(1)">
                            <option value="">全部状态</option>
                            <option value="pinned" ${filter === 'pinned' ? 'selected' : ''}>已置顶</option>
                            <option value="archived" ${filter === 'archived' ? 'selected' : ''}>已归档</option>
                        </select>
                        <input id="forumPostSearch" class="chat-input" style="width:200px;" placeholder="搜索标题/作者/内容" onkeydown="if(event.key==='Enter')ChatX.searchForumPosts(1)">
                        <button class="btn btn-primary" onclick="ChatX.searchForumPosts(1)">搜索</button>
                    </div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th></th><th>ID</th><th>标题</th><th>作者</th><th>分类</th><th>标签</th><th>浏览</th><th>反应</th><th>回复</th><th>状态</th><th>时间</th><th>操作</th></tr></thead>
                            <tbody>
                                ${posts.map(p => `
                                    <tr>
                                        <td><input type="checkbox" class="post-checkbox" value="${p.id}" onchange="ChatX._toggleBulkSelect()"></td>
                                        <td>${p.id}</td>
                                        <td style="max-width:200px;word-break:break-all;"><a href="forum.php?post=${p.id}" target="_blank" style="color:var(--primary);text-decoration:none;">${escapeHtml(p.title)}</a></td>
                                        <td>${escapeHtml(p.nickname || p.username)}</td>
                                        <td><span class="badge badge-user">${escapeHtml(p.category_name || '')}</span></td>
                                        <td style="max-width:120px;font-size:12px;">${escapeHtml(p.tag_names || '—')}</td>
                                        <td>${p.view_count || 0}</td>
                                        <td>${p.reaction_count || p.likes_count || 0}</td>
                                        <td>${p.replies_count}</td>
                                        <td>${p.is_pinned ? '<span class="badge badge-online">置顶</span>' : ''} ${p.is_archived ? '<span class="badge" style="background:#6b7280;color:#fff;">归档</span>' : ''}</td>
                                        <td>${p.created_at || ''}</td>
                                        <td>
                                            <button class="btn-sm btn-primary" onclick="ChatX.adminTogglePin(${p.id}, ${!!p.is_pinned})">${p.is_pinned ? '取消置顶' : '置顶'}</button>
                                            <button class="btn-sm btn-primary" onclick="ChatX.adminToggleArchive(${p.id}, ${!!p.is_archived})">${p.is_archived ? '取消归档' : '归档'}</button>
                                            <button class="btn-sm btn-primary" onclick="ChatX.adminEditPostPrompt(${p.id}, ${attrEscape(p.title)}, ${attrEscape(p.content)})">编辑</button>
                                            <button class="btn-sm btn-danger" onclick="ChatX.adminDeletePost(${p.id})">删除</button>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px;">
                        <div style="display:flex;gap:8px;">
                            <button class="btn btn-sm btn-primary" onclick="ChatX.bulkSelectAll()" id="bulkSelectAllBtn">全选</button>
                            <button class="btn btn-sm btn-primary" onclick="ChatX.bulkArchive()" disabled id="bulkArchiveBtn">批量归档</button>
                            <button class="btn btn-sm btn-danger" onclick="ChatX.bulkDelete()" disabled id="bulkDeleteBtn">批量删除</button>
                        </div>
                        <div style="display:flex;justify-content:center;gap:8px;">
                            <button class="btn btn-sm btn-primary" ${data.page <= 1 ? 'disabled' : ''} onclick="ChatX.searchForumPosts(${data.page - 1})">上一页</button>
                            <span style="padding:8px;font-size:13px;color:var(--text-secondary);">第 ${data.page} / ${data.pages} 页</span>
                            <button class="btn btn-sm btn-primary" ${data.page >= data.pages ? 'disabled' : ''} onclick="ChatX.searchForumPosts(${data.page + 1})">下一页</button>
                        </div>
                    </div>
                </div>
            `;
        };

        window.ChatX._forumPostsFilter = '';
        window.ChatX._reportFilter = '';

        window.ChatX.searchForumPosts = async function(page) {
            const keyword = document.getElementById('forumPostSearch')?.value || '';
            const filter = ChatX._forumPostsFilter || '';
            const container = document.getElementById('forumSubContent');
            container.innerHTML = '<div class="loading">加载中...</div>';
            try {
                let url = 'api/forum.php?action=admin_posts&page=' + page + (keyword ? '&search=' + encodeURIComponent(keyword) : '');
                if (filter) url += '&filter=' + filter;
                const data = await adminFetch(url, { headers: { 'X-Auth-Token': window.ChatX.token } });
                if (data.error) throw new Error(data.error);
                ChatX._renderForumPostsTable(container, data);
            } catch (e) {
                container.innerHTML = '<div style="color:red;">加载失败: ' + e.message + '</div>';
            }
        };

        window.ChatX._toggleBulkSelect = function() {
            const checked = document.querySelectorAll('.post-checkbox:checked').length;
            document.getElementById('bulkArchiveBtn').disabled = checked === 0;
            document.getElementById('bulkDeleteBtn').disabled = checked === 0;
        };

        window.ChatX.bulkSelectAll = function() {
            const checkboxes = document.querySelectorAll('.post-checkbox');
            const allChecked = Array.from(checkboxes).every(cb => cb.checked);
            checkboxes.forEach(cb => cb.checked = !allChecked);
            ChatX._toggleBulkSelect();
        };

        window.ChatX.bulkArchive = async function() {
            const ids = Array.from(document.querySelectorAll('.post-checkbox:checked')).map(cb => parseInt(cb.value));
            if (ids.length === 0) return;
            if (!confirm('确定批量归档选中的 ' + ids.length + ' 篇文章？')) return;
            try {
                for (const id of ids) {
                    await adminFetch('api/forum.php?action=toggle_archive', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                        body: JSON.stringify({ post_id: id })
                    });
                }
                alert('批量归档完成');
                ChatX.searchForumPosts(1);
            } catch (e) { alert('部分操作失败: ' + e.message); ChatX.searchForumPosts(1); }
        };

        window.ChatX.bulkDelete = async function() {
            const ids = Array.from(document.querySelectorAll('.post-checkbox:checked')).map(cb => parseInt(cb.value));
            if (ids.length === 0) return;
            if (!confirm('确定批量删除选中的 ' + ids.length + ' 篇文章？此操作不可恢复。')) return;
            try {
                for (const id of ids) {
                    await adminFetch('api/forum.php?action=delete_post', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                        body: JSON.stringify({ post_id: id })
                    });
                }
                alert('批量删除完成');
                ChatX.searchForumPosts(1);
            } catch (e) { alert('部分操作失败: ' + e.message); ChatX.searchForumPosts(1); }
        };

        window.ChatX.adminTogglePin = async function(postId, currentlyPinned) {
            if (!confirm(currentlyPinned ? '确定取消置顶？' : '确定置顶该文章？')) return;
            try {
                const res = await adminFetch('api/forum.php?action=admin_toggle_pin', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ post_id: postId })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                ChatX.renderForumSubTab();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.adminEditPostPrompt = async function(postId, title, content) {
            const newTitle = prompt('文章标题', title);
            if (newTitle === null) return;
            if (!newTitle.trim()) { alert('标题不能为空'); return; }
            const newContent = prompt('文章内容（请输入新内容，取消则不改）', '');
            try {
                const body = { post_id: postId, title: newTitle.trim() };
                if (newContent && newContent.trim()) body.content = newContent.trim();
                const res = await adminFetch('api/forum.php?action=admin_edit_post', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify(body)
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                ChatX.renderForumSubTab();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.adminDeletePost = async function(postId) {
            if (!confirm('确定删除该文章及其所有评论？此操作不可恢复。')) return;
            try {
                const res = await adminFetch('api/forum.php?action=delete_post', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ post_id: postId })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                ChatX.renderForumSubTab();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.adminToggleArchive = async function(postId, currentlyArchived) {
            if (!confirm(currentlyArchived ? '确定取消归档？' : '确定归档该文章？归档后不再接受评论。')) return;
            try {
                const res = await adminFetch('api/forum.php?action=toggle_archive', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ post_id: postId })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                ChatX.renderForumSubTab();
            } catch (e) { alert(e.message); }
        };

        // ============ 标签管理 ============
        window.ChatX.renderForumTags = async function(container) {
            container.innerHTML = '<div class="loading">加载中...</div>';
            try {
                const data = await adminFetch('api/forum.php?action=tags', { headers: { 'X-Auth-Token': window.ChatX.token } });
                if (data.error) throw new Error(data.error);
                const tags = data.tags || [];
                container.innerHTML = `
                    <div class="data-card">
                        <div class="toolbar">
                            <h3 style="flex:1;">标签管理 (${tags.length})</h3>
                            <input id="tagNewColor" type="color" style="width:40px;height:36px;cursor:pointer;border:none;" value="#667eea">
                            <input id="tagNewName" class="chat-input" style="width:140px;" placeholder="标签名称">
                            <input id="tagNewSort" class="chat-input" style="width:70px;" placeholder="排序" type="number" value="0">
                            <button class="btn btn-primary" onclick="ChatX.adminCreateTag()">添加标签</button>
                        </div>
                        <div style="overflow-x:auto;">
                            <table>
                                <thead><tr><th>ID</th><th>颜色</th><th>名称</th><th>文章数</th><th>排序</th><th>操作</th></tr></thead>
                                <tbody>
                                    ${tags.map(t => `
                                        <tr>
                                            <td>${t.id}</td>
                                            <td><span style="display:inline-block;width:20px;height:20px;border-radius:50%;background:${t.color || '#667eea'};vertical-align:middle;"></span></td>
                                            <td>${escapeHtml(t.name)}</td>
                                            <td>${t.post_count || 0}</td>
                                            <td>${t.sort_order}</td>
                                            <td>
                                                <button class="btn-sm btn-primary" onclick="ChatX.adminDeleteTag(${t.id})">删除</button>
                                            </td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                `;
            } catch (e) {
                container.innerHTML = '<div style="color:red;">加载失败: ' + e.message + '</div>';
            }
        };

        window.ChatX.adminCreateTag = async function() {
            const name = document.getElementById('tagNewName')?.value || '';
            const color = document.getElementById('tagNewColor')?.value || '#667eea';
            const sort_order = parseInt(document.getElementById('tagNewSort')?.value) || 0;
            if (!name.trim()) { alert('请输入标签名称'); return; }
            try {
                const res = await adminFetch('api/forum.php?action=admin_create_tag', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ name: name.trim(), color, sort_order })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                ChatX.renderForumSubTab();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.adminDeleteTag = async function(tagId) {
            if (!confirm('确定删除该标签？如被文章使用则无法删除。')) return;
            try {
                const res = await adminFetch('api/forum.php?action=admin_delete_tag', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ tag_id: tagId })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                ChatX.renderForumSubTab();
            } catch (e) { alert(e.message); }
        };

        // ============ 举报管理 ============
        window.ChatX.renderForumReports = async function(container) {
            container.innerHTML = '<div class="loading">加载中...</div>';
            try {
                const data = await adminFetch('api/forum.php?action=admin_reports&page=1', { headers: { 'X-Auth-Token': window.ChatX.token } });
                if (data.error) throw new Error(data.error);
                ChatX._renderForumReportsTable(container, data);
            } catch (e) {
                container.innerHTML = '<div style="color:red;">加载失败: ' + e.message + '</div>';
            }
        };

        window.ChatX._renderForumReportsTable = function(container, data) {
            const reports = data.reports || [];
            container.innerHTML = `
                <div class="data-card">
                    <div class="toolbar">
                        <h3 style="flex:1;">举报管理 (${data.total})</h3>
                        <select class="chat-input" style="width:120px;" onchange="ChatX._reportFilter=this.value;ChatX.loadForumReports(ChatX._reportFilter||'', 1)">
                            <option value="" ${(ChatX._reportFilter||'') === '' ? 'selected' : ''}>全部状态</option>
                            <option value="pending" ${ChatX._reportFilter === 'pending' ? 'selected' : ''}>待处理</option>
                            <option value="resolved" ${ChatX._reportFilter === 'resolved' ? 'selected' : ''}>已处理</option>
                            <option value="dismissed" ${ChatX._reportFilter === 'dismissed' ? 'selected' : ''}>已驳回</option>
                        </select>
                    </div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>举报人</th><th>类型</th><th>内容预览</th><th>原因</th><th>状态</th><th>时间</th><th>操作</th></tr></thead>
                            <tbody>
                                ${reports.map(r => `
                                    <tr>
                                        <td>${r.id}</td>
                                        <td>${escapeHtml(r.reporter_nickname || '')}</td>
                                        <td><span class="badge badge-${r.target_type === 'post' ? 'online' : 'user'}">${r.target_type === 'post' ? '文章' : '评论'}</span></td>
                                        <td style="max-width:200px;word-break:break-all;font-size:12px;">${escapeHtml(r.target_preview || '—')}</td>
                                        <td style="max-width:200px;word-break:break-all;font-size:12px;">${escapeHtml(r.reason || '')}</td>
                                        <td>${r.status === 'pending' ? '<span class="badge" style="background:#f59e0b;color:#fff;">待处理</span>' : r.status === 'resolved' ? '<span class="badge badge-online">已处理</span>' : '<span class="badge badge-offline">已驳回</span>'}</td>
                                        <td>${r.created_at || ''}</td>
                                        <td>
                                            ${r.status === 'pending' ? `
                                                <button class="btn-sm btn-primary" onclick="ChatX.adminResolveReport(${r.id}, 'resolved')">处理</button>
                                                <button class="btn-sm btn-secondary" onclick="ChatX.adminResolveReport(${r.id}, 'dismissed')">驳回</button>
                                            ` : '<span style="color:var(--text-muted);font-size:12px;">已处理</span>'}
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                    <div style="display:flex;justify-content:center;gap:8px;margin-top:12px;">
                        <button class="btn btn-sm btn-primary" ${data.page <= 1 ? 'disabled' : ''} onclick="ChatX.loadForumReports(ChatX._reportFilter||'', ${data.page - 1})">上一页</button>
                        <span style="padding:8px;font-size:13px;color:var(--text-secondary);">第 ${data.page} / ${data.pages} 页</span>
                        <button class="btn btn-sm btn-primary" ${data.page >= data.pages ? 'disabled' : ''} onclick="ChatX.loadForumReports(ChatX._reportFilter||'', ${data.page + 1})">下一页</button>
                    </div>
                </div>
            `;
        };

        window.ChatX.loadForumReports = async function(status, page) {
            const container = document.getElementById('forumSubContent');
            container.innerHTML = '<div class="loading">加载中...</div>';
            try {
                const url = 'api/forum.php?action=admin_reports&page=' + page + (status ? '&status=' + status : '');
                const data = await adminFetch(url, { headers: { 'X-Auth-Token': window.ChatX.token } });
                if (data.error) throw new Error(data.error);
                ChatX._renderForumReportsTable(container, data);
            } catch (e) {
                container.innerHTML = '<div style="color:red;">加载失败: ' + e.message + '</div>';
            }
        };

        window.ChatX.adminResolveReport = async function(reportId, action) {
            if (!confirm(action === 'resolved' ? '确定处理该举报？' : '确定驳回该举报？')) return;
            try {
                const res = await adminFetch('api/forum.php?action=admin_resolve_report', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ report_id: reportId, action })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                ChatX.renderForumSubTab();
            } catch (e) { alert(e.message); }
        };

        // ============ 论坛数据分析 ============
        window.ChatX.renderForumAnalytics = async function(container) {
            container.innerHTML = '<div class="loading">加载中...</div>';
            try {
                const [statsData, analyticsData] = await Promise.all([
                    adminFetch('api/forum.php?action=admin_stats', { headers: { 'X-Auth-Token': window.ChatX.token } }),
                    adminFetch('api/forum.php?action=admin_analytics', { headers: { 'X-Auth-Token': window.ChatX.token } })
                ]);
                if (statsData.error) throw new Error(statsData.error);
                ChatX._renderForumAnalytics(container, statsData.stats, analyticsData);
            } catch (e) {
                container.innerHTML = '<div style="color:red;">加载失败: ' + e.message + '</div>';
            }
        };

        window.ChatX._renderForumAnalytics = function(container, stats, analytics) {
            const topViewed = analytics.top_viewed || [];
            const topReacted = analytics.top_reacted || [];
            const topCommenters = analytics.top_commenters || [];
            const topContributors = analytics.top_contributors || [];

            container.innerHTML = `
                <div class="data-card">
                    <div class="toolbar">
                        <h3 style="flex:1;">论坛数据分析</h3>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-bottom:20px;">
                        <div style="text-align:center;padding:16px;background:var(--bg-secondary);border-radius:12px;">
                            <div style="font-size:28px;font-weight:700;color:var(--primary);">${stats.posts_today || 0}</div>
                            <div style="font-size:12px;color:var(--text-secondary);margin-top:4px;">今日新文章</div>
                        </div>
                        <div style="text-align:center;padding:16px;background:var(--bg-secondary);border-radius:12px;">
                            <div style="font-size:28px;font-weight:700;color:var(--primary);">${stats.posts_week || 0}</div>
                            <div style="font-size:12px;color:var(--text-secondary);margin-top:4px;">近7日文章</div>
                        </div>
                        <div style="text-align:center;padding:16px;background:var(--bg-secondary);border-radius:12px;">
                            <div style="font-size:28px;font-weight:700;color:var(--primary);">${(stats.total_reactions || 0).toLocaleString()}</div>
                            <div style="font-size:12px;color:var(--text-secondary);margin-top:4px;">总互动数</div>
                        </div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                        <div>
                            <h4 style="font-size:14px;font-weight:600;margin-bottom:12px;">🔥 热门文章（按浏览量）</h4>
                            <div style="display:flex;flex-direction:column;gap:8px;">
                                ${topViewed.map((p, i) => `
                                    <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:var(--bg-secondary);border-radius:8px;">
                                        <span style="font-size:14px;font-weight:700;color:var(--text-muted);width:24px;text-align:center;">${i + 1}</span>
                                        <span style="flex:1;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escapeHtml(p.title || '')}">${escapeHtml(p.title || '')}</span>
                                        <span style="font-size:12px;color:var(--primary);font-weight:600;">${p.view_count || 0} 浏览</span>
                                    </div>
                                `).join('') || '<div style="color:var(--text-muted);font-size:13px;">暂无数据</div>'}
                            </div>
                        </div>
                        <div>
                            <h4 style="font-size:14px;font-weight:600;margin-bottom:12px;">💬 热门互动（按反应+点赞）</h4>
                            <div style="display:flex;flex-direction:column;gap:8px;">
                                ${topReacted.map((p, i) => `
                                    <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:var(--bg-secondary);border-radius:8px;">
                                        <span style="font-size:14px;font-weight:700;color:var(--text-muted);width:24px;text-align:center;">${i + 1}</span>
                                        <span style="flex:1;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="${escapeHtml(p.title || '')}">${escapeHtml(p.title || '')}</span>
                                        <span style="font-size:12px;color:var(--primary);font-weight:600;">${(p.reaction_count || 0) + (p.likes_count || 0)} 互动</span>
                                    </div>
                                `).join('') || '<div style="color:var(--text-muted);font-size:13px;">暂无数据</div>'}
                            </div>
                        </div>
                    </div>
                    <div style="margin-top:16px;display:grid;grid-template-columns:1fr 1fr;gap:16px;">
                        <div>
                            <h4 style="font-size:14px;font-weight:600;margin-bottom:12px;">🏆 活跃评论者</h4>
                            <div style="display:flex;flex-direction:column;gap:8px;">
                                ${topCommenters.map((c, i) => `
                                    <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:var(--bg-secondary);border-radius:8px;">
                                        <span style="font-size:14px;font-weight:700;color:var(--text-muted);width:24px;text-align:center;">${i + 1}</span>
                                        <span style="flex:1;font-size:13px;">${escapeHtml(c.nickname || '')}</span>
                                        <span style="font-size:12px;color:var(--primary);font-weight:600;">${c.comment_count} 条</span>
                                    </div>
                                `).join('') || '<div style="color:var(--text-muted);font-size:13px;">暂无数据</div>'}
                            </div>
                        </div>
                        <div>
                            <h4 style="font-size:14px;font-weight:600;margin-bottom:12px;">✍️ 活跃作者</h4>
                            <div style="display:flex;flex-direction:column;gap:8px;">
                                ${topContributors.map((c, i) => `
                                    <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:var(--bg-secondary);border-radius:8px;">
                                        <span style="font-size:14px;font-weight:700;color:var(--text-muted);width:24px;text-align:center;">${i + 1}</span>
                                        <span style="flex:1;font-size:13px;">${escapeHtml(c.nickname || '')}</span>
                                        <span style="font-size:12px;color:var(--primary);font-weight:600;">${c.post_count} 篇</span>
                                    </div>
                                `).join('') || '<div style="color:var(--text-muted);font-size:13px;">暂无数据</div>'}
                            </div>
                        </div>
                    </div>
                </div>
            `;
        };

        window.ChatX.renderForumComments = async function(container) {
            container.innerHTML = '<div class="loading">加载中...</div>';
            try {
                const data = await adminFetch('api/forum.php?action=admin_comments&page=1', { headers: { 'X-Auth-Token': window.ChatX.token } });
                if (data.error) throw new Error(data.error);
                ChatX._forumCommentsData = data;
                ChatX._forumCommentsPage = 1;
                ChatX._renderForumCommentsTable(container, data);
            } catch (e) {
                container.innerHTML = '<div style="color:red;">加载失败: ' + e.message + '</div>';
            }
        };

        window.ChatX._renderForumCommentsTable = function(container, data) {
            const comments = data.comments || [];
            container.innerHTML = `
                <div class="data-card">
                    <div class="toolbar">
                        <h3 style="flex:1;">评论管理 (${data.total})</h3>
                    </div>
                    <div style="overflow-x:auto;">
                        <table>
                            <thead><tr><th>ID</th><th>文章</th><th>用户</th><th>内容</th><th>点赞</th><th>时间</th><th>操作</th></tr></thead>
                            <tbody>
                                ${comments.map(c => `
                                    <tr>
                                        <td>${c.id}</td>
                                        <td><a href="forum.php?post=${c.post_id}" target="_blank" style="color:var(--primary);text-decoration:none;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;display:inline-block;vertical-align:middle;">${escapeHtml(c.post_title || '')}</a></td>
                                        <td>${escapeHtml(c.nickname || c.username)}</td>
                                        <td style="max-width:300px;word-break:break-all;">${escapeHtml(c.content || '')}</td>
                                        <td>${c.likes_count}</td>
                                        <td>${c.created_at || ''}</td>
                                        <td>
                                            <button class="btn-sm btn-danger" onclick="ChatX.adminDeleteComment(${c.id})">删除</button>
                                        </td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                    <div style="display:flex;justify-content:center;gap:8px;margin-top:12px;">
                        <button class="btn btn-sm btn-primary" ${data.page <= 1 ? 'disabled' : ''} onclick="ChatX.loadForumComments(${data.page - 1})">上一页</button>
                        <span style="padding:8px;font-size:13px;color:var(--text-secondary);">第 ${data.page} / ${data.pages} 页</span>
                        <button class="btn btn-sm btn-primary" ${data.page >= data.pages ? 'disabled' : ''} onclick="ChatX.loadForumComments(${data.page + 1})">下一页</button>
                    </div>
                </div>
            `;
        };

        window.ChatX.loadForumComments = async function(page) {
            const container = document.getElementById('forumSubContent');
            container.innerHTML = '<div class="loading">加载中...</div>';
            try {
                const data = await adminFetch('api/forum.php?action=admin_comments&page=' + page, { headers: { 'X-Auth-Token': window.ChatX.token } });
                if (data.error) throw new Error(data.error);
                ChatX._renderForumCommentsTable(container, data);
            } catch (e) {
                container.innerHTML = '<div style="color:red;">加载失败: ' + e.message + '</div>';
            }
        };

        window.ChatX.adminDeleteComment = async function(commentId) {
            if (!confirm('确定删除该评论？')) return;
            try {
                const res = await adminFetch('api/forum.php?action=admin_delete_comment', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ comment_id: commentId })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                ChatX.renderForumSubTab();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.renderForumCategories = async function(container) {
            container.innerHTML = '<div class="loading">加载中...</div>';
            try {
                const data = await adminFetch('api/forum.php?action=admin_categories', { headers: { 'X-Auth-Token': window.ChatX.token } });
                if (data.error) throw new Error(data.error);
                const categories = data.categories || [];
                container.innerHTML = `
                    <div class="data-card">
                        <div class="toolbar">
                            <h3 style="flex:1;">分类管理</h3>
                            <input id="catNewIcon" class="chat-input" style="width:60px;" placeholder="图标" value="📁">
                            <input id="catNewName" class="chat-input" style="width:140px;" placeholder="分类名称">
                            <input id="catNewDesc" class="chat-input" style="width:160px;" placeholder="描述(可选)">
                            <input id="catNewSort" class="chat-input" style="width:70px;" placeholder="排序" type="number" value="0">
                            <button class="btn btn-primary" onclick="ChatX.adminCreateCategory()">添加分类</button>
                        </div>
                        <div style="overflow-x:auto;">
                            <table>
                                <thead><tr><th>ID</th><th>图标</th><th>名称</th><th>描述</th><th>排序</th><th>文章数</th><th>操作</th></tr></thead>
                                <tbody>
                                    ${categories.map(c => `
                                        <tr>
                                            <td>${c.id}</td>
                                            <td style="font-size:20px;">${escapeHtml(c.icon || '📁')}</td>
                                            <td>${escapeHtml(c.name)}</td>
                                            <td>${escapeHtml(c.description || '')}</td>
                                            <td>${c.sort_order}</td>
                                            <td>${c.post_count || 0}</td>
                                            <td>
                                                <button class="btn-sm btn-primary" onclick="ChatX.adminEditCategoryPrompt(${c.id}, ${attrEscape(c.name)}, ${attrEscape(c.description || '')}, ${attrEscape(c.icon || '📁')}, ${c.sort_order || 0})">编辑</button>
                                                <button class="btn-sm btn-danger" onclick="ChatX.adminDeleteCategory(${c.id})">删除</button>
                                            </td>
                                        </tr>
                                    `).join('')}
                                </tbody>
                            </table>
                        </div>
                    </div>
                `;
            } catch (e) {
                container.innerHTML = '<div style="color:red;">加载失败: ' + e.message + '</div>';
            }
        };

        window.ChatX.adminCreateCategory = async function() {
            const name = document.getElementById('catNewName')?.value || '';
            const description = document.getElementById('catNewDesc')?.value || '';
            const icon = document.getElementById('catNewIcon')?.value || '📁';
            const sort_order = parseInt(document.getElementById('catNewSort')?.value) || 0;
            if (!name.trim()) { alert('请输入分类名称'); return; }
            try {
                const res = await adminFetch('api/forum.php?action=admin_create_category', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ name: name.trim(), description: description.trim(), icon: icon.trim() || '📁', sort_order })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                ChatX.renderForumSubTab();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.adminEditCategoryPrompt = async function(id, name, description, icon, sort_order) {
            const newName = prompt('分类名称', name);
            if (newName === null) return;
            if (!newName.trim()) { alert('分类名称不能为空'); return; }
            const newDesc = prompt('分类描述', description || '');
            const newIcon = prompt('分类图标', icon || '📁');
            const newSort = prompt('排序值', sort_order || '0');
            try {
                const res = await adminFetch('api/forum.php?action=admin_update_category', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ id, name: newName.trim(), description: (newDesc || '').trim(), icon: (newIcon || '📁').trim(), sort_order: parseInt(newSort) || 0 })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                ChatX.renderForumSubTab();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.adminDeleteCategory = async function(id) {
            if (!confirm('确定删除该分类？如有文章将先转移或删除文章。')) return;
            try {
                const res = await adminFetch('api/forum.php?action=admin_delete_category', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ id })
                });
                if (res.error) throw new Error(res.error);
                alert(res.message);
                ChatX.renderForumSubTab();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.deleteUser = async function(userId) {
            if (!confirm('确定删除该用户？此操作不可恢复。')) return;
            try {
                const res = await adminFetch('api/users.php?action=admin_delete_user', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ user_id: userId })
                });
                if (res.error) throw new Error(res.error);
                loadUsers();
                loadStats();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.adminDeleteGroup = async function(groupId) {
            if (!confirm('确定解散该群组？此操作不可恢复。')) return;
            try {
                const res = await adminFetch('api/users.php?action=admin_delete_group', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ group_id: groupId })
                });
                if (res.error) throw new Error(res.error);
                loadGroups();
                loadStats();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.adminDeleteFriendship = async function(friendshipId) {
            if (!confirm('确定删除该好友关系？')) return;
            try {
                const res = await adminFetch('api/users.php?action=admin_delete_friendship', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ friendship_id: friendshipId })
                });
                if (res.error) throw new Error(res.error);
                loadFriendships();
                loadStats();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.approveFriendship = async function(friendshipId) {
            try {
                const res = await adminFetch('api/users.php?action=admin_approve_friendship', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ friendship_id: friendshipId })
                });
                if (res.error) throw new Error(res.error);
                loadFriendships();
                loadStats();
            } catch (e) { alert(e.message); }
        };

        window.ChatX.rejectFriendship = async function(friendshipId) {
            if (!confirm('确定拒绝该好友请求？')) return;
            try {
                const res = await adminFetch('api/users.php?action=admin_reject_friendship', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                    body: JSON.stringify({ friendship_id: friendshipId })
                });
                if (res.error) throw new Error(res.error);
                loadFriendships();
                loadStats();
            } catch (e) { alert(e.message); }
        };

        // ============ 数据备份 / 恢复 ============
        function escAttr(s) {
            return String(s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        }

        async function loadBackup() {
            const content = document.getElementById('adminContent');
            content.innerHTML = `
                <div class="data-card" style="margin-bottom:16px;">
                    <h3>📦 全站数据备份</h3>
                    <p style="color:var(--text-secondary);font-size:13px;margin-bottom:14px;">
                        导出的备份包为 JSON 文件，直接下载到当前设备本地，不会在服务器上留存任何副本。
                        备份包含全部数据表：用户、消息、群组、好友、论坛、赌局、五子棋对局、积分钱包等。
                    </p>
                    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
                        <button class="btn btn-primary" id="btnExportBackup">⬇️ 导出备份包到本地</button>
                        <span id="backupExportHint" style="font-size:12px;color:var(--text-secondary);"></span>
                    </div>
                </div>
                <div class="data-card" style="margin-bottom:16px;">
                    <h3>♻️ 从备份包恢复</h3>
                    <p style="color:#c0392b;font-size:13px;margin-bottom:14px;">
                        ⚠️ 恢复会<b>清空并重建</b>备份包内的所有数据表。当前服务器的对应数据将被覆盖，操作不可撤销。
                        建议先导出一份当前备份再导入。恢复过程在事务中执行，任何一步失败都会自动回滚，数据保持原样。
                    </p>
                    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
                        <input type="file" id="backupFile" accept=".json,application/json" style="font-size:13px;">
                        <button class="btn" id="btnAnalyzeBackup">🔍 校验备份包</button>
                        <button class="btn btn-danger" id="btnImportBackup" disabled>⚠️ 开始恢复</button>
                    </div>
                    <div id="backupAnalyzeResult" style="margin-top:12px;font-size:13px;"></div>
                    <div id="backupImportResult" style="margin-top:12px;font-size:13px;"></div>
                </div>
                <div class="data-card">
                    <h3>ℹ️ 说明</h3>
                    <ul style="font-size:13px;color:var(--text-secondary);line-height:1.9;padding-left:18px;margin:0;">
                        <li>备份包格式：JSON，含全量数据行，可在不同版本之间导入。</li>
                        <li>跨版本导入规则：<strong>只恢复当前库里已经存在的表</strong>——保留现有表结构，只替换数据；备份里多出的旧列会被忽略，当前版本新增的列取默认值。</li>
                        <li>备份里有、但当前库没有的表：<strong>不创建也不删除，保持原样</strong>。</li>
                        <li>若旧备份中的枚举值超出当前版本定义（例如通知类型），导入时会自动把该列放宽为 VARCHAR，不会中断。</li>
                        <li>为保证安全，恢复时不会覆盖 <code>sessions</code> 登录会话表，避免恢复后自己被登出。</li>
                        <li>校验步骤会对比备份与当前库的结构差异，只读取备份包，不会修改任何数据。</li>
                        <li>恢复前会自动做一次全库内存快照，任何一步失败都会自动回滚到导入前状态。</li>
                        <li>恢复期间请勿刷新页面，大数据量恢复可能需要数十秒。</li>
                    </ul>
                </div>`;

            const btnExport = document.getElementById('btnExportBackup');
            btnExport.onclick = function() {
                const hint = document.getElementById('backupExportHint');
                hint.textContent = '正在生成备份，请稍候...';
                btnExport.disabled = true;
                // 浏览器直接触发下载：请求发往本地设备，服务器不落盘
                const url = 'api/backup.php?action=export&token=' + encodeURIComponent(window.ChatX.token);
                const a = document.createElement('a');
                a.href = url;
                a.download = '';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                setTimeout(function() {
                    hint.textContent = '已触发下载。若未开始，请检查浏览器下载拦截。';
                    btnExport.disabled = false;
                }, 1500);
            };

            const btnAnalyze = document.getElementById('btnAnalyzeBackup');
            const btnImport = document.getElementById('btnImportBackup');
            const fileInput = document.getElementById('backupFile');
            const analyzeBox = document.getElementById('backupAnalyzeResult');
            const importBox = document.getElementById('backupImportResult');
            let analyzed = null;

            btnAnalyze.onclick = async function() {
                importBox.innerHTML = '';
                const file = fileInput.files[0];
                if (!file) { analyzeBox.innerHTML = '<span style="color:#c0392b;">请先选择备份包文件（.json）</span>'; return; }
                analyzeBox.innerHTML = '正在校验...';
                btnAnalyze.disabled = true;
                try {
                    const text = await file.text();
                    let data;
                    try { data = JSON.parse(text); }
                    catch (e) { throw new Error('不是有效的 JSON 文件'); }
                    const res = await adminFetch('api/backup.php?action=analyze', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                        body: JSON.stringify(data)
                    });
                    if (res.error) throw new Error(res.error);
                    analyzed = data;
                    const meta = res.meta || {};
                    const rows = (res.tables || []).map(function(t) {
                        return '<tr><td>' + escAttr(t.name) + '</td><td style="text-align:right;">' + t.rows + '</td></tr>';
                    }).join('');
                    // 跨版本兼容报告：告诉管理员导入时哪些表会保留现有结构、哪些列会被忽略
                    const compat = res.compat || [];
                    const missingTables = compat.filter(function(c) { return !c.exists; });
                    const droppedCols = [];
                    const keptNewCols = [];
                    compat.forEach(function(c) {
                        if (c.exists) {
                            (c.dropped_columns || []).forEach(function(col) { droppedCols.push(c.table + '.' + col); });
                            (c.new_columns_kept || []).forEach(function(col) { keptNewCols.push(c.table + '.' + col); });
                        }
                    });
                    let compatHtml = '';
                    if (missingTables.length) {
                        compatHtml += '<div style="color:#8e6b1f;margin-bottom:6px;">⏭️ 当前库没有 ' + missingTables.length + ' 张表，将保持原样（不创建、不删除）：' + escAttr(missingTables.map(function(c) { return c.table; }).join('、')) + '</div>';
                    }
                    if (droppedCols.length) {
                        compatHtml += '<div style="color:#8e6b1f;margin-bottom:6px;">⚠️ 备份中有 ' + droppedCols.length + ' 个列在当前版本不存在，这些列的数据会被忽略（当前版本结构保持不变）：' + escAttr(droppedCols.join('、')) + '</div>';
                    }
                    if (keptNewCols.length) {
                        compatHtml += '<div style="color:#2980b9;margin-bottom:6px;">ℹ️ 当前版本独有 ' + keptNewCols.length + ' 个列将保留并被置为默认值：' + escAttr(keptNewCols.join('、')) + '</div>';
                    }
                    if (!compatHtml) {
                        compatHtml = '<div style="color:#7f8c8d;margin-bottom:6px;">备份与当前版本表结构一致。</div>';
                    }
                    analyzeBox.innerHTML =
                        '<div style="color:#27ae60;margin-bottom:8px;">✅ 备份包校验通过</div>' +
                        '<div style="margin-bottom:8px;">备份时间：' + escAttr(meta.created_at || '未知') +
                        ' · 数据库：' + escAttr(meta.db_name || '未知') + '</div>' +
                        compatHtml +
                        '<table style="width:100%;font-size:13px;border-collapse:collapse;"><thead><tr><th style="text-align:left;">数据表</th><th style="text-align:right;">行数</th></tr></thead><tbody>' +
                        rows +
                        '</tbody><tfoot><tr><td><b>合计</b></td><td style="text-align:right;"><b>' + res.total_rows + '</b></td></tr></tfoot></table>';
                    btnImport.disabled = false;
                } catch (e) {
                    analyzed = null;
                    btnImport.disabled = true;
                    analyzeBox.innerHTML = '<span style="color:#c0392b;">校验失败：' + escAttr(e.message) + '</span>';
                } finally {
                    btnAnalyze.disabled = false;
                }
            };

            btnImport.onclick = async function() {
                if (!analyzed) return;
                const tableCount = Object.keys(analyzed.tables || {}).length;
                const ok = confirm(
                    '即将用备份包覆盖全站数据（' + tableCount + ' 张表）。\n' +
                    '当前数据库中的对应数据会被清空重建，且不可撤销。\n\n' +
                    '确定要继续吗？'
                );
                if (!ok) return;
                const ok2 = confirm('最后确认：真的要执行恢复吗？此操作不可撤销。');
                if (!ok2) return;
                importBox.innerHTML = '正在恢复，请勿刷新页面...';
                btnImport.disabled = true;
                btnAnalyze.disabled = true;
                try {
                    const res = await adminFetch('api/backup.php?action=import', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json', 'X-Auth-Token': window.ChatX.token },
                        body: JSON.stringify(analyzed)
                    });
                    if (res.error) throw new Error(res.error);
                    const rep = (res.report || []).filter(function(r) {
                        return r.action === 'widened' || r.action === 'skipped_cols' || r.action === 'skipped';
                    });
                    const repHtml = rep.length
                        ? '<div style="margin-top:6px;color:#8e6b1f;">版本差异处理：' + escAttr(rep.map(function(r) {
                            return r.action === 'widened' ? ('[放宽] ' + r.note) :
                                   ('[跳过] ' + r.table + ' ' + r.note);
                        }).join('；')) + '</div>'
                        : '';
                    importBox.innerHTML =
                        '<div style="color:#27ae60;">✅ ' + escAttr(res.message || '恢复完成') + '</div>' +
                        repHtml +
                        (res.skipped_tables && res.skipped_tables.length
                            ? '<div style="margin-top:6px;color:var(--text-secondary);">已跳过（保持现状）：' + escAttr(res.skipped_tables.join(', ')) + '</div>'
                            : '');
                } catch (e) {
                    importBox.innerHTML = '<span style="color:#c0392b;">恢复失败：' + escAttr(e.message) + '</span>';
                    btnImport.disabled = false;
                    btnAnalyze.disabled = false;
                }
            };
        }

        applyTabPermissions();
        const firstVisibleTab = Array.from(document.querySelectorAll('#adminTabs .tab')).find(tab => tab.style.display !== 'none');
        if (firstVisibleTab) {
            firstVisibleTab.click();
        } else {
            document.getElementById('adminContent').innerHTML = '<div class="loading" style="color:red;">无权访问管理员后台</div>';
        }
    })();
    </script>
</body>
</html>