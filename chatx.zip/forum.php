<?php
session_start();
require_once __DIR__ . '/functions.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
$pdo = db_connect();
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user_row = $stmt->fetch();
if (!$user_row) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}
$current_user = [
    'id' => $user_row['id'],
    'username' => $user_row['username'],
    'nickname' => $user_row['nickname'] ?? $user_row['username'],
    'avatar' => $user_row['avatar'] ?? 'default.png',
    'role' => $user_row['role'] ?? 'user'
];
$frontend_token = $_SESSION['chatx_token'] ?? '';
if (isset($_SESSION['user_id']) && empty($frontend_token)) {
    $_SESSION['chatx_token'] = create_token($_SESSION['user_id']);
    $frontend_token = $_SESSION['chatx_token'];
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatX 论坛</title>
    <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
    <link rel="stylesheet" href="css/style.css">
    <script>
        const _savedTheme = localStorage.getItem('chatx_theme') || 'light';
        if (_savedTheme) document.documentElement.setAttribute('data-theme', _savedTheme);
    </script>
    <style>
        .forum-wrap { max-width: 780px; margin: 0 auto; padding: 20px 16px; min-height: 100vh; background: var(--bg-page, #f5f7fa); }
        .forum-header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 16px; padding: 24px; color: #fff; margin-bottom: 16px; box-shadow: 0 4px 20px rgba(102,126,234,0.3); }
        .forum-header-row { display: flex; align-items: center; justify-content: space-between; }
        .forum-title { font-size: 22px; font-weight: 700; }
        .forum-header-actions { display: flex; gap: 8px; align-items: center; }
        .forum-header-actions .back-btn { width: auto; padding: 8px 14px; font-size: 13px; }
        .forum-search { margin-top: 12px; display: flex; gap: 8px; }
        .forum-search input { flex: 1; padding: 10px 14px; border: none; border-radius: 10px; font-size: 14px; outline: none; }
        .forum-search .btn { width: auto; padding: 10px 16px; }
        .category-tabs { display: flex; gap: 8px; overflow-x: auto; padding-bottom: 12px; margin-bottom: 8px; scrollbar-width: none; }
        .category-tabs::-webkit-scrollbar { display: none; }
        .cat-tab { padding: 8px 16px; border-radius: 20px; font-size: 13px; font-weight: 500; cursor: pointer; white-space: nowrap; transition: all 0.2s; border: 1.5px solid var(--border); background: var(--bg-white); color: var(--text-secondary); }
        .cat-tab.active { background: var(--primary, #4f46e5); color: #fff; border-color: var(--primary, #4f46e5); }
        .cat-tab:hover:not(.active) { border-color: var(--primary, #4f46e5); color: var(--primary, #4f46e5); }
        .post-list { display: flex; flex-direction: column; gap: 12px; }
        .post-card { background: var(--bg-white); border-radius: 14px; padding: 16px 18px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); cursor: pointer; transition: transform 0.15s, box-shadow 0.15s; border: 1px solid var(--border); }
        .post-card:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(0,0,0,0.1); }
        .post-card-header { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
        .post-card-avatar { flex-shrink: 0; }
        .post-card-meta { flex: 1; min-width: 0; }
        .post-card-author { font-size: 13px; color: var(--text-secondary); font-weight: 500; }
        .post-card-time { font-size: 11px; color: var(--text-muted, #aaa); }
        .post-card-cat { font-size: 11px; padding: 3px 8px; border-radius: 10px; background: var(--primary-light, #eef2ff); color: var(--primary, #4f46e5); font-weight: 500; white-space: nowrap; }
        .post-card-title { font-size: 16px; font-weight: 600; color: var(--text-primary); margin-bottom: 6px; line-height: 1.4; }
        .post-card-title .pin-badge { font-size: 10px; background: #f59e0b; color: #fff; padding: 1px 6px; border-radius: 8px; margin-right: 6px; vertical-align: middle; font-weight: 500; }
        .post-card-excerpt { font-size: 13px; color: var(--text-secondary); line-height: 1.6; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
        .post-card-stats { display: flex; gap: 16px; margin-top: 12px; font-size: 12px; color: var(--text-muted, #aaa); }
        .post-card-stats span { display: flex; align-items: center; gap: 4px; }
        .post-card-stats svg { width: 14px; height: 14px; }
        .post-detail { display: none; }
        .post-detail.show { display: block; }
        .post-detail-header { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
        .post-detail-back { width: auto; padding: 8px 12px; }
        .post-detail-title { font-size: 22px; font-weight: 700; color: var(--text-primary); line-height: 1.4; margin-bottom: 12px; }
        .post-detail-meta { display: flex; align-items: center; gap: 10px; padding: 12px 0; border-bottom: 1px solid var(--border); margin-bottom: 16px; }
        .post-detail-body { font-size: 15px; color: var(--text-primary); line-height: 1.8; white-space: pre-wrap; word-break: break-word; margin-bottom: 20px; }
        .post-detail-actions { display: flex; gap: 12px; margin-bottom: 24px; padding: 12px 0; border-bottom: 1px solid var(--border); }
        .post-detail-actions .action-btn { display: flex; align-items: center; gap: 6px; padding: 8px 16px; border-radius: 20px; border: 1.5px solid var(--border); background: var(--bg-white); color: var(--text-secondary); font-size: 13px; cursor: pointer; transition: all 0.2s; }
        .post-detail-actions .action-btn:hover { border-color: var(--primary); color: var(--primary); }
        .post-detail-actions .action-btn.liked { background: #fef2f2; border-color: #fca5a5; color: #dc2626; }
        .post-detail-actions .action-btn.liked svg { fill: #dc2626; }
        .comments-section { margin-top: 24px; }
        .comments-title { font-size: 16px; font-weight: 600; margin-bottom: 16px; color: var(--text-primary); }
        .comment-list { display: flex; flex-direction: column; gap: 16px; }
        .comment-item { display: flex; gap: 10px; }
        .comment-avatar { flex-shrink: 0; }
        .comment-body { flex: 1; min-width: 0; }
        .comment-header { display: flex; align-items: center; gap: 8px; margin-bottom: 4px; }
        .comment-author { font-size: 13px; font-weight: 500; color: var(--text-primary); cursor: pointer; }
        .comment-author:hover { color: var(--primary); }
        .comment-time { font-size: 11px; color: var(--text-muted, #aaa); }
        .comment-text { font-size: 14px; color: var(--text-primary); line-height: 1.6; margin-bottom: 6px; white-space: pre-wrap; word-break: break-word; }
        .comment-actions { display: flex; gap: 12px; }
        .comment-actions .cbtn { font-size: 12px; color: var(--text-muted, #aaa); cursor: pointer; display: flex; align-items: center; gap: 3px; transition: color 0.2s; }
        .comment-actions .cbtn:hover { color: var(--primary); }
        .comment-actions .cbtn.liked { color: #dc2626; }
        .comment-actions .cbtn.liked svg { fill: #dc2626; }
        .reaction-btn-sm { font-size: 12px; padding: 2px 6px; border-radius: 10px; border: 1px solid var(--border); background: var(--bg-white); cursor: pointer; transition: all 0.15s; line-height: 1; }
        .reaction-btn-sm:hover { border-color: var(--primary); background: #f8faff; }
        .reaction-btn-sm.active { border-color: #fca5a5; background: #fef2f2; }
        .reply-list { margin-left: 42px; margin-top: 8px; display: flex; flex-direction: column; gap: 8px; }
        .comment-input-area { margin-top: 20px; }
        .comment-input-row { display: flex; gap: 10px; align-items: flex-start; }
        .comment-input-row textarea { flex: 1; padding: 12px; border: 1.5px solid var(--border); border-radius: 12px; font-size: 14px; resize: none; min-height: 60px; font-family: inherit; outline: none; transition: border-color 0.2s; background: var(--bg-white); }
        .comment-input-row textarea:focus { border-color: var(--primary); }
        .fab { position: fixed; bottom: 32px; right: 32px; width: 56px; height: 56px; border-radius: 50%; background: linear-gradient(135deg, #667eea, #764ba2); color: #fff; display: flex; align-items: center; justify-content: center; box-shadow: 0 6px 24px rgba(102,126,234,0.4); cursor: pointer; transition: transform 0.2s; z-index: 50; border: none; }
        .fab:hover { transform: scale(1.1); }
        .fab svg { width: 24px; height: 24px; }
        .modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 100; align-items: center; justify-content: center; padding: 20px; }
        .modal.show { display: flex; }
        .modal-box { background: var(--bg-white); border-radius: 16px; padding: 24px; width: 100%; max-width: 560px; max-height: 80vh; overflow-y: auto; box-shadow: 0 20px 60px rgba(0,0,0,0.3); }
        .modal-title { font-size: 18px; font-weight: 700; margin-bottom: 16px; color: var(--text-primary); }
        .modal-field { margin-bottom: 14px; }
        .modal-field label { display: block; font-size: 13px; color: var(--text-secondary); margin-bottom: 6px; font-weight: 500; }
        .modal-field input, .modal-field select, .modal-field textarea { width: 100%; padding: 10px 14px; border: 1.5px solid var(--border); border-radius: 10px; font-size: 14px; outline: none; transition: border-color 0.2s; font-family: inherit; background: var(--bg-white); }
        .modal-field input:focus, .modal-field select:focus, .modal-field textarea:focus { border-color: var(--primary); }
        .modal-field textarea { min-height: 140px; resize: vertical; }
        .modal-actions { display: flex; gap: 10px; justify-content: flex-end; margin-top: 8px; }
        .modal-actions .btn { width: auto; padding: 10px 20px; }
        .empty-state { text-align: center; padding: 60px 20px; color: var(--text-muted, #aaa); }
        .empty-state svg { width: 64px; height: 64px; margin: 0 auto 16px; opacity: 0.4; }
        .empty-state p { font-size: 14px; margin-bottom: 16px; }
        .load-more-btn { display: block; margin: 20px auto; padding: 10px 32px; background: var(--bg-white); border: 1.5px solid var(--border); border-radius: 20px; color: var(--text-secondary); font-size: 13px; cursor: pointer; transition: all 0.2s; }
        .load-more-btn:hover { border-color: var(--primary); color: var(--primary); }
        .load-more-btn:disabled { opacity: 0.5; cursor: default; }
        .pagination { display: flex; justify-content: center; gap: 8px; margin: 20px 0; }
        .pagination .btn { width: auto; padding: 8px 16px; font-size: 13px; }
        .hot-tag { display: inline-flex; align-items: center; gap: 3px; font-size: 10px; padding: 2px 6px; border-radius: 8px; background: #fef3c7; color: #92400e; font-weight: 500; margin-left: 6px; }
        .avatar-click { cursor: pointer; }
        .avatar-click:hover { filter: brightness(1.1); }
        .post-card-tags { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 8px; }
        .post-tag { font-size: 11px; padding: 2px 8px; border-radius: 10px; background: #eef2ff; color: #4f46e5; font-weight: 500; }
        .post-card-status { font-size: 10px; padding: 2px 6px; border-radius: 8px; margin-right: 4px; vertical-align: middle; }
        .post-card-status.pinned { background: #f59e0b; color: #fff; }
        .post-card-status.archived { background: #6b7280; color: #fff; }
        .post-card-status.poll { background: #764ba2; color: #fff; }
        .post-card.archived { opacity: 0.7; }
        .post-tags-bar { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 16px; }
        .post-tags-bar .post-tag { font-size: 12px; padding: 3px 10px; border-radius: 10px; font-weight: 500; }
        .post-reactions { display: flex; gap: 8px; margin-bottom: 20px; flex-wrap: wrap; align-items: center; }
        .reaction-btn { display: flex; align-items: center; gap: 4px; padding: 6px 12px; border-radius: 20px; border: 1.5px solid var(--border); background: var(--bg-white); font-size: 14px; cursor: pointer; transition: all 0.2s; }
        .reaction-btn:hover { border-color: var(--primary); background: #f8faff; }
        .reaction-btn.active { border-color: #fca5a5; background: #fef2f2; }
        .reaction-count { font-size: 11px; color: var(--text-muted); font-weight: 500; }
        .reaction-btn.active .reaction-count { color: #dc2626; }
        .reaction-picker { position: absolute; background: var(--bg-white); border: 1.5px solid var(--border); border-radius: 12px; padding: 8px; display: flex; gap: 4px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 10; }
        .reaction-emoji-btn { font-size: 20px; padding: 4px 8px; border: none; background: none; cursor: pointer; border-radius: 8px; transition: background 0.15s; }
        .reaction-emoji-btn:hover { background: #f0f0f0; }
        .poll-container { background: #f8f9ff; border: 1.5px solid #e0e7ff; border-radius: 12px; padding: 16px; margin-bottom: 20px; }
        .poll-question { font-size: 14px; font-weight: 600; color: var(--text-primary); margin-bottom: 12px; }
        .poll-option { position: relative; width: 100%; display: flex; align-items: center; border: 1.5px solid var(--border); border-radius: 10px; padding: 0; margin-bottom: 8px; overflow: hidden; background: var(--bg-white); cursor: pointer; transition: border-color 0.2s; }
        .poll-option:hover { border-color: var(--primary); }
        .poll-option.voted { border-color: #764ba2; }
        .poll-option-bar { position: absolute; left: 0; top: 0; bottom: 0; background: #764ba215; transition: width 0.3s; }
        .poll-option-content { position: relative; z-index: 1; display: flex; justify-content: space-between; align-items: center; width: 100%; padding: 10px 14px; font-size: 13px; }
        .poll-option-text { color: var(--text-primary); font-weight: 500; }
        .poll-option-pct { color: var(--text-muted); font-size: 12px; }
        .poll-total { text-align: center; font-size: 12px; color: var(--text-muted); margin-top: 4px; }
        .archived-notice { background: #fef3c7; color: #92400e; padding: 10px 16px; border-radius: 10px; font-size: 13px; margin-bottom: 20px; text-align: center; }
        @media (max-width: 640px) {
            .forum-wrap { padding: 12px; }
            .forum-header { padding: 16px; border-radius: 12px; }
            .fab { bottom: 20px; right: 20px; width: 48px; height: 48px; }
        }
    </style>
</head>
<body>
    <div class="forum-wrap">
        <!-- Forum List View -->
        <div id="forumList">
            <div class="forum-header">
                <div class="forum-header-row">
                    <div class="forum-title">💬 社区论坛</div>
                    <div class="forum-header-actions">
                        <a href="chat.php" class="btn btn-secondary back-btn">← 返回</a>
                    </div>
                </div>
                <div class="forum-search">
                    <input type="text" id="searchInput" placeholder="搜索文章标题或内容...">
                    <button class="btn btn-primary" onclick="doSearch()">搜索</button>
                </div>
            </div>
            <div class="category-tabs" id="categoryTabs">
                <div class="cat-tab active" data-cat="0">📋 全部</div>
            </div>
            <div id="postListContainer">
                <div class="loading">加载中...</div>
            </div>
            <div id="loadMoreContainer" style="text-align:center;"></div>
        </div>

        <!-- Post Detail View -->
        <div id="postDetail" class="post-detail"></div>
    </div>

    <!-- Create Post FAB -->
    <button class="fab" id="fabCreate" onclick="showCreateModal()" title="发布新帖">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
    </button>

    <!-- Create Post Modal -->
    <div class="modal" id="createModal">
        <div class="modal-box">
            <div class="modal-title">✍️ 发布新帖</div>
            <div class="modal-field">
                <label>文章标题</label>
                <input type="text" id="createTitle" placeholder="请输入文章标题（至少4个字符）" maxlength="100">
            </div>
            <div class="modal-field">
                <label>选择分类</label>
                <select id="createCategory"></select>
            </div>
            <div class="modal-field">
                <label>选择标签（可选）</label>
                <div id="createTags" style="display:flex;gap:6px;flex-wrap:wrap;"></div>
            </div>
            <div class="modal-field">
                <label>文章内容</label>
                <textarea id="createContent" placeholder="请输入文章内容..."></textarea>
            </div>
            <div class="modal-field" id="pollSection" style="display:none;">
                <label>📊 创建投票（可选）</label>
                <input type="text" id="pollQuestion" placeholder="投票问题..." maxlength="200" style="margin-bottom:8px;">
                <div id="pollOptions">
                    <input type="text" class="poll-option-input" placeholder="选项 1" maxlength="100" style="margin-bottom:6px;">
                    <input type="text" class="poll-option-input" placeholder="选项 2" maxlength="100" style="margin-bottom:6px;">
                </div>
                <button type="button" class="btn btn-secondary" style="width:auto;padding:6px 12px;font-size:12px;" onclick="addPollOption()">+ 添加选项</button>
            </div>
            <div class="modal-field">
                <label><input type="checkbox" id="createPollToggle" onchange="document.getElementById('pollSection').style.display = this.checked ? 'block' : 'none';"> 创建投票帖</label>
            </div>
            <div class="modal-actions">
                <button class="btn btn-secondary" onclick="closeCreateModal()">取消</button>
                <button class="btn btn-primary" onclick="submitPost()">发布</button>
            </div>
        </div>
    </div>

    <!-- Report Modal -->
    <div class="modal" id="reportModal">
        <div class="modal-box" style="max-width:440px;">
            <div class="modal-title">🚩 举报内容</div>
            <div class="modal-field">
                <label>举报原因</label>
                <textarea id="reportReason" placeholder="请描述举报原因..." style="min-height:100px;"></textarea>
            </div>
            <div class="modal-actions">
                <button class="btn btn-secondary" onclick="closeReportModal()">取消</button>
                <button class="btn btn-primary" onclick="submitReport()">提交举报</button>
            </div>
        </div>
    </div>

    <script>
    window.ChatX = {
        user: <?php echo json_encode($current_user, JSON_UNESCAPED_UNICODE); ?>,
        token: '<?php echo $frontend_token; ?>'
    };
    </script>
    <script src="js/forum.js?v=20260825u"></script>
</body>
</html>
