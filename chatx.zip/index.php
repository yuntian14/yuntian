<?php
session_start();
require_once __DIR__ . '/functions.php';
if (isset($_SESSION['user_id'])) {
    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    if ($stmt->fetch()) {
        header("Location: chat.php");
        exit;
    }
    // User deleted but session remains: clear and show login
    session_unset();
    session_destroy();
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    if ($username && $password) {
        $pdo = db_connect();
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['nickname'] = $user['nickname'];
            $_SESSION['avatar'] = $user['avatar'];
            $_SESSION['role'] = $user['role'] ?? 'user';
            header("Location: chat.php");
            exit;
        }
        $error = '用户名或密码错误';
    } else {
        $error = '请填写完整信息';
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatX - 登录</title>
    <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">
    <div class="auth-box">
        <div class="auth-header">
            <img src="assets/logo.svg" alt="ChatX" style="width:72px;height:72px;margin:0 auto 12px;display:block;">
            <h1>ChatX</h1>
            <p>即时聊天，连接你我</p>
        </div>
        <?php if ($error): ?>
        <div class="alert error"><?php echo h($error); ?></div>
        <?php endif; ?>
        <form method="post" action="">
            <div class="form-group">
                <label>用户名</label>
                <input type="text" name="username" placeholder="请输入用户名" required autofocus>
            </div>
            <div class="form-group">
                <label>密码</label>
                <input type="password" name="password" placeholder="请输入密码" required>
            </div>
            <button type="submit" class="btn-primary">登录</button>
        </form>
        <div class="auth-footer">
            还没有账号？<a href="register.php">立即注册</a>
        </div>
    </div>
    <script src="js/main.js"></script>
</body>
</html>
