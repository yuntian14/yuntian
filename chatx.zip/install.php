<?php
session_start();
require_once __DIR__ . '/functions.php';
$host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'chatx';
$error = '';
$success = '';
$step = empty($_GET['step']) ? 1 : (int)$_GET['step'];

if ($step > 1 && (!isset($_SESSION['install_db_host']) || !isset($_SESSION['install_db_user']) || !isset($_SESSION['install_db_name']))) {
    $step = 1;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step === 1) {
        $host = trim($_POST['host'] ?? 'localhost');
        $db_user = trim($_POST['db_user'] ?? 'root');
        $db_pass = trim($_POST['db_pass'] ?? '');
        $db_name = trim($_POST['db_name'] ?? 'chatx');

        $_SESSION['install_db_host'] = $host;
        $_SESSION['install_db_user'] = $db_user;
        $_SESSION['install_db_pass'] = $db_pass;
        $_SESSION['install_db_name'] = $db_name;

        try {
            $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $db_user, $db_pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            header("Location: install.php?step=2");
            exit;
        } catch (Exception $e) {
            $error = "数据库连接失败: " . $e->getMessage();
        }
    } elseif ($step === 2) {
        $host = $_SESSION['install_db_host'];
        $db_user = $_SESSION['install_db_user'];
        $db_pass = $_SESSION['install_db_pass'] ?? '';
        $db_name = $_SESSION['install_db_name'];

        try {
            $pdo = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $sql = file_get_contents(__DIR__ . '/schema.sql');
            if (!$sql) {
                throw new Exception("无法读取数据库 schema 文件");
            }

            $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
            $pdo->exec("DROP TABLE IF EXISTS admin_permissions");
            $pdo->exec("DROP TABLE IF EXISTS announcements");
            $pdo->exec("DROP TABLE IF EXISTS feedbacks");
            $pdo->exec("DROP TABLE IF EXISTS sensitive_words");
            $pdo->exec("DROP TABLE IF EXISTS settings");
            $pdo->exec("DROP TABLE IF EXISTS login_logs");
            $pdo->exec("DROP TABLE IF EXISTS notifications");
            $pdo->exec("DROP TABLE IF EXISTS sessions");
            $pdo->exec("DROP TABLE IF EXISTS point_transactions");
            $pdo->exec("DROP TABLE IF EXISTS casino_rooms");
            $pdo->exec("DROP TABLE IF EXISTS game_moves");
            $pdo->exec("DROP TABLE IF EXISTS game_players");
            $pdo->exec("DROP TABLE IF EXISTS game_stats");
            $pdo->exec("DROP TABLE IF EXISTS game_rooms");
            $pdo->exec("DROP TABLE IF EXISTS user_wallets");
            $pdo->exec("DROP TABLE IF EXISTS message_reactions");
            $pdo->exec("DROP TABLE IF EXISTS pinned_messages");
            $pdo->exec("DROP TABLE IF EXISTS messages");
            $pdo->exec("DROP TABLE IF EXISTS group_members");
            $pdo->exec("DROP TABLE IF EXISTS `groups`");
            $pdo->exec("DROP TABLE IF EXISTS friendships");
            $pdo->exec("DROP TABLE IF EXISTS forum_likes");
            $pdo->exec("DROP TABLE IF EXISTS forum_comments");
            $pdo->exec("DROP TABLE IF EXISTS forum_posts");
            $pdo->exec("DROP TABLE IF EXISTS forum_categories");
            $pdo->exec("DROP TABLE IF EXISTS forum_reactions");
            $pdo->exec("DROP TABLE IF EXISTS forum_tags");
            $pdo->exec("DROP TABLE IF EXISTS forum_post_tags");
            $pdo->exec("DROP TABLE IF EXISTS forum_polls");
            $pdo->exec("DROP TABLE IF EXISTS forum_poll_options");
            $pdo->exec("DROP TABLE IF EXISTS forum_poll_votes");
            $pdo->exec("DROP TABLE IF EXISTS forum_reports");
            $pdo->exec("DROP TABLE IF EXISTS users");
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

            $pdo->exec($sql);

            // Ensure world channel exists
            $stmt = $pdo->query("SELECT id FROM `groups` WHERE id = 1");
            if (!$stmt->fetch()) {
                $pdo->exec("INSERT INTO `groups` (id, name, owner_id, description, is_private) VALUES (1, '世界频道', 1, '公共世界频道，所有人可见', 0)");
                $pdo->exec("INSERT INTO group_members (group_id, user_id, role) VALUES (1, 1, 'owner')");
            }

            // Upgrade existing installations
            $upgrades = [];
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'bio'");
                if (!$stmt->fetch()) $upgrades[] = "ALTER TABLE users ADD COLUMN bio TEXT DEFAULT NULL AFTER avatar";
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'signature'");
                if (!$stmt->fetch()) $upgrades[] = "ALTER TABLE users ADD COLUMN signature VARCHAR(255) DEFAULT NULL AFTER bio";
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'avatar_frame'");
                if (!$stmt->fetch()) $upgrades[] = "ALTER TABLE users ADD COLUMN avatar_frame VARCHAR(20) DEFAULT NULL COMMENT '头像框: gold/silver/neon' AFTER signature";
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM users LIKE 'role'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "ALTER TABLE users ADD COLUMN role ENUM('user','admin','super_admin') DEFAULT 'user' AFTER signature";
                    $upgrades[] = "ALTER TABLE users ADD INDEX idx_role (role)";
                } else {
                    $col = $stmt->fetch();
                    if ($col && stripos($col['Type'], 'super_admin') === false) {
                        $upgrades[] = "ALTER TABLE users MODIFY COLUMN role ENUM('user','admin','super_admin') DEFAULT 'user'";
                    }
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM messages LIKE 'is_read'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "ALTER TABLE messages ADD COLUMN is_read BOOLEAN DEFAULT FALSE AFTER recall_time";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM messages LIKE 'file_path'");
                $col = $stmt->fetch();
                if ($col && stripos($col['Type'], 'varchar') !== false) {
                    $upgrades[] = "ALTER TABLE messages MODIFY COLUMN file_path MEDIUMTEXT DEFAULT NULL";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'admin_permissions'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS admin_permissions (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        user_id INT NOT NULL,
                        permission VARCHAR(50) NOT NULL,
                        UNIQUE KEY unique_admin_permission (user_id, permission),
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        INDEX idx_user_permission (user_id, permission)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM group_members LIKE 'permissions'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "ALTER TABLE group_members ADD COLUMN permissions JSON DEFAULT NULL AFTER nickname_as";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM group_members LIKE 'muted_until'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "ALTER TABLE group_members ADD COLUMN muted_until DATETIME DEFAULT NULL AFTER permissions";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'announcements'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS announcements (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        title VARCHAR(255) NOT NULL,
                        content TEXT NOT NULL,
                        created_by INT NOT NULL,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE,
                        INDEX idx_created (created_at)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'feedbacks'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS feedbacks (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        user_id INT NOT NULL,
                        type ENUM('bug','feature','abuse','other') DEFAULT 'other',
                        content TEXT NOT NULL,
                        contact VARCHAR(255) DEFAULT NULL,
                        status ENUM('pending','processing','resolved','closed') DEFAULT 'pending',
                        reply TEXT DEFAULT NULL,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        INDEX idx_user_status (user_id, status),
                        INDEX idx_status (status)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM feedbacks LIKE 'contact'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "ALTER TABLE feedbacks ADD COLUMN contact VARCHAR(255) DEFAULT NULL AFTER content";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'sensitive_words'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS sensitive_words (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        word VARCHAR(100) NOT NULL,
                        category VARCHAR(50) DEFAULT 'custom',
                        created_by INT NOT NULL,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE,
                        INDEX idx_word (word)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'settings'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS settings (
                        name VARCHAR(100) PRIMARY KEY,
                        value TEXT DEFAULT NULL,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'login_logs'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS login_logs (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        user_id INT NOT NULL,
                        username VARCHAR(50) NOT NULL,
                        ip VARCHAR(45),
                        user_agent VARCHAR(255),
                        status ENUM('success','failed') DEFAULT 'success',
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        INDEX idx_user_time (user_id, created_at),
                        INDEX idx_time (created_at)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                }
            } catch (Exception $e) {}

            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'game_rooms'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS game_rooms (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        game_type ENUM('gomoku') NOT NULL,
                        status ENUM('waiting','playing','finished') DEFAULT 'waiting',
                        host_id INT NOT NULL,
                        seed INT NOT NULL DEFAULT 0,
                        max_players TINYINT NOT NULL DEFAULT 2,
                        current_seat TINYINT NOT NULL DEFAULT 0,
                        board_state JSON DEFAULT NULL,
                        winner_id INT DEFAULT NULL,
                        started_at DATETIME DEFAULT NULL,
                        finished_at DATETIME DEFAULT NULL,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (host_id) REFERENCES users(id) ON DELETE CASCADE,
                        INDEX idx_status (status),
                        INDEX idx_host (host_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS game_players (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        room_id INT NOT NULL,
                        user_id INT NOT NULL,
                        seat TINYINT NOT NULL,
                        progress INT NOT NULL DEFAULT 0,
                        finished_at DATETIME DEFAULT NULL,
                        status ENUM('active','resigned') DEFAULT 'active',
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        UNIQUE KEY uniq_room_user (room_id, user_id),
                        FOREIGN KEY (room_id) REFERENCES game_rooms(id) ON DELETE CASCADE,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        INDEX idx_room (room_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS game_moves (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        room_id INT NOT NULL,
                        user_id INT NOT NULL,
                        seat TINYINT NOT NULL,
                        move_data JSON NOT NULL,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (room_id) REFERENCES game_rooms(id) ON DELETE CASCADE,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        INDEX idx_room_time (room_id, created_at)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS game_stats (
                        user_id INT PRIMARY KEY,
                        wins INT NOT NULL DEFAULT 0,
                        losses INT NOT NULL DEFAULT 0,
                        draws INT NOT NULL DEFAULT 0,
                        rating INT NOT NULL DEFAULT 1000,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'user_wallets'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS user_wallets (
                        user_id INT NOT NULL,
                        currency ENUM('points','gomoku','casino') NOT NULL,
                        balance BIGINT NOT NULL DEFAULT 0,
                        last_signin DATE DEFAULT NULL,
                        signin_streak INT NOT NULL DEFAULT 0,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        PRIMARY KEY (user_id, currency),
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS point_transactions (
                        id BIGINT AUTO_INCREMENT PRIMARY KEY,
                        from_user_id INT DEFAULT NULL,
                        to_user_id INT DEFAULT NULL,
                        currency VARCHAR(20) NOT NULL,
                        amount BIGINT NOT NULL,
                        type ENUM('signin','transfer','exchange','bet','win','lose') NOT NULL,
                        memo VARCHAR(255) DEFAULT NULL,
                        detail JSON DEFAULT NULL,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE SET NULL,
                        FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE SET NULL,
                        INDEX idx_from (from_user_id, created_at),
                        INDEX idx_to (to_user_id, created_at)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'casino_rooms'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS casino_rooms (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        game_mode ENUM('dice','roulette') NOT NULL,
                        status ENUM('waiting','finished') DEFAULT 'waiting',
                        host_id INT NOT NULL,
                        guest_id INT DEFAULT NULL,
                        bet_amount BIGINT NOT NULL,
                        host_choice JSON DEFAULT NULL,
                        result JSON DEFAULT NULL,
                        winner_id INT DEFAULT NULL,
                        is_draw TINYINT NOT NULL DEFAULT 0,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        finished_at DATETIME DEFAULT NULL,
                        FOREIGN KEY (host_id) REFERENCES users(id) ON DELETE CASCADE,
                        FOREIGN KEY (guest_id) REFERENCES users(id) ON DELETE SET NULL,
                        INDEX idx_status (status),
                        INDEX idx_host (host_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                }
            } catch (Exception $e) {}

            // 论坛系统
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'forum_categories'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS forum_categories (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(50) NOT NULL,
                        description VARCHAR(255) DEFAULT NULL,
                        icon VARCHAR(10) DEFAULT '📁',
                        sort_order INT DEFAULT 0,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS forum_posts (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        user_id INT NOT NULL,
                        title VARCHAR(200) NOT NULL,
                        content TEXT NOT NULL,
                        category_id INT NOT NULL DEFAULT 1,
                        likes_count INT DEFAULT 0,
                        replies_count INT DEFAULT 0,
                        is_pinned TINYINT NOT NULL DEFAULT 0,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        INDEX idx_user (user_id),
                        INDEX idx_category (category_id),
                        INDEX idx_created (created_at),
                        INDEX idx_pinned (is_pinned)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS forum_comments (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        post_id INT NOT NULL,
                        user_id INT NOT NULL,
                        parent_id INT DEFAULT NULL,
                        content TEXT NOT NULL,
                        likes_count INT DEFAULT 0,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        INDEX idx_post (post_id),
                        INDEX idx_user (user_id),
                        INDEX idx_parent (parent_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS forum_likes (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        post_id INT DEFAULT NULL,
                        comment_id INT DEFAULT NULL,
                        user_id INT NOT NULL,
                        type ENUM('post','comment') NOT NULL DEFAULT 'post',
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        INDEX idx_post_type (post_id, type),
                        INDEX idx_comment_type (comment_id, type),
                        INDEX idx_user (user_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    // 默认分类
                    $upgrades[] = "INSERT IGNORE INTO forum_categories (id, name, description, icon, sort_order) VALUES (1, '综合讨论', '什么都可以聊', '💬', 1)";
                    $upgrades[] = "INSERT IGNORE INTO forum_categories (id, name, description, icon, sort_order) VALUES (2, '技术交流', '技术分享与讨论', '💻', 2)";
                    $upgrades[] = "INSERT IGNORE INTO forum_categories (id, name, description, icon, sort_order) VALUES (3, '生活随笔', '分享生活中的点滴', '🌸', 3)";
                    $upgrades[] = "INSERT IGNORE INTO forum_categories (id, name, description, icon, sort_order) VALUES (4, '公告新闻', '重要公告和资讯', '📢', 4)";
                    $upgrades[] = "INSERT IGNORE INTO forum_categories (id, name, description, icon, sort_order) VALUES (5, '求助问答', '有问题就问，有问必答', '❓', 5)";
                    $upgrades[] = "INSERT IGNORE INTO forum_categories (id, name, description, icon, sort_order) VALUES (6, '娱乐休闲', '轻松一刻，休闲娱乐', '🎮', 6)";
                }
            } catch (Exception $e) {}

            // 论坛增强：归档 + Emoji反应 + 标签 + 投票
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM forum_posts LIKE 'is_archived'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "ALTER TABLE forum_posts ADD COLUMN is_archived TINYINT NOT NULL DEFAULT 0 AFTER is_pinned";
                    $upgrades[] = "ALTER TABLE forum_posts ADD INDEX idx_archived (is_archived)";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM forum_posts LIKE 'view_count'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "ALTER TABLE forum_posts ADD COLUMN view_count INT DEFAULT 0 AFTER replies_count";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'forum_reactions'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS forum_reactions (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        target_type ENUM('post','comment') NOT NULL DEFAULT 'post',
                        target_id INT NOT NULL,
                        user_id INT NOT NULL,
                        emoji VARCHAR(16) NOT NULL,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        UNIQUE KEY uniq_target_emoji (target_type, target_id, emoji),
                        INDEX idx_target (target_type, target_id),
                        INDEX idx_user (user_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'forum_tags'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS forum_tags (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(50) NOT NULL UNIQUE,
                        color VARCHAR(7) DEFAULT '#667eea',
                        sort_order INT DEFAULT 0,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS forum_post_tags (
                        post_id INT NOT NULL,
                        tag_id INT NOT NULL,
                        PRIMARY KEY (post_id, tag_id),
                        FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE,
                        FOREIGN KEY (tag_id) REFERENCES forum_tags(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    $upgrades[] = "INSERT IGNORE INTO forum_tags (name, color, sort_order) VALUES ('技术', '#667eea', 1)";
                    $upgrades[] = "INSERT IGNORE INTO forum_tags (name, color, sort_order) VALUES ('分享', '#764ba2', 2)";
                    $upgrades[] = "INSERT IGNORE INTO forum_tags (name, color, sort_order) VALUES ('问答', '#e91e63', 3)";
                    $upgrades[] = "INSERT IGNORE INTO forum_tags (name, color, sort_order) VALUES ('求助', '#ff9800', 4)";
                    $upgrades[] = "INSERT IGNORE INTO forum_tags (name, color, sort_order) VALUES ('活动', '#4caf50', 5)";
                    $upgrades[] = "INSERT IGNORE INTO forum_tags (name, color, sort_order) VALUES ('公告', '#2196f3', 6)";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'forum_polls'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS forum_polls (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        post_id INT NOT NULL UNIQUE,
                        question VARCHAR(500) NOT NULL,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS forum_poll_options (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        poll_id INT NOT NULL,
                        text VARCHAR(255) NOT NULL,
                        sort_order INT DEFAULT 0,
                        FOREIGN KEY (poll_id) REFERENCES forum_polls(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS forum_poll_votes (
                        poll_id INT NOT NULL,
                        option_id INT NOT NULL,
                        user_id INT NOT NULL,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        UNIQUE KEY uniq_poll_user (poll_id, user_id),
                        FOREIGN KEY (poll_id) REFERENCES forum_polls(id) ON DELETE CASCADE,
                        FOREIGN KEY (option_id) REFERENCES forum_poll_options(id) ON DELETE CASCADE,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        INDEX idx_option (option_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                }
            } catch (Exception $e) {}
            try {
                $stmt = $pdo->query("SHOW TABLES LIKE 'forum_reports'");
                if (!$stmt->fetch()) {
                    $upgrades[] = "CREATE TABLE IF NOT EXISTS forum_reports (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        reporter_id INT NOT NULL,
                        target_type ENUM('post','comment') NOT NULL,
                        target_id INT NOT NULL,
                        reason VARCHAR(255) NOT NULL,
                        status ENUM('pending','resolved','dismissed') NOT NULL DEFAULT 'pending',
                        resolved_by INT DEFAULT NULL,
                        resolved_at DATETIME DEFAULT NULL,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
                        FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL,
                        INDEX idx_target (target_type, target_id),
                        INDEX idx_status (status),
                        INDEX idx_reporter (reporter_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
                }
            } catch (Exception $e) {}

            foreach ($upgrades as $sql_upgrade) {
                $pdo->exec($sql_upgrade);
            }

            // Promote legacy admin/site admin to super_admin and seed permissions
            $pdo->exec("UPDATE users SET role = 'super_admin' WHERE username = 'admin' AND role != 'super_admin'");
            $permissions = ['manage_users','manage_groups','view_messages','manage_settings','manage_roles','manage_feedbacks','manage_sensitive_words','manage_forum','view_login_logs','manage_sessions','view_reports'];
            $stmt = $pdo->prepare("SELECT id FROM users WHERE role = 'super_admin'");
            $stmt->execute();
            $permStmt = $pdo->prepare("INSERT IGNORE INTO admin_permissions (user_id, permission) VALUES (?, ?)");
            while ($row = $stmt->fetch()) {
                foreach ($permissions as $perm) {
                    $permStmt->execute([$row['id'], $perm]);
                }
            }

            $config_content = "<?php\n";
            $config_content .= "define('DB_HOST', '" . addslashes($host) . "');\n";
            $config_content .= "define('DB_USER', '" . addslashes($db_user) . "');\n";
            $config_content .= "define('DB_PASS', '" . addslashes($db_pass) . "');\n";
            $config_content .= "define('DB_NAME', '" . addslashes($db_name) . "');\n";
            $config_content .= "?>\n";

            if (file_put_contents(__DIR__ . '/config.php', $config_content) === false) {
                throw new Exception("无法写入 config.php 文件，请检查目录权限");
            }

            $_SESSION['install_complete'] = true;
            $success = "安装成功！正在跳转到登录页...";
            echo "<script>setTimeout(function(){ window.location.href='index.php'; }, 2000);</script>";
        } catch (Exception $e) {
            $error = "安装失败: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatX 安装向导</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
        .container { background: #fff; border-radius: 16px; box-shadow: 0 20px 60px rgba(0,0,0,0.3); width: 100%; max-width: 520px; overflow: hidden; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; padding: 30px; text-align: center; }
        .header h1 { font-size: 28px; margin-bottom: 8px; }
        .header p { opacity: 0.9; font-size: 14px; }
        .body { padding: 30px; }
        .step-indicator { display: flex; justify-content: center; margin-bottom: 25px; }
        .step { width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 14px; margin: 0 6px; }
        .step.active { background: #667eea; color: #fff; }
        .step.done { background: #28a745; color: #fff; }
        .step.pending { background: #e9ecef; color: #6c757d; }
        .step-line { width: 40px; height: 2px; background: #e9ecef; align-self: center; margin: 0 4px; }
        .step-line.done { background: #28a745; }
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; margin-bottom: 6px; color: #333; font-weight: 500; font-size: 14px; }
        .form-group input { width: 100%; padding: 12px 14px; border: 2px solid #e9ecef; border-radius: 10px; font-size: 14px; transition: border-color 0.2s; }
        .form-group input:focus { outline: none; border-color: #667eea; }
        .btn { width: 100%; padding: 14px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; border: none; border-radius: 10px; font-size: 16px; font-weight: 600; cursor: pointer; transition: transform 0.1s, box-shadow 0.2s; }
        .btn:hover { transform: translateY(-1px); box-shadow: 0 8px 25px rgba(102,126,234,0.4); }
        .btn:active { transform: translateY(0); }
        .alert { padding: 12px 16px; border-radius: 10px; margin-bottom: 18px; font-size: 14px; display: none; }
        .alert.error { display: block; background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .alert.success { display: block; background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .info-box { background: #e7f1ff; border: 1px solid #b3d7ff; border-radius: 10px; padding: 14px 18px; margin-bottom: 20px; color: #004085; font-size: 13px; line-height: 1.6; }
        .info-box strong { color: #002752; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>ChatX 安装向导</h1>
            <p>即时聊天系统 · 数据库配置</p>
        </div>
        <div class="body">
            <div class="step-indicator">
                <div class="step <?php echo $step >= 1 ? ($step > 1 ? 'done' : 'active') : 'pending'; ?>">1</div>
                <div class="step-line <?php echo $step > 1 ? 'done' : ''; ?>"></div>
                <div class="step <?php echo $step >= 2 ? ($step > 2 ? 'done' : 'active') : 'pending'; ?>">2</div>
                <div class="step-line <?php echo $step > 2 ? 'done' : ''; ?>"></div>
                <div class="step <?php echo $step >= 3 ? 'active' : 'pending'; ?>">3</div>
            </div>

            <?php if ($step === 1): ?>
            <div class="info-box">
                <strong>数据库配置</strong><br>
                请填写您的 MySQL 数据库信息。如果您的虚拟主机使用的是 SQLite，请稍后参考文档进行兼容配置。安装程序将自动创建数据库和数据表。
            </div>
            <div class="alert error" id="alert"><?php echo $error; ?></div>
            <form method="post" action="install.php?step=1">
                <div class="form-group">
                    <label>数据库主机</label>
                    <input type="text" name="host" value="<?php echo htmlspecialchars($host); ?>" placeholder="通常为 localhost">
                </div>
                <div class="form-group">
                    <label>数据库用户名</label>
                    <input type="text" name="db_user" value="<?php echo htmlspecialchars($db_user); ?>" placeholder="通常为 root">
                </div>
                <div class="form-group">
                    <label>数据库密码</label>
                    <input type="password" name="db_pass" value="<?php echo htmlspecialchars($db_pass); ?>" placeholder="数据库密码">
                </div>
                <div class="form-group">
                    <label>数据库名称</label>
                    <input type="text" name="db_name" value="<?php echo htmlspecialchars($db_name); ?>" placeholder="例如 chatx">
                </div>
                <button type="submit" class="btn">下一步：测试连接</button>
            </form>
            <?php elseif ($step === 2): ?>
            <div class="info-box">
                <strong>安装数据表</strong><br>
                数据库连接成功！点击下方按钮将创建 ChatX 所需的全部数据表，并生成默认配置文件和测试数据。
            </div>
            <div class="alert error" id="alert"><?php echo $error; ?></div>
            <form method="post" action="install.php?step=2">
                <button type="submit" class="btn">开始安装</button>
            </form>
            <?php else: ?>
            <div class="info-box">
                <strong>安装完成</strong><br>
                ChatX 已成功安装到您的虚拟主机。您现在可以注册账号并开始使用了。测试账号：<code>admin / password</code>
            </div>
            <div class="alert success" id="alert"><?php echo $success; ?></div>
            <a href="index.php" class="btn" style="text-align:center;display:block;text-decoration:none;">前往登录</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
