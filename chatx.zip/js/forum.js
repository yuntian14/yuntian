// ChatX Forum - 论坛前端逻辑
(function() {
    'use strict';

    const API = 'api/forum.php';
    const EMOJIS = ['👍', '❤️', '😂', '🔥', '🎉', '😮'];
    const state = {
        token: window.ChatX?.token || '',
        categories: [],
        tags: [],
        currentCategory: 0,
        currentPage: 1,
        totalPages: 1,
        searchQuery: '',
        view: 'list'
    };

    // ============ API ============
    async function api(url, options = {}) {
        const headers = { 'Content-Type': 'application/json' };
        if (state.token && state.token !== 'logged-in-session') {
            headers['X-Auth-Token'] = state.token;
        }
        const res = await fetch(url, { ...options, headers: { ...headers, ...(options.headers || {}) }, credentials: 'include' });
        const text = await res.text();
        let data = null;
        try { data = JSON.parse(text); } catch (e) {}
        if (!res.ok || data === null) {
            throw new Error((data && data.error) || '请求失败 (' + res.status + '): ' + text.substring(0, 150));
        }
        return data || {};
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    function timeAgo(dateStr) {
        if (!dateStr) return '';
        const d = new Date(dateStr.replace(' ', 'T'));
        if (isNaN(d.getTime())) return dateStr;
        const diff = (Date.now() - d.getTime()) / 1000;
        if (diff < 60) return '刚刚';
        if (diff < 3600) return Math.floor(diff / 60) + '分钟前';
        if (diff < 86400) return Math.floor(diff / 3600) + '小时前';
        if (diff < 604800) return Math.floor(diff / 86400) + '天前';
        return d.toLocaleDateString('zh-CN', { year: 'numeric', month: '2-digit', day: '2-digit' });
    }

    // ============ Avatar ============
    function avatarHTML(user, size) {
        size = size || 32;
        const name = user.nickname || user.username || '?';
        const avatar = user.avatar || '';
        const isDefault = !avatar || avatar === 'default.png';
        const letter = name.charAt(0);
        const hash = Array.from(name).reduce((a, c) => a + c.charCodeAt(0), 0);
        const colors = ['#ff9a9e','#fad0c4','#a18cd1','#fbc2eb','#8fd3f4','#84fab0','#fccb90','#e0c3fc'];
        const bg = 'linear-gradient(135deg, ' + colors[hash % colors.length] + ', ' + colors[(hash + 3) % colors.length] + ')';
        const uid = user.id || '';
        const clickAttr = uid ? "onclick=\"window.location.href='profile.php?user_id=" + uid + "'\" style=\"cursor:pointer;\"" : 'style="cursor:default;"';
        if (!isDefault) {
            const src = avatar;
            return '<span class="avatar-click" ' + (uid ? "onclick=\"window.location.href='profile.php?user_id=" + uid + "'\"" : '') + '><img src="' + escapeHtml(src) + '" style="width:' + size + 'px;height:' + size + 'px;border-radius:50%;object-fit:cover;flex-shrink:0;border:2px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.1);"></span>';
        }
        return '<span class="avatar-click" ' + (uid ? "onclick=\"window.location.href='profile.php?user_id=" + uid + "'\"" : '') + '><div style="width:' + size + 'px;height:' + size + 'px;background:' + bg + ';color:#fff;display:flex;align-items:center;justify-content:center;border-radius:50%;font-size:' + (size * 0.4) + 'px;font-weight:600;flex-shrink:0;border:2px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.1);">' + escapeHtml(letter) + '</div></span>';
    }

    // ============ Load Categories & Tags ============
    async function loadCategories() {
        try {
            const [catData, tagData] = await Promise.all([
                api(API + '?action=categories'),
                api(API + '?action=tags')
            ]);
            state.categories = catData.categories || [];
            state.tags = tagData.tags || [];
            renderCategoryTabs();
            populateCreateCategorySelect();
        } catch (e) {
            console.error('加载分类/标签失败:', e);
        }
    }

    function renderCategoryTabs() {
        const tabs = document.getElementById('categoryTabs');
        if (!tabs) return;
        let html = '<div class="cat-tab ' + (state.currentCategory === 0 ? 'active' : '') + '" data-cat="0">📋 全部</div>';
        state.categories.forEach(c => {
            html += '<div class="cat-tab ' + (state.currentCategory === c.id ? 'active' : '') + '" data-cat="' + c.id + '">' + (c.icon || '📁') + ' ' + escapeHtml(c.name) + '</div>';
        });
        tabs.innerHTML = html;
        tabs.querySelectorAll('.cat-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                state.currentCategory = parseInt(tab.dataset.cat);
                state.currentPage = 1;
                renderCategoryTabs();
                loadPosts();
            });
        });
    }

    function populateCreateCategorySelect() {
        const sel = document.getElementById('createCategory');
        if (!sel) return;
        sel.innerHTML = state.categories.map(c => '<option value="' + c.id + '">' + (c.icon || '📁') + ' ' + escapeHtml(c.name) + '</option>').join('');
        // Populate tags
        const tagsDiv = document.getElementById('createTags');
        if (tagsDiv) {
            tagsDiv.innerHTML = state.tags.map(t =>
                '<label style="display:flex;align-items:center;gap:4px;font-size:13px;cursor:pointer;padding:4px 10px;border:1.5px solid var(--border);border-radius:16px;background:' + (t.color || '#667eea') + '10;">' +
                '<input type="checkbox" value="' + t.id + '" style="accent-color:' + (t.color || '#667eea') + ';"> #' + escapeHtml(t.name) +
                '</label>'
            ).join('');
        }
    }

    // ============ Poll Option ============
    window.addPollOption = function() {
        const container = document.getElementById('pollOptions');
        const count = container.querySelectorAll('.poll-option-input').length;
        if (count >= 6) { alert('最多6个选项'); return; }
        const input = document.createElement('input');
        input.type = 'text';
        input.className = 'poll-option-input';
        input.placeholder = '选项 ' + (count + 1);
        input.maxLength = 100;
        input.style.marginBottom = '6px';
        container.appendChild(input);
    };

    // ============ Load Posts ============
    async function loadPosts() {
        const container = document.getElementById('postListContainer');
        const moreContainer = document.getElementById('loadMoreContainer');
        if (!container) return;
        container.innerHTML = '<div class="loading">加载中...</div>';
        moreContainer.innerHTML = '';

        const params = new URLSearchParams();
        if (state.currentCategory > 0) params.set('category_id', state.currentCategory);
        if (state.searchQuery) params.set('search', state.searchQuery);
        params.set('page', state.currentPage);

        try {
            const data = await api(API + '?action=list&' + params.toString());
            state.totalPages = data.pages || 1;
            renderPostList(data.posts || []);

            // Load more button
            if (state.currentPage < state.totalPages) {
                moreContainer.innerHTML = '<button class="load-more-btn" onclick="loadMore()">加载更多</button>';
            } else if (state.totalPages > 1) {
                moreContainer.innerHTML = '<div style="color:var(--text-muted);font-size:13px;padding:16px;">已加载全部文章</div>';
            }
        } catch (e) {
            console.error('Forum load error:', e);
            container.innerHTML = '<div class="empty-state"><p>加载失败: ' + escapeHtml(e.message) + '</p></div>';
        }
    }

    window.loadMore = function() {
        state.currentPage++;
        loadPosts();
    };

    function renderPostList(posts) {
        const container = document.getElementById('postListContainer');
        if (!container) return;
        if (!posts.length) {
            container.innerHTML = '<div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg><p>暂无文章</p><button class="btn btn-primary" onclick="showCreateModal()">发表第一篇</button></div>';
            return;
        }
        container.innerHTML = '<div class="post-list">' + posts.map(post => postCardHTML(post)).join('') + '</div>';
        // Bind click handlers
        container.querySelectorAll('.post-card').forEach(card => {
            card.addEventListener('click', () => openPost(parseInt(card.dataset.id)));
        });
    }

    function postCardHTML(post) {
        const excerpt = post.content.length > 120 ? post.content.substring(0, 120) + '...' : post.content;
        const isHot = (post.likes_count || 0) >= 10 || (post.replies_count || 0) >= 5;
        const tagsHtml = post.tag_names ? '<div class="post-card-tags">' + post.tag_names.split(', ').map(t => '<span class="post-tag">' + escapeHtml(t.trim()) + '</span>').join('') + '</div>' : '';
        const statusHtml = (post.is_pinned ? '<span class="post-card-status pinned">📌</span>' : '') + (post.is_archived ? '<span class="post-card-status archived">📦</span>' : '') + (post.poll_id ? '<span class="post-card-status poll">📊</span>' : '');
        return '<div class="post-card' + (post.is_archived ? ' archived' : '') + '" data-id="' + post.id + '">' +
            '<div class="post-card-header">' +
                avatarHTML({ id: post.user_id, nickname: post.nickname, avatar: post.avatar }, 36) +
                '<div class="post-card-meta">' +
                    '<div class="post-card-author">' + escapeHtml(post.nickname) + ' ' + (isHot ? '<span class="hot-tag">🔥 热门</span>' : '') + '</div>' +
                    '<div class="post-card-time">' + timeAgo(post.created_at) + '</div>' +
                '</div>' +
                '<span class="post-card-cat">' + (post.category_icon || '📁') + ' ' + escapeHtml(post.category_name) + '</span>' +
            '</div>' +
            '<div class="post-card-title">' + statusHtml + escapeHtml(post.title) + '</div>' +
            '<div class="post-card-excerpt">' + escapeHtml(excerpt) + '</div>' +
            tagsHtml +
            '<div class="post-card-stats">' +
                '<span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg> ' + (post.reaction_count || post.likes_count || 0) + '</span>' +
                '<span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg> ' + (post.replies_count || 0) + '</span>' +
                '<span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg> ' + (post.view_count || 0) + '</span>' +
            '</div>' +
        '</div>';
    }

    // ============ Open Post Detail ============
    async function openPost(postId) {
        const listEl = document.getElementById('forumList');
        const detailEl = document.getElementById('postDetail');
        if (!detailEl) return;

        listEl.style.display = 'none';
        detailEl.classList.add('show');
        state.view = 'detail';
        detailEl.innerHTML = '<div class="loading">加载中...</div>';

        try {
            const data = await api(API + '?action=post&id=' + postId);
            // Track view
            api(API + '?action=view_post', { method: 'POST', body: JSON.stringify({ post_id: postId }) }).catch(() => {});
            renderPostDetail(data.post, data.comments || [], data.reactions || [], data.my_reactions || [], data.tags || [], data.poll || null);
        } catch (e) {
            detailEl.innerHTML = '<div class="empty-state"><p>加载失败: ' + escapeHtml(e.message) + '</p></div>';
        }
    }

    function renderMarkdown(text) {
        if (!text) return '';
        let h = escapeHtml(text);
        h = h.replace(/```(\w*)\n?([\s\S]*?)```/g, '<pre><code>$2</code></pre>');
        h = h.replace(/`([^`]+)`/g, '<code>$1</code>');
        h = h.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
        h = h.replace(/\*([^*]+)\*/g, '<em>$1</em>');
        h = h.replace(/\n/g, '<br>');
        return h;
    }

    function renderPostDetail(post, comments, reactions, myReactions, tags, poll) {
        const detailEl = document.getElementById('postDetail');
        const isOwner = post.user_id === window.ChatX.user.id;
        const isAdmin = ['admin', 'super_admin'].includes(window.ChatX.user.role);

        let html = '';

        // Header
        html += '<div class="post-detail-header">' +
            '<button class="btn btn-secondary post-detail-back" onclick="closePostDetail()">← 返回</button>' +
            '<span style="font-size:13px;color:var(--text-secondary);">' + (post.category_icon || '📁') + ' ' + escapeHtml(post.category_name) + '</span>' +
        '</div>';

        // Title
        html += '<div class="post-detail-title">' + escapeHtml(post.title) + '</div>';

        // Meta
        html += '<div class="post-detail-meta">' +
            avatarHTML({ id: post.user_id, nickname: post.nickname, avatar: post.avatar }, 36) +
            '<div style="flex:1;">' +
                '<div style="font-size:14px;font-weight:500;cursor:pointer;" onclick="window.location.href=\'profile.php?user_id=' + post.user_id + '\'">' + escapeHtml(post.nickname) + '</div>' +
                '<div style="font-size:12px;color:var(--text-muted);">' + timeAgo(post.created_at) + '</div>' +
            '</div>' +
            '<div style="display:flex;gap:6px;flex-wrap:wrap;">' +
                '<button class="btn btn-secondary' + (post.liked ? ' active' : '') + '" style="width:auto;padding:8px 12px;font-size:12px;' + (post.liked ? 'color:#dc2626;border-color:#fca5a5;' : '') + '" onclick="toggleLike(' + post.id + ')">👍 ' + (post.likes_count || 0) + '</button>' +
                '<button class="btn btn-secondary" style="width:auto;padding:8px 12px;font-size:12px;" onclick="showReportModal(\'post\', ' + post.id + ')">🚩 举报</button>' +
                (isOwner || isAdmin ? '<button class="btn btn-secondary" style="width:auto;padding:8px 12px;font-size:12px;" onclick="toggleArchive(' + post.id + ', this)">' + (post.is_archived ? '📦 已归档' : '📦 归档') + '</button>' : '') +
                (isOwner || isAdmin ? '<button class="btn btn-danger" style="width:auto;padding:8px 12px;font-size:12px;" onclick="deletePost(' + post.id + ')">🗑 删除</button>' : '') +
            '</div>' +
        '</div>';

        // Tags
        if (tags && tags.length) {
            html += '<div class="post-tags-bar">' + tags.map(t => '<span class="post-tag" style="background:' + (t.color || '#667eea') + '15;color:' + (t.color || '#667eea') + ';">#' + escapeHtml(t.name) + '</span>').join('') + '</div>';
        }

        // Body
        html += '<div class="post-detail-body">' + renderMarkdown(post.content) + '</div>';

        // Poll
        if (poll) {
            html += renderPoll(poll, post.id);
        }

        // Emoji Reactions
        html += '<div class="post-reactions">' +
            EMOJIS.map(e => {
                const r = (reactions || []).find(r => r.emoji === e);
                const count = r ? r.count : 0;
                const active = myReactions && myReactions.includes(e);
                return '<button class="reaction-btn' + (active ? ' active' : '') + '" onclick="toggleReaction(' + post.id + ', \'' + e + '\', this)">' + e + '<span class="reaction-count">' + count + '</span></button>';
            }).join('') +
            '<div class="reaction-picker" id="reactionPicker" style="display:none;">' +
                EMOJIS.map(e => '<button class="reaction-emoji-btn" onclick="toggleReaction(' + post.id + ', \'' + e + '\')">' + e + '</button>').join('') +
            '</div>' +
        '</div>';

        // Actions
        html += '<div class="post-detail-actions">' +
            '<button class="action-btn" onclick="scrollToComment()">' +
                '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;height:16px;"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>' +
                ' 评论 ' + (post.replies_count || 0) +
            '</button>' +
        '</div>';

        // Archived notice
        if (post.is_archived) {
            html += '<div class="archived-notice">📦 此文章已归档，不再接受评论</div>';
        }

        // Comments
        html += '<div class="comments-section" id="commentsSection">' +
            '<div class="comments-title">💬 评论 (' + (post.replies_count || 0) + ')</div>';

        if (!comments.length) {
            html += '<div style="text-align:center;color:var(--text-muted);padding:24px;font-size:13px;">暂无评论，来抢沙发吧！</div>';
        } else {
            const topLevel = comments.filter(c => !c.parent_id);
            topLevel.forEach(c => {
                html += commentHTML(c);
                const replies = comments.filter(cr => cr.parent_id === c.id);
                if (replies.length) {
                    html += '<div class="reply-list">';
                    replies.forEach(r => { html += commentHTML(r, true); });
                    html += '</div>';
                }
            });
        }

        // Comment input
        if (!post.is_archived) {
            html += '<div class="comment-input-area">' +
                '<div class="comment-input-row">' +
                    avatarHTML(window.ChatX.user, 36) +
                    '<textarea id="commentInput" placeholder="写下你的评论..."></textarea>' +
                '</div>' +
                '<div style="display:flex;justify-content:flex-end;margin-top:8px;">' +
                    '<button class="btn btn-primary" style="width:auto;padding:8px 20px;font-size:13px;" onclick="submitComment(' + post.id + ')">发表评论</button>' +
                '</div>' +
            '</div>';
        }
        html += '</div>';

        detailEl.innerHTML = html;
    }

    function commentHTML(c, isReply) {
        const reactionsHtml = EMOJIS.slice(0, 3).map(e =>
            '<button class="reaction-btn-sm" onclick="event.stopPropagation();toggleCommentReaction(' + c.id + ', \'' + e + '\', this)">' + e + '</button>'
        ).join('');
        return '<div class="comment-item">' +
            '<div class="comment-avatar">' + avatarHTML({ id: c.user_id, nickname: c.nickname, avatar: c.avatar }, isReply ? 28 : 32) + '</div>' +
            '<div class="comment-body">' +
                '<div class="comment-header">' +
                    '<span class="comment-author" onclick="window.location.href=\'profile.php?user_id=' + c.user_id + '\'">' + escapeHtml(c.nickname) + '</span>' +
                    '<span class="comment-time">' + timeAgo(c.created_at) + '</span>' +
                '</div>' +
                '<div class="comment-text">' + escapeHtml(c.content) + '</div>' +
                '<div class="comment-actions">' +
                    reactionsHtml +
                    '<span class="cbtn ' + (c.liked ? 'liked' : '') + '" onclick="toggleCommentLike(' + c.id + ', this)">' +
                        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:12px;height:12px;"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"></path></svg>' +
                        ' ' + (c.likes_count || 0) +
                    '</span>' +
                    (isReply ? '' : '<span class="cbtn" onclick="showReplyForm(' + c.id + ', this)">↩ 回复</span>') +
                '</div>' +
                '<div class="reply-form" id="replyForm_' + c.id + '" style="display:none;margin-top:8px;">' +
                    '<textarea id="replyInput_' + c.id + '" placeholder="回复 ' + escapeHtml(c.nickname) + '..." style="width:100%;padding:8px 12px;border:1.5px solid var(--border);border-radius:8px;font-size:13px;resize:none;min-height:40px;font-family:inherit;outline:none;"></textarea>' +
                    '<button class="btn btn-primary" style="width:auto;padding:6px 14px;font-size:12px;margin-top:6px;" onclick="submitReply(' + c.post_id + ', ' + c.id + ')">回复</button>' +
                '</div>' +
            '</div>' +
        '</div>';
    }

    // ============ Actions ============
    window.closePostDetail = function() {
        document.getElementById('forumList').style.display = '';
        document.getElementById('postDetail').classList.remove('show');
        state.view = 'list';
    };

    window.deletePost = async function(postId) {
        if (!confirm('确定删除这篇文章吗？')) return;
        try {
            await api(API + '?action=delete_post', {
                method: 'POST',
                body: JSON.stringify({ post_id: postId })
            });
            closePostDetail();
            loadPosts();
        } catch (e) {
            alert(e.message);
        }
    };

    window.toggleLike = async function(postId, btn) {
        try {
            const data = await api(API + '?action=like', {
                method: 'POST',
                body: JSON.stringify({ type: 'post', target_id: postId })
            });
            const countEl = btn.querySelector('.like-count');
            if (countEl) countEl.textContent = data.count;
            if (data.liked) btn.classList.add('liked');
            else btn.classList.remove('liked');
        } catch (e) {
            alert(e.message);
        }
    };

    window.toggleCommentLike = async function(commentId, btn) {
        try {
            const data = await api(API + '?action=like', {
                method: 'POST',
                body: JSON.stringify({ type: 'comment', target_id: commentId })
            });
            btn.textContent = (data.liked ? '👍 ' : '👍 ') + data.count;
            if (data.liked) btn.classList.add('liked');
            else btn.classList.remove('liked');
        } catch (e) {
            alert(e.message);
        }
    };

    window.toggleCommentReaction = async function(commentId, emoji, btn) {
        try {
            await api(API + '?action=react', {
                method: 'POST',
                body: JSON.stringify({ target_type: 'comment', target_id: commentId, emoji: emoji })
            });
            if (btn) btn.classList.toggle('active');
        } catch (e) {
            alert(e.message);
        }
    };

    window.showReplyForm = function(commentId, btn) {
        const form = document.getElementById('replyForm_' + commentId);
        if (form) {
            form.style.display = form.style.display === 'none' ? 'block' : 'none';
        }
    };

    window.submitComment = async function(postId) {
        const input = document.getElementById('commentInput');
        const content = input.value.trim();
        if (!content) { alert('请输入评论内容'); return; }
        try {
            await api(API + '?action=comment', {
                method: 'POST',
                body: JSON.stringify({ post_id: postId, content: content })
            });
            input.value = '';
            openPost(postId); // Reload
        } catch (e) {
            alert(e.message);
        }
    };

    window.submitReply = async function(postId, parentId) {
        const input = document.getElementById('replyInput_' + parentId);
        const content = input.value.trim();
        if (!content) { alert('请输入回复内容'); return; }
        try {
            await api(API + '?action=comment', {
                method: 'POST',
                body: JSON.stringify({ post_id: postId, parent_id: parentId, content: content })
            });
            openPost(postId); // Reload
        } catch (e) {
            alert(e.message);
        }
    };

    window.scrollToComment = function() {
        document.getElementById('commentsSection')?.scrollIntoView({ behavior: 'smooth' });
    };

    // ============ Create Post ============
    window.showCreateModal = function() {
        document.getElementById('createModal').classList.add('show');
    };

    window.closeCreateModal = function() {
        document.getElementById('createModal').classList.remove('show');
        document.getElementById('createTitle').value = '';
        document.getElementById('createContent').value = '';
        document.getElementById('createPollToggle').checked = false;
        document.getElementById('pollSection').style.display = 'none';
        document.getElementById('pollQuestion').value = '';
        document.querySelectorAll('#createTags input:checked').forEach(el => el.checked = false);
    };

    window.submitPost = async function() {
        const title = document.getElementById('createTitle').value.trim();
        const content = document.getElementById('createContent').value.trim();
        const categoryId = parseInt(document.getElementById('createCategory').value);
        const selectedTags = Array.from(document.querySelectorAll('#createTags input:checked')).map(el => parseInt(el.value));

        if (title.length < 4) { alert('标题至少4个字符'); return; }
        if (!content) { alert('请输入文章内容'); return; }

        try {
            const res = await api(API + '?action=create', {
                method: 'POST',
                body: JSON.stringify({ title, content, category_id: categoryId })
            });
            const postId = res.id;

            // Add tags
            for (const tagId of selectedTags) {
                await api(API + '?action=add_tag', {
                    method: 'POST',
                    body: JSON.stringify({ post_id: postId, tag_id: tagId })
                });
            }

            // Create poll
            if (document.getElementById('createPollToggle').checked) {
                const pollQ = document.getElementById('pollQuestion').value.trim();
                const pollOpts = Array.from(document.querySelectorAll('.poll-option-input')).map(el => el.value.trim()).filter(v => v);
                if (pollQ && pollOpts.length >= 2) {
                    await api(API + '?action=create_poll', {
                        method: 'POST',
                        body: JSON.stringify({ post_id: postId, question: pollQ, options: pollOpts })
                    });
                }
            }

            closeCreateModal();
            state.currentPage = 1;
            loadPosts();
        } catch (e) {
            alert(e.message);
        }
    };

    // ============ Report ============
    var _reportTarget = { type: 'post', id: 0 };
    window.showReportModal = function(type, id) {
        _reportTarget = { type: type, id: id };
        document.getElementById('reportModal').classList.add('show');
        var reason = document.getElementById('reportReason');
        reason.value = '';
        reason.focus();
    };
    window.closeReportModal = function() {
        document.getElementById('reportModal').classList.remove('show');
    };
    window.submitReport = async function() {
        var reason = document.getElementById('reportReason').value.trim();
        if (!reason) { alert('请填写举报原因'); return; }
        try {
            await api(API + '?action=report', {
                method: 'POST',
                body: JSON.stringify({ target_type: _reportTarget.type, target_id: _reportTarget.id, reason: reason })
            });
            closeReportModal();
            alert('举报已提交，管理员将尽快处理');
        } catch (e) {
            alert(e.message);
        }
    };

    // ============ Search ============
    window.doSearch = function() {
        const input = document.getElementById('searchInput');
        state.searchQuery = input.value.trim();
        state.currentPage = 1;
        state.currentCategory = 0;
        renderCategoryTabs();
        loadPosts();
    };

    // ============ Emoji Reactions ============
    window.toggleReaction = async function(targetId, emoji) {
        try {
            await api(API + '?action=react', {
                method: 'POST',
                body: JSON.stringify({ target_type: 'post', target_id: targetId, emoji: emoji })
            });
            openPost(targetId);
        } catch (e) {
            alert(e.message);
        }
    };

    // ============ Archive ============
    window.toggleArchive = async function(postId, btn) {
        try {
            const data = await api(API + '?action=toggle_archive', {
                method: 'POST',
                body: JSON.stringify({ post_id: postId })
            });
            if (btn) btn.textContent = data.is_archived ? '📦 已归档' : '📦 归档';
        } catch (e) {
            alert(e.message);
        }
    };

    // ============ Poll ============
    function renderPoll(poll, postId) {
        const total = poll.total_votes || 0;
        let html = '<div class="poll-container">';
        html += '<div class="poll-question">📊 ' + escapeHtml(poll.question) + '</div>';
        poll.options.forEach(opt => {
            const pct = total > 0 ? Math.round((opt.votes / total) * 100) : 0;
            const myVote = poll.my_vote == opt.id;
            html += '<button class="poll-option' + (myVote ? ' voted' : '') + '" onclick="votePoll(' + poll.id + ', ' + opt.id + ', ' + postId + ')">' +
                '<div class="poll-option-bar" style="width:' + pct + '%;"></div>' +
                '<div class="poll-option-content">' +
                    '<span class="poll-option-text">' + escapeHtml(opt.text) + (myVote ? ' ✓' : '') + '</span>' +
                    '<span class="poll-option-pct">' + pct + '% (' + opt.votes + ')</span>' +
                '</div>' +
            '</button>';
        });
        html += '<div class="poll-total">共 ' + total + ' 票</div>';
        html += '</div>';
        return html;
    }

    window.votePoll = async function(pollId, optionId, postId) {
        try {
            await api(API + '?action=vote_poll', {
                method: 'POST',
                body: JSON.stringify({ poll_id: pollId, option_id: optionId })
            });
            openPost(postId);
        } catch (e) {
            alert(e.message);
        }
    };

    // Close modal on background click
    document.getElementById('createModal')?.addEventListener('click', function(e) {
        if (e.target === this) closeCreateModal();
    });
    document.getElementById('reportModal')?.addEventListener('click', function(e) {
        if (e.target === this) closeReportModal();
    });

    // Search on Enter
    document.getElementById('searchInput')?.addEventListener('keydown', function(e) {
        if (e.key === 'Enter') doSearch();
    });

    // ============ Init ============
    async function init() {
        await loadCategories();
        // Check for ?post= parameter to open detail view
        const params = new URLSearchParams(window.location.search);
        const postId = params.get('post');
        if (postId) {
            openPost(parseInt(postId));
        } else {
            await loadPosts();
        }
    }

    init();

    // ============ 帖子订阅 ============
    window.ChatX.toggleSubscribe = async function (postId) {
        const btn = document.getElementById('subscribeBtn' + postId);
        if (!btn) return;
        const data = await api('?action=is_subscribed&post_id=' + postId);
        if (data.subscribed) {
            await api('?action=unsubscribe', { method: 'POST', body: JSON.stringify({ post_id: postId }) });
            btn.textContent = '🔔 订阅';
            btn.classList.remove('subscribed');
        } else {
            await api('?action=subscribe', { method: 'POST', body: JSON.stringify({ post_id: postId }) });
            btn.textContent = '✓ 已订阅';
            btn.classList.add('subscribed');
        }
    };
})();