// 主题图标系统
const THEME_ICONS = {
    // 默认线条图标（原样式）
    default: {
        chat: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>',
        contacts: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>',
        groups: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>',
        games: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><line x1="6" y1="11" x2="10" y2="11"></line><line x1="8" y1="9" x2="8" y2="13"></line><line x1="15" y1="12" x2="15.01" y2="12"></line><line x1="18" y1="10" x2="18.01" y2="10"></line><rect x="2" y="6" width="20" height="12" rx="2"></rect></svg>',
        casino: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="2" width="20" height="20" rx="4"></rect><circle cx="8" cy="8" r="1.5"></circle><circle cx="16" cy="16" r="1.5"></circle><circle cx="16" cy="8" r="1.5"></circle><circle cx="8" cy="16" r="1.5"></circle><circle cx="12" cy="12" r="2"></circle></svg>',
        ai: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><path d="M8 14s1.5 2 4 2 4-2 4-2"></path><line x1="9" y1="9" x2="9.01" y2="9"></line><line x1="15" y1="9" x2="15.01" y2="9"></line></svg>',
        admin: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>',
        settings: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg>',
        logout: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>'
    },
    // 少女粉 - 可爱风格
    'kawaii-pink': {
        chat: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FF7BA4"/><circle cx="9" cy="10" r="1.5" fill="white"/><circle cx="15" cy="10" r="1.5" fill="white"/><path d="M9 15c0-1.5 1.8-3 3-3s3 1.5 3 3" stroke="white" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        contacts: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FF9BB5"/><circle cx="10" cy="10" r="2" fill="white"/><circle cx="14" cy="10" r="2" fill="white"/><path d="M9 16c0-1.5 2-3 3-3s3 1.5 3 3" stroke="white" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        groups: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FFB3C6"/><circle cx="8" cy="9" r="1.5" fill="white"/><circle cx="16" cy="9" r="1.5" fill="white"/><circle cx="12" cy="14" r="1.5" fill="white"/><path d="M7 16c0-1.5 2-3 5-3s5 1.5 5 3" stroke="white" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        games: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FF7BA4"/><rect x="8" y="9" width="8" height="6" rx="1" fill="white"/><circle cx="10" cy="12" r="1" fill="#FF7BA4"/><circle cx="14" cy="12" r="1" fill="#FF7BA4"/></svg>',
        casino: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FF69B4"/><circle cx="9" cy="9" r="1.5" fill="white"/><circle cx="15" cy="9" r="1.5" fill="white"/><circle cx="9" cy="15" r="1.5" fill="white"/><circle cx="15" cy="15" r="1.5" fill="white"/><circle cx="12" cy="12" r="2" fill="white"/></svg>',
        ai: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FF85B8"/><circle cx="9" cy="10" r="1.5" fill="white"/><circle cx="15" cy="10" r="1.5" fill="white"/><path d="M9 15c0-1 1.8-2.5 3-2.5s3 1.5 3 2.5" stroke="white" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        admin: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FF7BA4"/><path d="M9 12l2 2 4-4" stroke="white" stroke-width="2" stroke-linecap="round" fill="none"/></svg>',
        settings: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FF9BB5"/><circle cx="12" cy="12" r="3" fill="white"/><circle cx="12" cy="12" r="1.5" fill="#FF9BB5"/></svg>',
        logout: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FF6B8A"/><path d="M9 9l6 6M15 9l-6 6" stroke="white" stroke-width="2" stroke-linecap="round"/></svg>'
    },
    // 科技蓝 - 未来风格
    'tech-blue': {
        chat: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#00C6FF"/><rect x="8" y="9" width="8" height="2" rx="1" fill="white"/><rect x="8" y="12" width="5" height="2" rx="1" fill="white"/><circle cx="17" cy="16" r="2" fill="#00FF88"/></svg>',
        contacts: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#0099CC"/><circle cx="10" cy="10" r="2" fill="white"/><circle cx="14" cy="10" r="2" fill="white"/><path d="M8 16c0-1.5 2-3 4-3s4 1.5 4 3" stroke="white" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        groups: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#00BFFF"/><circle cx="8" cy="9" r="1.5" fill="white"/><circle cx="16" cy="9" r="1.5" fill="white"/><circle cx="12" cy="14" r="1.5" fill="white"/><path d="M6 16c0-1.5 3-3 6-3s6 1.5 6 3" stroke="white" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        games: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#00C6FF"/><rect x="8" y="9" width="8" height="6" rx="1" fill="white"/><circle cx="10" cy="12" r="1" fill="#00FF88"/><circle cx="14" cy="12" r="1" fill="white"/></svg>',
        casino: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#0088FF"/><rect x="8" y="8" width="8" height="8" rx="1" fill="white"/><circle cx="12" cy="12" r="2" fill="#0088FF"/></svg>',
        ai: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#00B4D8"/><circle cx="9" cy="10" r="1.5" fill="#00FF88"/><circle cx="15" cy="10" r="1.5" fill="#00FF88"/><path d="M9 15h6" stroke="white" stroke-width="1.5" stroke-linecap="round"/></svg>',
        admin: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#00C6FF"/><path d="M9 12l2 2 4-4" stroke="white" stroke-width="2" stroke-linecap="round" fill="none"/></svg>',
        settings: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#0099CC"/><circle cx="12" cy="12" r="3" fill="white"/><circle cx="12" cy="12" r="1.5" fill="#0099CC"/></svg>',
        logout: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FF4444"/><path d="M9 9l6 6M15 9l-6 6" stroke="white" stroke-width="2" stroke-linecap="round"/></svg>'
    },
    // 樱花 - 日式风格
    'sakura': {
        chat: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FFB7C5"/><circle cx="9" cy="10" r="1.5" fill="white"/><circle cx="15" cy="10" r="1.5" fill="white"/><path d="M9 15c0-1.5 1.8-3 3-3s3 1.5 3 3" stroke="white" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        contacts: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FFC8D6"/><circle cx="10" cy="10" r="2" fill="white"/><circle cx="14" cy="10" r="2" fill="white"/><path d="M9 16c0-1.5 2-3 3-3s3 1.5 3 3" stroke="white" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        groups: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FFD1DC"/><circle cx="8" cy="9" r="1.5" fill="white"/><circle cx="16" cy="9" r="1.5" fill="white"/><circle cx="12" cy="14" r="1.5" fill="white"/><path d="M7 16c0-1.5 2-3 5-3s5 1.5 5 3" stroke="white" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        games: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FFB7C5"/><rect x="8" y="9" width="8" height="6" rx="1" fill="white"/><circle cx="10" cy="12" r="1" fill="#FFB7C5"/><circle cx="14" cy="12" r="1" fill="#FFB7C5"/></svg>',
        casino: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FF9EAD"/><circle cx="9" cy="9" r="1.5" fill="white"/><circle cx="15" cy="9" r="1.5" fill="white"/><circle cx="9" cy="15" r="1.5" fill="white"/><circle cx="15" cy="15" r="1.5" fill="white"/><circle cx="12" cy="12" r="2" fill="white"/></svg>',
        ai: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FFC2D1"/><circle cx="9" cy="10" r="1.5" fill="white"/><circle cx="15" cy="10" r="1.5" fill="white"/><path d="M9 15c0-1 1.8-2.5 3-2.5s3 1.5 3 2.5" stroke="white" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        admin: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FFB7C5"/><path d="M9 12l2 2 4-4" stroke="white" stroke-width="2" stroke-linecap="round" fill="none"/></svg>',
        settings: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FFC8D6"/><circle cx="12" cy="12" r="3" fill="white"/><circle cx="12" cy="12" r="1.5" fill="#FFC8D6"/></svg>',
        logout: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FF8DA1"/><path d="M9 9l6 6M15 9l-6 6" stroke="white" stroke-width="2" stroke-linecap="round"/></svg>'
    },
    // 赛博朋克 - 霓虹风格
    'cyberpunk': {
        chat: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#00F0FF"/><rect x="8" y="9" width="8" height="2" rx="1" fill="#FF00FF"/><rect x="8" y="12" width="5" height="2" rx="1" fill="#FF00FF"/><circle cx="17" cy="16" r="2" fill="#FF00FF"/></svg>',
        contacts: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#0099FF"/><circle cx="10" cy="10" r="2" fill="#FF00FF"/><circle cx="14" cy="10" r="2" fill="#FF00FF"/><path d="M8 16c0-1.5 2-3 4-3s4 1.5 4 3" stroke="white" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        groups: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#0066FF"/><circle cx="8" cy="9" r="1.5" fill="#FF00FF"/><circle cx="16" cy="9" r="1.5" fill="#FF00FF"/><circle cx="12" cy="14" r="1.5" fill="white"/><path d="M6 16c0-1.5 3-3 6-3s6 1.5 6 3" stroke="white" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        games: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#00F0FF"/><rect x="8" y="9" width="8" height="6" rx="1" fill="#FF00FF"/><circle cx="10" cy="12" r="1" fill="#00FF88"/><circle cx="14" cy="12" r="1" fill="white"/></svg>',
        casino: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#0088FF"/><rect x="8" y="8" width="8" height="8" rx="1" fill="#FF00FF"/><circle cx="12" cy="12" r="2" fill="#0088FF"/></svg>',
        ai: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#00CFFF"/><circle cx="9" cy="10" r="1.5" fill="#FF00FF"/><circle cx="15" cy="10" r="1.5" fill="#FF00FF"/><path d="M9 15h6" stroke="white" stroke-width="1.5" stroke-linecap="round"/></svg>',
        admin: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#00F0FF"/><path d="M9 12l2 2 4-4" stroke="#FF00FF" stroke-width="2" stroke-linecap="round" fill="none"/></svg>',
        settings: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#0099FF"/><circle cx="12" cy="12" r="3" fill="#FF00FF"/><circle cx="12" cy="12" r="1.5" fill="#0099FF"/></svg>',
        logout: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#FF0044"/><path d="M9 9l6 6M15 9l-6 6" stroke="white" stroke-width="2" stroke-linecap="round"/></svg>'
    },
    // 羊皮卷 - 古卷做旧风格
    'parchment': {
        chat: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#8b4513"/><circle cx="9" cy="10" r="1.5" fill="#f5e6d3"/><circle cx="15" cy="10" r="1.5" fill="#f5e6d3"/><path d="M9 15c0-1.5 1.8-3 3-3s3 1.5 3 3" stroke="#f5e6d3" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        contacts: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#a0522d"/><circle cx="10" cy="10" r="2" fill="#f5e6d3"/><circle cx="14" cy="10" r="2" fill="#f5e6d3"/><path d="M9 16c0-1.5 2-3 3-3s3 1.5 3 3" stroke="#f5e6d3" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        groups: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#b5651d"/><circle cx="8" cy="9" r="1.5" fill="#f5e6d3"/><circle cx="16" cy="9" r="1.5" fill="#f5e6d3"/><circle cx="12" cy="14" r="1.5" fill="#f5e6d3"/><path d="M7 16c0-1.5 2-3 5-3s5 1.5 5 3" stroke="#f5e6d3" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        games: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#8b4513"/><rect x="8" y="9" width="8" height="6" rx="1" fill="#f5e6d3"/><circle cx="10" cy="12" r="1" fill="#8b4513"/><circle cx="14" cy="12" r="1" fill="#8b4513"/></svg>',
        casino: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#654321"/><circle cx="9" cy="9" r="1.5" fill="#f5e6d3"/><circle cx="15" cy="9" r="1.5" fill="#f5e6d3"/><circle cx="9" cy="15" r="1.5" fill="#f5e6d3"/><circle cx="15" cy="15" r="1.5" fill="#f5e6d3"/><circle cx="12" cy="12" r="2" fill="#f5e6d3"/></svg>',
        ai: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#a0522d"/><circle cx="9" cy="10" r="1.5" fill="#f5e6d3"/><circle cx="15" cy="10" r="1.5" fill="#f5e6d3"/><path d="M9 15c0-1 1.8-2.5 3-2.5s3 1.5 3 2.5" stroke="#f5e6d3" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        admin: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#8b4513"/><path d="M9 12l2 2 4-4" stroke="#f5e6d3" stroke-width="2" stroke-linecap="round" fill="none"/></svg>',
        settings: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#a0522d"/><circle cx="12" cy="12" r="3" fill="#f5e6d3"/><circle cx="12" cy="12" r="1.5" fill="#a0522d"/></svg>',
        logout: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#654321"/><path d="M9 9l6 6M15 9l-6 6" stroke="#f5e6d3" stroke-width="2" stroke-linecap="round"/></svg>'
    },
    // 卡西欧 - 像素LCD风格
    'casio': {
        chat: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#4a7c59"/><rect x="7" y="8" width="10" height="2" rx="1" fill="#9bbc0f"/><rect x="7" y="12" width="7" height="2" rx="1" fill="#9bbc0f"/><circle cx="17" cy="16" r="2" fill="#9bbc0f"/></svg>',
        contacts: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#5a8c69"/><circle cx="10" cy="10" r="2" fill="#9bbc0f"/><circle cx="14" cy="10" r="2" fill="#9bbc0f"/><path d="M8 16c0-1.5 2-3 4-3s4 1.5 4 3" stroke="#9bbc0f" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        groups: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#6a9c79"/><circle cx="8" cy="9" r="1.5" fill="#9bbc0f"/><circle cx="16" cy="9" r="1.5" fill="#9bbc0f"/><circle cx="12" cy="14" r="1.5" fill="#9bbc0f"/><path d="M6 16c0-1.5 3-3 6-3s6 1.5 6 3" stroke="#9bbc0f" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>',
        games: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#4a7c59"/><rect x="7" y="8" width="10" height="8" rx="1" fill="#9bbc0f"/><rect x="9" y="11" width="2" height="2" fill="#4a7c59"/><rect x="13" y="11" width="2" height="2" fill="#4a7c59"/></svg>',
        casino: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#3a6c49"/><rect x="7" y="7" width="10" height="10" rx="1" fill="#9bbc0f"/><rect x="10" y="10" width="4" height="4" fill="#3a6c49"/></svg>',
        ai: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#5a8c69"/><circle cx="9" cy="10" r="1.5" fill="#9bbc0f"/><circle cx="15" cy="10" r="1.5" fill="#9bbc0f"/><path d="M9 15h6" stroke="#9bbc0f" stroke-width="1.5" stroke-linecap="round"/></svg>',
        admin: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#4a7c59"/><rect x="8" y="8" width="8" height="8" rx="1" fill="#9bbc0f"/><path d="M10 12l1 1 3-3" stroke="#4a7c59" stroke-width="1.5" stroke-linecap="round" fill="none"/></svg>',
        settings: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#5a8c69"/><rect x="8" y="8" width="8" height="8" rx="1" fill="#9bbc0f"/><circle cx="12" cy="12" r="2" fill="#5a8c69"/></svg>',
        logout: '<svg viewBox="0 0 24 24" width="24" height="24"><rect x="4" y="4" width="16" height="16" rx="4" fill="#3a6c49"/><rect x="8" y="8" width="8" height="8" rx="1" fill="#9bbc0f"/><path d="M10 10l4 4M14 10l-4 4" stroke="#3a6c49" stroke-width="1.5" stroke-linecap="round"/></svg>'
    }
};

// 应用图标到侧边栏
function applyThemeIcons(themeId, useIcons) {
    const iconSet = useIcons && THEME_ICONS[themeId] ? THEME_ICONS[themeId] : THEME_ICONS.default;
    
    const navItems = {
        chat: document.querySelector('[data-tab="chat"]'),
        contacts: document.querySelector('[data-tab="contacts"]'),
        groups: document.querySelector('[data-tab="groups"]'),
        games: document.querySelector('[data-tab="games"]'),
        casino: document.querySelector('[data-tab="casino"]'),
        ai: document.querySelector('[data-tab="ai"]'),
        admin: document.querySelector('#navAdmin'),
        settings: document.querySelector('[data-tab="settings"]'),
        logout: document.querySelector('[data-tab="logout"]')
    };
    
    Object.entries(navItems).forEach(([key, el]) => {
        if (el && iconSet[key]) {
            const title = el.getAttribute('title');
            el.innerHTML = iconSet[key];
            if (title) el.setAttribute('title', title);
        }
    });
    
    // 更新侧边栏 logo
    const sidebarLogo = document.querySelector('.sidebar-logo');
    if (sidebarLogo) {
        if (useIcons && THEME_ICONS[themeId]?.chat) {
            let logoSvg = THEME_ICONS[themeId].chat;
            logoSvg = logoSvg.replace('width="24"', 'width="100%"').replace('height="24"', 'height="100%"');
            sidebarLogo.innerHTML = logoSvg;
        } else {
            sidebarLogo.innerHTML = THEME_ICONS.default.chat;
        }
    }
}

// 初始化图标
function initThemeIcons() {
    let themeId = document.documentElement.getAttribute('data-theme');
    if (!themeId) {
        themeId = localStorage.getItem('chatx_theme') || 'sakura';
    }
    const useIcons = localStorage.getItem('chatx_use_icons') === '1';
    applyThemeIcons(themeId, useIcons);
}
