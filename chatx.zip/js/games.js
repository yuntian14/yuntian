// ChatX 游戏模块：大厅 + 五子棋
(function () {
    const API_GAMES = 'api/games.php';
    let pollTimer = null;
    let currentRoom = null;
    let mySeat = null;
    let gomokuBoard = null;

    async function api(action, options) {
        const token = (window.ChatX && window.ChatX.token) || '';
        const url = action.startsWith('?') ? API_GAMES + action : API_GAMES + '?' + action;
        const r = await fetch(url, Object.assign({
            headers: { 'X-Auth-Token': token, 'Content-Type': 'application/json' },
            credentials: 'include'
        }, options));
        const text = await r.text();
        try {
            return JSON.parse(text);
        } catch (e) {
            throw new Error('服务异常 (' + r.status + '): ' + text.substring(0, 200));
        }
    }

    function esc(s) { if (!s) return ''; return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

    // ============ 大厅 ============
    window.ChatX.showGames = function () {
        const panel = document.getElementById('gamePanel');
        if (!panel) return;
        panel.style.display = 'flex';
        renderLobby();
    };

    window.ChatX.hideGames = function () {
        const panel = document.getElementById('gamePanel');
        if (panel) panel.style.display = 'none';
        stopPolling();
        currentRoom = null;
    };

    function renderLobby() {
        const content = document.getElementById('gameContent');
        if (!content) return;
        content.innerHTML = `
            <div class="game-lobby">
                <div class="game-cards">
                    <div class="game-card" id="cardGomoku">
                        <div class="game-card-icon">⚫</div>
                        <div class="game-card-name">五子棋</div>
                        <div class="game-card-desc">15×15 棋盘，五子连珠胜</div>
                        <button class="btn btn-primary" id="btnCreateGomoku">创建房间</button>
                    </div>
                    <div class="game-card" id="cardCasino">
                        <div class="game-card-icon">🎰</div>
                        <div class="game-card-name">赌场</div>
                        <div class="game-card-desc">投骰子比大小 · 俄罗斯轮盘</div>
                        <button class="btn btn-primary" id="btnEnterCasino">进入赌场</button>
                    </div>
                </div>
                <h3 style="margin:16px 0 8px;">开放房间</h3>
                <div id="openRooms"><div class="loading">加载中...</div></div>
                <h3 style="margin:16px 0 8px;">排行榜</h3>
                <div id="gameLeaderboard"><div class="loading">加载中...</div></div>
            </div>
        `;
        document.getElementById('btnCreateGomoku').onclick = () => createRoom('gomoku');
        document.getElementById('btnEnterCasino').onclick = () => {
            window.ChatX.hideGames();
            if (window.ChatX.showCasino) window.ChatX.showCasino();
        };
        loadOpenRooms();
        loadLeaderboard();
    }

    async function loadOpenRooms() {
        try {
            const data = await api('?action=rooms');
            const el = document.getElementById('openRooms');
            if (!el) return;
            if (data.error) { el.innerHTML = '<p style="color:red;">' + esc(data.error) + '</p>'; return; }
            const rooms = data.rooms || [];
            if (!rooms.length) { el.innerHTML = '<p style="color:#999;">暂无开放房间，创建一个吧</p>'; return; }
            el.innerHTML = rooms.map(r => `
                <div class="room-item">
                    <div class="room-info">
                        <span class="room-type">⚫ 五子棋</span>
                        <span class="room-host">房主: ${esc(r.host_name)}</span>
                        <span class="room-count">${r.player_count}/${r.max_players}</span>
                    </div>
                    <button class="btn btn-sm btn-primary" data-join="${r.id}">加入</button>
                </div>
            `).join('');
            el.querySelectorAll('[data-join]').forEach(btn => {
                btn.onclick = () => joinRoom(parseInt(btn.dataset.join), btn);
            });
        } catch (e) {
            const el = document.getElementById('openRooms');
            if (el) el.innerHTML = '<p style="color:red;">加载失败</p>';
        }
    }

    async function loadLeaderboard() {
        try {
            const data = await api('?action=leaderboard');
            const el = document.getElementById('gameLeaderboard');
            if (!el) return;
            if (data.error) { el.innerHTML = '<p style="color:red;">' + esc(data.error) + '</p>'; return; }
            const lb = data.leaderboard || [];
            if (!lb.length) { el.innerHTML = '<p style="color:#999;">还没有战绩，快去开局吧</p>'; return; }
            el.innerHTML = lb.slice(0, 10).map((p, i) => `
                <div class="lb-item">
                    <span class="lb-rank">${i + 1}</span>
                    <span class="lb-name">${esc(p.nickname || p.username)}</span>
                    <span class="lb-record">${p.wins}胜 ${p.losses}负 ${p.draws}平</span>
                    <span class="lb-rating">${p.rating}</span>
                </div>
            `).join('');
        } catch (e) {}
    }

    async function createRoom(gameType) {
        const btn = document.getElementById('btnCreateGomoku');
        if (btn) btn.disabled = true;
        try {
            const data = await api('action=create', { method: 'POST', body: JSON.stringify({ game_type: gameType }) });
            if (data.error) { alert(data.error); return; }
            enterRoom(data.room_id);
        } catch (e) { alert('创建失败：' + e.message); }
        finally { if (btn) btn.disabled = false; }
    }

    async function joinRoom(roomId, btn) {
        if (btn) btn.disabled = true;
        try {
            const data = await api('action=join', { method: 'POST', body: JSON.stringify({ room_id: roomId }) });
            if (data.error) { alert(data.error); loadOpenRooms(); return; }
            enterRoom(roomId);
        } catch (e) { alert('加入失败：' + e.message); }
        finally { if (btn) btn.disabled = false; }
    }

    // ============ 房间 ============
    function enterRoom(roomId) {
        currentRoom = roomId;
        stopPolling();
        const content = document.getElementById('gameContent');
        if (content) content.innerHTML = '<div class="loading">正在进入房间...</div>';
        pollRoom();
    }

    function pollRoom() {
        stopPolling();
        fetchRoomState();
        pollTimer = setInterval(fetchRoomState, 700);
    }

    function stopPolling() {
        if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
    }

    async function fetchRoomState() {
        if (!currentRoom) return;
        try {
            const data = await api('?action=state&room_id=' + currentRoom);
            if (data.error) {
                stopPolling();
                const content = document.getElementById('gameContent');
                if (content) content.innerHTML = '<p style="color:red;">' + esc(data.error) + '</p>';
                return;
            }
            mySeat = null;
            (data.players || []).forEach(p => { if (p.user_id === data.my_id) mySeat = p.seat; });
            renderGomoku(data);
        } catch (e) {
            stopPolling();
            const content = document.getElementById('gameContent');
            if (content) content.innerHTML = '<p style="color:red;">' + esc(e.message) + '</p>';
        }
    }

    // ============ 五子棋 ============
    function renderGomoku(data) {
        const content = document.getElementById('gameContent');
        if (!content) return;
        const room = data.room;
        const players = data.players;
        if (room.status === 'waiting') {
            content.innerHTML = `
                <div class="game-waiting">
                    <h3>⚫ 五子棋</h3>
                    <p>房间 #${room.id} — 等待对手加入...</p>
                    <p style="color:#999;">把房间号告诉好友，或在开放房间列表里加入</p>
                    <button class="btn btn-sm" id="btnLeaveGomoku">离开房间</button>
                </div>
            `;
            const btn = document.getElementById('btnLeaveGomoku');
            if (btn) btn.onclick = leaveRoom;
            return;
        }
        if (room.status === 'finished' || !gomokuBoard) {
            gomokuBoard = array2D(15, 15, -1);
            (data.moves || []).forEach(m => {
                const mv = typeof m.move_data === 'string' ? JSON.parse(m.move_data) : m.move_data;
                gomokuBoard[mv.y][mv.x] = m.seat;
            });
        }
        const myTurn = room.status === 'playing' && room.current_seat === mySeat;
        const winnerName = room.winner_id !== null
            ? (players.find(p => p.user_id === room.winner_id) || {}).nickname
            : null;
        content.innerHTML = `
            <div class="gomoku-wrap">
                <div class="gomoku-status">
                    ${room.status === 'finished'
                        ? (room.winner_id === data.my_id ? '🎉 你赢了！' : (winnerName ? '😞 ' + esc(winnerName) + ' 获胜' : '🤝 平局'))
                        : (myTurn ? '🟢 轮到你落子（黑棋）' : '🔴 等待对手落子')}
                </div>
                <div class="gomoku-players">
                    ${players.map(p => `<span class="player-chip ${room.current_seat === p.seat && room.status === 'playing' ? 'active' : ''}">${p.seat === 0 ? '⚫' : '⚪'} ${esc(p.nickname)}</span>`).join('')}
                </div>
                <canvas id="gomokuCanvas" width="600" height="600" style="max-width:100%;touch-action:none;"></canvas>
                <div style="margin-top:12px;display:flex;gap:8px;">
                    ${room.status === 'finished' ? '<button class="btn btn-primary" id="btnBackToLobby">返回大厅</button>' : '<button class="btn btn-sm" id="btnLeaveGomoku">认输离开</button>'}
                </div>
            </div>
        `;
        const canvas = document.getElementById('gomokuCanvas');
        if (canvas) {
            drawGomoku(canvas);
            if (myTurn && room.status === 'playing') {
                canvas.onclick = e => {
                    const rect = canvas.getBoundingClientRect();
                    const sx = canvas.width / rect.width;
                    const sy = canvas.height / rect.height;
                    const px = (e.clientX - rect.left) * sx;
                    const py = (e.clientY - rect.top) * sy;
                    const margin = 30, cell = (canvas.width - margin * 2) / 14;
                    const x = Math.round((px - margin) / cell);
                    const y = Math.round((py - margin) / cell);
                    if (x < 0 || x > 14 || y < 0 || y > 14) return;
                    if (gomokuBoard[y][x] !== -1) return;
                    submitGomokuMove(x, y);
                };
            }
        }
        const btnBack = document.getElementById('btnBackToLobby');
        if (btnBack) btnBack.onclick = () => { stopPolling(); currentRoom = null; gomokuBoard = null; renderLobby(); };
        const btnLeave = document.getElementById('btnLeaveGomoku');
        if (btnLeave) btnLeave.onclick = leaveRoom;
    }

    function array2D(w, h, val) {
        return Array.from({ length: h }, () => Array.from({ length: w }, () => val));
    }

    function drawGomoku(canvas) {
        const ctx = canvas.getContext('2d');
        const W = canvas.width, margin = 30, cell = (W - margin * 2) / 14;
        ctx.fillStyle = '#f0d9b5';
        ctx.fillRect(0, 0, W, W);
        ctx.strokeStyle = '#8d6e3d';
        ctx.lineWidth = 1;
        for (let i = 0; i < 15; i++) {
            ctx.beginPath();
            ctx.moveTo(margin, margin + i * cell);
            ctx.lineTo(W - margin, margin + i * cell);
            ctx.stroke();
            ctx.beginPath();
            ctx.moveTo(margin + i * cell, margin);
            ctx.lineTo(margin + i * cell, W - margin);
            ctx.stroke();
        }
        ctx.fillStyle = '#8d6e3d';
        [[3, 3], [11, 3], [3, 11], [11, 11], [7, 7]].forEach(([gx, gy]) => {
            ctx.beginPath();
            ctx.arc(margin + gx * cell, margin + gy * cell, 4, 0, Math.PI * 2);
            ctx.fill();
        });
        for (let y = 0; y < 15; y++) {
            for (let x = 0; x < 15; x++) {
                if (gomokuBoard[y][x] !== -1) {
                    ctx.beginPath();
                    ctx.arc(margin + x * cell, margin + y * cell, cell * 0.42, 0, Math.PI * 2);
                    ctx.fillStyle = gomokuBoard[y][x] === 0 ? '#222' : '#fff';
                    ctx.fill();
                    ctx.strokeStyle = '#333';
                    ctx.lineWidth = 1;
                    ctx.stroke();
                }
            }
        }
    }

    async function submitGomokuMove(x, y) {
        try {
            const data = await api('action=move', { method: 'POST', body: JSON.stringify({ room_id: currentRoom, x, y }) });
            if (data.error) { alert(data.error); return; }
            gomokuBoard[y][x] = mySeat;
            const canvas = document.getElementById('gomokuCanvas');
            if (canvas) drawGomoku(canvas);
            if (data.win || data.draw) {
                setTimeout(fetchRoomState, 600);
            } else {
                setTimeout(fetchRoomState, 300);
            }
        } catch (e) { alert('落子失败'); }
    }

    async function leaveRoom() {
        if (!currentRoom) return;
        try {
            await api('action=leave&room_id=' + currentRoom, { method: 'POST' });
            stopPolling();
            currentRoom = null;
            gomokuBoard = null;
            renderLobby();
        } catch (e) { alert(e.message); }
    }

    // 大厅自动刷新
    (function () {
        const closeBtn = document.getElementById('btnCloseGames');
        if (closeBtn) closeBtn.onclick = () => { window.ChatX.hideGames(); const nav = document.querySelector('.nav-item[data-tab="chat"]'); if (nav) nav.click(); };
    })();
    setInterval(() => {
        const panel = document.getElementById('gamePanel');
        const content = document.getElementById('gameContent');
        if (panel && panel.style.display === 'flex' && content && content.querySelector('.game-lobby') && !currentRoom) {
            loadOpenRooms();
        }
    }, 5000);
})();
