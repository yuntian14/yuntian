// ChatX - Main JavaScript
// Version: 1.0

(function() {
    'use strict';

    const API = {
        auth: 'api/auth.php',
        chat: 'api/chat.php',
        users: 'api/users.php',
        groups: 'api/groups.php'
    };

    const state = {
        user: window.ChatX?.user || null,
        token: (window.ChatX?.token && window.ChatX.token !== 'logged-in-session' ? window.ChatX.token : '') || localStorage.getItem('chatx_token') || '',
        currentTab: 'chat',
        currentChat: null,
        chatType: null,
        friends: [],
        groups: [],
        requests: [],
        messages: [],
        pollTimer: null,
        unreadTimer: null
    };

    // Utility
    function $(sel) { return document.querySelector(sel); }
    function $$(sel) { return document.querySelectorAll(sel); }
    function h(str) { const div = document.createElement('div'); div.innerHTML = str; return div.textContent; }
    function escapeHtml(str) { if (!str) return ''; return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
    function formatTime(ts) { if (!ts) return ''; const d = new Date(ts.replace(' ', 'T') + 'Z'); if (isNaN(d.getTime())) return ''; const now = new Date(); const diff = now - d; if (diff < 60000) return '刚刚'; if (diff < 3600000) return Math.floor(diff/60000) + '分钟前'; if (diff < 86400000) return Math.floor(diff/3600000) + '小时前'; return d.toLocaleDateString('zh-CN', {month:'short', day:'numeric'}); }
    function avatarHTML(user, size) {
        size = size || 40;
        const name = user.nickname || user.username || '?';
        const avatar = user.avatar || '';
        const isDefault = !avatar || avatar === 'default.png';
        const letter = name.charAt(0).toUpperCase();
        const hash = Array.from(name).reduce((a,c)=>a+c.charCodeAt(0),0);
        const colors = ['#ff9a9e','#fad0c4','#a18cd1','#fbc2eb','#8fd3f4','#84fab0','#fccb90','#e0c3fc'];
        const bg = `linear-gradient(135deg, ${colors[hash % colors.length]}, ${colors[(hash+3) % colors.length]})`;
        const uid = user.id || '';
        const frame = user.avatar_frame || '';
        const frameClass = frame ? 'frame-' + frame : '';
        const clickOnclick = uid ? "onclick=\"window.location.href='profile.php?user_id=${uid}'\"" : '';
        if (!isDefault) {
            const src = avatar.startsWith('http') ? avatar : avatar;
            return `<div class="avatar-frame ${frameClass}" style="position:relative;flex-shrink:0;">
                <img src="${escapeHtml(src)}" style="width:${size}px;height:${size}px;border-radius:50%;object-fit:cover;flex-shrink:0;border:2px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.1);cursor:pointer;" ${clickOnclick} onerror="this.style.display='none';this.nextElementSibling.style.display='flex';">
                <div style="width:${size}px;height:${size}px;background:${bg};color:#fff;display:${isDefault?'flex':'none'};align-items:center;justify-content:center;border-radius:50%;font-size:${size*0.4}px;font-weight:600;flex-shrink:0;border:2px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.1);">${escapeHtml(letter)}</div>
            </div>`;
        }
        return `<div class="avatar-frame ${frameClass}" style="position:relative;flex-shrink:0;">
            <div style="width:${size}px;height:${size}px;background:${bg};color:#fff;display:flex;align-items:center;justify-content:center;border-radius:50%;font-size:${size*0.4}px;font-weight:600;flex-shrink:0;border:2px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.1);cursor:pointer;" ${clickOnclick}>${escapeHtml(letter)}</div>
        </div>`;
    }

    // API
    async function api(url, options) {
        const headers = {
            'Content-Type': 'application/json'
        };
        if (state.token && state.token !== 'logged-in-session') {
            headers['X-Auth-Token'] = state.token;
        }
        const res = await fetch(url, {
            ...options,
            headers: {
                ...headers,
                ...(options?.headers || {})
            }
        });
        const data = await res.json().catch(() => null);
        if (!res.ok) {
            if (data && data.error) throw new Error(data.error);
            throw new Error('请求失败 (' + res.status + ')');
        }
        return data || {};
    }

    // Auth
    async function checkAuth() {
        const loopKey = 'chatx_auth_loops';
        const loops = parseInt(sessionStorage.getItem(loopKey) || '0');
        if (loops > 5) {
            document.body.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100vh;flex-direction:column;font-family:sans-serif;"><h2>登录状态异常</h2><p style="color:#666;">检测到反复跳转，请清除浏览器数据后重新打开 index.php</p><button class="btn btn-primary" onclick="sessionStorage.removeItem(\'' + loopKey + '\'); window.location.href=\'index.php\';">重试</button></div>';
            return false;
        }
        try {
            const data = await api(API.auth + '?action=me');
            if (data.user) {
                state.user = data.user;
                window.ChatX.user = data.user;
                state.token = state.token || 'logged-in-session';
                sessionStorage.removeItem(loopKey);
                return true;
            }
        } catch (e) {}

        sessionStorage.setItem(loopKey, loops + 1);

        // Loop protection: if already on chat page, don't bounce back to index
        if (window.location.pathname.includes('chat.php')) {
            document.body.innerHTML = '<div style="display:flex;align-items:center;justify-content:center;height:100vh;flex-direction:column;font-family:sans-serif;"><h2>登录已失效</h2><p style="color:#666;">请关闭此页面，重新打开 index.php 登录</p><button class="btn btn-primary" onclick="window.location.href=\'index.php\';">去登录</button></div>';
            return false;
        }
        window.location.href = 'index.php';
        return false;
    }

    // Tabs
    function initTabs() {
        $$('.nav-item[data-tab]').forEach(btn => {
            btn.addEventListener('click', () => {
                const tab = btn.dataset.tab;
                if (tab === 'settings') {
                    const sidebar = $('#sidebar');
                    const overlay = $('#sidebarOverlay');
                    if (sidebar) sidebar.classList.remove('open');
                    if (overlay) overlay.style.display = 'none';
                    showSettings();
                    return;
                }
                if (tab === 'logout') { doLogout(); return; }
                if (tab === 'games') {
                    const sidebar = $('#sidebar');
                    const overlay = $('#sidebarOverlay');
                    if (sidebar) sidebar.classList.remove('open');
                    if (overlay) overlay.style.display = 'none';
                    if (window.ChatX && window.ChatX.showGames) window.ChatX.showGames();
                    return;
                }
                if (tab === 'casino') {
                    const sidebar = $('#sidebar');
                    const overlay = $('#sidebarOverlay');
                    if (sidebar) sidebar.classList.remove('open');
                    if (overlay) overlay.style.display = 'none';
                    if (window.ChatX && window.ChatX.showCasino) window.ChatX.showCasino();
                    return;
                }
                if (tab === 'ai') {
                    const sidebar = $('#sidebar');
                    const overlay = $('#sidebarOverlay');
                    if (sidebar) sidebar.classList.remove('open');
                    if (overlay) overlay.style.display = 'none';
                    if (window.ChatX && window.ChatX.showAI) window.ChatX.showAI();
                    return;
                }
                $$('.nav-item').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                state.currentTab = tab;
                $('#listTitle').textContent = tab === 'chat' ? '消息' : tab === 'contacts' ? '联系人' : '群组';
                $('#btnAdd').style.display = tab === 'contacts' ? 'flex' : 'none';
                if (tab === 'chat') loadChatList();
                else if (tab === 'contacts') loadContacts();
                else if (tab === 'groups') loadGroups();
                const sidebar = $('#sidebar');
                const overlay = $('#sidebarOverlay');
                if (sidebar) sidebar.classList.remove('open');
                if (overlay) overlay.style.display = 'none';
            });
        });
    }

    // List Loading
    async function loadChatList() {
        const el = $('#listContent');
        el.innerHTML = '<div class="loading">加载中...</div>';
        try {
            const [friendsData, groupsData] = await Promise.all([
                api(API.users + '?action=list&type=friends').catch(() => ({friends:[]})),
                api(API.groups + '?action=list').catch(() => ({groups:[]}))
            ]);
            state.friends = friendsData.friends || [];
            state.groups = groupsData.groups || [];
            renderChatList();
        } catch (e) {
            el.innerHTML = '<div class="loading" style="color:red">加载失败: ' + escapeHtml(e.message) + '</div>';
        }
    }

    function renderChatList() {
        const el = $('#listContent');
        const items = [];
        items.push({
            id: 1, type: 'world', name: '🌐 世界频道',
            nickname: '🌐 世界频道', avatar: '', status: null, lastMsg: '', lastTime: '', unread: 0
        });
        state.friends.forEach(f => {
            items.push({
                id: f.id, type: 'private', name: f.nickname || f.username,
                avatar: f.avatar, avatar_frame: f.avatar_frame, status: f.status,
                lastMsg: f.last_message, lastTime: f.last_time, unread: f.unread
            });
        });
        state.groups.forEach(g => {
            items.push({
                id: g.id, type: 'group', name: g.name,
                avatar: g.avatar, status: null,
                lastMsg: g.last_message, lastTime: g.last_time, unread: 0
            });
        });
        // Sort by last time (newest first, but we have limited data, so keep original order)
        if (items.length === 0) {
            el.innerHTML = '<div class="loading">暂无消息</div>';
            return;
        }
        el.innerHTML = items.map(item => `
            <div class="list-item" data-type="${item.type}" data-id="${item.id}">
                ${avatarHTML(item, 40)}
                <div class="list-item-info">
                    <div class="list-item-name">${escapeHtml(item.name)}</div>
                    <div class="list-item-meta">${escapeHtml(item.lastMsg || '')}</div>
                </div>
                <div style="text-align:right;">
                    <div class="list-item-time">${item.lastTime || ''}</div>
                    ${item.unread > 0 ? `<span class="unread-badge">${item.unread}</span>` : ''}
                </div>
            </div>
        `).join('');
        bindListClicks();
    }

    function bindListClicks() {
        $$('.list-item').forEach(item => {
            item.addEventListener('click', () => {
                const type = item.dataset.type;
                const id = parseInt(item.dataset.id);
                openChat(type, id);
                $$('.list-item').forEach(i => i.classList.remove('active'));
                item.classList.add('active');
            });
        });
    }

    // Contacts
    async function loadContacts() {
        const el = $('#listContent');
        el.innerHTML = '<div class="loading">加载中...</div>';
        try {
            const [friendsData, requestsData] = await Promise.all([
                api(API.users + '?action=list&type=friends').catch(() => ({friends:[]})),
                api(API.users + '?action=list&type=requests').catch(() => ({requests:[]}))
            ]);
            state.friends = friendsData.friends || [];
            state.requests = requestsData.requests || [];
            renderContacts();
        } catch (e) {
            el.innerHTML = '<div class="loading" style="color:red">加载失败: ' + escapeHtml(e.message) + '</div>';
        }
    }

    function renderContacts() {
        const el = $('#listContent');
        let html = '';
        if (state.requests.length) {
            html += '<div class="contact-section"><div class="contact-section-title">好友请求 (' + state.requests.length + ')</div></div>';
            html += state.requests.map(r => `
                <div class="request-item">
                    ${avatarHTML(r, 36)}
                    <div class="request-info">
                        <div class="list-item-name">${escapeHtml(r.nickname || r.username)}</div>
                        <div class="list-item-meta">@${escapeHtml(r.username)} · ${r.created_at ? formatTime(r.created_at) : ''}</div>
                    </div>
                    <div class="request-actions">
                        <button class="btn btn-sm btn-accept" onclick="ChatX.acceptRequest(${r.id})">接受</button>
                        <button class="btn btn-sm btn-reject" onclick="ChatX.rejectRequest(${r.id})">拒绝</button>
                    </div>
                </div>
            `).join('');
        }
        const online = state.friends.filter(f => f.status === 'online');
        const offline = state.friends.filter(f => f.status !== 'online');
        if (online.length) {
            html += '<div class="contact-section"><div class="contact-section-title">在线 - ' + online.length + '</div></div>';
            html += online.map(f => contactItem(f)).join('');
        }
        if (offline.length) {
            html += '<div class="contact-section"><div class="contact-section-title">离线 - ' + offline.length + '</div></div>';
            html += offline.map(f => contactItem(f)).join('');
        }
        if (!state.friends.length && !state.requests.length) html = '<div class="loading">暂无联系人</div>';
        el.innerHTML = html;
        bindContactClicks();
    }

    window.ChatX.acceptRequest = async function(reqId) {
        try {
            await api(API.users + '?action=accept', { method: 'POST', body: JSON.stringify({request_id: reqId}) });
            state.requests = state.requests.filter(r => r.id !== reqId);
            renderContacts();
            loadChatList();
        } catch (e) { alert(e.message); }
    };
    window.ChatX.rejectRequest = async function(reqId) {
        try {
            await api(API.users + '?action=reject', { method: 'POST', body: JSON.stringify({request_id: reqId}) });
            state.requests = state.requests.filter(r => r.id !== reqId);
            renderContacts();
        } catch (e) { alert(e.message); }
    };

    function contactItem(f) {
        return `
            <div class="list-item" data-type="private" data-id="${f.id}">
                ${avatarHTML(f, 40)}
                <div class="status-dot status-${f.status || 'offline'}"></div>
                <div class="list-item-info">
                    <div class="list-item-name">${escapeHtml(f.nickname || f.username)}</div>
                </div>
            </div>
        `;
    }

    function bindContactClicks() {
        $$('.list-item').forEach(item => {
            item.addEventListener('click', () => {
                const type = item.dataset.type;
                const id = parseInt(item.dataset.id);
                openChat(type, id);
            });
        });
    }

    // Groups
    async function loadGroups() {
        const el = $('#listContent');
        el.innerHTML = '<div class="loading">加载中...</div>';
        try {
            const data = await api(API.groups + '?action=list');
            state.groups = data.groups || [];
            renderGroups();
        } catch (e) {
            el.innerHTML = '<div class="loading" style="color:red">加载失败: ' + escapeHtml(e.message) + '</div>';
        }
    }

    function renderGroups() {
        const el = $('#listContent');
        if (!state.groups.length) {
            el.innerHTML = `<div style="text-align:center;padding:40px 0;color:#999;">暂无群组<br><br><button class="btn btn-primary" onclick="ChatX.showCreateGroup()">创建群组</button></div>`;
            return;
        }
        const html = `<div style="padding:8px 16px;text-align:right;"><button class="btn btn-primary" style="padding:6px 12px;font-size:12px;" onclick="ChatX.showCreateGroup()">+ 创建群组</button></div>` + state.groups.map(g => `
            <div class="list-item" data-type="group" data-id="${g.id}">
                ${avatarHTML({nickname: g.name, avatar: g.avatar}, 40)}
                <div class="list-item-info">
                    <div class="list-item-name">${escapeHtml(g.name)}</div>
                    <div class="list-item-meta">${escapeHtml(g.last_message || '')}</div>
                </div>
                <div class="list-item-time">${g.last_time || ''}</div>
            </div>
        `).join('');
        el.innerHTML = html;
        $$('.list-item').forEach(item => {
            item.addEventListener('click', () => {
                const type = item.dataset.type;
                const id = parseInt(item.dataset.id);
                openChat(type, id);
            });
        });
    }

    // Chat Window
    async function openChat(type, id) {
        // Close sidebar on mobile
        const sidebar = $('#sidebar');
        const overlay = $('#sidebarOverlay');
        if (sidebar) sidebar.classList.remove('open');
        if (overlay) overlay.style.display = 'none';
        // Mobile: hide list panel when opening chat
        const listPanel = document.querySelector('.list-panel');
        if (listPanel && window.innerWidth <= 768) {
            listPanel.classList.add('hidden-mobile');
        }

        try {
        state.currentChat = id;
        state.chatType = type;
        if (typeof hideTypingIndicatorName === 'function') hideTypingIndicatorName();
        $('#listTitle').textContent = type === 'group' ? '群组聊天' : (type === 'world' ? '世界频道' : '聊天');
        renderChatPlaceholder();
            let title = '世界频道';
            if (type === 'private') {
                const friend = state.friends.find(f => f.id === id);
                if (friend) title = friend.nickname || friend.username;
            } else if (type === 'group') {
                const grp = state.groups.find(g => g.id === id);
                if (grp) title = grp.name;
            }
            renderChatHeader(title, type, id);
            await loadMessages(type, id);
            // Mark messages as read
            if (type === 'private') {
                try { await api(API.chat + '?action=read', { method: 'POST', body: JSON.stringify({with: id}) }); } catch(e) {}
            } else if (type === 'group' || type === 'world') {
                try { await api(API.chat + '?action=read', { method: 'POST', body: JSON.stringify({group_id: id}) }); } catch(e) {}
            }
            renderMessages();
            startPolling(type, id);
            updateUnread();
        } catch (e) {
            $('#chatArea').innerHTML = '<div class="chat-placeholder"><p style="color:red">加载失败: ' + escapeHtml(e.message) + '</p></div>';
        }
    }

    function renderChatPlaceholder() {
        $('#chatArea').innerHTML = '<div class="chat-placeholder"><div class="placeholder-icon"><svg viewBox="0 0 24 24" width="64" height="64" fill="none" stroke="#c0c4cc" stroke-width="1.5"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg></div><p>选择一个联系人开始聊天</p></div>';
    }

    function renderChatHeader(title, type, id) {
        const actions = type === 'group'
            ? `<button class="icon-btn" id="btnGroupInfo" title="群信息"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg></button>`
            : (type === 'world'
                ? `<button class="icon-btn" id="btnWorldInfo" title="世界频道"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg></button>`
                : `<button class="icon-btn" id="btnUserInfo" title="用户信息"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg></button>`);
        $('#chatArea').innerHTML = `
            <div class="chat-header">
                <div class="chat-header-info">
                    <button class="icon-btn" id="btnBack" style="margin-right:8px;display:none;" title="返回">
                        <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"></polyline></svg>
                    </button>
                    <div class="avatar avatar-md">${title.charAt(0)}</div>
                    <div style="margin-left:12px;">
                        <div class="chat-header-name">${escapeHtml(title)}</div>
                        <div style="font-size:12px;color:#999;" id="typingIndicator"></div>
                    </div>
                </div>
                <div class="chat-header-actions">${actions}</div>
            </div>
            <div class="chat-messages" id="chatMessages"></div>
            <div class="pinned-bar" id="pinnedBar" style="display:none;"></div>
            <div class="chat-input-area">
                <button class="icon-btn" id="btnEmoji" title="表情" data-icon="emoji">😊</button>
                <button class="icon-btn" id="btnUpload" title="上传图片" data-icon="upload">📷</button>
                <input type="file" id="fileInput" accept="image/*" style="display:none;">
                <textarea class="chat-input" id="chatInput" rows="1" placeholder="输入消息..."></textarea>
                <button class="btn-send" id="btnSend" data-icon="send">发送</button>
            </div>
        `;
        // Bind events after render
        setTimeout(() => {
            const input = $('#chatInput');
            const btn = $('#btnSend');
            if (input) {
                input.addEventListener('keydown', e => {
                    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
                });
                input.addEventListener('input', () => {
                    input.style.height = 'auto';
                    input.style.height = Math.min(input.scrollHeight, 120) + 'px';
                    if (state.currentChat && input.value.trim()) {
                        api(API.chat + '?action=typing', { method: 'POST', body: JSON.stringify({ chat_type: state.chatType, chat_id: state.currentChat }) }).catch(() => {});
                    }
                });
            }
            if (btn) btn.addEventListener('click', sendMessage);
            if ($('#btnEmoji')) {
                $('#btnEmoji').addEventListener('click', () => showEmojiPicker());
            }
            if ($('#btnUpload')) {
                $('#btnUpload').addEventListener('click', () => $('#fileInput').click());
            }
            if ($('#fileInput')) {
                $('#fileInput').addEventListener('change', handleFileUpload);
            }
            if ($('#btnBack')) {
                $('#btnBack').addEventListener('click', () => {
                    state.currentChat = null;
                    state.chatType = null;
                    stopPolling();
                    renderChatPlaceholder();
                    $('#listTitle').textContent = '消息';
                    $$('.list-item').forEach(i => i.classList.remove('active'));
                    const listPanel = document.querySelector('.list-panel');
                    if (listPanel && window.innerWidth <= 768) {
                        listPanel.classList.remove('hidden-mobile');
                    }
                });
            }
            if (type === 'group' && $('#btnGroupInfo')) {
                $('#btnGroupInfo').addEventListener('click', () => showGroupInfo(id));
            }
            if (type === 'world' && $('#btnWorldInfo')) {
                $('#btnWorldInfo').addEventListener('click', () => {
                    showModal('世界频道', `
                        <div style="text-align:center;padding:16px 0;">
                            <div style="font-size:48px;margin-bottom:12px;">🌐</div>
                            <div style="font-size:18px;font-weight:600;">世界频道</div>
                            <div style="color:#666;margin-top:8px;">这是一个公共频道，所有人可见</div>
                            <div style="color:#999;font-size:12px;margin-top:4px;">请文明发言</div>
                        </div>
                    `);
                });
            }
            if (type === 'private' && $('#btnUserInfo')) {
                $('#btnUserInfo').addEventListener('click', () => showUserInfo(id));
            }
            initMessageContextMenu();
            // Mobile back button
            if (window.innerWidth <= 768) {
                const backBtn = $('#btnBack');
                if (backBtn) backBtn.style.display = 'flex';
            }
        }, 0);
    }

    function handleFileUpload(e) {
        const file = e.target.files[0];
        if (!file) return;
        if (file.size > 2 * 1024 * 1024) { alert('图片大小不能超过2MB'); return; }
        const reader = new FileReader();
        reader.onload = function(evt) {
            const base64 = evt.target.result;
            sendImageMessage(base64);
        };
        reader.onerror = function() {
            alert('读取图片失败，请重试');
        };
        reader.readAsDataURL(file);
        e.target.value = '';
    }

    async function sendImageMessage(base64) {
        if (!state.currentChat) { alert('请先打开一个聊天'); return; }
        try {
            const body = {
                type: 'image',
                content: '[图片]',
                file_path: base64,
                ...(state.chatType === 'private' ? { to: state.currentChat } : { group_id: state.currentChat })
            };
            const data = await api(API.chat + '?action=send', { method: 'POST', body: JSON.stringify(body) });
            if (data.message) {
                state.messages.push(data.message);
                renderMessages();
                if (state.currentTab === 'chat') loadChatList();
            }
        } catch (e) { alert('发送失败: ' + e.message); }
    }

    function showEmojiPicker() {
        const emojis = ['😀','😁','😂','🤣','😃','😄','😅','😆','😉','😊','😋','😎','😍','😘','😗','😙','😚','🙂','🤗','🤔','😐','😑','😶','🙄','😏','😣','😥','😮','🤐','😯','😪','😫','😴','😌','😛','😜','😝','🤤','😒','😓','😔','😕','🙃','🤑','😲','🙁','😖','😞','😟','😤','😢','😭','😦','😧','😨','😩','🤯','😬','😰','😱','🥵','🥶','😳','🤪','😵','😡','😠','🤬','😷','🤒','🤕','🤢','🤮','🤧','😇','🤠','🤡','🥳','🥴','🥺','🤥','🤫','🤭','🧐','🤓','😈','👿','👹','👺','💀','👻','👽','🤖','💩','😺','😸','😹','😻','😼','😽','🙀','😿','😾','👋','🤚','🖐','✋','🖖','👌','🤌','🤏','✌️','🤞','🫰','🤟','🤘','🤙','👈','👉','👆','🖕','👇','☝️','👍','👎','✊','👊','🤛','🤜','👏','🙌','👐','🫶','🤝','🙏','✍️','💪','🦾','🦿','🦵','🦶','👂','🦻','👃','🧠','🫀','🫁','🦷','🦴','👀','👁','👅','👄','🫦','💋','🩷','❤️','🧡','💛','💚','💙','💜','🖤','🩶','🤍','🤎','❣️','💕','💞','💓','💗','💖','💘','💝','💟','☮️','✝️','☪️','🕉','☸️','✡️','🔯','🕎','☯️','☦️','🛐','⛎','♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓','🆔','⚛️','🉑','☢️','☣️','📴','📳','🈶','🈚','🈸','🈺','🈷️','✴️','🆚','💮','🉐','㊙️','㊗️','🈴','🈵','🈹','🈲','🅰️','🅱️','🆎','🆑','🅾️','🆘','❌','⭕','🛑','⛔','📛','🚫','💯','💢','♨️','🚷','🚯','🚳','🚱','🔞','📵','🚭','❗','❕','❓','❔','‼️','⁉️','🔅','🔆','〽️','⚠️','🚸','🔱','⚜️','🔰','♻️','✅','🈯','💹','❇️','✳️','❎','🌐','💠','Ⓜ️','🌀','💤','🏧','🚾','♿','🅿️','🛗','🈳','🈂','🛂','🛃','🛄','🛅','🛜','🚹','🚺','🚼','⚧','🚻','🚮','🎦','📶','🈁','🔣','ℹ️','🔤','🔡','🔠','🔟','🔢','⏺','⏮','⏭','⏩','⏪','⏫','⏬','🎵','🎶','➕','➖','✖️','➗','💲','💱','™️','©️','®️','👁️','🔚','🔙','🔛','🔝','🔜','〰️','➰','➿','✔️','☑️','🔘','🔴','🟠','🟡','🟢','🔵','🟣','⚫','⚪','🟤','🔺','🔻','🔸','🔹','🔶','🔷','🔳','🔲','▪️','▫️','◾','◽','◼️','◻️','🟥','🟧','🟨','🟩','🟦','🟪','⬛','⬜','🟫','🔈','🔇','🔉','🔊','🔔','🔕','📣','📢','💬','💭','🗯','♠️','♣️','♥️','♦️','🃏','🎴','🀄','🕐','🕑','🕒','🕓','🕔','🕕','🕖','🕗','🕘','🕙','🕚','🕛','🕜','🕝','🕞','🕟','🕠','🕡','🕢','🕣','🕤','🕥','🕦','🕧','🛎','🔋','🪫','🔌','💻','🖥','🖨','⌨️','🖱','🖲','💽','💾','💿','📀','🧮','🎥','🎞','📽','🎬','📺','📷','📸','📹','📼','🔍','🔎','🕯','💡','🔦','🏮','🪔','📔','📕','📖','📗','📘','📙','📚','📓','📒','📃','📜','📄','📰','🗞','📑','🔖','🏷','💰','🪙','💴','💵','💶','💷','💸','💳','🧾','✉️','💌','📧','📨','📩','📤','📥','📦','📫','📪','📬','📭','📮','🗳','✏️','✒️','🖋','🖊','🖌','🖍','📝','💼','📁','📂','🗂','📅','📆','🗒','🗓','📇','📈','📉','📊','📋','📌','📍','📎','🖇','📏','📐','✂️','🗃','🗄','🗑','🔒','🔓','🔏','🔐','🔑','🗝','🔨','🪓','⛏','⚒','🛠','🗡','⚔️','💣','🪃','🏹','🛡','🪚','🔧','🪛','🔩','⚙️','🗜','⚗️','🪜','🧪','🧫','🧬','🔬','🔭','📡','💉','🩸','💊','🩹','🩼','🩺','🌡','🩻','🚪','🛗','🪞','🪟','🛏','🛋','🪑','🚽','🪠','🚿','🛁','🪤','🪒','🧴','🧷','🧹','🧺','🧻','🪣','🧼','🫧','🪥','🧽','🧯','🛒','🚬','⚰️','🪦','⚱️','🧿','🪬','🗿','🪧','🚰','💘','💝','💖','💗','💓','💞','💕','❣️','💔','❤️','🧡','💛','💚','💙','💜','🤎','🖤','🤍','💯','💢','💥','💫','💦','💨','🕳','💣','💬','👁️‍🗨️','🗨','🗯','💭','💤','👋','🤚','🖐','✋','🖖','👌','🤌','🤏','✌️','🤞','🫰','🤟','🤘','🤙','🫵','🖕','👇','☝️','👍','👎','✊','👊','🤛','🤜','👏','🙌','🫶','👐','🤲','🤝','🙏','✍️','💪','🦾','🦿','🦵','🦶','👂','🦻','👃','🧠','🫀','🫁','🦷','🦴','👀','👁','👅','👄','🫦','👶','🧒','👦','👧','🧑','👱','👨','🧔','👨‍🦰','👨‍🦱','👨‍🦲','👨‍🦳','👩','👩‍🦰','🧑‍🦰','👩‍🦱','🧑‍🦱','👩‍🦲','🧑‍🦲','👩‍🦳','🧑‍🦳','👱‍♀️','👱‍♂️','🧓','👴','👵','🙍','🙍‍♂️','🙍‍♀️','🙎','🙎‍♂️','🙎‍♀️','🙅','🙅‍♂️','🙅‍♀️','🙆','🙆‍♂️','🙆‍♀️','💁','💁‍♂️','💁‍♀️','🙋','🙋‍♂️','🙋‍♀️','🧏','🧏‍♂️','🧏‍♀️','🙇','🙇‍♂️','🙇‍♀️','🤦','🤦‍♂️','🤦‍♀️','🤷','🤷‍♂️','🤷‍♀️','🧑‍⚕️','👨‍⚕️','👩‍⚕️','🧑‍🎓','👨‍🎓','👩‍🎓','🧑‍🏫','👨‍🏫','👩‍🏫','🧑‍⚖️','👨‍⚖️','👩‍⚖️','🧑‍🌾','👨‍🌾','👩‍🌾','🧑‍🍳','👨‍🍳','👩‍🍳','🧑‍🔧','👨‍🔧','👩‍🔧','🧑‍🏭','👨‍🏭','👩‍🏭','🧑‍💼','👨‍💼','👩‍💼','🧑‍🔬','👨‍🔬','👩‍🔬','🧑‍💻','👨‍💻','👩‍💻','🧑‍🎤','👨‍🎤','👩‍🎤','🧑‍🎨','👨‍🎨','👩‍🎨','🧑‍✈️','👨‍✈️','👩‍✈️','🧑‍🚀','👨‍🚀','👩‍🚀','🧑‍🚒','👨‍🚒','👩‍🚒','👮','👮‍♂️','👮‍♀️','🕵️','🕵️‍♂️','🕵️‍♀️','💂','💂‍♂️','💂‍♀️','🥷','👷','👷‍♂️','👷‍♀️','🫅','🤴','👸','👳','👳‍♂️','👳‍♀️','👲','🧕','🤰','🫄','🫃','🤱','👩‍🍼','👨‍🍼','🧑‍🍼','👼','👸','🎅','🤶','🧑‍🎄','🦸','🦸‍♂️','🦸‍♀️','🦹','🦹‍♂️','🦹‍♀️','🧙','🧙‍♂️','🧙‍♀️','🧚','🧚‍♂️','🧚‍♀️','🧛','🧛‍♂️','🧛‍♀️','🧜','🧜‍♂️','🧜‍♀️','🧝','🧝‍♂️','🧝‍♀️','🧞','🧞‍♂️','🧞‍♀️','🧟','🧟‍♂️','🧟‍♀️','🧌','💆','💆‍♂️','💆‍♀️','💇','💇‍♂️','💇‍♀️','🚶','🚶‍♂️','🚶‍♀️','🧍','🧍‍♂️','🧍‍♀️','🧎','🧎‍♂️','🧎‍♀️','🧑‍🦯','👨‍🦯','👩‍🦯','🧑‍🦼','👨‍🦼','👩‍🦼','🧑‍🦽','👨‍🦽','👩‍🦽','🏃','🏃‍♂️','🏃‍♀️','💃','🕺','🕴','👯','👯‍♂️','👯‍♀️','🧖','🧖‍♂️','🧖‍♀️','🧘','🧑‍🤝‍🧑','👭','👫','👬','💏','💑','👨‍👩‍👦','👨‍👩‍👧','👨‍👩‍👧‍👦','👨‍👩‍👦‍👦','👨‍👩‍👧‍👧','👨‍👦','👨‍👦‍👦','👨‍👧','👨‍👧‍👦','👨‍👧‍👧','👩‍👦','👩‍👦‍👦','👩‍👧','👩‍👧‍👦','👩‍👧‍👧','🗣','👤','👥','🫂','👣','🧳','🌂','☂️','🧵','🪡','🪢','🧶','👓','🕶','🥽','🥼','🦺','👔','👕','👖','🧣','🧤','🧥','🧦','👗','👘','🥻','🩱','🩲','🩳','👙','👚','👛','👜','👝','🎒','🩴','👞','👟','🥾','🥿','👠','👡','🩰','👢','👑','👒','🎩','🎓','🧢','🪖','⛑','📿','💄','💍','💎','🔇','🔈','🔉','🔊','📢','📣','📯','🔔','🔕','🎼','🎵','🎶','🎙','🎚','🎛','🎤','🎧','📻','🎷','🪗','🎸','🎹','🎺','🎻','🪕','🥁','🪘','🪇','🪈','📱','📲','☎️','📞','📟','📠','🔋','🪫','🔌','💻','🖥','🖨','⌨️','🖱','🖲','💽','💾','💿','📀','🧮','🎥','🎞','📽','🎬','📺','📷','📸','📹','📼','🔍','🔎','🕯','💡','🔦','🏮','🪔','📔','📕','📖','📗','📘','📙','📚','📓','📒','📃','📜','📄','📰','🗞','📑','🔖','🏷','💰','🪙','💴','💵','💶','💷','💸','💳','🧾','✉️','💌','📧','📨','📩','📤','📥','📦','📫','📪','📬','📭','📮','🗳','✏️','✒️','🖋','🖊','🖌','🖍','📝','💼','📁','📂','🗂','📅','📆','🗒','🗓','📇','📈','📉','📊','📋','📌','📍','📎','🖇','📏','📐','✂️','🗃','🗄','🗑','🔒','🔓','🔏','🔐','🔑','🗝','🔨','🪓','⛏','⚒','🛠','🗡','⚔️','💣','🪃','🏹','🛡','🪚','🔧','🪛','🔩','⚙️','🗜','⚗️','🪜','🧪','🧫','🧬','🔬','🔭','📡','💉','🩸','💊','🩹','🩼','🩺','🌡','🩻','🚪','🛗','🪞','🪟','🛏','🛋','🪑','🚽','🪠','🚿','🛁','🪤','🪒','🧴','🧷','🧹','🧺','🧻','🪣','🧼','🫧','🪥','🧽','🧯','🛒','🚬','⚰️','🪦','⚱️','🧿','🪬','🗿','🪧','🚰','💘','💝','💖','💗','💓','💞','💕','❣️','💔','❤️','🧡','💛','💚','💙','💜','🤎','🖤','🤍','💯','💢','💥','💫','💦','💨','🕳','💣','💬','👁️‍🗨️','🗨','🗯','💭','💤'];
        showEmojiPanel(emojis);
    }

    function showEmojiPanel(emojis) {
        let panel = $('#emojiPanel');
        if (panel) { panel.remove(); return; }
        panel = document.createElement('div');
        panel.id = 'emojiPanel';
        panel.style.cssText = 'position:absolute;bottom:60px;left:10px;background:#fff;border:1px solid var(--border);border-radius:var(--radius);padding:8px;width:280px;max-height:200px;overflow-y:auto;box-shadow:var(--shadow);z-index:100;display:grid;grid-template-columns:repeat(8,1fr);gap:4px;';
        panel.innerHTML = emojis.map(e => `<span style="cursor:pointer;font-size:20px;text-align:center;padding:4px;border-radius:4px;" onmouseover="this.style.background='#f0f0f0'" onmouseout="this.style.background='transparent'">${e}</span>`).join('');
        panel.querySelectorAll('span').forEach(span => {
            span.addEventListener('click', () => {
                const input = $('#chatInput');
                if (input) { input.value += span.textContent; input.focus(); }
                panel.remove();
            });
        });
        const inputArea = document.querySelector('.chat-input-area');
        if (inputArea) inputArea.appendChild(panel);
    }

    // Context menu for messages
    async function initMessageContextMenu() {
        $('#chatMessages')?.addEventListener('contextmenu', async e => {
            const msgEl = e.target.closest('.message');
            if (!msgEl) return;
            e.preventDefault();
            const msgId = msgEl.dataset.msgId;
            if (!msgId) return;
            const msg = state.messages.find(m => m.id == msgId);
            if (!msg) return;
            const options = [];
            if (!msg.is_recall) {
                options.push('💬 回复');
                options.push('📌 置顶');
                options.push('➡️ 转发');
            }
            if (msg.is_me && !msg.is_recall) {
                options.push('❌ 撤回');
            }
            if (!options.length) return;
            showModal('消息操作', `<div style="display:flex;flex-direction:column;gap:8px;">${options.map((o, idx) => `<button class="btn btn-primary" data-action-idx="${idx}">${o}</button>`).join('')}</div>`);
            const selected = await promptChoice(options.map(o => o.split(' ').slice(1).join(' ')));
            if (selected === null) return;
            const idx = options.findIndex(o => o.endsWith(selected));
            if (idx === -1) return;
            if (options[idx].includes('回复')) showReactionPicker(msg.id);
            else if (options[idx].includes('置顶')) togglePin(msg.id);
            else if (options[idx].includes('转发')) forwardMessage(msg.id);
            else if (options[idx].includes('撤回')) recallMessage(msg.id);
        });
        // Mobile long press
        let longPressTimer;
        $('#chatMessages')?.addEventListener('touchstart', e => {
            const msgEl = e.target.closest('.message');
            if (!msgEl) return;
            longPressTimer = setTimeout(() => {
                const msgId = msgEl.dataset.msgId;
                const msg = state.messages.find(m => m.id == msgId);
                if (msg && msg.is_me && !msg.is_recall && confirm('撤回这条消息？')) {
                    recallMessage(msg.id);
                }
            }, 600);
        });
        $('#chatMessages')?.addEventListener('touchend', () => clearTimeout(longPressTimer));
        $('#chatMessages')?.addEventListener('touchmove', () => clearTimeout(longPressTimer));
    }

    function showReactionPicker(msgId) {
        const emojis = ['👍','❤️','😂','😮','😢','😡','🎉','🔥'];
        const msg = state.messages.find(m => m.id == msgId);
        const hasReaction = (emoji) => (msg?.reactions || []).some(r => r.emoji === emoji && r.users?.includes(window.ChatX.user?.nickname || window.ChatX.user?.username || ''));
        showModal('表情回应', `<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;">${emojis.map(e => `<button class="btn btn-primary reaction-btn" data-emoji="${e}">${e} ${hasReaction(e) ? '✅' : ''}</button>`).join('')}</div>`);
        document.querySelectorAll('.reaction-btn').forEach(btn => {
            btn.addEventListener('click', async () => {
                const emoji = btn.dataset.emoji;
                try {
                    await api(API.chat + '?action=reaction', { method: 'POST', body: JSON.stringify({ message_id: msgId, emoji, remove: hasReaction(emoji) }) });
                    await loadMessages(state.chatType, state.currentChat);
                    closeModal();
                } catch (e) { alert(e.message); }
            });
        });
    }

    async function togglePin(msgId) {
        if (!confirm('确定置顶/取消置顶该消息？')) return;
        try {
            const chatType = state.chatType;
            const chatId = state.currentChat;
            const body = { message_id: msgId, chat_type: chatType, chat_id: chatId };
            if ((await api(API.chat + '?action=pin', { method: 'POST', body: JSON.stringify(body) })).pinned) {
                state.pinnedMessages = data.pinned;
            }
            await loadMessages(state.chatType, state.currentChat);
        } catch (e) { alert(e.message); }
    }

    async function forwardMessage(msgId) {
        const target = await promptInput('转发到', '请输入目标用户ID或群组ID');
        if (!target) return;
        const num = parseInt(target, 10);
        if (isNaN(num)) { alert('ID格式无效'); return; }
        try {
            const body = { message_id: msgId, ...(state.chatType === 'private' ? { to: num } : { group_id: num }) };
            await api(API.chat + '?action=forward', { method: 'POST', body: JSON.stringify(body) });
            alert('转发成功');
            await loadMessages(state.chatType, state.currentChat);
        } catch (e) { alert(e.message); }
    }

    function promptInput(title, placeholder) {
        return new Promise(resolve => {
            showModal(title, `<input type="text" id="promptInput" class="chat-input" style="width:100%;margin-top:12px;" placeholder="${placeholder}"><button class="btn btn-primary" id="btnPromptOk" style="width:100%;margin-top:8px;">确定</button>`);
            setTimeout(() => {
                const input = $('#promptInput');
                const btn = $('#btnPromptOk');
                const done = () => { const v = $('#promptInput')?.value?.trim(); closeModal(); resolve(v); };
                if (btn) btn.addEventListener('click', done);
                if (input) input.addEventListener('keydown', e => { if (e.key === 'Enter') done(); });
            }, 0);
        });
    }

    function promptChoice(options) {
        return new Promise(resolve => {
            showModal('选择操作', `<div style="display:flex;flex-direction:column;gap:8px;">${options.map((o, idx) => `<button class="btn btn-primary choice-btn" data-idx="${idx}">${o}</button>`).join('')}</div>`);
            document.querySelectorAll('.choice-btn').forEach(btn => {
                btn.addEventListener('click', () => {
                    const idx = parseInt(btn.dataset.idx, 10);
                    closeModal();
                    resolve(options[idx]);
                });
            });
        });
    }

    function hideTypingIndicatorName() {
        const el = $('#typingIndicator');
        if (!el) return;
        el.textContent = '';
        clearTimeout(state.typingTimer);
    }

    function showTypingIndicatorName(name) {
        const el = $('#typingIndicator');
        if (!el) return;
        el.textContent = (name ? escapeHtml(name) : '对方') + ' 正在输入...';
        clearTimeout(state.typingTimer);
        state.typingTimer = setTimeout(() => { el.textContent = ''; }, 2000);
    }

    async function recallMessage(msgId) {
        try {
            await api(API.chat + '?action=recall', { method: 'POST', body: JSON.stringify({message_id: msgId}) });
            await loadMessages(state.chatType, state.currentChat);
        } catch (e) { alert(e.message); }
    }

    async function loadMessages(type, id) {
        try {
            const qs = type === 'private' ? 'with=' + id : 'group_id=' + id;
            const data = await api(API.chat + '?action=history&' + qs);
            state.messages = data.messages || [];
            renderMessages();
            await loadPinnedMessages(type, id);
        } catch (e) {
            $('#chatArea').innerHTML = '<div class="chat-placeholder"><p style="color:red">加载失败: ' + escapeHtml(e.message) + '</p></div>';
        }
    }

    async function loadPinnedMessages(type, id) {
        try {
            const data = await api(API.chat + '?action=pin&chat_type=' + type + '&chat_id=' + id);
            const pinned = data.pinned || [];
            const bar = $('#pinnedBar');
            if (!bar) return;
            if (!pinned.length) { bar.style.display = 'none'; return; }
            bar.style.display = 'block';
            bar.innerHTML = pinned.map(p => `<div style="cursor:pointer;" data-pinned-msg-id="${p.message_id}">📌 ${escapeHtml(p.content || '')} - ${escapeHtml(p.nickname || '')}</div>`).join('');
            bar.querySelectorAll('[data-pinned-msg-id]').forEach(el => {
                el.addEventListener('click', () => {
                    const msgId = el.dataset.pinnedMsgId;
                    const target = document.querySelector(`.message[data-msg-id="${msgId}"]`);
                    if (target) target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                });
            });
        } catch (e) {}
    }

    function renderMessages() {
        const el = $('#chatMessages');
        if (!el) return;
        if (!state.messages.length) {
            el.innerHTML = '<div style="text-align:center;color:#999;padding:40px;">暂无消息，开始聊天吧</div>';
            return;
        }
        el.innerHTML = state.messages.map(m => {
            if (m.is_recall) {
                return `<div class="message recall"><div class="message-content">${m.is_me ? '你撤回了一条消息' : (escapeHtml(m.sender_name) + ' 撤回了一条消息')}</div></div>`;
            }
            const cls = m.is_me ? 'self' : 'other';
            const sender = !m.is_me && (state.chatType === 'group' || state.chatType === 'world') ? `<div class="message-sender">${escapeHtml(m.sender_name || '')}</div>` : '';
            const readStatus = m.is_me ? `<div style="font-size:10px;opacity:0.7;margin-top:2px;text-align:right;">${m.is_read ? '已读' : '未读'}</div>` : '';
            if (m.type === 'image') {
                return `<div class="message ${cls} fade-in" data-msg-id="${m.id}">
                    ${!m.is_me ? avatarHTML({id: m.sender_id, username: m.sender_name || '?', nickname: m.sender_name, avatar_frame: m.avatar_frame}, 32) : avatarHTML(window.ChatX.user, 32)}
                    <div>
                        ${sender}
                        <img src="${escapeHtml(m.file_path || '')}" style="max-width:200px;border-radius:8px;cursor:pointer;" onclick="window.open('${escapeHtml(m.file_path || '')}')" onerror="this.style.display='none';this.nextElementSibling.style.display='block';">
                        <div style="display:none;color:red;font-size:12px;">图片加载失败</div>
                        <div class="message-time">${m.formatted_time || ''}</div>
                        ${readStatus}
                    </div>
                </div>`;
            }
            const reactionsHtml = (m.reactions || []).length ? `<div class="message-reactions">${m.reactions.map(r => `<span class="reaction-chip" data-emoji="${escapeHtml(r.emoji)}">${escapeHtml(r.emoji)} ${r.count}</span>`).join('')}</div>` : '';
            const forwardLabel = m.forward_from_message_id ? `<div style="font-size:10px;opacity:0.6;margin-top:2px;">[转发]</div>` : '';
            return `<div class="message ${cls} fade-in" data-msg-id="${m.id}">
                ${!m.is_me ? avatarHTML({id: m.sender_id, username: m.sender_name || '?', nickname: m.sender_name, avatar_frame: m.avatar_frame}, 32) : avatarHTML(window.ChatX.user, 32)}
                <div>
                    ${sender}
                    <div class="message-content">${escapeHtml(m.content)}</div>
                    ${forwardLabel}
                    <div class="message-time">${m.formatted_time || ''} ${m.pinned ? '📌' : ''}</div>
                    ${readStatus}
                    ${reactionsHtml}
                </div>
            </div>`;
        }).join('');
        el.scrollTop = el.scrollHeight;
        el.querySelectorAll('.reaction-chip').forEach(chip => {
            chip.addEventListener('click', () => {
                const msgEl = chip.closest('.message');
                if (!msgEl) return;
                const msgId = msgEl.dataset.msgId;
                const emoji = chip.dataset.emoji;
                if (!msgId || !emoji) return;
                api(API.chat + '?action=reaction', { method: 'POST', body: JSON.stringify({ message_id: msgId, emoji, remove: true }) }).then(() => loadMessages(state.chatType, state.currentChat)).catch(() => {});
            });
        });
    }

    async function sendMessage() {
        const input = $('#chatInput');
        const content = input.value.trim();
        if (!content || !state.currentChat) return;
        try {
            input.disabled = true;
            const body = {
                type: 'text',
                content: content,
                ...(state.chatType === 'private' ? { to: state.currentChat } : { group_id: state.currentChat })
            };
            if (state.chatType === 'world') {
                body.group_id = 1;
            } else if (state.chatType === 'group') {
                body.group_id = state.currentChat;
                delete body.to;
            }
            const data = await api(API.chat + '?action=send', {
                method: 'POST',
                body: JSON.stringify(body)
            });
            if (data.message) {
                state.messages.push(data.message);
                renderMessages();
                input.value = '';
                input.style.height = 'auto';
                hideTypingIndicatorName();
                // Refresh list in background
                if (state.currentTab === 'chat') loadChatList();
            }
        } catch (e) {
            showToast(e.message || '发送失败');
        } finally {
            input.disabled = false;
            input.focus();
        }
    }

    function startPolling(type, id) {
        stopPolling();
        state.pollTimer = setInterval(async () => {
            try {
                const qs = type === 'private' ? 'with=' + id : 'group_id=' + id;
                const data = await api(API.chat + '?action=history&' + qs);
                const newMsgs = data.messages || [];
                if (newMsgs.length !== state.messages.length) {
                    state.messages = newMsgs;
                    renderMessages();
                }
                const typingData = await api(API.chat + '?action=typing&chat_type=' + type + '&chat_id=' + id);
                if (typingData.typing && typingData.typing.nickname) {
                    showTypingIndicatorName(typingData.typing.nickname);
                } else if (state.currentChat === id) {
                    hideTypingIndicatorName();
                }
            } catch (e) {}
        }, 2000);
    }

    function stopPolling() {
        if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; }
    }

    // Search
    function initSearch() {
        $('#btnSearch').addEventListener('click', () => {
            const box = $('#searchBox');
            if (box.style.display === 'none') {
                box.style.display = 'block';
                $('#searchInput').focus();
            } else {
                box.style.display = 'none';
                $('#searchInput').value = '';
                if (state.currentTab === 'chat') loadChatList();
                else if (state.currentTab === 'contacts') renderContacts();
                else if (state.currentTab === 'groups') renderGroups();
            }
        });
        $('#searchInput').addEventListener('input', debounce(async e => {
            const q = e.target.value.trim();
            if (q.length < 2) {
                if (state.currentTab === 'chat') loadChatList();
                else if (state.currentTab === 'contacts') renderContacts();
                return;
            }
            try {
                const data = await api(API.users + '?action=search&q=' + encodeURIComponent(q));
                const users = data.users || [];
                if (state.currentTab === 'contacts' || state.currentTab === 'chat') {
                    renderSearchResults(users);
                }
            } catch (e) {}
        }, 300));
    }

    function renderSearchResults(users) {
        const el = $('#listContent');
        if (!users.length) { el.innerHTML = '<div class="loading">未找到用户</div>'; return; }
        el.innerHTML = users.map(u => `
            <div class="list-item" style="cursor:pointer;" onclick="window.location.href='profile.php?user_id=${u.id}'">
                ${avatarHTML(u, 40)}
                <div class="list-item-info">
                    <div class="list-item-name">${escapeHtml(u.nickname || u.username)}</div>
                    <div class="list-item-meta">@${escapeHtml(u.username)} · ${u.status === 'online' ? '在线' : '离线'}</div>
                </div>
                <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); window.ChatX.openChat('private', ${u.id})">聊天</button>
                <button class="btn btn-sm btn-secondary add-friend-btn" data-id="${u.id}" onclick="event.stopPropagation(); ChatX.addFriend(${u.id}, this)">加好友</button>
            </div>
        `).join('');
        $$('.add-friend-btn').forEach(btn => {
            btn.addEventListener('click', async e => {
                e.stopPropagation();
                const fid = parseInt(btn.dataset.id);
                try {
                    await api(API.users + '?action=add', { method: 'POST', body: JSON.stringify({friend_id: fid}) });
                    btn.textContent = '已发送';
                    btn.disabled = true;
                    btn.classList.remove('btn-secondary');
                    btn.classList.add('btn-accept');
                } catch (e) {
                    alert(e.message);
                }
            });
        });
    }

    // Add friend / create group
    function initActions() {
        $('#btnAdd').addEventListener('click', () => {
            if (state.currentTab === 'contacts') showAddFriend();
            else if (state.currentTab === 'groups') showCreateGroup();
        });
    }

    function showAddFriend() {
        showModal('添加好友', `
            <div class="form-group">
                <label>搜索用户名</label>
                <input type="text" id="addFriendInput" placeholder="输入用户名搜索" class="chat-input" style="width:100%">
                <div id="addFriendResults" style="margin-top:12px;"></div>
            </div>
        `);
        setTimeout(() => {
            const input = $('#addFriendInput');
            if (input) {
                input.addEventListener('input', debounce(async e => {
                    const q = e.target.value.trim();
                    const results = $('#addFriendResults');
                    if (q.length < 2) { results.innerHTML = ''; return; }
                    try {
                        const data = await api(API.users + '?action=search&q=' + encodeURIComponent(q));
                        const users = data.users || [];
                        if (!users.length) { results.innerHTML = '<div class="loading">未找到用户</div>'; return; }
                        results.innerHTML = users.map(u => `
                            <div class="list-item">
                                ${avatarHTML(u, 36)}
                                <div class="list-item-info">
                                    <div class="list-item-name">${escapeHtml(u.nickname || u.username)}</div>
                                </div>
                                <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); window.ChatX.openChat('private', ${u.id})">聊天</button>
                                <button class="btn btn-sm btn-secondary" onclick="ChatX.addFriend(${u.id}, this)">添加</button>
                            </div>
                        `).join('');
                    } catch (e) { results.innerHTML = '<div style="color:red">搜索失败</div>'; }
                }, 300));
            }
        }, 0);
    }

    window.ChatX = window.ChatX || {};
    window.ChatX.addFriend = async function(fid, btn) {
        try {
            await api(API.users + '?action=add', { method: 'POST', body: JSON.stringify({friend_id: fid}) });
            btn.textContent = '已发送';
            btn.disabled = true;
        } catch (e) { alert(e.message); }
    };
    window.ChatX.showEditProfile = showEditProfile;

    window.ChatX.showCreateGroup = showCreateGroup;

    function showCreateGroup() {
        showModal('创建群组', `
            <div class="form-group">
                <label>群名称</label>
                <input type="text" id="groupNameInput" placeholder="请输入群名称" class="chat-input" style="width:100%">
            </div>
            <div class="form-group">
                <label>选择好友（按住Ctrl多选）</label>
                <select id="groupMembers" multiple style="width:100%;height:120px;padding:8px;border:1px solid var(--border);border-radius:var(--radius);">
                    ${state.friends.map(f => `<option value="${f.id}">${escapeHtml(f.nickname || f.username)}</option>`).join('')}
                </select>
            </div>
            <button class="btn btn-primary" id="btnCreateGroup" style="width:100%">创建群组</button>
        `);
        setTimeout(() => {
            const btn = $('#btnCreateGroup');
            if (btn) btn.addEventListener('click', async () => {
                const name = $('#groupNameInput').value.trim();
                const select = $('#groupMembers');
                const members = Array.from(select.selectedOptions).map(o => parseInt(o.value));
                try {
                    const data = await api(API.groups + '?action=create', { method: 'POST', body: JSON.stringify({name, members}) });
                    closeModal();
                    if (state.currentTab === 'groups') loadGroups();
                    else if (state.currentTab === 'chat') loadChatList();
                    openChat('group', data.group.id);
                } catch (e) { alert(e.message); }
            });
            // My feedbacks modal
            const btnMyFb = $('#btnMyFeedbacks');
            if (btnMyFb) btnMyFb.addEventListener('click', async e => {
                e.stopPropagation();
                showModal('我的反馈', '<div style="text-align:center;padding:40px;">加载中...</div>');
                try {
                    const data = await api(API.users + '?action=my_feedbacks');
                    const list = data.feedbacks || [];
                    if (!list.length) {
                        document.getElementById('modalBody').innerHTML = '<div style="text-align:center;padding:40px;color:#999;">暂无反馈记录</div>';
                    } else {
                        document.getElementById('modalBody').innerHTML = list.map(f => {
                            const statusMap = {pending:'待处理',processing:'处理中',resolved:'已回复',closed:'已关闭'};
                            const statusColor = {pending:'#999',processing:'#faad14',resolved:'#52c41a',closed:'#ff4d4f'};
                            return '<div style="border:1px solid var(--border);border-radius:8px;padding:12px;margin-bottom:8px;">' +
                                '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">' +
                                    '<span style="font-size:12px;padding:2px 8px;border-radius:4px;background:' + (statusColor[f.status]||'#999') + '20;color:' + (statusColor[f.status]||'#999') + ';">' + (statusMap[f.status]||f.status) + '</span>' +
                                    '<span style="font-size:12px;color:#999;">' + (f.created_at||'') + '</span>' +
                                '</div>' +
                                '<div style="margin-bottom:8px;">' + escapeHtml(f.content) + '</div>' +
                                (f.reply ? '<div style="background:#f0f7ff;border-left:3px solid #1890ff;padding:8px;border-radius:4px;margin-top:8px;"><div style="font-size:12px;font-weight:600;margin-bottom:4px;">官方回复：</div>' + escapeHtml(f.reply) + '</div>' : '') +
                            '</div>';
                        }).join('');
                    }
                } catch (err) {
                    document.getElementById('modalBody').innerHTML = '<div style="text-align:center;padding:40px;color:red;">加载失败: ' + err.message + '</div>';
                }
            });
        }, 0);
    }

    // User / Group Info
    function showUserInfo(userId) {
        const friend = state.friends.find(f => f.id === userId);
        if (!friend) return;
        showModal('用户信息', `
            <div style="text-align:center;margin-bottom:16px;">${avatarHTML(friend, 64)}</div>
            <div class="form-group"><label>用户名</label><div style="padding:8px 0;">${escapeHtml(friend.username)}</div></div>
            <div class="form-group"><label>昵称</label><div style="padding:8px 0;">${escapeHtml(friend.nickname || '')}</div></div>
            <div class="form-group"><label>状态</label><div style="padding:8px 0;">${friend.status === 'online' ? '在线' : '离线'}</div></div>
            <button class="btn btn-danger" style="width:100%" onclick="ChatX.removeFriend(${friend.id})">删除好友</button>
        `);
    }

    window.ChatX.removeFriend = async function(fid) {
        if (!confirm('确定删除该好友？')) return;
        try {
            await api(API.users + '?action=remove', { method: 'POST', body: JSON.stringify({friend_id: fid}) });
            closeModal();
            if (state.currentTab === 'contacts') loadContacts();
            else loadChatList();
        } catch (e) { alert(e.message); }
    };

    async function showGroupInfo(groupId) {
        try {
            const data = await api(API.groups + '?action=members&group_id=' + groupId);
            const members = data.members || [];
            const owner = members.find(m => m.role === 'owner');
            const me = members.find(m => m.id === state.user?.id);
            const myRole = me ? me.role : null;
            const myPerms = me?.permissions || {};
            const canManage = myRole === 'owner' || myRole === 'admin';
            const isOwner = myRole === 'owner';
            const permLabel = { kick: '踢人', mute: '禁言', invite: '邀请' };
            showModal('群组信息', `
                <div style="text-align:center;margin-bottom:16px;font-size:48px;">&#128485;</div>
                <div class="form-group"><label>群主</label><div style="padding:8px 0;">${escapeHtml(owner ? (owner.nickname || owner.username) : '未知')}</div></div>
                <div class="form-group"><label>成员 (${members.length})</label>
                    <div style="max-height:220px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--radius);">
                        ${members.map(m => {
                            const perms = m.permissions || {};
                            const permBadges = Object.keys(perms).filter(k => perms[k]).map(k => `<span class="member-role">${permLabel[k] || k}</span>`).join(' ');
                            const muteText = m.muted_until ? `<span class="member-role" style="background:#f8d7da;color:#721c24;">禁言至 ${m.muted_until.replace('T', ' ').substring(0, 19)}</span>` : '';
                            let actionBtn = '';
                            if (m.id !== (state.user?.id) && m.role !== 'owner') {
                                if (isOwner && m.role === 'admin') {
                                    actionBtn = `<button class="btn btn-sm btn-warning toggle-admin-btn" data-user-id="${m.id}" data-group-id="${groupId}" data-admin="0" style="margin-left:8px;padding:4px 8px;font-size:11px;">取消管理员</button>`;
                                } else if (isOwner && m.role === 'member') {
                                    actionBtn = `<button class="btn btn-sm btn-primary toggle-admin-btn" data-user-id="${m.id}" data-group-id="${groupId}" data-admin="1" style="margin-left:8px;padding:4px 8px;font-size:11px;">设为管理员</button>`;
                                }
                                if ((myRole === 'owner' || myPerms.kick) && m.role !== 'owner') {
                                    actionBtn += `<button class="btn btn-sm btn-danger kick-member-btn" data-user-id="${m.id}" data-group-id="${groupId}" style="margin-left:4px;padding:4px 8px;font-size:11px;">踢出</button>`;
                                }
                                if ((myRole === 'owner' || myPerms.mute) && m.role !== 'owner') {
                                    const muteLabel = m.muted_until ? '解除禁言' : '禁言';
                                    const muteClass = m.muted_until ? 'btn-secondary' : 'btn-warning';
                                    actionBtn += `<button class="btn btn-sm ${muteClass} mute-member-btn" data-user-id="${m.id}" data-group-id="${groupId}" data-muted="${!!m.muted_until}" style="margin-left:4px;padding:4px 8px;font-size:11px;">${muteLabel}</button>`;
                                }
                            }
                            return `<div class="member-item" data-user-id="${m.id}" data-role="${m.role}">
                                ${avatarHTML(m, 32)}
                                <div style="font-size:13px;flex:1;">${escapeHtml(m.nickname || m.username)}<span class="member-role">${m.role}</span>${permBadges}${muteText}</div>
                                ${actionBtn}
                            </div>`;
                        }).join('')}
                    </div>
                </div>
                ${canManage ? `
                <div class="form-group" style="margin-top:12px;">
                    <label>邀请用户</label>
                    <div style="display:flex;gap:8px;">
                        <input type="text" id="inviteSearchInput" class="chat-input" placeholder="搜索用户名/昵称" style="flex:1;">
                        <button class="btn btn-primary" id="btnSearchInvite" style="width:auto;padding:8px 12px;font-size:12px;">搜索</button>
                    </div>
                    <div id="inviteResults" style="margin-top:8px;max-height:150px;overflow-y:auto;"></div>
                </div>
                ` : ''}
                ${isOwner ? `<button class="btn btn-danger" style="width:100%;margin-top:12px;" onclick="ChatX.dismissGroup(${groupId})">解散群组</button>` : `<button class="btn btn-danger" style="width:100%;margin-top:12px;" onclick="ChatX.leaveGroup(${groupId})">退出群组</button>`}
            `);

            if (canManage) {
                const searchBtn = $('#btnSearchInvite');
                const searchInput = $('#inviteSearchInput');
                if (searchBtn && searchInput) {
                    const doSearch = async () => {
                        const q = searchInput.value.trim();
                        if (q.length < 2) { alert('请输入至少2个字符'); return; }
                        try {
                            const results = await api(API.users + '?action=search&q=' + encodeURIComponent(q));
                            const users = results.users || [];
                            const resultsDiv = $('#inviteResults');
                            const memberIds = members.map(m => m.id);
                            const available = users.filter(u => !memberIds.includes(u.id));
                            if (!available.length) {
                                resultsDiv.innerHTML = '<div style="padding:8px;color:#999;font-size:12px;">没有可邀请的用户</div>';
                                return;
                            }
                            resultsDiv.innerHTML = available.map(u => `
                                <div class="list-item" style="padding:8px 12px;" data-user-id="${u.id}">
                                    ${avatarHTML(u, 28)}
                                    <div style="font-size:13px;flex:1;">${escapeHtml(u.nickname || u.username)}</div>
                                    <button class="btn btn-sm btn-primary invite-user-btn" data-user-id="${u.id}" data-group-id="${groupId}" style="padding:4px 10px;font-size:11px;">邀请</button>
                                </div>
                            `).join('');
                            resultsDiv.querySelectorAll('.invite-user-btn').forEach(btn => {
                                btn.addEventListener('click', async (e) => {
                                    e.stopPropagation();
                                    const uid = parseInt(btn.dataset.userId);
                                    const gid = parseInt(btn.dataset.groupId);
                                    btn.disabled = true;
                                    btn.textContent = '邀请中...';
                                    try {
                                        await api(API.groups + '?action=invite', { method: 'POST', body: JSON.stringify({group_id: gid, user_id: uid}) });
                                        alert('邀请成功');
                                        closeModal();
                                        showGroupInfo(gid);
                                        if (typeof renderChatList === 'function') renderChatList();
                                        loadGroups();
                                    } catch (err) { alert(err.message); }
                                });
                            });
                        } catch (err) { alert(err.message); }
                    };
                    searchBtn.addEventListener('click', doSearch);
                    searchInput.addEventListener('keydown', (e) => {
                        if (e.key === 'Enter') doSearch();
                    });
                }
            }

            document.querySelectorAll('.kick-member-btn').forEach(btn => {
                btn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    const uid = parseInt(btn.dataset.userId);
                    const gid = parseInt(btn.dataset.groupId);
                    if (!confirm('确定要踢出该成员吗？')) return;
                    try {
                        await api(API.groups + '?action=kick', { method: 'POST', body: JSON.stringify({group_id: gid, user_id: uid}) });
                        alert('已踢出');
                        closeModal();
                        showGroupInfo(gid);
                        if (typeof renderChatList === 'function') renderChatList();
                        loadGroups();
                    } catch (err) { alert(err.message); }
                });
            });

            document.querySelectorAll('.mute-member-btn').forEach(btn => {
                btn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    const uid = parseInt(btn.dataset.userId);
                    const gid = parseInt(btn.dataset.groupId);
                    const muted = btn.dataset.muted === 'true';
                    if (muted) {
                        try {
                            await api(API.groups + '?action=unmute_user', { method: 'POST', body: JSON.stringify({group_id: gid, user_id: uid}) });
                            btn.textContent = '禁言';
                            btn.classList.remove('btn-secondary');
                            btn.classList.add('btn-warning');
                            btn.dataset.muted = 'false';
                            closeModal();
                            showGroupInfo(gid);
                        } catch (err) { alert(err.message); }
                        return;
                    }
                    const minutes = prompt('请输入禁言时长（分钟）：', '30');
                    if (!minutes) return;
                    const num = parseInt(minutes, 10);
                    if (isNaN(num) || num <= 0) { alert('请输入有效的分钟数'); return; }
                    try {
                        await api(API.groups + '?action=mute_user', { method: 'POST', body: JSON.stringify({group_id: gid, user_id: uid, minutes: num}) });
                        alert('已禁言');
                        closeModal();
                        showGroupInfo(gid);
                    } catch (err) { alert(err.message); }
                });
            });

            document.querySelectorAll('.toggle-admin-btn').forEach(btn => {
                btn.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    const uid = parseInt(btn.dataset.userId);
                    const gid = parseInt(btn.dataset.groupId);
                    const makeAdmin = btn.dataset.admin === '1';
                    if (!confirm('确定要' + (makeAdmin ? '设为管理员' : '取消管理员') + '吗？')) return;
                    try {
                        await api(API.groups + '?action=set_group_admin', { method: 'POST', body: JSON.stringify({group_id: gid, user_id: uid, make_admin: makeAdmin}) });
                        alert('操作成功');
                        closeModal();
                        showGroupInfo(gid);
                        loadGroups();
                    } catch (err) { alert(err.message); }
                });
            });
        } catch (e) { alert(e.message); }
    }

    window.ChatX.leaveGroup = async function(gid) {
        if (!confirm('确定退出该群组？')) return;
        try {
            await api(API.groups + '?action=leave', { method: 'POST', body: JSON.stringify({group_id: gid}) });
            closeModal();
            loadGroups();
        } catch (e) { alert(e.message); }
    };
    window.ChatX.dismissGroup = async function(gid) {
        if (!confirm('确定解散该群组？此操作不可恢复，所有成员将失去该群。')) return;
        try {
            await api(API.groups + '?action=dismiss', { method: 'POST', body: JSON.stringify({group_id: gid}) });
            closeModal();
            loadGroups();
            if (state.currentChat === gid) {
                state.currentChat = null;
                state.chatType = null;
                stopPolling();
                renderChatPlaceholder();
                $('#listTitle').textContent = '消息';
            }
        } catch (e) { alert(e.message); }
    };

    // Theme System
    let sakuraTimer = null;
    let scanlineEl = null;

    function applyTheme(themeId) {
        const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        if (themeId === 'sakura') {
            document.documentElement.setAttribute('data-theme', 'sakura');
            document.documentElement.removeAttribute('data-theme-dark');
        } else {
            document.documentElement.setAttribute('data-theme', themeId);
        }
        // 清理旧特效
        const existing = document.getElementById('sakura-container');
        if (existing) existing.remove();
        clearInterval(sakuraTimer);
        sakuraTimer = null;
        if (scanlineEl) { scanlineEl.remove(); scanlineEl = null; }
        const oldBubbles = document.querySelectorAll('.ocean-bubble');
        oldBubbles.forEach(b => b.remove());
        const oldSparks = document.querySelectorAll('.lava-spark');
        oldSparks.forEach(s => s.remove());
        // 系统暗色偏好
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        if (prefersDark && themeId !== 'sakura') {
            document.documentElement.setAttribute('data-theme-dark', '1');
        } else {
            document.documentElement.removeAttribute('data-theme-dark');
        }
        // 启动新主题特效
        if (!reducedMotion) {
            if (themeId === 'sakura') {
                startSakura();
            } else if (themeId === 'cyberpunk') {
                scanlineEl = document.createElement('div');
                scanlineEl.className = 'scanlines';
                document.body.appendChild(scanlineEl);
                startCyberParticles();
            } else if (themeId === 'parchment') {
                startParchmentParticles();
            } else if (themeId === 'casio') {
                startCasioFlicker();
            } else if (themeId === 'kawaii-pink') {
                startKawaiiParticles();
            } else if (themeId === 'tech-blue') {
                startTechStream();
            }
        }
        // 更新主题图标
        updateThemeIcons(themeId);
    }

    function updateThemeIcons(themeId) {
        const theme = themes.find(t => t.id === themeId);
        const iconSet = theme?.iconSet;
        if (!iconSet) return;

        // 侧边栏导航图标
        document.querySelectorAll('.nav-item[data-tab]').forEach(el => {
            const key = el.dataset.tab;
            if (iconSet[key]) el.innerHTML = iconSet[key];
        });
        // 管理员后台入口图标
        const adminNav = document.getElementById('navAdmin');
        if (adminNav) adminNav.innerHTML = iconSet['admin'] || '';

        // 顶部操作按钮图标
        document.querySelectorAll('.icon-btn[data-icon]').forEach(el => {
            const key = el.dataset.icon;
            if (iconSet[key]) el.innerHTML = iconSet[key];
        });

        // 普通按钮图标（保留原有文本）
        document.querySelectorAll('button[data-icon]').forEach(el => {
            const key = el.dataset.icon;
            if (iconSet[key]) {
                const originalText = el.textContent.trim();
                const cleanedText = originalText.replace(iconSet[key], '').trim();
                el.innerHTML = iconSet[key] + (cleanedText ? ' ' + cleanedText : '');
            }
        });
    }

    function startSakura() {
        let container = document.getElementById('sakura-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'sakura-container';
            document.body.appendChild(container);
        }
        function createPetal() {
            const petal = document.createElement('div');
            petal.className = 'sakura-petal';
            petal.style.left = Math.random() * 100 + '%';
            petal.style.animationDuration = (5 + Math.random() * 4) + 's';
            petal.style.opacity = 0.4 + Math.random() * 0.5;
            petal.style.transform = `scale(${0.5 + Math.random() * 0.8}) rotate(${Math.random() * 360}deg)`;
            container.appendChild(petal);
            setTimeout(() => petal.remove(), 9000);
        }
        createPetal();
        sakuraTimer = setInterval(createPetal, 250);
    }

    function startCyberParticles() {
        let container = document.getElementById('cyber-particles');
        if (!container) {
            container = document.createElement('div');
            container.id = 'cyber-particles';
            container.setAttribute('aria-hidden', 'true');
            document.body.appendChild(container);
        }
        function createParticle() {
            const p = document.createElement('div');
            p.className = 'cyber-particle';
            p.style.left = Math.random() * 100 + '%';
            p.style.animationDuration = (4 + Math.random() * 6) + 's';
            p.style.opacity = (0.2 + Math.random() * 0.6).toFixed(2);
            p.style.transform = `scale(${0.5 + Math.random() * 1.2})`;
            container.appendChild(p);
            setTimeout(() => p.remove(), 10000);
        }
        for (let i = 0; i < 15; i++) createParticle();
        sakuraTimer = setInterval(createParticle, 600);
    }

    function startParchmentParticles() {
        let container = document.getElementById('parchment-particles');
        if (!container) {
            container = document.createElement('div');
            container.id = 'parchment-particles';
            container.setAttribute('aria-hidden', 'true');
            document.body.appendChild(container);
        }
        function createDust() {
            const d = document.createElement('div');
            d.className = 'parchment-dust';
            d.style.left = Math.random() * 100 + '%';
            d.style.animationDuration = (8 + Math.random() * 10) + 's';
            d.style.opacity = (0.15 + Math.random() * 0.35).toFixed(2);
            container.appendChild(d);
            setTimeout(() => d.remove(), 18000);
        }
        for (let i = 0; i < 12; i++) createDust();
        sakuraTimer = setInterval(createDust, 1200);
    }

    function startCasioFlicker() {
        const cards = document.querySelectorAll('.list-item, .message-content, .btn-primary');
        cards.forEach(el => el.classList.add('casio-flicker-target'));
        sakuraTimer = setInterval(() => {
            const targets = document.querySelectorAll('.casio-flicker-target');
            if (!targets.length) return;
            const el = targets[Math.floor(Math.random() * targets.length)];
            el.style.transition = 'filter 0.1s';
            el.style.filter = 'brightness(1.15)';
            setTimeout(() => { el.style.filter = 'brightness(1)'; }, 100);
        }, 2500);
    }

    function startKawaiiParticles() {
        let container = document.getElementById('kawaii-particles');
        if (!container) {
            container = document.createElement('div');
            container.id = 'kawaii-particles';
            container.setAttribute('aria-hidden', 'true');
            document.body.appendChild(container);
        }
        const icons = ['✨', '♡', '☆', '♡', '✦'];
        function createParticle() {
            const p = document.createElement('div');
            p.textContent = icons[Math.floor(Math.random() * icons.length)];
            p.style.position = 'fixed';
            p.style.left = Math.random() * 100 + '%';
            p.style.top = '-10%';
            p.style.fontSize = (14 + Math.random() * 16) + 'px';
            p.style.opacity = (0.35 + Math.random() * 0.55).toFixed(2);
            p.style.transition = 'all 6s linear';
            p.style.pointerEvents = 'none';
            p.style.zIndex = '0';
            container.appendChild(p);
            requestAnimationFrame(() => {
                p.style.top = '110%';
                p.style.left = (parseFloat(p.style.left) + (Math.random() * 20 - 10)) + '%';
                p.style.opacity = '0';
            });
            setTimeout(() => p.remove(), 6200);
        }
        for (let i = 0; i < 12; i++) {
            setTimeout(() => createParticle(), i * 180);
        }
        sakuraTimer = setInterval(createParticle, 520);
    }

    function startTechStream() {
        let container = document.getElementById('tech-particles');
        if (!container) {
            container = document.createElement('div');
            container.id = 'tech-particles';
            container.setAttribute('aria-hidden', 'true');
            document.body.appendChild(container);
        }
        function createStream() {
            const s = document.createElement('div');
            s.className = 'tech-stream';
            s.style.left = Math.random() * 100 + '%';
            s.style.height = (60 + Math.random() * 160) + 'px';
            s.style.opacity = (0.12 + Math.random() * 0.28).toFixed(2);
            s.style.animationDuration = (3 + Math.random() * 5) + 's';
            container.appendChild(s);
            setTimeout(() => s.remove(), 7000);
        }
        for (let i = 0; i < 10; i++) createStream();
        sakuraTimer = setInterval(createStream, 700);
    }

    // Settings
    const themes = [
        { id: 'light', name: '现代浅色', desc: '清新简约', color: '#4f46e5', icon: '☀️', iconSet: {} },
        { id: 'dark', name: '现代暗黑', desc: '护眼深色', color: '#1e293b', icon: '🌙', iconSet: {} },
        { id: 'sakura', name: '樱花物语', desc: '粉色飘落', color: '#FFB7C5', icon: '🌸', iconSet: {} },
        { id: 'cyberpunk', name: '赛博朋克', desc: '霓虹全息', color: '#00F0FF', icon: '🤖', iconSet: {} },
        { id: 'parchment', name: '羊皮卷', desc: '古卷做旧', color: '#8b4513', icon: '📜', iconSet: {} },
        { id: 'casio', name: '卡西欧', desc: '像素LCD', color: '#4a7c59', icon: '⌚', iconSet: {} },
        { id: 'kawaii-pink', name: '少女粉', desc: '可爱风格', color: '#FF7BA4', icon: '🎀', iconSet: { chat: '🐰', contacts: '🧸', groups: '🎀', settings: '🩷', admin: '🍭', logout: '🌈', menu: '🍬', search: '🔍', add: '✨', send: '💌', attach: '🎀', emoji: '🐰', upload: '📸', edit: '✏️', feedback: '💌', delete: '💔', submit: '💖' } },
        { id: 'tech-blue', name: '科技蓝', desc: '科技风格', color: '#00C6FF', icon: '⚡', iconSet: { chat: '💠', contacts: '🛸', groups: '📡', settings: '⚙️', admin: '🛡️', logout: '⏻', menu: '☰', search: '🔍', add: '➕', send: '🚀', attach: '📎', emoji: '🤖', upload: '📤', edit: '✏️', feedback: '📨', delete: '🗑️', submit: '📨' } },
    ];

    function showSettings() {
        const currentTheme = document.documentElement.getAttribute('data-theme') || 'sakura';
        const isAdmin = (window.ChatX.user?.role === 'admin' || window.ChatX.user?.role === 'super_admin');
        showModal('设置', `
            <div class="form-group">
                <label>在线状态</label>
                <select id="statusSelect" class="status-select" style="width:100%">
                    <option value="online">在线</option>
                    <option value="away">离开</option>
                    <option value="busy">忙碌</option>
                    <option value="offline">隐身</option>
                </select>
            </div>
            <div class="form-group">
                <label>选择主题</label>
                <div id="themeGrid" style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:8px;">
                    ${themes.map(t => `
                        <div class="theme-card ${currentTheme === t.id ? 'active' : ''}" data-theme-id="${t.id}" style="
                            padding:12px;border-radius:12px;cursor:pointer;text-align:center;border:2px solid ${currentTheme === t.id ? t.color : 'var(--border)'};
                            background:${t.color}15;transition:all 0.2s;
                        ">
                            <div style="font-size:28px;margin-bottom:4px;">${t.icon}</div>
                            <div style="font-weight:600;font-size:13px;color:var(--text-primary);">${t.name}</div>
                            <div style="font-size:11px;color:var(--text-secondary);">${t.desc}</div>
                        </div>
                    `).join('')}
                </div>
            </div>
            <div class="form-group">
                <label>当前账号</label>
                <div style="padding:8px 0;font-weight:500;">${escapeHtml(window.ChatX.user?.nickname || window.ChatX.user?.username || '')}</div>
            </div>
            <div class="form-group">
                <label>使用主题图标</label>
                <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;">
                    <span style="font-size:13px;color:var(--text-secondary);">彩色图标替代线条图标</span>
                    <label class="switch">
                        <input type="checkbox" id="useIconsToggle" ${localStorage.getItem('chatx_use_icons') === '1' ? 'checked' : ''}>
                        <span class="slider"></span>
                    </label>
                </div>
            </div>
            <div class="form-group">
                <label>暗色模式</label>
                <div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;">
                    <span style="font-size:13px;color:var(--text-secondary);">切换深色主题</span>
                    <label class="switch">
                        <input type="checkbox" id="darkModeToggle" ${document.body.classList.contains('dark') ? 'checked' : ''}>
                        <span class="slider"></span>
                    </label>
                </div>
            </div>
            <button type="button" class="btn btn-primary" id="btnLevelInfo" style="width:100%;margin-bottom:8px;" data-icon="level" onclick="window.ChatX.closeModal(); window.ChatX.showLevelInfo && window.ChatX.showLevelInfo();">🏆 我的等级</button>
            <button type="button" class="btn btn-primary" id="btnBlacklist" style="width:100%;margin-bottom:8px;" data-icon="block" onclick="window.ChatX.closeModal(); window.ChatX.showBlacklist && window.ChatX.showBlacklist();">🚫 黑名单管理</button>
            <button type="button" class="btn btn-primary" id="btnTasks" style="width:100%;margin-bottom:8px;" data-icon="tasks" onclick="window.ChatX.closeModal(); window.ChatX.showTasks && window.ChatX.showTasks();">📋 每日任务</button>
            <button type="button" class="btn btn-primary" id="btnUploadAvatar" style="width:100%;margin-bottom:8px;" data-icon="upload">上传头像</button>
            <button type="button" class="btn btn-primary" id="btnEditProfile" style="width:100%;margin-bottom:8px;" data-icon="edit">修改个人资料</button>
            <button type="button" class="btn btn-primary" id="btnSaveSettings" style="width:100%;margin-bottom:12px;">保存设置</button>
            <button type="button" class="btn btn-primary" id="btnFeedback" style="width:100%;margin-bottom:8px;" data-icon="feedback">意见反馈</button>
            <button type="button" class="btn btn-secondary" id="btnMyFeedbacks" style="width:100%;margin-bottom:12px;">📋 我的反馈</button>
            ${isAdmin ? `<a href="admin.php" class="btn btn-warning" style="display:block;text-align:center;text-decoration:none;width:100%;margin-bottom:8px;">管理员后台</a>` : ''}
            <a href="db_config.php" class="btn btn-secondary" style="display:block;text-align:center;text-decoration:none;width:100%;">数据库配置</a>
        `);
        setTimeout(() => {
            const btnUploadAvatar = $('#btnUploadAvatar');
            if (btnUploadAvatar) {
                btnUploadAvatar.addEventListener('click', e => {
                    e.stopPropagation();
                    const input = document.createElement('input');
                    input.type = 'file';
                    input.accept = 'image/*';
                    input.onchange = async (e) => {
                        const file = e.target.files[0];
                        if (!file) return;
                        const form = new FormData();
                        form.append('avatar', file);
                        try {
                            const data = await api(API.users + '?action=upload_avatar', { method: 'POST', body: form, headers: {} });
                            if (data.avatar) {
                                window.ChatX.user.avatar = data.avatar;
                                alert('头像已更新');
                                closeModal();
                            }
                        } catch (err) { alert(err.message); }
                    };
                    input.click();
                });
            }
            let selectedTheme = currentTheme;
            const useIconsToggle = $('#useIconsToggle');
            const btnSave = $('#btnSaveSettings');
            if (btnSave) btnSave.addEventListener('click', async e => {
                e.stopPropagation();
                const status = $('#statusSelect').value;
                const useIcons = useIconsToggle ? useIconsToggle.checked : false;
                try {
                    if (status) await api(API.users + '?action=status', { method: 'POST', body: JSON.stringify({status}) });
                    applyTheme(selectedTheme);
                    localStorage.setItem('chatx_theme', selectedTheme);
                    // 保存图标偏好并应用
                    localStorage.setItem('chatx_use_icons', useIcons ? '1' : '0');
                    if (typeof applyThemeIcons === 'function') {
                        applyThemeIcons(selectedTheme, useIcons);
                    }
                    alert('设置已保存');
                    if (typeof renderChatList === 'function') renderChatList();
                    closeModal();
                } catch (e) { alert(e.message); }
            });
            // theme card clicks
            setTimeout(() => {
                document.querySelectorAll('.theme-card').forEach(card => {
                    card.addEventListener('click', e => {
                        e.stopPropagation();
                        document.querySelectorAll('.theme-card').forEach(c => {
                            c.classList.remove('active');
                            c.style.borderColor = 'var(--border)';
                        });
                        card.classList.add('active');
                        const themeId = card.dataset.themeId;
                        selectedTheme = themeId;
                        // preview
                        applyTheme(themeId);
                        // 同步更新图标预览
                        if (typeof applyThemeIcons === 'function') {
                            const useIcons = localStorage.getItem('chatx_use_icons') === '1';
                            applyThemeIcons(themeId, useIcons);
                        }
                    });
                });
            }, 0);
            const btnEdit = $('#btnEditProfile');
            if (btnEdit) btnEdit.addEventListener('click', e => { e.stopPropagation(); closeModal(); showEditProfile(); });
            // Dark mode toggle
            const darkToggle = $('#darkModeToggle');
            if (darkToggle) darkToggle.addEventListener('change', e => {
                document.body.classList.toggle('dark', e.target.checked);
                localStorage.setItem('chatx_dark', e.target.checked ? '1' : '0');
            });
            // Restore dark mode
            if (localStorage.getItem('chatx_dark') === '1') document.body.classList.add('dark');



            const btnFeedback = $('#btnFeedback');
            if (btnFeedback) btnFeedback.addEventListener('click', e => {
                e.stopPropagation();
                showModal('意见反馈', `
                    <div class="form-group">
                        <label>反馈内容</label>
                        <textarea id="feedbackContent" class="chat-input" style="width:100%;height:120px;" placeholder="请描述遇到的问题或建议"></textarea>
                    </div>
                    <div class="form-group">
                        <label>联系方式（可选）</label>
                        <input type="text" id="feedbackContact" class="chat-input" style="width:100%" placeholder="邮箱或联系方式">
                    </div>
                    <button class="btn btn-primary" id="btnSubmitFeedback" style="width:100%" data-icon="submit">提交反馈</button>
                `);
                setTimeout(() => {
                    const btnSubmit = $('#btnSubmitFeedback');
                    if (btnSubmit) btnSubmit.addEventListener('click', async () => {
                        const content = $('#feedbackContent').value.trim();
                        const contact = $('#feedbackContact').value.trim();
                        if (!content) { alert('请填写反馈内容'); return; }
                        try {
                            await api(API.users + '?action=submit_feedback', { method: 'POST', body: JSON.stringify({content, contact}) });
                            alert('反馈已提交，感谢！');
                            closeModal();
                        } catch (err) { alert(err.message); }
                    });
                }, 0);
            });
        }, 0);
    }

    function showEditProfile() {
        showModal('修改个人资料', `
            <div class="form-group">
                <label>昵称</label>
                <input type="text" id="editNickname" class="chat-input" style="width:100%" value="${escapeHtml(window.ChatX.user?.nickname || window.ChatX.user?.username || '')}">
            </div>
            <div class="form-group">
                <label>个性签名</label>
                <input type="text" id="editSignature" class="chat-input" style="width:100%" placeholder="一句话介绍自己" value="${escapeHtml(window.ChatX.user?.signature || '')}">
            </div>
            <div class="form-group">
                <label>头像框</label>
                <select id="editAvatarFrame" class="chat-input" style="width:100%">
                    <option value="">无</option>
                    <option value="gold" ${window.ChatX.user?.avatar_frame === 'gold' ? 'selected' : ''}>黄金</option>
                    <option value="silver" ${window.ChatX.user?.avatar_frame === 'silver' ? 'selected' : ''}>白银</option>
                    <option value="neon" ${window.ChatX.user?.avatar_frame === 'neon' ? 'selected' : ''}>霓虹</option>
                </select>
            </div>
            <div class="form-group">
                <label>个人简介</label>
                <textarea id="editBio" class="chat-input" style="width:100%;height:80px;" placeholder="详细介绍自己（可选）"></textarea>
            </div>
            <hr style="border:none;border-top:1px solid var(--border);margin:16px 0;">
            <div class="form-group">
                <label>当前密码</label>
                <input type="password" id="editCurrentPwd" class="chat-input" style="width:100%" placeholder="修改密码时请填写当前密码">
            </div>
            <div class="form-group">
                <label>新密码</label>
                <input type="password" id="editNewPwd" class="chat-input" style="width:100%" placeholder="不修改请留空">
            </div>
            <button class="btn btn-primary" id="btnSaveProfile" style="width:100%">保存资料</button>
        `);
        setTimeout(() => {
            const btn = $('#btnSaveProfile');
            if (btn) btn.addEventListener('click', async () => {
                const nickname = $('#editNickname').value.trim();
                const signature = $('#editSignature').value.trim();
                const bio = $('#editBio').value.trim();
                const currentPwd = $('#editCurrentPwd').value;
                const newPwd = $('#editNewPwd').value;
                try {
                    const profileData = {};
                    if (nickname) profileData.nickname = nickname;
                    if (signature !== undefined) profileData.signature = signature;
                    if (bio !== undefined) profileData.bio = bio;
                    const frame = document.getElementById('editAvatarFrame')?.value || '';
                    profileData.avatar_frame = frame;
                    await api('api/features.php?action=profile', { method: 'POST', body: JSON.stringify(profileData) });
                    if (newPwd) {
                        if (!currentPwd) throw new Error('修改密码需要填写当前密码');
                        const verifyRes = await api(API.auth + '?action=login', { method: 'POST', body: JSON.stringify({username: window.ChatX.user.username, password: currentPwd}) });
                        if (verifyRes.error) throw new Error('当前密码不正确');
                        await api(API.auth + '?action=profile', { method: 'POST', body: JSON.stringify({field:'password', value:newPwd}) });
                    }
                    alert('资料已保存');
                    closeModal();
                    if (nickname) window.ChatX.user.nickname = nickname;
                    if (frame !== undefined) window.ChatX.user.avatar_frame = frame;
                } catch (e) { alert(e.message); }
            });
        }, 0);
    }

    // Apply theme on load
    const savedTheme = localStorage.getItem('chatx_theme') || 'sakura';
    applyTheme(savedTheme);

    // Modal
    function showModal(title, body) {
        $('#modalTitle').textContent = title;
        $('#modalBody').innerHTML = body;
        $('#modalOverlay').style.display = 'flex';
    }
    function closeModal() { $('#modalOverlay').style.display = 'none'; }
    window.ChatX.closeModal = closeModal;
    $('#modalClose').addEventListener('click', closeModal);
    $('#modalOverlay').addEventListener('click', e => { if (e.target === $('#modalOverlay')) closeModal(); });

    // Logout
    async function doLogout() {
        if (!confirm('确定退出登录？')) return;
        try {
            await api(API.auth + '?action=logout', { method: 'POST' });
        } catch (e) {}
        localStorage.removeItem('chatx_token');
        window.location.href = 'index.php';
    }

    // Unread
    async function updateUnread() {
        try {
            const data = await api(API.chat + '?action=unread');
            const count = data.unread || 0;
            const chatNav = document.querySelector('.nav-item[data-tab="chat"]');
            if (chatNav) {
                let badge = chatNav.querySelector('.badge');
                if (count > 0) {
                    if (!badge) { badge = document.createElement('span'); badge.className = 'badge'; chatNav.appendChild(badge); }
                    badge.textContent = count > 99 ? '99+' : count;
                } else if (badge) { badge.remove(); }
            }
            // Refresh chat list to update per-conversation unread badges
            if (state.currentTab === 'chat') {
                loadChatList();
            }
        } catch (e) {}
    }

    // Utils
    function debounce(fn, ms) { let t; return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); }; }

    function showToast(msg) {
        const el = $('#toast');
        if (el) { el.textContent = msg; el.classList.add('show'); setTimeout(() => el.classList.remove('show'), 2000); }
    }

    // Init
    async function init() {
        if (!await checkAuth()) { window.location.href = 'index.php'; return; }
        initTabs();
        initSearch();
        initActions();
        const adminBtn = $('#navAdmin');
        if (adminBtn) {
            adminBtn.addEventListener('click', () => {
                window.location.href = 'admin.php';
            });
        }
        const forumBtn = $('#navForum');
        if (forumBtn) {
            forumBtn.addEventListener('click', () => {
                window.location.href = 'forum.php';
            });
        }
        $('#modalOverlay').addEventListener('click', e => { if (e.target.id === 'modalOverlay') closeModal(); });
        // Mobile menu
        const menuBtn = $('#btnMenu');
        const sidebar = $('#sidebar');
        const overlay = $('#sidebarOverlay');
        if (menuBtn && sidebar) {
            menuBtn.addEventListener('click', () => {
                if (sidebar.classList.contains('open')) {
                    sidebar.classList.remove('open');
                    if (overlay) overlay.style.display = 'none';
                } else {
                    sidebar.classList.add('open');
                    if (overlay) overlay.style.display = 'block';
                }
            });
        }
        if (overlay) {
            overlay.addEventListener('click', () => {
                sidebar.classList.remove('open');
                overlay.style.display = 'none';
            });
        }
        // Chat message search
        initChatSearch();
        // URL params: ?tab=contacts|chat|groups & ?open=userId
        const urlParams = new URLSearchParams(window.location.search);
        const openId = parseInt(urlParams.get('open') || '0');
        const startTab = urlParams.get('tab') || 'chat';
        // Init theme
        const savedTheme = localStorage.getItem('chatx_theme') || 'light';
        applyTheme(savedTheme);
        if (startTab === 'contacts') {
            state.currentTab = 'contacts';
            $$('.nav-item').forEach(b => b.classList.remove('active'));
            const contactsBtn = document.querySelector('.nav-item[data-tab="contacts"]');
            if (contactsBtn) contactsBtn.classList.add('active');
            $('#listTitle').textContent = '联系人';
            $('#btnAdd').style.display = 'flex';
            await loadContacts();
        } else {
            await loadChatList();
        }
        if (openId > 0) {
            setTimeout(() => openChat('private', openId), 300);
        }
        updateUnread();
        state.unreadTimer = setInterval(updateUnread, 10000);
        // Set online status
        try { await api(API.users + '?action=status', { method: 'POST', body: JSON.stringify({status: 'online'}) }); } catch (e) {}
        window.addEventListener('beforeunload', () => {
            try { api(API.users + '?action=status', { method: 'POST', body: JSON.stringify({status: 'offline'}) }); } catch (e) {}
        });
        // Announcement banner
        try {
            const ann = await api(API.users + '?action=user_announcements&since=' + encodeURIComponent(new Date(Date.now() - 30*24*3600*1000).toISOString()));
            const list = (ann.announcements || []).filter(a => a.title && a.content);
            if (list.length) {
                const banner = $('#announcementBanner');
                if (banner) {
                    banner.style.display = 'block';
                    banner.textContent = '📢 ' + list[0].title + '：' + list[0].content;
                    banner.addEventListener('click', () => {
                        showModal('公告', '<div style="max-height:300px;overflow-y:auto;">' + list.map(a => '<div style="margin-bottom:12px;"><div style="font-weight:600;">' + escapeHtml(a.title) + '</div><div style="color:#666;font-size:12px;margin-top:4px;">' + escapeHtml(a.content) + '</div></div>').join('') + '</div>');
                    });
                }
            }
        } catch (e) {}
    }

    function initChatSearch() {
        const style = document.createElement('style');
        style.textContent = '.msg-highlight { background: yellow !important; } .chat-search { position: absolute; top: 60px; right: 20px; background: #fff; border: 1px solid var(--border); border-radius: var(--radius); padding: 8px; box-shadow: var(--shadow); z-index: 50; display: none; } .chat-search input { padding: 6px 10px; border: 1px solid var(--border); border-radius: 6px; font-size: 13px; width: 180px; }';
        document.head.appendChild(style);
        const observer = new MutationObserver(() => {
            const header = document.querySelector('.chat-header-actions');
            if (header && !document.getElementById('chatSearchBox')) {
                const searchBtn = document.createElement('button');
                searchBtn.className = 'icon-btn';
                searchBtn.id = 'btnChatSearch';
                searchBtn.title = '搜索消息';
                searchBtn.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>';
                header.insertBefore(searchBtn, header.firstChild);
                const searchBox = document.createElement('div');
                searchBox.id = 'chatSearchBox';
                searchBox.className = 'chat-search';
                searchBox.innerHTML = '<input type="text" id="chatSearchInput" placeholder="搜索当前聊天..."><button class="btn btn-sm btn-secondary" id="chatSearchPrev" style="margin-left:4px;">上一个</button><button class="btn btn-sm btn-secondary" id="chatSearchNext" style="margin-left:4px;">下一个</button><button class="btn btn-sm btn-secondary" id="chatSearchClose" style="margin-left:4px;">关闭</button>';
                header.appendChild(searchBox);
                let currentHighlight = -1;
                const highlightAll = () => {
                    document.querySelectorAll('.message .message-content').forEach(el => el.classList.remove('msg-highlight'));
                    currentHighlight = -1;
                };
                const doSearch = (dir) => {
                    const q = document.getElementById('chatSearchInput').value.trim();
                    if (!q) return;
                    const contents = Array.from(document.querySelectorAll('.message .message-content'));
                    highlightAll();
                    const matches = contents.filter(el => el.textContent.toLowerCase().includes(q.toLowerCase()));
                    if (!matches.length) { showToast('未找到匹配'); return; }
                    currentHighlight = (currentHighlight + dir + matches.length) % matches.length;
                    matches[currentHighlight].classList.add('msg-highlight');
                    matches[currentHighlight].scrollIntoView({behavior:'smooth', block:'center'});
                };
                searchBtn.addEventListener('click', () => {
                    const box = document.getElementById('chatSearchBox');
                    box.style.display = box.style.display === 'none' ? 'block' : 'none';
                });
                document.getElementById('chatSearchClose').addEventListener('click', highlightAll);
                document.getElementById('chatSearchPrev').addEventListener('click', () => doSearch(-1));
                document.getElementById('chatSearchNext').addEventListener('click', () => doSearch(1));
                document.getElementById('chatSearchInput').addEventListener('keydown', e => {
                    if (e.key === 'Enter') doSearch(e.shiftKey ? -1 : 1);
                });
            }
        }, {childList: true, subtree: true});
        observer.observe(document.body, {childList: true, subtree: true});
    }

    init();

    // Initialize features (notifications, unread checks)
    if (window.ChatX.initFeatures) window.ChatX.initFeatures();

    // Expose core functions for inline handlers
    window.ChatX.openChat = openChat;

    // ============ 消息搜索 ============
    window.ChatX.showSearch = function () {
        const modal = document.getElementById('searchModal');
        if (!modal) return;
        modal.style.display = 'flex';
        document.getElementById('msgSearchInput')?.focus();
    };
    window.ChatX.closeSearch = function () {
        document.getElementById('searchModal')?.style.setProperty('display', 'none');
    };
    window.ChatX.doSearch = async function () {
        const q = document.getElementById('msgSearchInput').value.trim();
        if (!q) return;
        const scope = document.getElementById('msgSearchScope').value || 'all';
        const btn = document.getElementById('msgSearchBtn');
        if (btn) btn.disabled = true;
        const list = document.getElementById('searchResults');
        list.innerHTML = '<div class="loading">搜索中...</div>';
        try {
            const data = await api('?action=search&q=' + encodeURIComponent(q) + '&scope=' + scope);
            if (data.error) { list.innerHTML = '<div style="color:red;">' + esc(data.error) + '</div>'; return; }
            if (!data.results?.length) { list.innerHTML = '<div style="color:#999;padding:20px;text-align:center;">未找到匹配消息</div>'; return; }
            list.innerHTML = data.results.map(m => {
                const scopeLabel = m.chat_type === 'group' ? '群聊' : (m.is_me ? '我发出' : '收到');
                return '<div class="search-result-item" onclick="window.ChatX.openSearchResult(' + m.id + ',' + (m.group_id || 0) + ',' + (m.receiver_id || 0) + ')">' +
                    '<div class="search-result-meta">' +
                        '<span class="search-scope">' + scopeLabel + '</span>' +
                        '<span class="search-sender">' + esc(m.sender_name) + '</span>' +
                        '<span class="search-time">' + esc(m.created_at) + '</span>' +
                    '</div>' +
                    '<div class="search-result-content">' + esc(m.content) + '</div>' +
                '</div>';
            }).join('');
        } catch (e) { list.innerHTML = '<div style="color:red;">搜索失败</div>'; }
        finally { if (btn) btn.disabled = false; }
    };
    window.ChatX.openSearchResult = function (msgId, groupId, receiverId, senderId) {
        window.ChatX.closeSearch();
        if (groupId) {
            openChat('group', groupId);
        } else {
            // For private chat: if I sent it, target = receiver; if I received it, target = sender
            const targetId = senderId === window.ChatX.user?.id ? receiverId : senderId;
            openChat('private', targetId || 0);
        }
    };
})();