// ChatX 赌场模块 v2：独立游戏页面 + 赔率展示
(function () {
    const API_CASINO = 'api/casino.php';
    let balances = { points: 0, gomoku: 0, casino: 0 };
    let canSignin = false;
    let streak = 0;
    let currentPage = 'lobby';
    let currentGame = null;

    const CUR_NAME = { points: '积分', gomoku: '五子币', casino: '筹码' };
    const CARD_NAMES = ['', 'A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    const SLOT_SYMBOLS = ['🍒', '🍋', '🔔', '⭐', '💎', '7️⃣', '🎯', '💰', '🍀', '🎲',
                          '🃏', '🎪', '🍉', '🍇', '🍑', '🍓', '🥝', '🍊', '🍌', '🍐'];

    // ============ 游戏定义 ============
    const GAMES = [
        { id: 'slot', name: '老虎机', icon: '🎰', desc: '3卷轮老虎机', odds: '20符号仅检中轴线 · 三连中 15倍 (5%) · 相邻两连 1.5倍 (9.5%) · 庄家优势约 11%' },
        { id: 'scratch', name: '刮刮乐', icon: '🎫', desc: '3×3 网格刮刮乐', odds: '10符号检8条线 · 三连 5倍 · 两连 1.5倍 · 庄家优势约 11%' },
        { id: 'wheel', name: '幸运转盘', icon: '🎡', desc: '加权转盘 7分区', odds: '不中 60% · 1倍 18% · 2倍 10% · 3倍 5% · 5倍 4% · 10倍 2% · 0.5倍 1% · 庄家优势约 6.5%' },
        { id: 'dice', name: '投骰子', icon: '🎲', desc: '3骰比大小', odds: '大(11-17) 48.6% · 小(4-10) 48.6% · 豹子(3/6/9/12/15/18) 通杀 · 赢2倍 · 庄家优势 2.8%' },
        { id: 'roulette', name: '俄罗斯轮盘', icon: '🔫', desc: '选1-3发子弹赌空仓', odds: '1发: 83%空仓1.3倍 · 2发: 67%空仓1.6倍 · 3发: 50%空仓2.1倍 · 玩家优势约 5%' },
        { id: 'blackjack', name: '21点', icon: '🃏', desc: '经典 Blackjack', odds: '黑杰克 2.5倍 · 赢 2倍 · 平局保本 · 爆牌输 · 庄家优势约 2%' },
        { id: 'liar', name: '骗子酒馆', icon: '🍺', desc: 'Liar Deck 2-4人局', odds: '20牌6K+6Q+6A+2🃏 · 桌面类型+🃏=真话 · 选1-3张声明真话数 · 被喊全真2倍 · 没被喊说谎1.5倍 · 输了玩左轮(1/6双倍) · 2/3/4人局 · 4动物角色' },
        { id: 'highlow', name: '猜大小', icon: '🔼', desc: '猜第二张牌大小', odds: '猜中 2倍 (46.2%) · 平局 7.7% 不退 · 猜错 46.2% · 庄家优势 7.7%' },
    ];

    // ============ 基础函数 ============
    async function api(action, options) {
        const token = (window.ChatX && window.ChatX.token) || '';
        const sep = action.includes('?') ? '&' : '?';
        const r = await fetch(API_CASINO + (action.startsWith('?') ? action : sep + action), Object.assign({
            headers: { 'X-Auth-Token': token, 'Content-Type': 'application/json' }, credentials: 'include'
        }, options));
        const text = await r.text();
        try { return JSON.parse(text); } catch (e) { throw new Error(text.substring(0, 200) || '响应格式错误'); }
    }
    function esc(s) { if (!s) return ''; return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
    function cardName(r) { return CARD_NAMES[r] || '?'; }

    // ============ 导航系统 ============
    function navigateTo(page, gameId) {
        currentPage = page;
        currentGame = gameId || null;
        const content = document.getElementById('casinoContent');
        if (!content) return;
        if (page === 'lobby') renderLobby();
        else if (page === 'multiplayer') renderMultiplayer();
        else if (page === 'mp_game' && gameId) renderMultiplayerGame(gameId);
        else if (page === 'game' && gameId) renderGame(gameId);
    }

    function renderLobby() {
        const content = document.getElementById('casinoContent');
        if (!content) return;
        content.innerHTML = `
            <div class="casino-lobby">
                <div class="wallet-bar" id="walletBar"></div>
                <div class="casino-actions">
                    <button class="btn btn-sm" id="btnSignin">📅 每日签到</button>
                    <button class="btn btn-sm" id="btnExchange">🔄 货币兑换</button>
                    <button class="btn btn-sm" id="btnTransfer">🎁 赠送/交易</button>
                </div>
                <div id="casinoForms"></div>
                <h3 style="margin:16px 0 8px;color:#ffd166;">🎮 选择游戏</h3>
                <div class="game-grid">
                    ${GAMES.map(g => `
                        <div class="game-card" data-game="${g.id}">
                            <div class="game-card-icon">${g.icon}</div>
                            <div class="game-card-name">${g.name}</div>
                            <div class="game-card-desc">${g.desc}</div>
                        </div>
                    `).join('')}
                </div>
                <h3 style="margin:16px 0 8px;color:#ffd166;">🤝 联机对赌</h3>
                <button class="btn btn-sm btn-primary game-card-enter" data-page="multiplayer">进入联机大厅</button>
                <h3 style="margin:16px 0 8px;color:#ffd166;">📋 交易记录</h3>
                <div id="casinoHistory"><div class="loading">加载中...</div></div>
            </div>
        `;
        bindLobbyControls();
        renderWallet();
        loadHistory();
    }

    function bindLobbyControls() {
        const btnSignin = document.getElementById('btnSignin');
        if (btnSignin) btnSignin.onclick = doSignin;
        const btnExchange = document.getElementById('btnExchange');
        if (btnExchange) btnExchange.onclick = () => showForm('exchange');
        const btnTransfer = document.getElementById('btnTransfer');
        if (btnTransfer) btnTransfer.onclick = () => showForm('transfer');
        document.querySelectorAll('.game-card').forEach(card => {
            card.onclick = () => navigateTo('game', card.dataset.game);
        });
        document.querySelectorAll('.game-card-enter').forEach(btn => {
            btn.onclick = () => navigateTo(btn.dataset.page);
        });
    }

    // ============ 游戏页面渲染 ============
    function renderGame(gameId) {
        const game = GAMES.find(g => g.id === gameId);
        if (!game) { navigateTo('lobby'); return; }
        const content = document.getElementById('casinoContent');
        if (!content) return;

        const pages = {
            slot: renderGameSlot, scratch: renderGameScratch, wheel: renderGameWheel,
            dice: renderGameDice, roulette: renderGameRoulette, blackjack: renderGameBlackjack,
            liar: renderGameLiar, highlow: renderGameHighLow,
        };
        const pageFn = pages[gameId];
        if (!pageFn) { navigateTo('lobby'); return; }

        content.innerHTML = `
            <div class="game-page">
                <div class="wallet-bar" id="walletBar"></div>
                <div class="game-page-header">
                    <button class="btn btn-sm" id="btnBackToLobby">← 返回大厅</button>
                    <h3 style="margin:0;color:#ffd166;">${game.icon} ${game.name}</h3>
                </div>
                <div class="game-odds-box">
                    <span class="game-odds-label">赔率</span>
                    <span class="game-odds-text">${game.odds}</span>
                </div>
                <div id="gameArea"></div>
            </div>
        `;
        renderWallet();
        pageFn(gameId);
        const btnBack = document.getElementById('btnBackToLobby');
        if (btnBack) btnBack.onclick = () => navigateTo('lobby');
    }

    // ---- 老虎机 ----
    function renderGameSlot() {
        document.getElementById('gameArea').innerHTML = `
            <div class="casino-form" style="max-width:400px;margin:12px auto;">
                <div class="bet-row">
                    <input type="number" id="slotBet" class="bet-input" value="100" min="1" placeholder="下注筹码">
                    <button class="btn btn-sm btn-primary" id="btnSlotSpin">拉杆转动</button>
                </div>
                <div class="slot-area" id="slotArea" style="display:none;">
                    <div class="slot-reels" id="slotReels"></div>
                    <div class="slot-result" id="slotResult"></div>
                </div>
            </div>`;
        const btn = document.getElementById('btnSlotSpin');
        if (btn) btn.onclick = slotSpin;
    }

    // ---- 刮刮乐 ----
    function renderGameScratch() {
        document.getElementById('gameArea').innerHTML = `
            <div class="casino-form" style="max-width:400px;margin:12px auto;">
                <div class="bet-row">
                    <input type="number" id="scBet" class="bet-input" value="100" min="1" placeholder="下注筹码">
                    <button class="btn btn-sm btn-primary" id="btnScratch">刮开看看</button>
                </div>
                <div class="scratch-area" id="scratchArea" style="display:none;">
                    <div class="scratch-grid" id="scratchGrid"></div>
                    <div class="scratch-result" id="scratchResult"></div>
                </div>
            </div>`;
        const btn = document.getElementById('btnScratch');
        if (btn) btn.onclick = scratchPlay;
    }

    // ---- 幸运转盘 ----
    function renderGameWheel() {
        document.getElementById('gameArea').innerHTML = `
            <div class="casino-form" style="max-width:400px;margin:12px auto;">
                <div class="bet-row">
                    <input type="number" id="wheelBet" class="bet-input" value="100" min="1" placeholder="下注筹码">
                    <button class="btn btn-sm btn-primary" id="btnWheel">转动转盘</button>
                </div>
                <div class="wheel-area" id="wheelArea" style="display:none;">
                    <div class="wheel-display" id="wheelDisplay"></div>
                    <div class="wheel-result" id="wheelResult"></div>
                </div>
            </div>`;
        const btn = document.getElementById('btnWheel');
        if (btn) btn.onclick = wheelSpin;
    }

    // ---- 投骰子 ----
    function renderGameDice() {
        document.getElementById('gameArea').innerHTML = `
            <div class="casino-form" style="max-width:400px;margin:12px auto;">
                <div class="bet-row">
                    <input type="number" id="diceBet" class="bet-input" value="100" min="1" placeholder="下注筹码">
                    <span id="diceSideRow">
                        <button class="btn btn-sm" id="btnDiceSmall">押 小 (4-10)</button>
                        <button class="btn btn-sm" id="btnDiceBig">押 大 (11-17)</button>
                    </span>
                    <button class="btn btn-sm btn-primary" id="btnDiceRoll">掷骰子</button>
                </div>
                <div id="diceResult" class="game-result"></div>
            </div>`;
        let pendingSide = 'big';
        const bs = document.getElementById('btnDiceSmall');
        const bb = document.getElementById('btnDiceBig');
        if (bs) bs.onclick = () => { pendingSide = 'small'; bs.style.background = '#e94560'; bb.style.background = ''; };
        if (bb) bb.onclick = () => { pendingSide = 'big'; bb.style.background = '#e94560'; bs.style.background = ''; };
        const btn = document.getElementById('btnDiceRoll');
        if (btn) btn.onclick = () => soloDice(pendingSide);
    }

    // ---- 俄罗斯轮盘 ----
    function renderGameRoulette() {
        document.getElementById('gameArea').innerHTML = `
            <div class="casino-form" style="max-width:400px;margin:12px auto;">
                <div class="bet-row">
                    <input type="number" id="rlBet" class="bet-input" value="100" min="1" placeholder="下注筹码">
                    <select id="rlBullets" class="bet-input" style="width:auto;">
                        ${[1,2,3].map(b => {
                            const m = (6.3 / (6 - b)).toFixed(1);
                            const p = ((6 - b) / 6 * 100).toFixed(0);
                            return `<option value="${b}">${b} 发 (${p}%空仓 ${m}倍)</option>`;
                        }).join('')}
                    </select>
                    <button class="btn btn-sm btn-primary" id="btnRlSpin">扣动扳机</button>
                </div>
                <div id="rlResult" class="game-result"></div>
            </div>`;
        const btn = document.getElementById('btnRlSpin');
        if (btn) btn.onclick = soloRoulette;
    }

    // ---- 21点 ----
    let bjState = null;
    function renderGameBlackjack() {
        bjState = null;
        document.getElementById('gameArea').innerHTML = `
            <div class="casino-form" style="max-width:480px;margin:12px auto;">
                <div id="bjIdle">
                    <div class="bet-row">
                        <input type="number" id="bjBet" class="bet-input" value="100" min="1" placeholder="下注筹码">
                        <button class="btn btn-sm btn-primary" id="btnBjStart">开局</button>
                    </div>
                </div>
                <div id="bjGame" style="display:none;">
                    <div class="bj-dealer">
                        <h5>庄家</h5>
                        <div id="bjDealerCards" class="bj-cards"></div>
                    </div>
                    <div class="bj-player">
                        <h5>玩家 <span id="bjPlayerVal"></span></h5>
                        <div id="bjPlayerCards" class="bj-cards"></div>
                    </div>
                    <div id="bjControls" class="bet-row">
                        <button class="btn btn-sm btn-primary" id="btnBjHit">要牌</button>
                        <button class="btn btn-sm" id="btnBjStand">停牌</button>
                        <button class="btn btn-sm" id="btnBjDouble">加倍</button>
                    </div>
                    <div id="bjResult" class="game-result"></div>
                </div>
            </div>`;
        const btnStart = document.getElementById('btnBjStart');
        if (btnStart) btnStart.onclick = bjStart;
        const btnHit = document.getElementById('btnBjHit');
        if (btnHit) btnHit.onclick = bjHit;
        const btnStand = document.getElementById('btnBjStand');
        if (btnStand) btnStand.onclick = bjStand;
        const btnDouble = document.getElementById('btnBjDouble');
        if (btnDouble) btnDouble.onclick = bjDouble;
    }

    // ---- 骗子酒馆 Liar's Deck (4动物角色 + 左轮) ----
    const LIAR_ANIMALS = [
        { id: 'scabby', name: 'Scabby', emoji: '🐕', desc: '纹身恶犬' },
        { id: 'foxy', name: 'Foxy', emoji: '🦊', desc: '哥特妖狐' },
        { id: 'bristol', name: 'Bristol', emoji: '🐷', desc: '屠夫胖猪' },
        { id: 'thor', name: 'Thor', emoji: '🐂', desc: '狂暴公牛' },
    ];
    let liarCharacter = null;
    let liarOpponents = [];
    let liarPlayerCount = 2;

    function renderGameLiar() {
        document.getElementById('gameArea').innerHTML = `
            <div class="casino-form" style="max-width:520px;margin:12px auto;">
                <div id="liarIdle">
                    <div style="text-align:center;margin-bottom:12px;">
                        <div style="font-size:13px;color:#8fa3c8;margin-bottom:8px;">选择你的角色</div>
                        <div id="liarAnimals" style="display:flex;justify-content:center;gap:8px;">
                            ${LIAR_ANIMALS.map(a => `<div class="liar-animal" data-animal="${a.id}" onclick="window.ChatX.selectLiarAnimal('${a.id}')" style="cursor:pointer;padding:8px;border-radius:10px;border:2px solid transparent;text-align:center;transition:all 0.15s;">
                                <div style="font-size:32px;">${a.emoji}</div>
                                <div style="font-size:11px;margin-top:4px;">${a.name}</div>
                            </div>`).join('')}
                        </div>
                    </div>
                    <div class="bet-row">
                        <input type="number" id="liarBet" class="bet-input" value="100" min="1" placeholder="下注筹码">
                        <select id="liarPlayers" class="bet-input" style="width:auto;">
                            <option value="2">2人局</option>
                            <option value="3">3人局</option>
                            <option value="4">4人局</option>
                        </select>
                        <button class="btn btn-sm btn-primary" id="btnLiarStart" disabled>开局</button>
                    </div>
                    <div id="liarPlayerHint" style="font-size:11px;color:#6a7f9a;margin-top:6px;text-align:center;"></div>
                </div>
                <div id="liarGame" style="display:none;">
                    <div id="liarVS" style="display:flex;justify-content:center;align-items:center;gap:10px;margin-bottom:12px;padding:10px;background:#0f1923;border:1px solid #1a3a4a;border-radius:10px;flex-wrap:wrap;">
                        <div style="text-align:center;">
                            <div style="font-size:32px;" id="liarMyEmoji"></div>
                            <div style="font-size:11px;color:#8fa3c8;">你</div>
                        </div>
                        <div style="font-size:16px;color:#e94560;font-weight:bold;">VS</div>
                        <div id="liarOpponents" style="display:flex;gap:8px;"></div>
                    </div>
                    <div id="liarTableType" style="text-align:center;padding:10px;margin-bottom:10px;background:#0f1923;border:1px solid #1a3a4a;border-radius:8px;font-size:14px;"></div>
                    <div style="font-size:13px;color:#8fa3c8;margin-bottom:8px;">你的5张牌（点击选择1-3张）</div>
                    <div id="liarCards" class="liar-cards"></div>
                    <div class="bet-row" style="margin-top:12px;">
                        <select id="liarTruths" class="bet-input" style="width:auto;">
                            <option value="0">声明0张真话</option>
                            <option value="1">声明1张真话</option>
                            <option value="2" selected>声明2张真话</option>
                            <option value="3">声明3张真话</option>
                        </select>
                        <button class="btn btn-sm btn-primary" id="btnLiarPlay">出牌</button>
                        <button class="btn btn-sm" id="btnLiarForfeit">弃权</button>
                    </div>
                    <div id="liarHint" style="font-size:11px;color:#6a7f9a;margin-top:8px;line-height:1.5;"></div>
                    <div id="liarResult" class="game-result"></div>
                </div>
            </div>`;
        const btnStart = document.getElementById('btnLiarStart');
        if (btnStart) btnStart.onclick = liarStart;
        const btnPlay = document.getElementById('btnLiarPlay');
        if (btnPlay) btnPlay.onclick = liarPlay;
        const btnForfeit = document.getElementById('btnLiarForfeit');
        if (btnForfeit) btnForfeit.onclick = liarForfeit;
        const selPlayers = document.getElementById('liarPlayers');
        if (selPlayers) selPlayers.onchange = function() {
            liarPlayerCount = parseInt(this.value);
            updatePlayerHint();
        };
        if (liarCharacter) { highlightLiarAnimal(liarCharacter); document.getElementById('btnLiarStart').disabled = false; }
        updatePlayerHint();
    }

    function updatePlayerHint() {
        const hints = {
            2: '2人局：1个AI对手，喊"骗子"概率中等',
            3: '3人局：2个AI对手，喊"骗子"概率较高',
            4: '4人局：3个AI对手，喊"骗子"概率最高，刺激！',
        };
        const el = document.getElementById('liarPlayerHint');
        if (el) el.textContent = hints[liarPlayerCount] || '';
    }

    function selectLiarAnimal(id) {
        liarCharacter = id;
        liarOpponents = [];
        document.getElementById('btnLiarStart').disabled = false;
        highlightLiarAnimal(id);
    }

    function highlightLiarAnimal(id) {
        document.querySelectorAll('.liar-animal').forEach(el => {
            if (el.dataset.animal === id) el.style.borderColor = '#e94560';
            else el.style.borderColor = 'transparent';
        });
    }
    window.ChatX.selectLiarAnimal = selectLiarAnimal;

    // ---- 猜大小 ----
    function renderGameHighLow() {
        document.getElementById('gameArea').innerHTML = `
            <div class="casino-form" style="max-width:400px;margin:12px auto;">
                <div class="bet-row">
                    <input type="number" id="hlBet" class="bet-input" value="100" min="1" placeholder="下注筹码">
                    <button class="btn btn-sm" id="btnHlHigher">猜更大 🔼</button>
                    <button class="btn btn-sm" id="btnHlLower">猜更小 🔽</button>
                </div>
                <div id="hlResult" class="game-result"></div>
            </div>`;
        const btnH = document.getElementById('btnHlHigher');
        if (btnH) btnH.onclick = () => soloHighLow('higher');
        const btnL = document.getElementById('btnHlLower');
        if (btnL) btnL.onclick = () => soloHighLow('lower');
    }

    // ============ 联机大厅 ============
    const MP_GAMES = [
        { id: 'dice', name: '投骰子比大小', icon: '🎲', desc: '3骰比大小，押大/小' },
        { id: 'roulette', name: '俄罗斯轮盘', icon: '🔫', desc: '选1-3发子弹，赌空仓' },
        { id: 'blackjack', name: '21点', icon: '🃏', desc: '2张比大，谁先爆谁输' },
        { id: 'liar', name: '骗子酒馆', icon: '🍺', desc: '回合制出牌 喊骗子 左轮' },
        { id: 'highlow', name: '猜大小', icon: '🔼', desc: '猜对方牌更大还是更小' },
    ];

    function renderMultiplayer() {
        const content = document.getElementById('casinoContent');
        if (!content) return;
        content.innerHTML = `
            <div class="casino-lobby">
                <div class="wallet-bar" id="walletBar"></div>
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;">
                    <button class="btn btn-sm" id="btnBackToLobby">← 返回大厅</button>
                    <h3 style="margin:0;color:#ffd166;">🤝 联机对赌</h3>
                </div>
                <div class="game-grid">
                    ${MP_GAMES.map(g => `
                        <div class="game-card" data-mpgame="${g.id}">
                            <div class="game-card-icon">${g.icon}</div>
                            <div class="game-card-name">${g.name}</div>
                            <div class="game-card-desc">${g.desc}</div>
                        </div>
                    `).join('')}
                </div>
            </div>`;
        const btnBack = document.getElementById('btnBackToLobby');
        if (btnBack) btnBack.onclick = () => navigateTo('lobby');
        renderWallet();
        document.querySelectorAll('.game-card[data-mpgame]').forEach(card => {
            card.onclick = () => navigateTo('mp_game', card.dataset.mpgame);
        });
    }

    // ---- 联机游戏独立页面 ----
    let mpLiarState = null; // 多人骗子酒馆游戏状态

    function renderMultiplayerGame(gameId) {
        // Liar with active game → game view
        if (gameId === 'liar' && mpLiarState) { renderMpLiarGame(); return; }
        // Dispatch to individual game pages
        if (gameId === 'dice') { renderMpDicePage(); return; }
        if (gameId === 'roulette') { renderMpRoulettePage(); return; }
        if (gameId === 'blackjack') { renderMpBlackjackPage(); return; }
        if (gameId === 'highlow') { renderMpHighLowPage(); return; }
        if (gameId === 'liar') { renderMpLiarPage(); return; }
        navigateTo('multiplayer');
    }

    function mpPageShell(game, title, body) {
        return `<div class="casino-lobby">
            <div class="wallet-bar" id="walletBar"></div>
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px;">
                <button class="btn btn-sm" id="btnBackToMpLobby">← 返回联机大厅</button>
                <h3 style="margin:0;color:#ffd166;">${game.icon} ${game.name}</h3>
            </div>
            ${body}
            <h3 style="margin:16px 0 8px;color:#ffd166;">开放赌局</h3>
            <div id="betRooms"><div class="loading">加载中...</div></div>
            <h3 style="margin:16px 0 8px;color:#ffd166;">我的赌局</h3>
            <div id="myBets"><div class="loading">加载中...</div></div>
        </div>`;
    }

    function mpBindCommon(gameId) {
        renderWallet();
        document.getElementById('btnBackToMpLobby').onclick = () => navigateTo('multiplayer');
        loadBetRooms(gameId);
        loadMyBets(gameId);
    }

    // ---- 投骰子比大小 ----
    function renderMpDicePage() {
        const game = MP_GAMES.find(g => g.id === 'dice');
        document.getElementById('casinoContent').innerHTML = mpPageShell(game, '🎲 投骰子比大小', `
            <div class="casino-form">
                <h4>🎲 开赌局</h4>
                <div class="bet-row">
                    <input type="number" id="betAmount" class="bet-input" value="100" min="1" placeholder="赌注">
                    <button class="btn btn-sm" id="btnSideSmall">押小 (4-10)</button>
                    <button class="btn btn-sm btn-primary" id="btnSideBig" style="background:#e94560;">押大 (11-17)</button>
                </div>
                <div class="game-result" id="betCreateResult"></div>
                <p style="font-size:11px;color:#6a7f9a;margin-top:4px;">3骰比大小，三同平局退回</p>
            </div>`);
        mpBindCommon('dice');
        let pendingSide = 'big';
        document.getElementById('btnSideSmall').onclick = () => { pendingSide = 'small'; document.getElementById('btnSideSmall').style.background = '#e94560'; document.getElementById('btnSideBig').style.background = ''; };
        document.getElementById('btnSideBig').onclick = () => { pendingSide = 'big'; document.getElementById('btnSideBig').style.background = '#e94560'; document.getElementById('btnSideSmall').style.background = ''; };
        document.getElementById('btnBetCreate').onclick = () => createBet(pendingSide);
    }

    // ---- 俄罗斯轮盘 ----
    function renderMpRoulettePage() {
        const game = MP_GAMES.find(g => g.id === 'roulette');
        document.getElementById('casinoContent').innerHTML = mpPageShell(game, '🔫 俄罗斯轮盘', `
            <div class="casino-form">
                <h4>🔫 开赌局</h4>
                <div class="bet-row">
                    <input type="number" id="betAmount" class="bet-input" value="100" min="1" placeholder="赌注">
                    <select id="betBullets" class="bet-input" style="width:auto;">
                        ${[1,2,3].map(b => {
                            const m = (6.3 / (6 - b)).toFixed(1);
                            const p = ((6 - b) / 6 * 100).toFixed(0);
                            return `<option value="${b}">${b}发 (${p}%空仓 ${m}倍)</option>`;
                        }).join('')}
                    </select>
                    <button class="btn btn-sm btn-primary" id="btnBetCreate">开局等人</button>
                </div>
                <div class="game-result" id="betCreateResult"></div>
                <p style="font-size:11px;color:#6a7f9a;margin-top:4px;">6个弹巢，放子弹后随机转，空仓=对手赢</p>
            </div>`);
        mpBindCommon('roulette');
        document.getElementById('btnBetCreate').onclick = () => createBet();
    }

    // ---- 21点 ----
    function renderMpBlackjackPage() {
        const game = MP_GAMES.find(g => g.id === 'blackjack');
        document.getElementById('casinoContent').innerHTML = mpPageShell(game, '🃏 21点', `
            <div class="casino-form">
                <h4>🃏 开赌局</h4>
                <div class="bet-row">
                    <input type="number" id="betAmount" class="bet-input" value="100" min="1" placeholder="赌注">
                    <button class="btn btn-sm btn-primary" id="btnBetCreate">开局等人</button>
                </div>
                <div class="game-result" id="betCreateResult"></div>
                <p style="font-size:11px;color:#6a7f9a;margin-top:4px;">各发2张牌比点数，最接近21且不爆赢</p>
            </div>`);
        mpBindCommon('blackjack');
        document.getElementById('btnBetCreate').onclick = () => createBet();
    }

    // ---- 猜大小 ----
    function renderMpHighLowPage() {
        const game = MP_GAMES.find(g => g.id === 'highlow');
        document.getElementById('casinoContent').innerHTML = mpPageShell(game, '🔼 猜大小', `
            <div class="casino-form">
                <h4>🔼 开赌局</h4>
                <div class="bet-row">
                    <input type="number" id="betAmount" class="bet-input" value="100" min="1" placeholder="赌注">
                    <select id="betHlDir" class="bet-input" style="width:auto;">
                        <option value="higher">猜对方更大</option>
                        <option value="lower">猜对方更小</option>
                    </select>
                    <button class="btn btn-sm btn-primary" id="btnBetCreate">开局等人</button>
                </div>
                <div class="game-result" id="betCreateResult"></div>
                <p style="font-size:11px;color:#6a7f9a;margin-top:4px;">各抽2张牌，猜对方比你大还是小</p>
            </div>`);
        mpBindCommon('highlow');
        document.getElementById('btnBetCreate').onclick = () => createBet();
    }

    // ---- 骗子酒馆（大厅页）----
    function renderMpLiarPage() {
        const game = MP_GAMES.find(g => g.id === 'liar');
        document.getElementById('casinoContent').innerHTML = mpPageShell(game, '🍺 骗子酒馆', `
            <div class="casino-form">
                <h4>🍺 开赌局</h4>
                <div class="bet-row">
                    <input type="number" id="betAmount" class="bet-input" value="100" min="1" placeholder="赌注">
                    <button class="btn btn-sm btn-primary" id="btnBetCreate">开局等人</button>
                </div>
                <div class="game-result" id="betCreateResult"></div>
                <p style="font-size:11px;color:#6a7f9a;margin-top:4px;">回合制出牌，喊"骗子"，左轮俄罗斯轮盘</p>
            </div>`);
        mpBindCommon('liar');
        document.getElementById('btnBetCreate').onclick = () => mpLiarCreate();
    }

    // ---- 多人骗子酒馆回合制游戏 ----
    const LIAR_CARD_MAP = { 'K': '👑', 'Q': '👸', 'A': '🅰️', '🃏': '🃏' };
    const LIAR_TYPE_NAMES = { 'K': 'King', 'Q': 'Queen', 'A': 'Ace' };
    let liarSelectedCards = new Set();

    function renderMpLiarGame() {
        const content = document.getElementById('casinoContent');
        if (!content) return;
        const s = mpLiarState;
        if (!s) { renderMultiplayerGame('liar'); return; }
        
        const myTurnText = s.my_turn ? '🎯 轮到你了！' : `⏳ 等待 ${s.opponent_name} ...`;
        const tableTypeEmoji = LIAR_CARD_MAP[s.table_type] || s.table_type;
        const tableTypeName = LIAR_TYPE_NAMES[s.table_type] || s.table_type;
        
        content.innerHTML = `
            <div class="casino-lobby">
                <div class="wallet-bar" id="walletBar"></div>
                <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">
                    <button class="btn btn-sm" id="btnBackToLobby">← 返回</button>
                    <h3 style="margin:0;color:#ffd166;">🍺 骗子酒馆</h3>
                    <span style="margin-left:auto;font-size:12px;color:#8fa3c8;">#${s.room_id} · ${s.bet_amount}筹码</span>
                    <button class="btn btn-sm" id="btnRefreshState">🔄</button>
                </div>
                <div style="text-align:center;padding:8px;background:#0f1923;border:1px solid #1a3a4a;border-radius:8px;margin-bottom:12px;">
                    <span style="font-size:13px;color:#8fa3c8;">桌面类型：</span>
                    <span style="font-size:20px;font-weight:bold;">${tableTypeEmoji} ${tableTypeName}</span>
                    <span style="font-size:11px;color:#6a7f9a;margin-left:8px;">(此类型+🃏=真话)</span>
                </div>
                <div style="text-align:center;padding:8px;margin-bottom:12px;font-size:14px;font-weight:bold;color:${s.my_turn ? '#67c23a' : '#e94560'};">
                    ${myTurnText}
                </div>
                ${s.my_eliminated ? '<div style="text-align:center;padding:16px;background:#1a0000;border:1px solid #f56c6c;border-radius:8px;color:#f56c6c;font-weight:bold;">💀 你已被淘汰</div>' : ''}
                ${!s.my_eliminated ? `
                    <div style="margin-bottom:12px;">
                        <div style="font-size:13px;color:#8fa3c8;margin-bottom:8px;">你的手牌（点击选择1-3张出牌）</div>
                        <div id="mpLiarCards" class="liar-cards" style="justify-content:flex-start;flex-wrap:wrap;"></div>
                    </div>
                    <div style="display:flex;gap:8px;justify-content:center;margin-bottom:12px;">
                        <button class="btn btn-sm btn-primary" id="btnMpLiarPlay" ${s.my_turn ? '' : 'disabled'}>出牌</button>
                        <button class="btn btn-sm btn-warning" id="btnMpLiarCall" ${s.my_turn && s.last_cards.length > 0 ? '' : 'disabled'}>喊"骗子"！</button>
                    </div>
                    <div id="mpLiarResult" class="game-result"></div>
                ` : ''}
                ${s.last_cards.length > 0 ? `
                    <div style="margin-bottom:12px;padding:8px;background:#0f1923;border:1px solid #1a3a4a;border-radius:8px;">
                        <div style="font-size:12px;color:#8fa3c8;margin-bottom:4px;">上一轮出的牌：</div>
                        <div style="display:flex;gap:6px;justify-content:center;">
                            ${s.last_cards.map(c => `<div class="liar-card">${LIAR_CARD_MAP[c] || c}</div>`).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>`;
        
        renderWallet();
        document.getElementById('btnBackToLobby').onclick = () => { mpLiarState = null; navigateTo('multiplayer'); };
        document.getElementById('btnRefreshState').onclick = async () => {
            try {
                const d = await api('?action=liar_mp_state&room_id=' + mpLiarState.room_id);
                if (d.error) { alert(d.error); return; }
                mpLiarState = {
                    room_id: d.room_id,
                    my_cards: d.my_cards,
                    table_type: d.table_type,
                    pile: d.pile || [],
                    last_cards: d.last_cards || [],
                    my_turn: d.my_turn,
                    my_eliminated: d.my_eliminated,
                    my_role: d.my_role,
                    opponent_name: d.opponent_name,
                    turn: d.turn,
                    bet_amount: d.bet_amount,
                    status: d.status,
                };
                liarSelectedCards = new Set();
                renderMpLiarGame();
            } catch (e) { alert('刷新失败'); }
        };
        
        // Render cards
        const cardsEl = document.getElementById('mpLiarCards');
        if (cardsEl) {
            cardsEl.innerHTML = s.my_cards.map((c, i) => {
                const selected = liarSelectedCards.has(i);
                const cls = selected ? 'liar-card liar-selected' : 'liar-card';
                return `<div class="${cls}" onclick="window.ChatX.toggleMpLiarCard(${i})" style="cursor:pointer;">${LIAR_CARD_MAP[c] || c}</div>`;
            }).join('');
        }
        
        const btnPlay = document.getElementById('btnMpLiarPlay');
        if (btnPlay) btnPlay.onclick = mpLiarPlay;
        const btnCall = document.getElementById('btnMpLiarCall');
        if (btnCall) btnCall.onclick = mpLiarCall;
    }

    function toggleMpLiarCard(idx) {
        if (liarSelectedCards.has(idx)) liarSelectedCards.delete(idx);
        else if (liarSelectedCards.size < 3) liarSelectedCards.add(idx);
        else return;
        renderMpLiarGame();
    }
    window.ChatX.toggleMpLiarCard = toggleMpLiarCard;

    async function mpLiarCreate() {
        const amount = parseInt(document.getElementById('betAmount').value) || 0;
        if (amount <= 0) { alert('请输入赌注'); return; }
        if (amount > balances.casino) { alert('筹码不足'); return; }
        try {
            const data = await api('action=bet_create', { method: 'POST', body: JSON.stringify({ game_mode: 'liar', bet_amount: amount, choice: {} }) });
            if (data.error) { alert(data.error); return; }
            mpLiarState = {
                room_id: data.room_id,
                my_cards: data.my_cards,
                table_type: data.table_type,
                pile: [],
                last_cards: [],
                my_turn: false,
                my_eliminated: false,
                my_role: 'host',
                opponent_name: '等待对手...',
                turn: 1,
                bet_amount: amount,
                status: 'waiting',
            };
            liarSelectedCards = new Set();
            loadWallet();
            loadBetRooms('liar');
            loadMyBets('liar');
            renderMpLiarGame();
        } catch (e) { alert('开局失败: ' + e.message); }
    }

    async function mpLiarJoin(roomId) {
        try {
            const data = await api('action=bet_join', { method: 'POST', body: JSON.stringify({ room_id: roomId, choice: {} }) });
            if (data.error) { alert(data.error); return; }
            mpLiarState = {
                room_id: data.room_id || roomId,
                my_cards: data.my_cards,
                table_type: data.table_type,
                pile: data.pile || [],
                last_cards: [],
                my_turn: data.my_turn,
                my_eliminated: false,
                my_role: 'guest',
                opponent_name: '房主',
                turn: 1,
                bet_amount: 0,
                status: 'playing',
            };
            liarSelectedCards = new Set();
            loadWallet();
            renderMpLiarGame();
        } catch (e) { alert('加入失败: ' + e.message); }
    }

    async function mpLiarPlay() {
        if (!mpLiarState || !mpLiarState.my_turn) return;
        if (liarSelectedCards.size < 1) { alert('请至少选择1张牌'); return; }
        const indices = Array.from(liarSelectedCards).sort((a,b) => a-b);
        try {
            const data = await api('action=liar_mp_action', { method: 'POST', body: JSON.stringify({ room_id: mpLiarState.room_id, action: 'play', card_indices: indices }) });
            if (data.error) { alert(data.error); return; }
            liarSelectedCards = new Set();
            mpLiarState = { ...mpLiarState, ...data, pile: data.pile || [], last_cards: data.last_cards || [] };
            loadWallet();
            renderMpLiarGame();
        } catch (e) { alert('操作失败: ' + e.message); }
    }

    async function mpLiarCall() {
        if (!mpLiarState || !mpLiarState.my_turn) return;
        if (!confirm('确定要喊"骗子"吗？如果喊错了，你要玩左轮！')) return;
        try {
            const data = await api('action=liar_mp_action', { method: 'POST', body: JSON.stringify({ room_id: mpLiarState.room_id, action: 'liar' }) });
            if (data.error) { alert(data.error); return; }
            liarSelectedCards = new Set();
            mpLiarState = { ...mpLiarState, ...data, pile: data.pile || [], last_cards: data.last_cards || [] };
            loadWallet();
            const r = data.result || {};
            let msg = '';
            if (r.has_lie !== undefined) {
                msg = r.has_lie ? '✅ 质疑成功！对手撒谎了！' : '❌ 质疑失败！对手全是真话！';
            }
            if (data.rr_result === 'dead') msg += '\n💀 左轮开了！双倍损失！';
            else if (data.rr_result === 'blank') msg += '\n💨 左轮空响，你活下来了！';
            if (data.game_over) msg += '\n🎮 游戏结束！' + (r.winner === mpLiarState.my_role ? '🏆 你赢了！' : '😞 你输了！');
            alert(msg);
            renderMpLiarGame();
        } catch (e) { alert('操作失败: ' + e.message); }
    }

    // ============ 钱包 ============
    function renderWallet() {
        const bar = document.getElementById('walletBar');
        if (!bar) return;
        bar.innerHTML = Object.keys(CUR_NAME).map(c => `
            <div class="wallet-chip">
                <span class="wallet-cur">${CUR_NAME[c]}</span>
                <span class="wallet-val" id="bal-${c}">${balances[c].toLocaleString()}</span>
            </div>
        `).join('');
        const btn = document.getElementById('btnSignin');
        if (btn) {
            btn.textContent = canSignin ? `📅 每日签到 (+${100 + Math.min(streak, 6) * 20})` : `✅ 今日已签 (连签${streak}天)`;
            btn.disabled = !canSignin;
        }
    }

    async function loadWallet() {
        try {
            const data = await api('?action=wallet');
            if (data.error) { alert(data.error); return; }
            balances = data.balances;
            canSignin = data.can_signin;
            streak = data.streak;
            if (currentPage === 'lobby') renderLobby();
            else if (currentPage === 'multiplayer') renderMultiplayer();
            else if (currentPage === 'mp_game' && currentGame) renderMultiplayerGame(currentGame);
            else if (currentPage === 'game' && currentGame) renderGame(currentGame);
            loadHistory();
        } catch (e) { console.error('Wallet load error:', e); alert('钱包加载失败: ' + e.message); }
    }

    function updateBalances(newBal) {
        balances = newBal;
        Object.keys(CUR_NAME).forEach(c => {
            const el = document.getElementById('bal-' + c);
            if (el) el.textContent = balances[c].toLocaleString();
        });
    }

    // ============ 签到/兑换/赠送 ============
    async function doSignin() {
        if (!canSignin) { alert('今天已签到，明天再来'); return; }
        try {
            const data = await api('?action=signin', { method: 'POST' });
            if (data.error) { alert(data.error); return; }
            alert('签到成功！获得 ' + data.reward + ' 积分（连续 ' + data.streak + ' 天）');
            loadWallet();
        } catch (e) { alert(e.message); }
    }

    function showForm(which) {
        const box = document.getElementById('casinoForms');
        if (!box) return;
        if (which === 'exchange') {
            box.innerHTML = `
                <div class="casino-form">
                    <h4>🔄 货币兑换</h4>
                    <div class="bet-row">
                        <select id="exFrom">${Object.keys(CUR_NAME).map(c => `<option value="${c}">${CUR_NAME[c]}</option>`).join('')}</select>
                        <span style="align-self:center;">→</span>
                        <select id="exTo">${Object.keys(CUR_NAME).map(c => `<option value="${c}" ${c === 'casino' ? 'selected' : ''}>${CUR_NAME[c]}</option>`).join('')}</select>
                        <input type="number" id="exAmount" class="bet-input" value="100" min="1">
                        <button class="btn btn-sm btn-primary" id="btnDoExchange">兑换</button>
                    </div>
                    <p style="font-size:11px;color:#999;margin-top:4px;">1 积分 = 2 五子币 = 10 筹码</p>
                </div>`;
            document.getElementById('btnDoExchange').onclick = doExchange;
        } else {
            box.innerHTML = `
                <div class="casino-form">
                    <h4>🎁 赠送 / 交易积分</h4>
                    <div class="bet-row">
                        <input type="text" id="tfUser" placeholder="对方用户名" style="flex:1;">
                        <input type="number" id="tfAmount" class="bet-input" value="100" min="1" placeholder="数量">
                        <select id="tfCur">${Object.keys(CUR_NAME).map(c => `<option value="${c}">${CUR_NAME[c]}</option>`).join('')}</select>
                        <button class="btn btn-sm btn-primary" id="btnDoTransfer">赠送</button>
                    </div>
                    <input type="text" id="tfMemo" placeholder="留言（可选）" style="width:100%;margin-top:6px;" class="chat-input">
                </div>`;
            document.getElementById('btnDoTransfer').onclick = doTransfer;
        }
    }

    async function doExchange() {
        const from = document.getElementById('exFrom').value;
        const to = document.getElementById('exTo').value;
        const amount = parseInt(document.getElementById('exAmount').value) || 0;
        if (!amount || amount <= 0) { alert('请输入有效数量'); return; }
        try {
            const data = await api('?action=exchange', { method: 'POST', body: JSON.stringify({ from, to, amount }) });
            if (data.error) { alert(data.error); return; }
            alert('兑换成功！获得 ' + data.amount + ' ' + CUR_NAME[data.to]);
            loadWallet();
            showForm('exchange');
        } catch (e) { alert(e.message); }
    }

    async function doTransfer() {
        const toUsername = document.getElementById('tfUser').value.trim();
        const amount = parseInt(document.getElementById('tfAmount').value) || 0;
        const currency = document.getElementById('tfCur').value;
        const memo = document.getElementById('tfMemo').value.trim();
        if (!toUsername) { alert('请输入对方用户名'); return; }
        if (!amount || amount <= 0) { alert('请输入有效数量'); return; }
        try {
            const data = await api('?action=transfer', { method: 'POST', body: JSON.stringify({ to_username: toUsername, amount, currency, memo }) });
            if (data.error) { alert(data.error); return; }
            alert('赠送成功！');
            loadWallet();
            showForm('transfer');
        } catch (e) { alert(e.message); }
    }

    // ============ 联机对赌 ============
    async function createBet(side) {
        if (currentGame === 'liar') { mpLiarCreate(); return; }
        const btn = document.getElementById('btnBetCreate');
        if (btn) btn.disabled = true;
        try {
            const game_mode = currentGame;
            const bet_amount = parseInt(document.getElementById('betAmount').value) || 0;
            if (bet_amount <= 0) { alert('请输入赌注'); return; }
            if (bet_amount > balances.casino) { alert('筹码不足，当前余额 ' + balances.casino.toLocaleString()); return; }
            let choice = {};
            if (game_mode === 'dice') choice = { side };
            else if (game_mode === 'roulette') choice = { bullets: parseInt(document.getElementById('betBullets').value) || 1 };
            else if (game_mode === 'highlow') choice = { direction: document.getElementById('betHlDir').value };
            const result = document.getElementById('betCreateResult');
            const data = await api('action=bet_create', { method: 'POST', body: JSON.stringify({ game_mode, bet_amount, choice }) });
            if (data.error) { if (result) result.innerHTML = '<span style="color:red;">' + esc(data.error) + '</span>'; return; }
            if (result) result.innerHTML = '<span style="color:#67c23a;">✅ 赌局 #' + data.room_id + ' 已开放</span>';
            loadBetRooms(game_mode); loadMyBets(game_mode);
        } catch (e) {
            const result = document.getElementById('betCreateResult');
            if (result) result.innerHTML = '<span style="color:red;">开局失败：' + esc(e.message) + '</span>';
        } finally { if (btn) btn.disabled = false; }
    }

    async function loadBetRooms(filterGame) {
        try {
            const data = await api('?action=bet_list');
            const el = document.getElementById('betRooms');
            if (!el) return;
            if (data.error) { el.innerHTML = '<p style="color:red;">' + esc(data.error) + '</p>'; return; }
            let rooms = (data.rooms || []).filter(r => r.status === 'waiting');
            if (filterGame) rooms = rooms.filter(r => r.game_mode === filterGame);
            if (!rooms.length) { el.innerHTML = '<p style="color:#999;">暂无开放赌局</p>'; return; }
            el.innerHTML = rooms.map(r => {
                const hc = r.host_choice || {};
                const iconMap = { dice: '🎲', roulette: '🔫', blackjack: '🃏', liar: '🍺', highlow: '🔼' };
                const descMap = { dice: '押' + (hc.side === 'big' ? '大' : '小'), roulette: hc.bullets + '发', blackjack: '2张比大', liar: '回合制出牌', highlow: '猜' + (hc.direction === 'higher' ? '大' : '小') };
                return `<div class="room-item">
                    <div class="room-info">
                        <span class="room-type">${iconMap[r.game_mode] || '❓'}</span>
                        <span class="room-host">${esc(r.host_name)}</span>
                        <span class="room-count">${descMap[r.game_mode] || ''}</span>
                        <span class="room-count" style="color:#ffd166;">${r.bet_amount}筹码</span>
                    </div>
                    <button class="btn btn-sm btn-primary" data-betjoin="${r.id}">加入</button>
                </div>`;
            }).join('');
            el.querySelectorAll('[data-betjoin]').forEach(btn => {
                btn.onclick = () => joinBet(parseInt(btn.dataset.betjoin), btn);
            });
        } catch (e) {}
    }

    async function joinBet(roomId, btn) {
        if (currentGame === 'liar') { mpLiarJoin(roomId); return; }
        if (btn) btn.disabled = true;
        try {
            const body = { room_id: roomId };
            const roomData = await api('?action=bet_list');
            const room = (roomData.rooms || []).find(r => r.id === roomId);
            if (room && room.game_mode === 'highlow') {
                body.choice = { direction: prompt('猜更大(h)还是更小(l)?', 'higher') || 'higher' };
            }
            const data = await api('action=bet_join', { method: 'POST', body: JSON.stringify(body) });
            if (data.error) { alert(data.error); if (btn) btn.disabled = false; return; }
            const r = data.result || {};
            let msg = data.draw ? '🤝 平局！' : '';
            if (r.dice) msg = (data.win ? '🎉 赢了' : '😞 输了') + ' 点数 ' + r.dice.join('+') + '=' + r.sum;
            else if (r.bullets !== undefined) msg = (data.win ? '🎉 对手走火' : '💥 你走火') + '(' + r.bullets + '发)';
            else if (r.host_claim) msg = (data.win ? '🎉 对手说谎' : '😞 你说谎') + '\n你:' + r.guest_cards.join(' ') + ' 声明' + cardName(r.guest_claim.value) + '×' + r.guest_claim.count + '(' + r.guest_claim.actual + ')' + '\n对手:' + r.host_cards.join(' ') + ' 声明' + cardName(r.host_claim.value) + '×' + r.host_claim.count + '(' + r.host_claim.actual + ')';
            else if (r.host_cards) msg = (data.win ? '🎉 赢了' : '😞 输了') + '\n你:' + r.guest_cards.join(' ') + '(' + r.guest_total + ')' + '\n对手:' + r.host_cards.join(' ') + '(' + r.host_total + ')';
            else if (r.card1 !== undefined) msg = (data.win ? '🎉 猜对了' : '😞 猜错了') + '\n' + r.card1 + '→' + r.card2 + ' 你猜' + (r.guest_direction === 'higher' ? '大' : '小');
            if (data.payout) msg += '\n+' + data.payout + '筹码';
            alert(msg);
            const balData = await api('?action=wallet');
            if (!balData.error) { updateBalances(balData.balances); canSignin = balData.can_signin; streak = balData.streak; renderWallet(); }
            loadBetRooms(currentGame); loadMyBets(currentGame);
        } catch (e) { alert('加入失败'); if (btn) btn.disabled = false; }
    }

    async function loadMyBets(filterGame) {
        try {
            const data = await api('?action=wallet');
            const el = document.getElementById('myBets');
            if (!el) return;
            const openData = await api('?action=bet_list');
            let mine = (openData.rooms || []).filter(r => r.host_id === window.ChatX.user.id);
            if (filterGame) mine = mine.filter(r => r.game_mode === filterGame);
            if (!mine.length) { el.innerHTML = '<p style="color:#999;">没有进行中的赌局</p>'; return; }
            el.innerHTML = mine.map(r => {
                const hc = r.host_choice || {};
                const iconMap = { dice: '🎲', roulette: '🔫', blackjack: '🃏', liar: '🍺', highlow: '🔼' };
                const descMap = { dice: '押' + (hc.side === 'big' ? '大' : '小'), roulette: hc.bullets + '发', blackjack: '2张比大', liar: '回合制出牌', highlow: '猜' + (hc.direction === 'higher' ? '大' : '小') };
                const statusText = r.status === 'playing' ? '🎮 进行中' : '⏳ 等待';
                const btn = r.status === 'playing' && r.game_mode === 'liar' 
                    ? `<button class="btn btn-sm btn-primary" data-betenter="${r.id}">进入</button>`
                    : `<button class="btn btn-sm btn-warning" data-betcancel="${r.id}">取消</button>`;
                return `<div class="room-item">
                    <div class="room-info">
                        <span class="room-type">#${r.id}</span>
                        <span>${iconMap[r.game_mode] || '❓'} ${descMap[r.game_mode] || ''} · ${r.bet_amount}筹码 · ${statusText}</span>
                    </div>
                    ${btn}
                </div>`;
            }).join('');
            el.querySelectorAll('[data-betcancel]').forEach(btn => {
                btn.onclick = async () => {
                    try {
                        const d = await api('action=bet_cancel', { method: 'POST', body: JSON.stringify({ room_id: parseInt(btn.dataset.betcancel) }) });
                        if (d.error) { alert(d.error); return; }
                        const balData = await api('?action=wallet');
                        if (!balData.error) updateBalances(balData.balances);
                        loadBetRooms(filterGame); loadMyBets(filterGame);
                    } catch (e) { alert('取消失败'); }
                };
            });
            el.querySelectorAll('[data-betenter]').forEach(btn => {
                btn.onclick = async () => {
                    try {
                        const d = await api('?action=liar_mp_state&room_id=' + parseInt(btn.dataset.betenter));
                        if (d.error) { alert(d.error); return; }
                        mpLiarState = {
                            room_id: d.room_id,
                            my_cards: d.my_cards,
                            table_type: d.table_type,
                            pile: d.pile || [],
                            last_cards: d.last_cards || [],
                            my_turn: d.my_turn,
                            my_eliminated: d.my_eliminated,
                            my_role: d.my_role,
                            opponent_name: d.opponent_name,
                            turn: d.turn,
                            bet_amount: d.bet_amount,
                            status: d.status,
                        };
                        liarSelectedCards = new Set();
                        renderMpLiarGame();
                    } catch (e) { alert('进入失败'); }
                };
            });
        } catch (e) {}
    }

    // ============ 单人游戏逻辑 ============
    // ---- 老虎机 ----
    let slotBusy = false;
    async function slotSpin() {
        if (slotBusy) return;
        const amount = parseInt(document.getElementById('slotBet').value) || 0;
        if (amount <= 0) { alert('请输入下注金额'); return; }
        if (amount > balances.casino) { alert('筹码不足'); return; }
        slotBusy = true;
        const btn = document.getElementById('btnSlotSpin');
        if (btn) btn.disabled = true;
        const area = document.getElementById('slotArea');
        if (area) area.style.display = '';
        const reelsEl = document.getElementById('slotReels');
        const resultEl = document.getElementById('slotResult');
        if (reelsEl) reelsEl.innerHTML = '<div class="slot-reel">🎰</div><div class="slot-reel">🎰</div><div class="slot-reel">🎰</div>';
        if (resultEl) resultEl.innerHTML = '';
        let ticks = 0;
        const anim = setInterval(() => {
            ticks++;
            if (reelsEl) reelsEl.innerHTML = '<div class="slot-reel">' + SLOT_SYMBOLS[Math.floor(Math.random() * 20)] + '</div>' +
                '<div class="slot-reel">' + SLOT_SYMBOLS[Math.floor(Math.random() * 20)] + '</div>' +
                '<div class="slot-reel">' + SLOT_SYMBOLS[Math.floor(Math.random() * 20)] + '</div>';
            if (ticks > 12) clearInterval(anim);
        }, 80);
        try {
            await new Promise(r => setTimeout(r, 1400));
            const data = await api('action=slot', { method: 'POST', body: JSON.stringify({ amount }) });
            if (data.error) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">' + esc(data.error) + '</span>'; return; }
            const reels = data.reels || [];
            if (reelsEl) {
                const isTriple = reels.length === 3 && reels[0] === reels[1] && reels[1] === reels[2];
                const isPair = reels.length === 3 && !isTriple && (reels[0] === reels[1] || reels[1] === reels[2]);
                reelsEl.innerHTML = reels.map((r, i) => {
                    let cls = 'slot-reel';
                    if (isTriple) cls += ' win';
                    else if (isPair) { if (r === reels[i === 0 ? 1 : 0] || (i === 1 && r === reels[2])) { cls += ' win'; } }
                    return '<div class="' + cls + '">' + r + '</div>';
                }).join('');
            }
            if (resultEl) resultEl.innerHTML = '<span style="color:' + (data.payout > 0 ? '#ffd166' : '#999') + ';">' + (data.payout > 0 ? '🎉 中奖 ' + data.payout + ' 筹码！' : '😞 没中奖，再来一次？') + '</span>';
            updateBalances({ ...balances, casino: data.balance });
            loadHistory();
        } catch (e) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">操作失败</span>'; }
        slotBusy = false;
        if (btn) btn.disabled = false;
    }

    // ---- 刮刮乐 ----
    let scBusy = false;
    async function scratchPlay() {
        if (scBusy) return;
        const amount = parseInt(document.getElementById('scBet').value) || 0;
        if (amount <= 0) { alert('请输入下注金额'); return; }
        if (amount > balances.casino) { alert('筹码不足'); return; }
        scBusy = true;
        const btn = document.getElementById('btnScratch');
        if (btn) btn.disabled = true;
        const area = document.getElementById('scratchArea');
        if (area) area.style.display = '';
        const gridEl = document.getElementById('scratchGrid');
        const resultEl = document.getElementById('scratchResult');
        if (gridEl) gridEl.innerHTML = [0,1,2,3,4,5,6,7,8].map(() => '<div class="scratch-cell">?</div>').join('');
        if (resultEl) resultEl.innerHTML = '刮开中...';
        try {
            await new Promise(r => setTimeout(r, 1400));
            const data = await api('action=scratch', { method: 'POST', body: JSON.stringify({ amount }) });
            if (data.error) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">' + esc(data.error) + '</span>'; return; }
            const grid = data.grid || [];
            const maxMatch = data.max_match || 0;
            const matchSym = data.match_symbol || '';
            if (gridEl) gridEl.innerHTML = grid.map(s => {
                const cls = s === matchSym && maxMatch >= 2 ? 'scratch-cell win' : 'scratch-cell';
                return '<div class="' + cls + '">' + s + '</div>';
            }).join('');
            let msg = '';
            if (maxMatch >= 3) msg = '🎉 三连中！' + data.payout + ' 筹码';
            else if (maxMatch === 2) msg = '✨ 小奖！' + data.payout + ' 筹码';
            else msg = '😞 差一点，再来？';
            if (resultEl) resultEl.innerHTML = '<span style="color:' + (data.payout > 0 ? '#ffd166' : '#999') + ';">' + msg + '</span>';
            updateBalances({ ...balances, casino: data.balance });
            loadHistory();
        } catch (e) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">操作失败</span>'; }
        scBusy = false;
        if (btn) btn.disabled = false;
    }

    // ---- 幸运转盘 ----
    let wheelBusy = false;
    async function wheelSpin() {
        if (wheelBusy) return;
        const amount = parseInt(document.getElementById('wheelBet').value) || 0;
        if (amount <= 0) { alert('请输入下注金额'); return; }
        if (amount > balances.casino) { alert('筹码不足'); return; }
        wheelBusy = true;
        const btn = document.getElementById('btnWheel');
        if (btn) btn.disabled = true;
        const area = document.getElementById('wheelArea');
        if (area) area.style.display = '';
        const displayEl = document.getElementById('wheelDisplay');
        const resultEl = document.getElementById('wheelResult');
        if (displayEl) displayEl.innerHTML = '<div class="wheel-spinner">🎡</div>';
        if (resultEl) resultEl.innerHTML = '转动中...';
        try {
            await new Promise(r => setTimeout(r, 2000));
            const data = await api('action=wheel', { method: 'POST', body: JSON.stringify({ amount }) });
            if (data.error) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">' + esc(data.error) + '</span>'; return; }
            if (displayEl) displayEl.innerHTML = '<div class="' + (data.payout > 0 ? 'wheel-prize big' : 'wheel-prize') + '">' + data.sector + '</div>';
            let msg = '';
            if (data.payout > 0) msg = '🎉 中了 ' + data.sector + '！' + data.payout + ' 筹码';
            else if (data.multiplier === 1) msg = '😐 保本';
            else msg = '😞 未中奖';
            if (resultEl) resultEl.innerHTML = '<span style="color:' + (data.payout > 0 ? '#ffd166' : '#999') + ';">' + msg + '</span>';
            updateBalances({ ...balances, casino: data.balance });
            loadHistory();
        } catch (e) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">操作失败</span>'; }
        wheelBusy = false;
        if (btn) btn.disabled = false;
    }

    // ---- 投骰子 (单人) ----
    let diceBusy = false;
    async function soloDice(side) {
        if (diceBusy) return;
        const amount = parseInt(document.getElementById('diceBet').value) || 0;
        if (amount <= 0) { alert('请输入下注金额'); return; }
        if (amount > balances.casino) { alert('筹码不足'); return; }
        diceBusy = true;
        const btn = document.getElementById('btnDiceRoll');
        if (btn) btn.disabled = true;
        const resultEl = document.getElementById('diceResult');
        if (resultEl) resultEl.innerHTML = '<span style="color:#999;">掷骰子中...</span>';
        try {
            const data = await api('action=dice', { method: 'POST', body: JSON.stringify({ bet: side, amount }) });
            if (data.error) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">' + esc(data.error) + '</span>'; return; }
            const dice = data.dice || [];
            const sum = data.sum || 0;
            const isBaozi = dice.length === 3 && dice[0] === dice[1] && dice[1] === dice[2];
            const win = data.win;
            let msg = '<div class="dice-display">';
            dice.forEach(d => { msg += '<span class="dice-icon">🎲' + d + '</span>'; });
            msg += '</div><div style="font-size:24px;margin:8px 0;">点数: ' + sum + '</div>';
            if (isBaozi) msg += '<div style="color:#f56c6c;">🎯 豹子！庄家通杀</div>';
            else if (win) msg += '<div style="color:#67c23a;">🎉 你赢了！+' + data.payout + ' 筹码</div>';
            else msg += '<div style="color:#999;">😞 没中，再来？</div>';
            if (resultEl) resultEl.innerHTML = msg;
            updateBalances({ ...balances, casino: data.balance });
            loadHistory();
        } catch (e) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">操作失败</span>'; }
        diceBusy = false;
        if (btn) btn.disabled = false;
    }

    // ---- 俄罗斯轮盘 (单人) ----
    let rlBusy = false;
    async function soloRoulette() {
        if (rlBusy) return;
        const amount = parseInt(document.getElementById('rlBet').value) || 0;
        const bullets = parseInt(document.getElementById('rlBullets').value) || 1;
        if (amount <= 0) { alert('请输入下注金额'); return; }
        if (amount > balances.casino) { alert('筹码不足'); return; }
        rlBusy = true;
        const btn = document.getElementById('btnRlSpin');
        if (btn) btn.disabled = true;
        const resultEl = document.getElementById('rlResult');
        if (resultEl) resultEl.innerHTML = '<span style="color:#999;">扣动扳机中...</span>';
        try {
            const data = await api('action=roulette', { method: 'POST', body: JSON.stringify({ bullets, amount }) });
            if (data.error) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">' + esc(data.error) + '</span>'; return; }
            let msg = '<div class="rl-display">';
            for (let i = 0; i < 6; i++) {
                msg += '<span class="rl-chamber ' + (i === data.chamber ? (data.fired ? 'fired' : 'empty') : 'normal') + '">';
                msg += i < data.bullets ? '💥' : '🔵';
                msg += '</span>';
            }
            msg += '</div><div style="margin:8px 0;">第 ' + (data.chamber + 1) + ' 槽</div>';
            if (data.win) msg += '<div style="color:#67c23a;">🎉 空仓！+' + data.payout + ' 筹码</div>';
            else msg += '<div style="color:#f56c6c;">💥 走火！</div>';
            if (resultEl) resultEl.innerHTML = msg;
            updateBalances({ ...balances, casino: data.balance });
            loadHistory();
        } catch (e) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">操作失败</span>'; }
        rlBusy = false;
        if (btn) btn.disabled = false;
    }

    // ---- 21点 (单人) ----
    let bjBusy = false;
    async function bjStart() {
        if (bjBusy) return;
        const bet = parseInt(document.getElementById('bjBet').value) || 0;
        if (bet <= 0) { alert('请输入下注金额'); return; }
        if (bet > balances.casino) { alert('筹码不足'); return; }
        bjBusy = true;
        const btn = document.getElementById('btnBjStart');
        if (btn) btn.disabled = true;
        try {
            const data = await api('action=blackjack', { method: 'POST', body: JSON.stringify({ action: 'start', bet }) });
            if (data.error) { alert(data.error); return; }
            bjState = data;
            document.getElementById('bjIdle').style.display = 'none';
            document.getElementById('bjGame').style.display = '';
            bjUpdateCards(data);
            document.getElementById('bjPlayerVal').textContent = '(' + bjCalcVal(data.player_cards) + ')';
        } catch (e) { alert('开局失败'); }
        bjBusy = false;
        if (btn) btn.disabled = false;
    }

    function bjCalcVal(cards) {
        let val = 0, aces = 0;
        for (const c of cards) { val += Math.min(c, 10); if (c === 1) aces++; }
        while (val + 10 <= 21 && aces > 0) { val += 10; aces--; }
        return val;
    }

    function bjUpdateCards(data) {
        const dealerEl = document.getElementById('bjDealerCards');
        const playerEl = document.getElementById('bjPlayerCards');
        if (dealerEl) {
            dealerEl.innerHTML = (data.dealer_cards || []).map((c, i) => {
                if (data.dealer_hole && i === 1) return '<div class="bj-card bj-hidden">🂠</div>';
                return '<div class="bj-card">' + bjCardHTML(c) + '</div>';
            }).join('');
        }
        if (playerEl) playerEl.innerHTML = (data.player_cards || []).map(c => '<div class="bj-card">' + bjCardHTML(c) + '</div>').join('');
    }

    function bjCardHTML(c) {
        const suit = ['♠','♥','♦','♣'][Math.floor(Math.random() * 4)];
        const color = suit === '♥' || suit === '♦' ? 'red' : 'black';
        return '<span class="card-val ' + color + '">' + cardName(c) + '</span><span class="card-suit ' + color + '">' + suit + '</span>';
    }

    async function bjHit() {
        if (bjBusy || !bjState) return;
        bjBusy = true;
        try {
            const data = await api('action=blackjack', { method: 'POST', body: JSON.stringify({ action: 'hit' }) });
            if (data.error) { alert(data.error); return; }
            bjState = data;
            bjUpdateCards(data);
            if (data.phase === 'done') bjShowResult(data);
            else document.getElementById('bjPlayerVal').textContent = '(' + bjCalcVal(data.player_cards) + ')';
        } catch (e) { alert('操作失败'); }
        bjBusy = false;
    }

    async function bjStand() {
        if (bjBusy || !bjState) return;
        bjBusy = true;
        try {
            const data = await api('action=blackjack', { method: 'POST', body: JSON.stringify({ action: 'stand' }) });
            if (data.error) { alert(data.error); return; }
            bjState = data;
            bjUpdateCards(data);
            bjShowResult(data);
        } catch (e) { alert('操作失败'); }
        bjBusy = false;
    }

    async function bjDouble() {
        if (bjBusy || !bjState) return;
        bjBusy = true;
        try {
            const data = await api('action=blackjack', { method: 'POST', body: JSON.stringify({ action: 'double' }) });
            if (data.error) { alert(data.error); return; }
            bjState = data;
            bjUpdateCards(data);
            bjShowResult(data);
        } catch (e) { alert('操作失败'); }
        bjBusy = false;
    }

    function bjShowResult(data) {
        const resultEl = document.getElementById('bjResult');
        if (!resultEl) return;
        const r = data.result || '';
        const payout = data.payout || 0;
        let msg = '';
        if (r === 'blackjack') msg = '<div style="color:#ffd166;">🎉 黑杰克！+' + payout + ' 筹码</div>';
        else if (r === 'win') msg = '<div style="color:#67c23a;">🎉 你赢了！+' + payout + ' 筹码</div>';
        else if (r === 'push') msg = '<div style="color:#999;">🤝 平局，保本</div>';
        else if (r === 'bust') msg = '<div style="color:#f56c6c;">💥 爆牌！</div>';
        else if (r === 'dealer_blackjack') msg = '<div style="color:#f56c6c;">🃏 庄家有黑杰克</div>';
        else msg = '<div style="color:#f56c6c;">😞 你输了</div>';
        resultEl.innerHTML = msg;
        updateBalances({ ...balances, casino: data.balance });
        loadHistory();
        document.getElementById('bjIdle').style.display = '';
        document.getElementById('bjGame').style.display = 'none';
        bjState = null;
    }

    // ---- 骗子酒馆 Liar's Deck (单人) ----
    let liarBusy = false;
    let liarCards = []; // 当前手牌
    let liarSelected = new Set(); // 选中的牌索引

    async function liarStart() {
        if (liarBusy) return;
        if (!liarCharacter) { alert('请先选择一个动物角色'); return; }
        const amount = parseInt(document.getElementById('liarBet').value) || 0;
        if (amount <= 0) { alert('请输入下注金额'); return; }
        if (amount > balances.casino) { alert('筹码不足'); return; }
        liarBusy = true;
        const btn = document.getElementById('btnLiarStart');
        if (btn) btn.disabled = true;
        try {
            const pc = parseInt(document.getElementById('liarPlayers').value) || 2;
            const data = await api('action=liar_start', { method: 'POST', body: JSON.stringify({ amount, player_count: pc }) });
            if (data.error) { alert(data.error); liarBusy = false; if (btn) btn.disabled = false; return; }
            liarCards = data.cards || [];
            liarSelected = new Set();
            liarPlayerCount = data.player_count;
            liarOpponents = data.ai_list || [];
            document.getElementById('liarIdle').style.display = 'none';
            document.getElementById('liarGame').style.display = '';
            // 显示角色
            const myAnimal = LIAR_ANIMALS.find(a => a.id === liarCharacter);
            document.getElementById('liarMyEmoji').innerHTML = myAnimal.emoji;
            // 显示AI对手
            const oppEl = document.getElementById('liarOpponents');
            oppEl.innerHTML = liarOpponents.map(ai => `<div style="text-align:center;"><div style="font-size:28px;">${ai.emoji}</div><div style="font-size:10px;color:#8fa3c8;">${ai.name}</div></div>`).join('');
            // 显示桌面类型
            const tt = data.table_type;
            document.getElementById('liarTableType').innerHTML = `🎯 桌面类型：<span style="font-size:18px;font-weight:bold;">${LIAR_CARD_MAP[tt] || tt} ${LIAR_TYPE_NAMES[tt] || tt}</span>（此类型+🃏=真话）`;
            // 显示牌
            renderLiarHand();
            // 显示提示
            document.getElementById('liarHint').innerHTML = `<b>${liarPlayerCount}人对局</b>，桌面类型是 <b>${LIAR_TYPE_NAMES[tt] || tt}</b>，你的牌中 ${LIAR_TYPE_NAMES[tt] || tt} 和 🃏 是真话，其余是谎言。选1-3张打出，声明几张真话（可说谎）。${liarPlayerCount > 2 ? '人多喊"骗子"概率更高！' : ''} 输了要玩左轮！`;
            updateBalances({ ...balances, casino: data.balance });
            loadHistory();
        } catch (e) { alert('开局失败'); liarBusy = false; if (btn) btn.disabled = false; }
    }

    function renderLiarHand() {
        const cardsEl = document.getElementById('liarCards');
        if (!cardsEl) return;
        cardsEl.innerHTML = liarCards.map((c, i) => {
            const selected = liarSelected.has(i);
            const cls = selected ? 'liar-card liar-selected' : 'liar-card';
            return `<div class="${cls}" onclick="window.ChatX.toggleLiarCard(${i})" style="cursor:pointer;">${LIAR_CARD_MAP[c] || c}</div>`;
        }).join('');
    }

    function toggleLiarCard(idx) {
        if (liarSelected.has(idx)) liarSelected.delete(idx);
        else if (liarSelected.size < 3) liarSelected.add(idx);
        else { alert('最多选3张牌'); return; }
        renderLiarHand();
        // 更新声明选项
        const n = liarSelected.size;
        const sel = document.getElementById('liarTruths');
        if (sel) {
            sel.innerHTML = '';
            for (let i = 0; i <= n; i++) {
                const opt = document.createElement('option');
                opt.value = i;
                opt.textContent = `声明${i}张真话`;
                sel.appendChild(opt);
            }
        }
    }
    window.ChatX.toggleLiarCard = toggleLiarCard;

    async function liarPlay() {
        if (liarBusy) return;
        if (liarSelected.size < 1) { alert('请至少选择1张牌'); return; }
        liarBusy = true;
        const btn = document.getElementById('btnLiarPlay');
        if (btn) btn.disabled = true;
        const indices = Array.from(liarSelected).sort((a,b)=>a-b);
        const truths = parseInt(document.getElementById('liarTruths').value) || 0;
        const resultEl = document.getElementById('liarResult');
        if (resultEl) resultEl.innerHTML = '<span style="color:#999;">等待庄家判断...</span>';
        try {
            const data = await api('action=liar_play', { method: 'POST', body: JSON.stringify({ card_indices: indices, claimed_truths: truths }) });
            if (data.error) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">' + esc(data.error) + '</span>'; liarBusy = false; if (btn) btn.disabled = false; return; }
            // 显示结果
            let msg = '<div style="margin-bottom:6px;font-size:12px;color:#8fa3c8;">桌面类型: ' + (LIAR_TYPE_NAMES[data.table_type] || data.table_type) + '</div>';
            msg += '<div class="liar-cards" style="margin-bottom:8px;">';
            (data.played || []).forEach(p => {
                const truthCls = p.is_truth ? 'border-color:#67c23a' : 'border-color:#f56c6c';
                const badge = p.is_truth ? ' ✅真话' : ' ❌谎言';
                msg += `<div class="liar-card" style="border:2px solid ${p.is_truth ? '#67c23a' : '#f56c6c'};padding:6px 10px;border-radius:8px;text-align:center;">${LIAR_CARD_MAP[p.card] || p.card}${badge}</div>`;
            });
            msg += '</div>';
            msg += `<div style="font-size:12px;margin-bottom:4px;">声明: ${data.claimed_truths}张真话 | 实际: ${data.actual_truths}张真话</div>`;
            if (data.called) {
                msg += '<div style="color:#ffd166;font-weight:bold;margin:6px 0;">⚖️ 庄家喊了"骗子"！</div>';
                if (data.win) msg += '<div style="color:#67c23a;">✅ 错喊！你全是真话，2倍奖励 +' + data.payout + ' 筹码</div>';
                else {
                    msg += '<div style="color:#f56c6c;">❌ 被抓住撒谎了！</div>';
                    if (data.revolver) {
                        if (data.revolver_dead) {
                            msg += '<div style="background:#1a0000;border:1px solid #f56c6c;border-radius:8px;padding:10px;margin:8px 0;text-align:center;">';
                            msg += '<div style="font-size:36px;">🔄💀</div>';
                            msg += '<div style="color:#f56c6c;font-weight:bold;">左轮开了！双倍损失！</div>';
                            msg += '</div>';
                        } else {
                            msg += '<div style="background:#0a1a0a;border:1px solid #67c23a;border-radius:8px;padding:10px;margin:8px 0;text-align:center;">';
                            msg += '<div style="font-size:36px;">🔄💨</div>';
                            msg += '<div style="color:#67c23a;">左轮空响，你活下来了。</div>';
                            msg += '</div>';
                        }
                    }
                }
            } else {
                msg += '<div style="color:#999;margin:6px 0;">庄家相信了你</div>';
                if (data.win) msg += '<div style="color:#67c23a;">🎉 诈唬成功！1.5倍 +' + data.payout + ' 筹码</div>';
                else msg += '<div style="color:#999;">😐 真话被信，保本</div>';
            }
            if (resultEl) resultEl.innerHTML = msg;
            updateBalances({ ...balances, casino: data.balance });
            loadHistory();
            document.getElementById('liarIdle').style.display = '';
            document.getElementById('liarGame').style.display = 'none';
            liarCards = []; liarSelected = new Set();
        } catch (e) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">操作失败</span>'; liarBusy = false; if (btn) btn.disabled = false; }
    }

    async function liarForfeit() {
        liarBusy = true;
        try {
            const data = await api('action=liar_forfeit', { method: 'POST' });
            if (data.error) { alert(data.error); liarBusy = false; return; }
            alert('已弃权，赌注退回');
            updateBalances({ ...balances, casino: data.balance });
            loadHistory();
            document.getElementById('liarIdle').style.display = '';
            document.getElementById('liarGame').style.display = 'none';
        } catch (e) { alert('操作失败'); liarBusy = false; }
    }

    // ---- 猜大小 (单人) ----
    let hlBusy = false;
    async function soloHighLow(dir) {
        if (hlBusy) return;
        const amount = parseInt(document.getElementById('hlBet').value) || 0;
        if (amount <= 0) { alert('请输入下注金额'); return; }
        if (amount > balances.casino) { alert('筹码不足'); return; }
        hlBusy = true;
        const resultEl = document.getElementById('hlResult');
        if (resultEl) resultEl.innerHTML = '<span style="color:#999;">发牌中...</span>';
        try {
            const data = await api('action=highlow', { method: 'POST', body: JSON.stringify({ amount, direction: dir }) });
            if (data.error) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">' + esc(data.error) + '</span>'; return; }
            let msg = '<div class="hl-cards">';
            msg += '<div class="hl-card">第1张<br><span style="font-size:24px;">' + cardName(data.card1) + '</span></div>';
            msg += '<div class="hl-arrow">→</div>';
            msg += '<div class="hl-card">第2张<br><span style="font-size:24px;">' + cardName(data.card2) + '</span></div>';
            msg += '</div>';
            msg += '<div style="margin:8px 0;font-size:13px;">你猜: ' + (dir === 'higher' ? '更大 🔼' : '更小 🔽') + '</div>';
            if (data.card1 === data.card2) msg += '<div style="color:#999;">🤝 平局，不退不赔</div>';
            else if (data.win) msg += '<div style="color:#67c23a;">🎉 猜对了！+' + data.payout + ' 筹码</div>';
            else msg += '<div style="color:#f56c6c;">😞 猜错了</div>';
            if (resultEl) resultEl.innerHTML = msg;
            updateBalances({ ...balances, casino: data.balance });
            loadHistory();
        } catch (e) { if (resultEl) resultEl.innerHTML = '<span style="color:red;">操作失败</span>'; }
        hlBusy = false;
    }

    // ============ 交易记录 ============
    async function loadHistory() {
        try {
            const data = await api('?action=history');
            const el = document.getElementById('casinoHistory');
            if (!el) return;
            if (data.error) { el.innerHTML = '<p style="color:red;">' + esc(data.error) + '</p>'; return; }
            const rows = data.history || [];
            if (!rows.length) { el.innerHTML = '<p style="color:#999;">暂无交易记录</p>'; return; }
            el.innerHTML = rows.map(t => {
                const typeMap = { signin: '签到', transfer: '转账', exchange: '兑换', bet: '下注', win: '赢取', lose: '损失' };
                const isIn = t.type === 'win' || t.type === 'signin' || (t.type === 'transfer' && t.to !== null);
                return `<div class="tx-item">
                    <span class="tx-type">${typeMap[t.type] || t.type}</span>
                    <span class="tx-amount" style="color:${isIn ? '#67c23a' : '#f56c6c'};">${isIn ? '+' : '-'}${t.amount} ${CUR_NAME[t.currency] || t.currency}</span>
                    <span class="tx-memo">${esc(t.memo || '')}</span>
                    <span class="tx-time">${esc(t.time)}</span>
                </div>`;
            }).join('');
        } catch (e) {}
    }

    // ============ 排行榜 ============
    window.ChatX.showCasinoLeaderboard = async function () {
        const panel = document.getElementById('lbPanel');
        if (!panel) return;
        if (panel.style.display !== 'none') { panel.style.display = 'none'; return; }
        panel.style.display = 'flex';
        const period = document.getElementById('lbPeriod')?.value || 'all';
        const periodMap = { all: '', today: '&period=today', week: '&period=week' };
        const data = await api('?action=leaderboard' + (periodMap[period] || ''));
        const el = document.getElementById('lbList');
        if (!el) return;
        if (!data.leaderboard?.length) { el.innerHTML = '<div style="color:#888;padding:20px;text-align:center;">暂无数据</div>'; return; }
        el.innerHTML = data.leaderboard.map((u, i) => {
            const net = (u.total_win || 0) - (u.total_lose || 0);
            const rankColor = i < 3 ? ['#FFD700', '#C0C0C0', '#CD7F32'][i] : '#888';
            return '<div class="lb-row">' +
                '<span class="lb-rank" style="color:' + rankColor + '">' + (i + 1) + '</span>' +
                '<div class="lb-avatar-wrap"><img src="' + (u.avatar ? 'uploads/avatars/' + u.avatar : 'assets/default-avatar.png') + '" class="avatar-sm"></div>' +
                '<div class="lb-info"><div class="lb-name">' + esc(u.nickname) + ' <span style="font-size:11px;color:#888;">Lv.' + (u.level || 1) + '</span></div>' +
                '<div class="lb-stats">赢:' + (u.total_win || 0) + ' / 输:' + (u.total_lose || 0) + ' / ' + (u.total_games || 0) + '局</div></div>' +
                '<span class="lb-net" style="color:' + (net >= 0 ? '#67c23a' : '#f56c6c') + '">' + (net >= 0 ? '+' : '') + net + '</span></div>';
        }).join('');
    };

    // ============ 幸运抽奖 ============
    let luckyBusy = false;
    window.ChatX.luckyDraw = async function (amount) {
        if (luckyBusy) return;
        amount = parseInt(amount) || 100;
        if (amount <= 0) { alert('请输入有效金额'); return; }
        luckyBusy = true;
        const btn = document.querySelector('[onclick*="luckyDraw"]');
        if (btn) btn.disabled = true;
        try {
            const data = await api('action=luckydraw', { method: 'POST', body: JSON.stringify({ amount }) });
            if (data.error) { alert(data.error); return; }
            updateBalances(balances);
            const result = document.getElementById('luckyResult');
            if (result) {
                const emoji = (data.prize.indexOf('大奖') >= 0 || data.prize.indexOf('Jackpot') >= 0) ? '🎊' : (data.win ? '🎉' : '😢');
                result.innerHTML = '<div class="lucky-result-box">' +
                    '<div style="font-size:36px;margin-bottom:8px;">' + emoji + '</div>' +
                    '<div style="font-size:18px;font-weight:bold;color:' + (data.win ? '#67c23a' : '#999') + ';">' + esc(data.prize) + '</div>' +
                    (data.payout > 0 ? '<div style="color:#67c23a;margin-top:4px;">+' + data.payout + ' 💰</div>' : '') +
                '</div>';
            }
        } catch (e) { alert('操作失败'); }
        finally { luckyBusy = false; if (btn) btn.disabled = false; }
    };

    // ============ 入口 ============
    window.ChatX.showCasino = function () {
        const panel = document.getElementById('casinoPanel');
        if (!panel) return;
        panel.style.display = 'flex';
        loadWallet();
    };
    window.ChatX.hideCasino = function () {
        const panel = document.getElementById('casinoPanel');
        if (panel) panel.style.display = 'none';
    };

    (function () {
        const closeBtn = document.getElementById('btnCloseCasino');
        if (closeBtn) closeBtn.onclick = () => {
            window.ChatX.hideCasino();
            if (window.ChatX.showGames) window.ChatX.showGames();
            else { const nav = document.querySelector('.nav-item[data-tab="chat"]'); if (nav) nav.click(); }
        };
    })();
})();
