// ============ ChatX Features: 通知 / 黑名单 / 等级 / 动态 ============
(function () {
    const API = 'api/features.php';

    async function api(action, options = {}) {
        const token = (window.ChatX && window.ChatX.token) || '';
        const url = action.startsWith('?') ? API + action : API + '?' + action;
        const r = await fetch(url, Object.assign({
            headers: { 'X-Auth-Token': token, 'Content-Type': 'application/json' }, credentials: 'include'
        }, options));
        const text = await r.text();
        try {
            return JSON.parse(text);
        } catch (e) {
            throw new Error(text.substring(0, 200) || '响应格式错误');
        }
    }

    function esc(s) { return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

    // ============ 通知中心 ============
    let notifTimer = null;

    window.ChatX.showNotifications = function () {
        const panel = document.getElementById('notifPanel');
        if (!panel) return;
        if (panel.style.display !== 'none') {
            panel.style.display = 'none';
            return;
        }
        panel.style.display = 'flex';
        loadNotifications();
    };

    window.ChatX.closeNotifications = function () {
        const panel = document.getElementById('notifPanel');
        if (panel) panel.style.display = 'none';
    };

    async function loadNotifications() {
        const list = document.getElementById('notifList');
        if (!list) return;
        list.innerHTML = '<div class="loading">加载中...</div>';
        try {
            const data = await api('?action=list');
            const unread = data.unread || 0;
            document.getElementById('notifUnreadBadge')?.replaceChildren(
                unread > 0 ? document.createTextNode(unread) : document.createTextNode('')
            );
            const badge = document.getElementById('notifBadge');
            if (badge) badge.textContent = unread;
            if (unread > 0) document.getElementById('notifDot')?.style.setProperty('display', '');
            else document.getElementById('notifDot')?.style.setProperty('display', 'none');

            if (!data.notifications?.length) {
                list.innerHTML = '<div style="text-align:center;color:#999;padding:40px 20px;">暂无通知</div>';
                return;
            }
            list.innerHTML = data.notifications.map(n => `
                <div class="notif-item ${n.is_read ? 'read' : ''}" onclick="window.ChatX.openNotif(${n.id})">
                    <div class="notif-icon">${notifIcon(n.type)}</div>
                    <div class="notif-body">
                        <div class="notif-title">${esc(n.title)}</div>
                        ${n.content ? '<div class="notif-content">' + esc(n.content) + '</div>' : ''}
                        <div class="notif-time">${timeAgo(n.created_at)}</div>
                    </div>
                    ${!n.is_read ? '<div class="notif-dot"></div>' : ''}
                </div>
            `).join('');
        } catch (e) {
            list.innerHTML = '<div style="color:red;padding:20px;">加载失败</div>';
        }
    }

    function notifIcon(type) {
        const icons = {
            friend_request: '🤝', blacklist: '🚫', moment_like: '❤️',
            moment_comment: '💬', system: '🔔', report: '⚠️',
            like: '❤️', comment: '💬', mention: '📣',
        };
        return icons[type] || '🔔';
    }

    window.ChatX.openNotif = function (id) {
        api('?action=mark_read_single&id=' + id);
        setTimeout(loadNotifications, 300);
    };

    window.ChatX.markAllRead = function () {
        api('?action=mark_read', { method: 'POST', body: JSON.stringify({}) });
        setTimeout(loadNotifications, 300);
    };

    // 定期检查未读
    async function checkUnread() {
        try {
            const data = await api('?action=list');
            const badge = document.getElementById('notifBadge');
            if (badge) badge.textContent = data.unread || 0;
            const dot = document.getElementById('notifDot');
            if (dot) dot.style.display = (data.unread > 0) ? '' : 'none';
        } catch (e) {}
    }

    // ============ 动态/Moments ============
    window.ChatX.showMoments = function () {
        const panel = document.getElementById('momentsPanel');
        if (!panel) return;
        if (panel.style.display !== 'none') {
            panel.style.display = 'none';
            return;
        }
        panel.style.display = 'flex';
        loadMoments();
    };

    async function loadMoments() {
        const list = document.getElementById('momentsList');
        if (!list) return;
        list.innerHTML = '<div class="loading">加载中...</div>';
        try {
            const data = await api('?action=list_moments');
            if (!data.moments?.length) {
                list.innerHTML = '<div style="text-align:center;color:#999;padding:40px 20px;">还没有动态，发布第一条吧！</div>';
                return;
            }
            list.innerHTML = data.moments.map(m => `
                <div class="moment-card" id="moment-${m.id}">
                    <div class="moment-header">
                        <div class="moment-avatar-wrap ${m.avatar_frame ? 'frame-' + esc(m.avatar_frame) : ''}">
                            <img src="${m.avatar ? 'uploads/avatars/' + esc(m.avatar) : 'assets/default-avatar.png'}" class="avatar" alt="">
                        </div>
                        <div>
                            <div class="moment-user">${esc(m.nickname)}</div>
                            <div class="moment-time">${timeAgo(m.created_at)}</div>
                        </div>
                        ${m.user_id === me()?.id ? '<button class="btn-mini btn-danger" onclick="window.ChatX.deleteMoment(' + m.id + ')">删除</button>' : ''}
                    </div>
                    <div class="moment-content">${esc(m.content)}</div>
                    ${m.image ? '<img class="moment-image" src="' + esc(m.image) + '" alt="">' : ''}
                    <div class="moment-actions">
                        <button class="moment-action-btn ${m.i_liked ? 'liked' : ''}" onclick="window.ChatX.toggleLike(${m.id})">
                            ❤️ <span>${m.like_count}</span>
                        </button>
                        <button class="moment-action-btn" onclick="window.ChatX.toggleComment(${m.id})">💬 <span>${m.comment_count}</span></button>
                    </div>
                    ${m.like_users ? '<div class="moment-likes">👍 ' + esc(m.like_users) + '</div>' : ''}
                    <div class="moment-comments" id="comments-${m.id}" style="display:none;"></div>
                    <div class="moment-comment-input" id="input-${m.id}" style="display:none;">
                        <input type="text" id="comment-text-${m.id}" placeholder="写下你的评论..." maxlength="500"
                            onkeydown="if(event.key==='Enter')window.ChatX.submitComment(${m.id})">
                        <button class="btn-mini btn-primary" onclick="window.ChatX.submitComment(${m.id})">发送</button>
                    </div>
                </div>
            `).join('');
        } catch (e) {
            list.innerHTML = '<div style="color:red;padding:20px;">加载失败</div>';
        }
    }

    function me() {
        return { id: (window.ChatX.user?.id) || 0 };
    }

    window.ChatX.toggleLike = async function (mid) {
        await api('?action=toggle_moment_like', { method: 'POST', body: JSON.stringify({ moment_id: mid }) });
        setTimeout(loadMoments, 200);
    };

    window.ChatX.toggleComment = function (mid) {
        const input = document.getElementById('input-' + mid);
        const comments = document.getElementById('comments-' + mid);
        if (input.style.display === 'none') {
            input.style.display = 'flex';
            loadComments(mid);
        } else {
            input.style.display = 'none';
            comments.style.display = 'none';
        }
    };

    async function loadComments(mid) {
        const el = document.getElementById('comments-' + mid);
        if (!el) return;
        el.style.display = 'block';
        const data = await api('?action=moment_comments&moment_id=' + mid);
        if (!data.comments?.length) {
            el.innerHTML = '<div style="color:#999;font-size:12px;padding:8px 0;">暂无评论</div>';
            return;
        }
        el.innerHTML = data.comments.map(c => `
            <div class="comment-item">
                <img src="${c.avatar ? 'uploads/avatars/' + esc(c.avatar) : 'assets/default-avatar.png'}" class="avatar-xs">
                <div>
                    <span class="comment-user">${esc(c.nickname)}</span>
                    <span class="comment-text">${esc(c.content)}</span>
                </div>
            </div>
        `).join('');
    }

    window.ChatX.submitComment = async function (mid) {
        const input = document.getElementById('comment-text-' + mid);
        const text = input.value.trim();
        if (!text) return;
        await api('?action=comment_moment', { method: 'POST', body: JSON.stringify({ moment_id: mid, content: text }) });
        input.value = '';
        setTimeout(loadMoments, 200);
    };

    window.ChatX.deleteMoment = async function (mid) {
        if (!confirm('确定删除这条动态？')) return;
        await api('?action=delete_moment', { method: 'POST', body: JSON.stringify({ moment_id: mid }) });
        setTimeout(loadMoments, 200);
    };

    // ============ 发布动态 ============
    window.ChatX.showPostMoment = function () {
        const modal = document.getElementById('postMomentModal');
        if (!modal) return;
        modal.style.display = 'flex';
    };

    window.ChatX.closePostMoment = function () {
        document.getElementById('postMomentModal')?.style.setProperty('display', 'none');
    };

    window.ChatX.submitMoment = async function () {
        const input = document.getElementById('momentInput');
        const text = input.value.trim();
        if (!text) { alert('请输入内容'); return; }
        await api('?action=create_moment', { method: 'POST', body: JSON.stringify({ content: text }) });
        input.value = '';
        window.ChatX.closePostMoment();
        loadMoments();
    };

    // ============ 黑名单 ============
    window.ChatX.showBlacklist = function () {
        const panel = document.getElementById('blacklistPanel');
        if (!panel) return;
        if (panel.style.display !== 'none') {
            panel.style.display = 'none';
            return;
        }
        panel.style.display = 'flex';
        loadBlacklist();
    };

    async function loadBlacklist() {
        const list = document.getElementById('blacklistList');
        if (!list) return;
        list.innerHTML = '<div class="loading">加载中...</div>';
        try {
            const data = await api('?action=blacklist_list');
            if (!data.blacklist?.length) {
                list.innerHTML = '<div style="text-align:center;color:#999;padding:40px 20px;">黑名单为空</div>';
                return;
            }
            list.innerHTML = data.blacklist.map(u => `
                <div class="blacklist-item">
                    <img src="${u.avatar ? 'uploads/avatars/' + esc(u.avatar) : 'assets/default-avatar.png'}" class="avatar-sm">
                    <span class="blacklist-name">${esc(u.nickname || u.username)}</span>
                    <button class="btn-mini btn-primary" onclick="window.ChatX.unblock(${u.blocked_id})">解除</button>
                </div>
            `).join('');
        } catch (e) {
            list.innerHTML = '<div style="color:red;padding:20px;">加载失败</div>';
        }
    }

    window.ChatX.blockUser = async function (uid) {
        await api('?action=blacklist_add', { method: 'POST', body: JSON.stringify({ blocked_id: uid }) });
        alert('已拉黑');
    };

    window.ChatX.unblock = async function (uid) {
        await api('?action=blacklist_remove', { method: 'POST', body: JSON.stringify({ blocked_id: uid }) });
        setTimeout(loadBlacklist, 200);
    };

    // ============ 等级系统 ============
    window.ChatX.showLevelInfo = function () {
        const modal = document.getElementById('levelModal');
        if (!modal) return;
        loadLevelInfo();
        modal.style.display = 'flex';
    };

    window.ChatX.closeLevelInfo = function () {
        document.getElementById('levelModal')?.style.setProperty('display', 'none');
    };

    async function loadLevelInfo() {
        const data = await api('?action=level_info');
        document.getElementById('levelNum').textContent = data.level;
        document.getElementById('xpCurrent').textContent = data.current;
        document.getElementById('xpNeeded').textContent = data.needed;
        const pct = Math.round((data.current / data.needed) * 100);
        document.getElementById('xpBar').style.width = pct + '%';
    }

    // ============ 每日任务 ============
    window.ChatX.closeTasks = function () {
        document.getElementById('tasksModal')?.style.setProperty('display', 'none');
    };

    // ============ 工具函数 ============
    function timeAgo(dateStr) {
        if (!dateStr) return '';
        const d = new Date(dateStr);
        const now = new Date();
        const diff = (now - d) / 1000;
        if (diff < 60) return '刚刚';
        if (diff < 3600) return Math.floor(diff / 60) + '分钟前';
        if (diff < 86400) return Math.floor(diff / 3600) + '小时前';
        if (diff < 604800) return Math.floor(diff / 86400) + '天前';
        return d.toLocaleDateString('zh-CN');
    }

    // ============ 每日任务 ============
    window.ChatX.showTasks = function () {
        const modal = document.getElementById('tasksModal');
        if (!modal) return;
        loadTasks();
        modal.style.display = 'flex';
    };
    window.ChatX.closeTasks = function () {
        document.getElementById('tasksModal')?.style.setProperty('display', 'none');
    };
    window.ChatX.claimTasks = async function () {
        const data = await api('?action=claim_tasks', { method: 'POST', body: JSON.stringify({}) });
        if (data.success) {
            alert('任务奖励已领取！');
            setTimeout(() => { window.ChatX.closeTasks(); }, 500);
        }
    };
    async function loadTasks() {
        const list = document.getElementById('tasksList');
        if (!list) return;
        list.innerHTML = '<div class="loading">加载中...</div>';
        try {
            const data = await api('?action=tasks');
            if (!data.tasks?.length) { list.innerHTML = '<div style="color:#999;padding:20px;">暂无任务</div>'; return; }
            const rewardEl = document.getElementById('taskReward');
            if (rewardEl) rewardEl.innerHTML = '<span style="color:#67c23a;">' + data.earned_reward + '</span> / ' + data.total_reward + ' XP';
            const claimBtn = document.getElementById('taskClaimBtn');
            if (claimBtn) {
                if (data.all_complete && data.earned_reward >= data.total_reward) {
                    claimBtn.textContent = '✓ 已全部完成';
                    claimBtn.disabled = true;
                } else {
                    claimBtn.textContent = '领取奖励';
                    claimBtn.disabled = false;
                }
            }
            list.innerHTML = data.tasks.map(t => {
                const progress = t.progress || 0;
                const target = t.key === 'chat' ? 5 : 1;
                const pct = Math.round((progress / target) * 100);
                return '<div class="task-item ' + (t.done ? 'done' : '') + '">' +
                    '<div class="task-icon">' + (t.done ? '✅' : '📋') + '</div>' +
                    '<div class="task-info">' +
                        '<div class="task-name">' + esc(t.name) + '</div>' +
                        '<div class="task-desc">' + esc(t.desc) + '</div>' +
                        (t.key === 'chat' && !t.done ? '<div class="task-progress"><div class="task-progress-bar" style="width:' + pct + '%"></div></div>' : '') +
                    '</div>' +
                    '<div class="task-reward">+' + t.reward + ' XP</div>' +
                '</div>';
            }).join('');
        } catch (e) {
            list.innerHTML = '<div style="color:red;padding:20px;">加载失败</div>';
        }
    }

    // ============ 初始化 ============
    if (window.ChatX) {
        window.ChatX.uid = (window.ChatX.user?.id) || 0;
        window.ChatX.initFeatures = function () {
            checkUnread();
            notifTimer = setInterval(checkUnread, 60000);
        };
    }

    // 自动初始化（features.js 加载后立即执行）
    if (window.ChatX.initFeatures) {
        window.ChatX.initFeatures();
    }
})();
