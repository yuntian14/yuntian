// ChatX AI 助手模块 - 牢大人设
(function () {
    const API_AI = 'api/ai.php';
    let sessionId = localStorage.getItem('chatx_ai_session') || '';
    let balance = 0;
    let canUse = true;
    let isLoading = false;
    let messages = [];

    // === API 工具 ===
    async function api(action, options) {
        const token = (window.ChatX && window.ChatX.token) || '';
        const url = action.startsWith('?') ? API_AI + action : API_AI + '?' + action;
        const r = await fetch(url, Object.assign({
            headers: { 'X-Auth-Token': token, 'Content-Type': 'application/json' }
        }, options));
        const text = await r.text();
        try {
            return JSON.parse(text);
        } catch (e) {
            throw new Error('登录已过期，请刷新页面重新登录');
        }
    }

    function esc(s) {
        if (!s) return '';
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    // === 显示/隐藏 ===
    window.ChatX.showAI = function () {
        const panel = document.getElementById('aiPanel');
        if (!panel) return;
        panel.style.display = 'flex';
        const content = document.getElementById('aiContent');
        if (!sessionId || !content || !content.innerHTML.trim()) {
            renderShell();
        } else {
            // sessionId 存在但 DOM 为空（页面刷新后），从服务端恢复历史
            loadHistory();
        }
        loadBalance();
        bindCloseButton();
    };

    window.ChatX.hideAI = function () {
        const panel = document.getElementById('aiPanel');
        if (panel) panel.style.display = 'none';
    };

    function bindCloseButton() {
        const btn = document.getElementById('btnCloseAI');
        if (btn && !btn.dataset.bound) {
            btn.onclick = function () { window.ChatX.hideAI(); };
            btn.dataset.bound = '1';
        }
    }

    // === 余额 ===
    async function loadBalance() {
        try {
            const data = await api('?action=balance');
            if (data.error) { alert(data.error); return; }
            balance = data.balance;
            canUse = data.can_use;
            const balEl = document.getElementById('aiBalance');
            if (balEl) {
                balEl.textContent = '积分: ' + balance.toLocaleString() + ' (' + data.cost_per_reply + '/次)';
                balEl.style.color = canUse ? '#67c23a' : '#f56c6c';
            }
        } catch (e) {}
    }

    // === 恢复历史 ===
    async function loadHistory() {
        try {
            const data = await api('?action=history&session_id=' + encodeURIComponent(sessionId));
            const container = document.getElementById('aiMessages');
            if (!container) return;
            container.innerHTML = '';
            const msgs = data.messages || [];
            if (!msgs.length) {
                // 无历史，显示欢迎页
                container.innerHTML = '<div class="ai-welcome"><div class="ai-avatar">🏀</div><div class="ai-welcome-text"><h3>我，科比</h3><p>24号，永远的24号。每次回复 5 积分。</p></div></div>';
                return;
            }
            msgs.forEach(m => appendMessage(m.role, m.content));
            scrollToBottom();
        } catch (e) {
            renderShell();
        }
    }

    // === 渲染界面 ===
    function renderShell() {
        const content = document.getElementById('aiContent');
        if (!content) return;
        content.innerHTML = `
            <div class="ai-chat-container">
                <div class="ai-chat-messages" id="aiMessages">
                    <div class="ai-welcome">
                        <div class="ai-avatar">🏀</div>
                        <div class="ai-welcome-text">
                            <h3>我，科比</h3>
                            <p>24号，永远的24号。每次回复 5 积分。</p>
                            <p style="color:#888;font-size:12px;">我的好兄弟，请你记住这句话。来，干翻全场。</p>
                        </div>
                    </div>
                </div>
                <div class="ai-chat-input-area">
                    <textarea id="aiInput" class="ai-input" placeholder="跟牢大说点什么..." rows="2" maxlength="2000"></textarea>
                    <div class="ai-input-actions">
                        <button class="btn btn-sm" id="btnNewSession">新对话</button>
                        <button class="btn btn-sm btn-primary" id="btnSend">发送</button>
                    </div>
                </div>
            </div>
        `;

        bindControls();
        scrollToBottom();
    }

    function bindControls() {
        const btnSend = document.getElementById('btnSend');
        const btnNew = document.getElementById('btnNewSession');
        const input = document.getElementById('aiInput');

        if (btnSend) btnSend.onclick = sendMessage;
        if (btnNew) btnNew.onclick = newSession;

        if (input) {
            input.onkeydown = function (e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                }
            };
        }
    }

    // === 发送消息 ===
    async function sendMessage() {
        if (isLoading) return;
        const input = document.getElementById('aiInput');
        if (!input) return;
        const text = input.value.trim();
        if (!text) return;

        if (!canUse) {
            alert('积分不足，每次回复需 5 积分。请先到赌场签到或兑换积分。');
            return;
        }

        isLoading = true;
        input.value = '';
        input.disabled = true;
        const btnSend = document.getElementById('btnSend');
        if (btnSend) btnSend.disabled = true;

        // 显示用户消息
        appendMessage('user', text);
        appendLoading();

        try {
            const data = await api('action=chat', {
                method: 'POST',
                body: JSON.stringify({ message: text, session_id: sessionId })
            });

            removeLoading();

            if (data.error) {
                appendMessage('assistant', '⚠️ ' + data.error);
                return;
            }

            sessionId = data.session_id;
            localStorage.setItem('chatx_ai_session', sessionId);
            balance = data.balance;
            canUse = balance >= 5;
            loadBalance();
            appendMessage('assistant', data.reply);
            appendCostTag(data.cost);
        } catch (e) {
            removeLoading();
            appendMessage('assistant', '⚠️ ' + e.message);
        } finally {
            isLoading = false;
            if (input) input.disabled = false;
            if (btnSend) btnSend.disabled = false;
            input.focus();
        }
    }

    // === 新对话 ===
    async function newSession() {
        sessionId = '';
        localStorage.removeItem('chatx_ai_session');
        messages = [];
        try {
            const data = await api('?action=new_session');
            if (data.session_id) { sessionId = data.session_id; localStorage.setItem('chatx_ai_session', sessionId); }
        } catch (e) {
            sessionId = 'sess_' + Date.now() + '_' + Math.random().toString(36).substr(2, 8);
            localStorage.setItem('chatx_ai_session', sessionId);
        }
        const el = document.getElementById('aiMessages');
        if (el) {
            el.innerHTML = `
                <div class="ai-welcome">
                    <div class="ai-avatar">🏀</div>
                    <div class="ai-welcome-text">
                        <h3>我，科比</h3>
                        <p>新对话。我的好兄弟，请你记住这句话。来，干翻全场。</p>
                    </div>
                </div>
            `;
        }
        scrollToBottom();
    }

    // === 渲染消息 ===
    function appendMessage(role, text) {
        const container = document.getElementById('aiMessages');
        if (!container) return;

        const isUser = role === 'user';
        const div = document.createElement('div');
        div.className = 'ai-msg ' + (isUser ? 'ai-msg-user' : 'ai-msg-assistant');

        if (!isUser) {
            const avatar = document.createElement('div');
            avatar.className = 'ai-msg-avatar';
            avatar.textContent = '🏀';
            div.appendChild(avatar);
        }

        const bubble = document.createElement('div');
        bubble.className = 'ai-msg-bubble';
        // 简单的文本格式化：换行保留
        bubble.innerHTML = esc(text).replace(/\n/g, '<br>');
        div.appendChild(bubble);

        container.appendChild(div);
        scrollToBottom();
    }

    function appendLoading() {
        const container = document.getElementById('aiMessages');
        if (!container) return;

        const div = document.createElement('div');
        div.className = 'ai-msg ai-msg-assistant';
        div.id = 'aiLoading';
        div.innerHTML = `
            <div class="ai-msg-avatar">🏀</div>
            <div class="ai-msg-bubble ai-loading">
                <span class="dot"></span><span class="dot"></span><span class="dot"></span>
            </div>
        `;
        container.appendChild(div);
        scrollToBottom();
    }

    function removeLoading() {
        const el = document.getElementById('aiLoading');
        if (el) el.remove();
    }

    function appendCostTag(cost) {
        const container = document.getElementById('aiMessages');
        if (!container) return;
        const div = document.createElement('div');
        div.className = 'ai-cost-tag';
        div.textContent = '- ' + cost + ' 积分（剩余 ' + balance + '）';
        container.appendChild(div);
        scrollToBottom();
    }

    function scrollToBottom() {
        const container = document.getElementById('aiMessages');
        if (container) container.scrollTop = container.scrollHeight;
    }

    // === 键盘快捷键 ===
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            window.ChatX.hideAI();
        }
    });
})();
