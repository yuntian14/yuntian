<?php
session_start();
require_once __DIR__ . '/functions.php';
if (isset($_SESSION['user_id'])) {
    header("Location: chat.php");
    exit;
}
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $nickname = trim($_POST['nickname'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $password2 = trim($_POST['password2'] ?? '');

    if (!$username || !$password) {
        $error = '请填写完整信息';
    } elseif (mb_strlen($username, 'UTF-8') < 3 || !preg_match('/^[a-zA-Z0-9_\x{4e00}-\x{9fa5}]+$/u', $username)) {
        $error = '用户名只能包含字母、数字、下划线或中文，长度至少3位';
    } elseif (mb_strlen($password, 'UTF-8') < 6) {
        $error = '密码长度至少6位';
    } elseif ($password !== $password2) {
        $error = '两次输入的密码不一致';
    } else {
        $pdo = db_connect();
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $error = '用户名已被占用';
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $nickname = $nickname ?: $username;
            $stmt = $pdo->prepare("INSERT INTO users (username, password, nickname) VALUES (?, ?, ?)");
            $stmt->execute([$username, $hash, $nickname]);
            $user_id = $pdo->lastInsertId();
            $_SESSION['user_id'] = $user_id;
            $_SESSION['username'] = $username;
            $_SESSION['nickname'] = $nickname;
            $_SESSION['role'] = 'user';
            header("Location: chat.php");
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatX - 注册</title>
    <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
    <link rel="stylesheet" href="css/style.css">
</head>
<body class="auth-page">
    <div class="auth-box">
        <div class="auth-header">
            <img src="assets/logo.svg" alt="ChatX" style="width:72px;height:72px;margin:0 auto 12px;display:block;">
            <h1>ChatX</h1>
            <p>创建你的账号</p>
        </div>
        <?php if ($error): ?>
        <div class="alert error"><?php echo h($error); ?></div>
        <?php endif; ?>
        <form method="post" action="">
            <div class="form-group">
                <label>用户名</label>
                <input type="text" name="username" placeholder="字母、数字、下划线或中文" required autofocus>
            </div>
            <div class="form-group">
                <label>昵称（可选）</label>
                <input type="text" name="nickname" placeholder="显示名称，不填则同用户名">
            </div>
            <div class="form-group">
                <label>密码</label>
                <input type="password" name="password" placeholder="至少6位" required>
            </div>
            <div class="form-group">
                <label>确认密码</label>
                <input type="password" name="password2" placeholder="再次输入密码" required>
            </div>
            <button type="submit" class="btn-primary">注册</button>
        </form>
        <div class="auth-footer">
            已有账号？<a href="index.php">立即登录</a>
        </div>
    </div>
    <script src="js/main.js"></script>
</body>
</html>
