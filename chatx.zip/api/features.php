<?php
require_once __DIR__ . '/../functions.php';
$pdo = db_connect();
$user = require_auth();
$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$uid = (int)$user['id'];

function ensure_features_tables($pdo) {
    $stmt = $pdo->query("SHOW TABLES");
    $existing = [];
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $t) $existing[$t] = true;

    // 用户表补充字段
    $cols = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
    $colMap = array_flip($cols);
    if (!isset($colMap['xp'])) {
        $pdo->exec("ALTER TABLE users ADD COLUMN xp INT NOT NULL DEFAULT 0 AFTER signature");
    }
    if (!isset($colMap['level'])) {
        $pdo->exec("ALTER TABLE users ADD COLUMN level INT NOT NULL DEFAULT 1 AFTER xp");
    }
    if (!isset($colMap['avatar_frame'])) {
        $pdo->exec("ALTER TABLE users ADD COLUMN avatar_frame VARCHAR(50) DEFAULT NULL AFTER level");
    }
    if (!isset($colMap['dark_mode'])) {
        $pdo->exec("ALTER TABLE users ADD COLUMN dark_mode TINYINT NOT NULL DEFAULT 0 AFTER avatar_frame");
    }

    if (!isset($existing['notifications'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS notifications (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            type VARCHAR(50) NOT NULL,
            title VARCHAR(255) NOT NULL,
            content TEXT DEFAULT NULL,
            related_id INT DEFAULT NULL,
            is_read TINYINT NOT NULL DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user_read (user_id, is_read, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } else {
        // 自愈：旧版 schema 的 type 是窄 ENUM，写入 blacklist/moment_like 等类型会报 1265 Data truncated
        $nCols = $pdo->query("SHOW COLUMNS FROM notifications")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($nCols as $nc) {
            if ($nc['Field'] === 'type' && stripos($nc['Type'], 'enum') !== false) {
                $pdo->exec("ALTER TABLE notifications MODIFY type VARCHAR(50) NOT NULL");
            }
        }
    }

    if (!isset($existing['blacklist'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS blacklist (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            blocked_id INT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_block (user_id, blocked_id),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (blocked_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    // Moments tables
    if (!isset($existing['moments'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS moments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            content TEXT NOT NULL,
            image VARCHAR(500) DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user_time (user_id, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($existing['moment_likes'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS moment_likes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            moment_id INT NOT NULL,
            user_id INT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_like (moment_id, user_id),
            FOREIGN KEY (moment_id) REFERENCES moments(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($existing['moment_comments'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS moment_comments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            moment_id INT NOT NULL,
            user_id INT NOT NULL,
            content VARCHAR(500) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (moment_id) REFERENCES moments(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_moment (moment_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    // Daily tasks table
    if (!isset($existing['daily_tasks'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS daily_tasks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            task_key VARCHAR(50) NOT NULL,
            completed_at DATETIME NOT NULL,
            task_date DATE NOT NULL,
            UNIQUE KEY uniq_task (user_id, task_key, task_date),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user_date (user_id, task_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
}

function xp_to_level($xp) {
    // 每级需要 100 + (level-1) * 50 经验
    // 累积: L1=0, L2=150, L3=350, L4=600, L5=900...
    $level = 1; $needed = 150; $total = 0;
    while ($xp >= $total + $needed && $level < 99) {
        $total += $needed;
        $level++;
        $needed = 150 + ($level - 2) * 50;
    }
    return ['level' => $level, 'current' => $xp - $total, 'needed' => $needed];
}

function add_xp($pdo, $uid, $amount) {
    // Get current level before update
    $stmt = $pdo->prepare("SELECT level FROM users WHERE id = ?");
    $stmt->execute([$uid]);
    $old_level = (int)$stmt->fetchColumn();
    
    $pdo->prepare("UPDATE users SET xp = xp + ? WHERE id = ?")->execute([$amount, $uid]);
    // Recalculate and update level
    $stmt = $pdo->prepare("SELECT xp FROM users WHERE id = ?");
    $stmt->execute([$uid]);
    $xp = (int)$stmt->fetchColumn();
    $lv = xp_to_level($xp);
    $pdo->prepare("UPDATE users SET level = ? WHERE id = ?")->execute([$lv['level'], $uid]);
    
    // Record level up task if leveled up
    if ($lv['level'] > $old_level) {
        record_task($pdo, $uid, 'level');
    }
}

function send_notification($pdo, $user_id, $type, $title, $content = null, $related_id = null) {
    // 通知是附属动作，绝不能因为通知写失败让主操作 500
    try {
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, type, title, content, related_id) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$user_id, $type, $title, $content, $related_id]);
    } catch (Exception $e) {}
}

try {
    ensure_features_tables($pdo);
} catch (Throwable $e) {
    json_response(['error' => '功能数据初始化失败: ' . $e->getMessage()], 500);
}

// ============ 每日任务 ============
function get_task_definitions() {
    return [
        ['key' => 'signin', 'name' => '每日签到', 'desc' => '今天已登录', 'target' => 1, 'reward' => 10],
        ['key' => 'chat', 'name' => '活跃聊天', 'desc' => '发送5条消息', 'target' => 5, 'reward' => 20],
        ['key' => 'moment', 'name' => '分享动态', 'desc' => '发布1条动态', 'target' => 1, 'reward' => 15],
        ['key' => 'friend', 'name' => '拓展社交', 'desc' => '添加1个好友', 'target' => 1, 'reward' => 20],
        ['key' => 'level', 'name' => '成长进阶', 'desc' => '升级1次', 'target' => 1, 'reward' => 30],
    ];
}

// record_task() 由 functions.php 统一提供，此处不再重复声明

if ($method === 'GET' && $action === 'tasks') {
    $today = date('Y-m-d');
    $tasks = get_task_definitions();
    
    // Get completed tasks for today
    $stmt = $pdo->prepare("SELECT task_key, COUNT(*) as cnt FROM daily_tasks WHERE user_id = ? AND task_date = ? GROUP BY task_key");
    $stmt->execute([$uid, $today]);
    $completed = [];
    while ($row = $stmt->fetch()) $completed[$row['task_key']] = (int)$row['cnt'];
    
    // Get claimed status
    $stmt = $pdo->prepare("SELECT task_key FROM daily_tasks WHERE user_id = ? AND task_date = ? AND task_key LIKE 'claimed_%'");
    $stmt->execute([$uid, $today]);
    $claimed = [];
    while ($row = $stmt->fetch()) $claimed[$row['task_key']] = true;
    
    $result = [];
    $total_reward = 0;
    $earned_reward = 0;
    $all_complete = true;
    
    foreach ($tasks as $t) {
        $progress = min($completed[$t['key']] ?? 0, $t['target']);
        $done = $progress >= $t['target'];
        $total_reward += $t['reward'];
        if ($done) $earned_reward += $t['reward'];
        else $all_complete = false;
        
        $result[] = [
            'key' => $t['key'],
            'name' => $t['name'],
            'desc' => $t['desc'],
            'progress' => $progress,
            'target' => $t['target'],
            'done' => $done,
            'reward' => $t['reward'],
            'claimed' => isset($claimed['claimed_' . $t['key']])
        ];
    }
    
    json_response([
        'tasks' => $result,
        'total_reward' => $total_reward,
        'earned_reward' => $earned_reward,
        'all_complete' => $all_complete
    ]);
}

if ($method === 'POST' && $action === 'claim_tasks') {
    $today = date('Y-m-d');
    $tasks = get_task_definitions();
    $stmt = $pdo->prepare("SELECT task_key, COUNT(*) as cnt FROM daily_tasks WHERE user_id = ? AND task_date = ? GROUP BY task_key");
    $stmt->execute([$uid, $total]);
    $completed = [];
    while ($row = $stmt->fetch()) $completed[$row['task_key']] = (int)$row['cnt'];
    
    $total_xp = 0;
    foreach ($tasks as $t) {
        $progress = min($completed[$t['key']] ?? 0, $t['target']);
        if ($progress >= $t['target']) {
            // Check if already claimed
            $claim_key = 'claimed_' . $t['key'];
            $stmt2 = $pdo->prepare("SELECT COUNT(*) FROM daily_tasks WHERE user_id = ? AND task_key = ? AND task_date = ?");
            $stmt2->execute([$uid, $claim_key, $today]);
            if ((int)$stmt2->fetchColumn() > 0) continue;
            
            // Mark as claimed
            $pdo->prepare("INSERT INTO daily_tasks (user_id, task_key, completed_at, task_date) VALUES (?, ?, NOW(), ?)")->execute([$uid, $claim_key, $today]);
            $total_xp += $t['reward'];
        }
    }
    
    if ($total_xp > 0) {
        add_xp($pdo, $uid, $total_xp);
        json_response(['success' => true, 'xp' => $total_xp]);
    } else {
        json_response(['success' => false, 'message' => '没有可领取的奖励']);
    }
}

// ============ 用户资料更新（含签名/等级/头像框/暗色模式）============
if ($method === 'POST' && $action === 'profile') {
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $fields = [];
    $params = [];
    if (isset($in['nickname'])) {
        $nickname = trim($in['nickname']);
        if ($nickname && mb_strlen($nickname) <= 50) { $fields[] = 'nickname = ?'; $params[] = $nickname; }
    }
    if (isset($in['bio'])) {
        $fields[] = 'bio = ?'; $params[] = $in['bio'] ?? null;
    }
    if (isset($in['signature'])) {
        $sig = trim($in['signature']);
        if (mb_strlen($sig) <= 255) { $fields[] = 'signature = ?'; $params[] = $sig ?: null; }
    }
    if (isset($in['avatar_frame'])) {
        $fields[] = 'avatar_frame = ?'; $params[] = $in['avatar_frame'] ?: null;
    }
    if (isset($in['dark_mode'])) {
        $fields[] = 'dark_mode = ?'; $params[] = (int)$in['dark_mode'] ? 1 : 0;
    }
    if ($fields) {
        $params[] = $uid;
        $pdo->prepare("UPDATE users SET " . implode(', ', $fields) . " WHERE id = ?")->execute($params);
    }
    $stmt = $pdo->prepare("SELECT nickname, bio, signature, avatar_frame, xp, level, dark_mode FROM users WHERE id = ?");
    $stmt->execute([$uid]);
    $me = $stmt->fetch();
    $lv = xp_to_level((int)$me['xp']);
    $me['level'] = $lv['level'];
    $me['xp_current'] = $lv['current'];
    $me['xp_needed'] = $lv['needed'];
    json_response(['profile' => $me]);
}

// ============ 获取我的等级信息 ============
if ($method === 'GET' && $action === 'level_info') {
    $stmt = $pdo->prepare("SELECT xp, level FROM users WHERE id = ?");
    $stmt->execute([$uid]);
    $row = $stmt->fetch();
    $lv = xp_to_level((int)$row['xp']);
    json_response($lv);
}

// ============ 通知中心 ============
if ($method === 'GET' && $action === 'list') {
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY is_read ASC, created_at DESC LIMIT 50");
    $stmt->execute([$uid]);
    $unread = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0");
    $unread->execute([$uid]);
    json_response(['notifications' => $stmt->fetchAll(), 'unread' => (int)$unread->fetchColumn()]);
}

if ($method === 'POST' && $action === 'mark_read') {
    $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?")->execute([$uid]);
    json_response(['success' => true]);
}

if ($method === 'POST' && $action === 'mark_read_single') {
    $id = (int)($_GET['id'] ?? 0);
    $pdo->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND id = ?")->execute([$uid, $id]);
    json_response(['success' => true]);
}

// ============ 黑名单 ============
if ($method === 'GET' && $action === 'blacklist_list') {
    $stmt = $pdo->prepare("SELECT b.*, u.username, u.nickname, u.avatar, u.avatar_frame FROM blacklist b JOIN users u ON u.id = b.blocked_id WHERE b.user_id = ? ORDER BY b.created_at DESC");
    $stmt->execute([$uid]);
    json_response(['blacklist' => $stmt->fetchAll()]);
}

if ($method === 'POST' && $action === 'blacklist_add') {
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $blocked_id = (int)($in['blocked_id'] ?? 0);
    if ($blocked_id <= 0) json_response(['error' => '无效用户'], 400);
    if ($blocked_id === $uid) json_response(['error' => '不能拉黑自己'], 400);
    $pdo->prepare("INSERT IGNORE INTO blacklist (user_id, blocked_id) VALUES (?, ?)")->execute([$uid, $blocked_id]);
    // 通知被拉黑的人
    $stmt = $pdo->prepare("SELECT nickname FROM users WHERE id = ?");
    $stmt->execute([$uid]);
    $me = $stmt->fetch();
    send_notification($pdo, $blocked_id, 'blacklist', ($me['nickname'] ?? '某人') . ' 将你加入了黑名单');
    json_response(['success' => true]);
}

if ($method === 'POST' && $action === 'blacklist_remove') {
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $blocked_id = (int)($in['blocked_id'] ?? 0);
    $pdo->prepare("DELETE FROM blacklist WHERE user_id = ? AND blocked_id = ?")->execute([$uid, $blocked_id]);
    json_response(['success' => true]);
}

// ============ 获取完整用户信息（含等级）============
if ($method === 'GET' && $action === 'full_profile') {
    $target_id = (int)($_GET['user_id'] ?? $uid);
    $stmt = $pdo->prepare("SELECT id, username, nickname, avatar, bio, signature, xp, level, avatar_frame, status, last_seen, created_at FROM users WHERE id = ?");
    $stmt->execute([$target_id]);
    $user_row = $stmt->fetch();
    if (!$user_row) json_response(['error' => '用户不存在'], 404);
    $lv = xp_to_level((int)$user_row['xp']);
    $user_row['level'] = $lv['level'];
    $user_row['xp_current'] = $lv['current'];
    $user_row['xp_needed'] = $lv['needed'];
    json_response(['user' => $user_row]);
}

// ============ 好友动态/Moments ============

// 发布动态
if ($method === 'POST' && $action === 'create_moment') {
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $content = trim($in['content'] ?? '');
    if (!$content || mb_strlen($content) > 1000) json_response(['error' => '内容不能为空且不超过1000字'], 400);
    $image = $in['image'] ?? null;
    $pdo->prepare("INSERT INTO moments (user_id, content, image) VALUES (?, ?, ?)")->execute([$uid, $content, $image]);
    add_xp($pdo, $uid, 10);
    json_response(['success' => true]);
}

// 动态列表（好友动态 + 自己）
if ($method === 'GET' && $action === 'list_moments') {
    // 获取好友 ID 列表
    $stmt = $pdo->prepare("SELECT friend_id FROM friendships WHERE user_id = ? AND status = 'accepted'
                          UNION SELECT user_id FROM friendships WHERE friend_id = ? AND status = 'accepted'");
    $stmt->execute([$uid, $uid]);
    $friend_ids = [$uid];
    foreach ($stmt->fetchAll() as $row) $friend_ids[] = (int)$row[0];
    $placeholders = implode(',', array_fill(0, count($friend_ids), '?'));
    $stmt = $pdo->prepare("SELECT m.*, u.nickname, u.avatar, u.avatar_frame,
        (SELECT COUNT(*) FROM moment_likes WHERE moment_id = m.id) AS like_count,
        (SELECT COUNT(*) FROM moment_comments WHERE moment_id = m.id) AS comment_count,
        (SELECT GROUP_CONCAT(ul.nickname SEPARATOR ',') FROM moment_likes ml JOIN users ul ON ul.id = ml.user_id WHERE ml.moment_id = m.id LIMIT 5) AS like_users,
        (SELECT GROUP_CONCAT(ucc.nickname SEPARATOR ',') FROM moment_comments mc JOIN users ucc ON ucc.id = mc.user_id WHERE mc.moment_id = m.id ORDER BY mc.created_at DESC LIMIT 3) AS comment_users
        FROM moments m JOIN users u ON u.id = m.user_id
        WHERE m.user_id IN ($placeholders)
        ORDER BY m.created_at DESC LIMIT 30");
    $stmt->execute($friend_ids);
    $moments = $stmt->fetchAll();
    // 检查自己是否点赞了
    $stmt = $pdo->prepare("SELECT moment_id FROM moment_likes WHERE user_id = ?");
    $stmt->execute([$uid]);
    $my_likes = [];
    foreach ($stmt->fetchAll() as $row) $my_likes[(int)$row[0]] = true;
    foreach ($moments as &$m) $m['i_liked'] = isset($my_likes[(int)$m['id']]);
    json_response(['moments' => $moments]);
}

// 点赞/取消点赞
if ($method === 'POST' && $action === 'toggle_moment_like') {
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $mid = (int)($in['moment_id'] ?? 0);
    if ($mid <= 0) json_response(['error' => '无效'], 400);
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM moment_likes WHERE moment_id = ? AND user_id = ?");
    $stmt->execute([$mid, $uid]);
    if ($stmt->fetchColumn() > 0) {
        $pdo->prepare("DELETE FROM moment_likes WHERE moment_id = ? AND user_id = ?")->execute([$mid, $uid]);
    } else {
        $pdo->prepare("INSERT INTO moment_likes (moment_id, user_id) VALUES (?, ?)")->execute([$mid, $uid]);
        // 通知动态发布者
        $stmt = $pdo->prepare("SELECT user_id FROM moments WHERE id = ?");
        $stmt->execute([$mid]);
        $owner = $stmt->fetch();
        if ($owner && (int)$owner['user_id'] !== $uid) {
            send_notification($pdo, (int)$owner['user_id'], 'moment_like', '你的动态被点赞了');
        }
    }
    json_response(['success' => true]);
}

// 评论动态
if ($method === 'POST' && $action === 'comment_moment') {
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $mid = (int)($in['moment_id'] ?? 0);
    $content = trim($in['content'] ?? '');
    if ($mid <= 0 || !$content || mb_strlen($content) > 500) json_response(['error' => '无效评论'], 400);
    $pdo->prepare("INSERT INTO moment_comments (moment_id, user_id, content) VALUES (?, ?, ?)")->execute([$mid, $uid, $content]);
    add_xp($pdo, $uid, 5);
    // 通知动态发布者
    $stmt = $pdo->prepare("SELECT user_id FROM moments WHERE id = ?");
    $stmt->execute([$mid]);
    $owner = $stmt->fetch();
    if ($owner && (int)$owner['user_id'] !== $uid) {
        send_notification($pdo, (int)$owner['user_id'], 'moment_comment', '你的动态有新评论');
    }
    json_response(['success' => true]);
}

// 删除自己的动态
if ($method === 'POST' && $action === 'delete_moment') {
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $mid = (int)($in['moment_id'] ?? 0);
    $pdo->prepare("DELETE FROM moments WHERE id = ? AND user_id = ?")->execute([$mid, $uid]);
    json_response(['success' => true]);
}

// 获取动态评论
if ($method === 'GET' && $action === 'moment_comments') {
    $mid = (int)($_GET['moment_id'] ?? 0);
    $stmt = $pdo->prepare("SELECT mc.*, u.nickname, u.avatar FROM moment_comments mc JOIN users u ON u.id = mc.user_id WHERE mc.moment_id = ? ORDER BY mc.created_at DESC");
    $stmt->execute([$mid]);
    json_response(['comments' => $stmt->fetchAll()]);
}

json_response(['error' => '未知操作'], 404);
