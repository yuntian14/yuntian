<?php
// ChatX 数据备份 / 恢复 API
// 导出：全站数据以 JSON 包形式直接流式下载到管理员本地设备，不在服务器落盘
// 导入：上传备份包，只恢复目标库已存在的表；失败自动回滚
require_once __DIR__ . '/../functions.php';

$pdo = db_connect();
header('Content-Type: application/json; charset=utf-8');

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

// 备份与恢复是最高敏感操作：仅超级管理员
function backup_require_super_admin($pdo) {
    $user = require_auth();
    if (!is_super_admin($user)) {
        json_response(['error' => '仅超级管理员可执行备份/恢复操作'], 403);
    }
    return $user;
}

// 允许通过 query token 触发浏览器直接下载（<a download> 无法带自定义头）
function backup_auth_by_query_token($pdo) {
    $token = $_GET['token'] ?? '';
    if (!empty($token)) {
        $user = get_user_by_token($token);
        if ($user && is_super_admin($user)) return $user;
    }
    $user = require_auth();
    if (!is_super_admin($user)) {
        json_response(['error' => '仅超级管理员可执行备份/恢复操作'], 403);
    }
    return $user;
}

function backup_all_tables($pdo) {
    $tables = [];
    $stmt = $pdo->query("SHOW TABLES");
    foreach ($stmt->fetchAll(PDO::FETCH_NUM) as $row) {
        $tables[] = $row[0];
    }
    return $tables;
}

// 导出：流式输出，不在服务器生成任何临时文件
if ($action === 'export') {
    $user = backup_auth_by_query_token($pdo);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // 关闭缓冲查询，真正做到逐行流式读取并输出，大表不会整表载入内存
    // （本请求随后即 exit，不影响同一进程内的其他逻辑）
    try {
        $pdo->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, false);
    } catch (Exception $e) {
        // 驱动不支持时退回默认行为，不影响正确性
    }

    $tables = backup_all_tables($pdo);
    $filename = 'chatx_backup_' . date('Ymd_His') . '.json';

    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('X-Accel-Buffering: no');

    $totalRows = 0;
    echo "{\n";
    echo '"meta": ' . json_encode([
        'app' => 'chatx',
        'format' => 1,
        'created_at' => date('c'),
        'db_name' => DB_NAME,
        'table_count' => count($tables),
        'php_version' => PHP_VERSION,
    ], JSON_UNESCAPED_UNICODE) . ",\n";
    echo '"tables": {' . "\n";

    $firstTable = true;
    foreach ($tables as $table) {
        // 只导出基表，跳过视图（本应用无视图，防御性处理）
        // 注意：非缓冲查询模式下，任何未读完的结果集都会阻塞后续查询，
        // 因此每取完一段就必须 closeCursor() 显式结束该结果集。
        $chk = $pdo->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND TABLE_TYPE = 'BASE TABLE'");
        $chk->execute([DB_NAME, $table]);
        $isBase = $chk->fetchColumn();
        $chk->closeCursor();
        if (!$isBase) continue;

        if (!$firstTable) echo ",\n";
        $firstTable = false;

        $createStmt = $pdo->prepare("SHOW CREATE TABLE `$table`");
        $createStmt->execute();
        $createRow = $createStmt->fetch(PDO::FETCH_NUM);
        $createSql = $createRow[1] ?? '';
        $createStmt->closeCursor();

        $rowStmt = $pdo->query("SELECT * FROM `$table`");
        echo '"' . $table . '": {"create": ' . json_encode($createSql, JSON_UNESCAPED_UNICODE) . ', "rows": [';
        $firstRow = true;
        while ($row = $rowStmt->fetch(PDO::FETCH_ASSOC)) {
            echo ($firstRow ? "\n" : ",\n");
            $firstRow = false;
            echo json_encode($row, JSON_UNESCAPED_UNICODE);
            $totalRows++;
        }
        echo ($firstRow ? '' : "\n") . ']}';
        // 冲刷输出缓冲，边查边下，大表不会整表载入内存
        if (ob_get_level() > 0) @ob_flush();
        @flush();
    }

    echo "\n}}\n";
    if (ob_get_level() > 0) @ob_end_flush();
    exit;
}

// 备份包摘要（不落盘，纯校验）
if ($action === 'analyze' && $method === 'POST') {
    $user = backup_require_super_admin($pdo);
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data) || !isset($data['tables']) || !is_array($data['tables'])) {
        json_response(['error' => '备份包格式无效：缺少 tables 字段'], 400);
    }
    if (($data['meta']['app'] ?? '') !== 'chatx') {
        json_response(['error' => '备份包来源无效：meta.app 不是 chatx'], 400);
    }
    $tables = [];
    $totalRows = 0;
    $compat = [];
    foreach ($data['tables'] as $name => $entry) {
        if (!is_array($entry) || !isset($entry['create'], $entry['rows'])) {
            json_response(['error' => "表 $name 的备份条目不完整"], 400);
        }
        if (!is_array($entry['rows'])) {
            json_response(['error' => "表 $name 的 rows 不是数组"], 400);
        }
        $tables[] = ['name' => $name, 'rows' => count($entry['rows'])];
        $totalRows += count($entry['rows']);

        // 跨版本差异：该表在当前库中的存在情况与列交集
        if (preg_match('/^[A-Za-z0-9_]+$/', (string)$name)) {
            $targetCols = backup_table_columns($pdo, $name);
            if ($targetCols === null) {
                $compat[] = ['table' => $name, 'exists' => false, 'action' => 'skipped', 'note' => '当前库没有该表，保持原样，不会被创建'];
            } else {
                $rowCols = [];
                foreach ($entry['rows'] as $row) {
                    if (!is_array($row)) continue;
                    foreach (array_keys($row) as $k) $rowCols[$k] = true;
                }
                $rowCols = array_keys($rowCols);
                $skipped = array_values(array_diff($rowCols, array_keys($targetCols)));
                $newTargetCols = array_values(array_diff(array_keys($targetCols), $rowCols));
                $compat[] = [
                    'table' => $name,
                    'exists' => true,
                    'action' => 'rows',
                    'note' => '保留当前表结构，仅恢复数据',
                    'dropped_columns' => $skipped,
                    'new_columns_kept' => $newTargetCols,
                ];
            }
        }
    }
    json_response([
        'meta' => $data['meta'] ?? [],
        'tables' => $tables,
        'compat' => $compat,
        'total_rows' => $totalRows,
        'current_tables' => backup_all_tables($pdo),
    ]);
}

// 恢复导入：事务内重建，失败整体回滚
if ($action === 'import' && $method === 'POST') {
    $user = backup_require_super_admin($pdo);
    $raw = file_get_contents('php://input');
    if (!$raw) json_response(['error' => '请求体为空'], 400);
    $data = json_decode($raw, true);
    if (!is_array($data) || !isset($data['tables']) || !is_array($data['tables'])) {
        json_response(['error' => '备份包格式无效：缺少 tables 字段'], 400);
    }
    if (($data['meta']['app'] ?? '') !== 'chatx') {
        json_response(['error' => '备份包来源无效：meta.app 不是 chatx'], 400);
    }

    // 导入前先做一次自动备份校验：表结构语句必须存在
    $skipTables = ['sessions']; // 不覆盖当前登录态，避免恢复后管理员被踢出
    $importTables = [];
    foreach ($data['tables'] as $name => $entry) {
        if (!preg_match('/^[A-Za-z0-9_]+$/', (string)$name)) {
            json_response(['error' => "非法表名: $name"], 400);
        }
        if (!is_array($entry) || empty($entry['create']) || !isset($entry['rows']) || !is_array($entry['rows'])) {
            json_response(['error' => "表 $name 的备份条目不完整"], 400);
        }
        if (!in_array($name, $skipTables, true)) $importTables[$name] = $entry;
    }
    if (!$importTables) json_response(['error' => '备份包中没有可恢复的数据表'], 400);

    // MySQL 的 DDL（DROP/CREATE TABLE）会隐式提交事务，真正的"事务回滚"不存在。
    // 因此：先把当前全库数据dump成内存快照，恢复失败时用快照真实写回，实现可回滚。
    $snapshot = null;
    try {
        $snapshot = backup_build_dump($pdo);
    } catch (Exception $e) {
        json_response(['error' => '无法创建导入前快照，已中止恢复以保护数据: ' . $e->getMessage()], 500);
    }

    try {
        $restoredTables = 0;
        $restoredRows = 0;
        $report = [];
        $widened = [];
        backup_apply_tables($pdo, $importTables, $restoredTables, $restoredRows, $report, $widened);
        $warnings = array_values(array_filter($report, function ($r) {
            return in_array($r['action'], ['skipped', 'skipped_cols', 'widened'], true);
        }));
        $msg = "已恢复 {$restoredTables} 张表 / {$restoredRows} 行数据（保留当前表结构，跨版本安全）";
        if ($warnings) {
            $msg .= '；其中 ' . count($warnings) . ' 项因版本差异被跳过或调整列，详见报告';
        }
        json_response([
            'success' => true,
            'restored_tables' => $restoredTables,
            'restored_rows' => $restoredRows,
            'skipped_tables' => $skipTables,
            'warnings' => $warnings,
            'report' => $report,
            'message' => $msg,
        ]);
    } catch (Exception $e) {
        // 恢复失败：把导入前的快照写回去，数据库恢复到导入前状态
        try {
            $snapData = json_decode($snapshot, true);
            $rollbackTables = 0;
            $rollbackRows = 0;
            $rollbackReport = [];
            backup_apply_tables($pdo, $snapData['tables'], $rollbackTables, $rollbackRows, $rollbackReport);
            // 放宽过的列也要还原成导入前的类型，保证结构与数据都回到原状
            if ($widened) {
                foreach ($widened as $w) {
                    $nullSql = ($w['null'] === 'NO') ? ' NOT NULL' : ' NULL';
                    if ($w['default'] !== null) {
                        $def = is_string($w['default']) ? "'" . str_replace("'", "''", $w['default']) . "'" : $w['default'];
                        $nullSql .= " DEFAULT $def";
                    }
                    $pdo->exec("ALTER TABLE `{$w['table']}` MODIFY `{$w['col']}` {$w['type']}$nullSql");
                }
            }
            json_response(['error' => '恢复失败，已自动回滚到导入前状态（' . $rollbackTables . ' 张表）: ' . $e->getMessage()], 500);
        } catch (Exception $e2) {
            json_response(['error' => '恢复失败且自动回滚失败，请立即用其他备份修复。导入错误: ' . $e->getMessage() . '；回滚错误: ' . $e2->getMessage()], 500);
        }
    }
}

json_response(['error' => '未知操作'], 400);

// 目标表结构快照：null = 表不存在；否则 col => ['type','null','default','is_enum','enum']
function backup_table_columns($pdo, $table) {
    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM `$table`");
    } catch (Exception $e) {
        return null;
    }
    $cols = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (!$cols) return null;
    $out = [];
    foreach ($cols as $c) {
        $type = (string)$c['Type'];
        $isEnum = stripos($type, 'enum(') === 0;
        $values = [];
        if ($isEnum && preg_match_all("/'((?:[^']|'')*)'/", $type, $m)) {
            $values = array_map(function ($v) { return str_replace("''", "'", $v); }, $m[1]);
        }
        $out[$c['Field']] = [
            'type' => $type,
            'null' => $c['Null'],
            'default' => $c['Default'],
            'is_enum' => $isEnum,
            'enum' => $values,
        ];
    }
    return $out;
}

// 行集合里某列的全部出现值（用于枚举越界检测）
function backup_column_values($rows, $col) {
    $vals = [];
    foreach ($rows as $row) {
        if (is_array($row) && array_key_exists($col, $row) && $row[$col] !== null && $row[$col] !== '') {
            $vals[(string)$row[$col]] = true;
        }
    }
    return array_keys($vals);
}

// 跨版本兼容：备份里的值超出目标库 ENUM 定义时，把该列放宽为足够宽的 VARCHAR
function backup_widen_enum_column($pdo, $table, $col, $info, $values) {
    $width = 50;
    foreach ($values as $v) $width = max($width, mb_strlen($v) + 20);
    $nullSql = ($info['null'] === 'NO') ? ' NOT NULL' : ' NULL';
    if ($info['default'] !== null) {
        $def = is_string($info['default']) ? "'" . str_replace("'", "''", $info['default']) . "'" : $info['default'];
        $nullSql .= " DEFAULT $def";
    }
    $pdo->exec("ALTER TABLE `$table` MODIFY `$col` VARCHAR($width)$nullSql");
    return $width;
}

// 全库 dump 成 JSON 字符串（用于导入前的内存快照，失败时写回实现真回滚）
function backup_build_dump($pdo) {
    $tables = backup_all_tables($pdo);
    $out = ['tables' => []];
    foreach ($tables as $table) {
        $chk = $pdo->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND TABLE_TYPE = 'BASE TABLE'");
        $chk->execute([DB_NAME, $table]);
        $isBase = $chk->fetchColumn();
        $chk->closeCursor();
        if (!$isBase) continue;
        $createStmt = $pdo->prepare("SHOW CREATE TABLE `$table`");
        $createStmt->execute();
        $createRow = $createStmt->fetch(PDO::FETCH_NUM);
        $createStmt->closeCursor();
        $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
        $out['tables'][$table] = ['create' => $createRow[1] ?? '', 'rows' => $rows];
    }
    return json_encode($out, JSON_UNESCAPED_UNICODE);
}

// 把备份写入数据库（跨版本安全）。
// 语义：只恢复"目标库已存在"的表 —— 保留其现有表结构，仅清空并灌入数据（列取交集，新版独有列取默认值）；
//       目标库没有的表一律跳过：不新建、不删除，保持原样。
// 因此旧版本备份导入新版本库，既不会把新 schema 打回旧 schema，也不会污染当前版本不认识的老表。
function backup_apply_tables($pdo, $tables, &$restoredTables, &$restoredRows, &$report = null, &$widened = null) {
    // 跨版本恢复：旧备份可能缺少新版本新增的 NOT NULL 列（无默认值），严格模式下整批 INSERT 会 1364 失败。
    // 临时去掉 STRICT 模式，让缺失列按隐式默认值（0/'' 等）落库，与 mysqldump 恢复的做法一致。
    $prevSqlMode = (string)$pdo->query("SELECT @@SESSION.sql_mode")->fetchColumn();
    $pdo->exec("SET SESSION sql_mode = REPLACE(REPLACE(REPLACE(@@SESSION.sql_mode, 'STRICT_TRANS_TABLES', ''), 'STRICT_ALL_TABLES', ''), ',,', ',')");
    $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
    try {
        foreach ($tables as $name => $entry) {
            if (!preg_match('/^[A-Za-z0-9_]+$/', (string)$name)) {
                throw new Exception("非法表名: $name");
            }
            if (!is_array($entry) || empty($entry['create']) || !isset($entry['rows']) || !is_array($entry['rows'])) {
                throw new Exception("表 $name 的备份条目不完整");
            }
            $targetCols = backup_table_columns($pdo, $name);
            if ($targetCols === null) {
                // 目标库没有该表：既不新建也不删除，保持原样（跨版本只动已有库）
                $report[] = ['table' => $name, 'action' => 'skipped', 'note' => '当前库没有该表，保持原样'];
                continue;
            }
            $report[] = ['table' => $name, 'action' => 'rows', 'note' => '保留现有表结构，仅恢复数据'];

            // 列集合：备份行键的并集，与目标库列取交集
            $rowCols = [];
            foreach ($entry['rows'] as $row) {
                if (!is_array($row)) throw new Exception("表 $name 存在非对象行");
                foreach (array_keys($row) as $k) $rowCols[$k] = true;
            }
            $rowCols = array_keys($rowCols);
            $insertCols = array_values(array_intersect($rowCols, array_keys($targetCols)));
            $skippedCols = array_values(array_diff($rowCols, array_keys($targetCols)));
            if ($skippedCols) {
                $report[] = ['table' => $name, 'action' => 'skipped_cols', 'note' => '目标库无这些列，数据已忽略: ' . implode(', ', $skippedCols)];
            }
            // 有数据却与目标库毫无共同列：无法安全灌入，整张表跳过且不清空，避免误删目标数据
            if ($entry['rows'] && !$insertCols) {
                $report[] = ['table' => $name, 'action' => 'skipped', 'note' => '与目标库无共同列，已跳过（未改动该表数据）'];
                continue;
            }

            // 恢复语义 = 用备份数据替换目标数据：先清空目标表（备份为空表时也要清空）
            $pdo->exec("DELETE FROM `$name`");
            if (!$insertCols) {
                // 备份中该表无数据行：已清空目标表，无需插入
                $restoredTables++;
                continue;
            }

            // 跨版本枚举越界：旧备份的值可能超出新版 ENUM 定义，先把该列放宽
            foreach ($insertCols as $col) {
                $info = $targetCols[$col];
                if (empty($info['is_enum'])) continue;
                $vals = backup_column_values($entry['rows'], $col);
                $missing = array_values(array_diff($vals, $info['enum']));
                if ($missing) {
                    $width = backup_widen_enum_column($pdo, $name, $col, $info, $vals);
                    $widened[] = ['table' => $name, 'col' => $col, 'type' => $info['type'], 'null' => $info['null'], 'default' => $info['default']];
                    $report[] = ['table' => $name, 'action' => 'widened', 'note' => "列 $col 放宽为 VARCHAR($width) 以容纳旧版数据: " . implode(', ', array_slice($missing, 0, 5))];
                }
            }

            $batchSize = 100;
            $buffer = [];
            foreach ($entry['rows'] as $row) {
                $buffer[] = $row;
                if (count($buffer) >= $batchSize) {
                    backup_insert_batch($pdo, $name, $insertCols, $buffer);
                    $restoredRows += count($buffer);
                    $buffer = [];
                }
            }
            if ($buffer) {
                backup_insert_batch($pdo, $name, $insertCols, $buffer);
                $restoredRows += count($buffer);
            }
            $restoredTables++;
        }
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        $pdo->exec("SET SESSION sql_mode = " . $pdo->quote($prevSqlMode));
    } catch (Exception $e) {
        try { $pdo->exec("SET FOREIGN_KEY_CHECKS = 1"); } catch (Exception $e2) {}
        try { $pdo->exec("SET SESSION sql_mode = " . $pdo->quote($prevSqlMode)); } catch (Exception $e2) {}
        throw $e;
    }
}

// 批量 INSERT 的属主约束：既限行数，也限累计字节数。
// PDO 默认开启模拟预编译，多行 VALUES 会把参数值拼进 SQL 文本，
// 一旦单条 SQL 超过 max_allowed_packet（常见 16MB）整批插入直接失败，
// 因此必须按数据量切批，而不是固定行数。
function backup_insert_batch($pdo, $table, $columns, $rows) {
    if (!$rows) return;
    $colSql = '`' . implode('`, `', $columns) . '`';
    $placeholders = '(' . rtrim(str_repeat('?, ', count($columns)), ', ') . ')';
    $maxRows = 100;
    $maxBytes = 4 * 1024 * 1024; // 单条 INSERT 的估算上限，留足余量
    $batch = [];
    $batchBytes = 0;
    foreach ($rows as $row) {
        // 缺失列补 null，多余列忽略，保证与列集合一致
        $groups = [];
        $rowBytes = 0;
        foreach ($columns as $col) {
            $v = $row[$col] ?? null;
            $groups[] = $v;
            if (is_string($v)) $rowBytes += strlen($v) + 4; // 粗略折算引号与转义开销
        }
        $batch[] = $groups;
        $batchBytes += $rowBytes;
        if (count($batch) >= $maxRows || $batchBytes >= $maxBytes) {
            backup_exec_insert($pdo, $table, $colSql, $placeholders, $batch);
            $batch = [];
            $batchBytes = 0;
        }
    }
    if ($batch) backup_exec_insert($pdo, $table, $colSql, $placeholders, $batch);
}

function backup_exec_insert($pdo, $table, $colSql, $placeholders, $batch) {
    $sql = "INSERT INTO `$table` ($colSql) VALUES " . implode(', ', array_fill(0, count($batch), $placeholders));
    $params = [];
    foreach ($batch as $groups) foreach ($groups as $v) $params[] = $v;
    $pdo->prepare($sql)->execute($params);
}
