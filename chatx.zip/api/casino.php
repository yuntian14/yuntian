<?php
require_once __DIR__ . '/../functions.php';
$pdo = db_connect();
$user = require_auth();

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$uid = (int)$user['id'];

// 表自愈：缺表时自动创建（失败时返回 JSON 错误而非 HTML 崩溃页）
try {
    ensure_casino_tables($pdo);
    bj_ensure_table($pdo); // 事务外预建 21 点牌局表，避免 DDL 隐式提交事务
} catch (Throwable $e) {
    json_response(['error' => '赌场数据初始化失败: ' . $e->getMessage()], 500);
}

function ensure_casino_tables($pdo) {
    $stmt = $pdo->query("SHOW TABLES");
    $existing = [];
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $t) $existing[$t] = true;

    if (!isset($existing['user_wallets'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS user_wallets (
            user_id INT NOT NULL,
            currency ENUM('points','gomoku','casino') NOT NULL,
            balance BIGINT NOT NULL DEFAULT 0,
            last_signin DATE DEFAULT NULL,
            signin_streak INT NOT NULL DEFAULT 0,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, currency),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($existing['point_transactions'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS point_transactions (
            id BIGINT AUTO_INCREMENT PRIMARY KEY,
            from_user_id INT DEFAULT NULL,
            to_user_id INT DEFAULT NULL,
            currency VARCHAR(20) NOT NULL,
            amount BIGINT NOT NULL,
            type ENUM('signin','transfer','exchange','bet','win','lose') NOT NULL,
            memo VARCHAR(255) DEFAULT NULL,
            detail JSON DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE SET NULL,
            FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_from (from_user_id, created_at),
            INDEX idx_to (to_user_id, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($existing['casino_rooms'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS casino_rooms (
            id INT AUTO_INCREMENT PRIMARY KEY,
            game_mode ENUM('dice','roulette','blackjack','liar','highlow') NOT NULL,
            status ENUM('waiting','playing','finished') DEFAULT 'waiting',
            host_id INT NOT NULL,
            guest_id INT DEFAULT NULL,
            bet_amount BIGINT NOT NULL,
            host_choice JSON DEFAULT NULL,
            guest_choice JSON DEFAULT NULL,
            result JSON DEFAULT NULL,
            winner_id INT DEFAULT NULL,
            is_draw TINYINT NOT NULL DEFAULT 0,
            game_state JSON DEFAULT NULL,
            players JSON DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            finished_at DATETIME DEFAULT NULL,
            FOREIGN KEY (host_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (guest_id) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_status (status),
            INDEX idx_host (host_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    // 已有表：检查并扩展 game_mode / status ENUM 和添加列（失败不阻断主流程）
    try {
        $col = $pdo->query("SHOW COLUMNS FROM casino_rooms LIKE 'game_mode'")->fetch();
        if ($col && strpos($col['Type'], 'highlow') === false) {
            $pdo->exec("ALTER TABLE casino_rooms MODIFY game_mode ENUM('dice','roulette','blackjack','liar','highlow') NOT NULL");
        }
    } catch (Throwable $e) {}
    try {
        $col = $pdo->query("SHOW COLUMNS FROM casino_rooms LIKE 'status'")->fetch();
        if ($col && strpos($col['Type'], 'playing') === false) {
            $pdo->exec("ALTER TABLE casino_rooms MODIFY status ENUM('waiting','playing','finished') DEFAULT 'waiting'");
        }
    } catch (Throwable $e) {}
    try {
        $col = $pdo->query("SHOW COLUMNS FROM casino_rooms LIKE 'game_state'")->fetch();
        if (!$col) $pdo->exec("ALTER TABLE casino_rooms ADD COLUMN game_state JSON DEFAULT NULL");
    } catch (Throwable $e) {}
    try {
        $col = $pdo->query("SHOW COLUMNS FROM casino_rooms LIKE 'players'")->fetch();
        if (!$col) $pdo->exec("ALTER TABLE casino_rooms ADD COLUMN players JSON DEFAULT NULL");
    } catch (Throwable $e) {}
}

const CURRENCIES = ['points', 'gomoku', 'casino'];
const STARTING_POINTS = 1000;
const SIGNIN_BASE = 100;
const SIGNIN_STREAK_BONUS = 20;
const SIGNIN_STREAK_CAP = 7;
// 积分 <-> 游戏币 汇率（1 积分换 N 游戏币）
const EXCHANGE_RATE = ['gomoku' => 2, 'casino' => 10];

function input() {
    // GET 请求参数必须可用：liar_mp_state 等 GET 端点依赖 room_id 等 query 参数
    $body = json_decode(file_get_contents('php://input'), true) ?: [];
    if (!is_array($body)) $body = [];
    return array_merge($_GET, is_array($_POST) ? $_POST : [], $body);
}

// 确保钱包存在，首次访问送起始积分
function ensure_wallet($pdo, $uid, $currency) {
    $stmt = $pdo->prepare("SELECT balance, last_signin, signin_streak FROM user_wallets WHERE user_id = ? AND currency = ?");
    $stmt->execute([$uid, $currency]);
    $row = $stmt->fetch();
    if ($row) return $row;
    $init = ($currency === 'points') ? STARTING_POINTS : 0;
    $stmt = $pdo->prepare("INSERT IGNORE INTO user_wallets (user_id, currency, balance) VALUES (?, ?, ?)");
    $stmt->execute([$uid, $currency, $init]);
    return ['balance' => (string)$init, 'last_signin' => null, 'signin_streak' => 0];
}

function log_tx($pdo, $from, $to, $currency, $amount, $type, $memo = null, $detail = null) {
    $stmt = $pdo->prepare("INSERT INTO point_transactions (from_user_id, to_user_id, currency, amount, type, memo, detail) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$from, $to, $currency, $amount, $type, $memo, $detail ? json_encode($detail, JSON_UNESCAPED_UNICODE) : null]);
}

function all_balances($pdo, $uid) {
    $out = ['points' => 0, 'gomoku' => 0, 'casino' => 0];
    foreach (CURRENCIES as $c) {
        $row = ensure_wallet($pdo, $uid, $c);
        $out[$c] = (int)$row['balance'];
    }
    return $out;
}

// ============ 钱包查询 ============
if ($method === 'GET' && $action === 'wallet') {
    $row = ensure_wallet($pdo, $uid, 'points');
    $today = date('Y-m-d');
    json_response([
        'balances' => all_balances($pdo, $uid),
        'last_signin' => $row['last_signin'],
        'can_signin' => ($row['last_signin'] !== $today),
        'streak' => (int)$row['signin_streak'],
        'rates' => EXCHANGE_RATE,
    ]);
}

// ============ 每日签到 ============
if ($method === 'POST' && $action === 'signin') {
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT balance, last_signin, signin_streak FROM user_wallets WHERE user_id = ? AND currency = 'points' FOR UPDATE");
        $stmt->execute([$uid]);
        $row = $stmt->fetch();
        if (!$row) {
            $row = ensure_wallet($pdo, $uid, 'points');
            $stmt->execute([$uid]);
            $row = $stmt->fetch();
        }
        $today = date('Y-m-d');
        if ($row['last_signin'] === $today) {
            $pdo->commit();
            json_response(['error' => '今天已签到，明天再来'], 400);
        }
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $streak = ($row['last_signin'] === $yesterday) ? min((int)$row['signin_streak'] + 1, SIGNIN_STREAK_CAP) : 1;
        $reward = SIGNIN_BASE + min($streak - 1, SIGNIN_STREAK_CAP - 1) * SIGNIN_STREAK_BONUS;
        $newBalance = (int)$row['balance'] + $reward;
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = ?, last_signin = ?, signin_streak = ? WHERE user_id = ? AND currency = 'points'");
        $stmt->execute([$newBalance, $today, $streak, $uid]);
        log_tx($pdo, null, $uid, 'points', $reward, 'signin', "每日签到 第{$streak}天", ['streak' => $streak]);
        $pdo->commit();
        json_response(['reward' => $reward, 'streak' => $streak, 'balance' => $newBalance]);
    } catch (Exception $e) {
        $pdo->rollBack();
        json_response(['error' => '签到失败: ' . $e->getMessage()], 500);
    }
}

// ============ 货币兑换 ============
if ($method === 'POST' && $action === 'exchange') {
    $in = input();
    $from = $in['from'] ?? '';
    $to = $in['to'] ?? '';
    $amount = (int)($in['amount'] ?? 0);
    if (!in_array($from, CURRENCIES, true) || !in_array($to, CURRENCIES, true)) {
        json_response(['error' => '无效货币'], 400);
    }
    if ($from === $to) json_response(['error' => '不能兑换同种货币'], 400);
    if ($amount <= 0) json_response(['error' => '兑换数量必须大于 0'], 400);
    // points <-> game：points 是全局积分，游戏币用汇率
    // points->game 增加游戏币；game->points 消耗游戏币按汇率折算
    $pdo->beginTransaction();
    try {
        ensure_wallet($pdo, $uid, $from);
        ensure_wallet($pdo, $uid, $to);
        // 积分→游戏币用目标汇率（1积分=N游戏币），游戏币→积分用源汇率（N游戏币=1积分）
        $rate = ($from === 'points') ? (EXCHANGE_RATE[$to] ?? 1) : (EXCHANGE_RATE[$from] ?? 1);
        // 兑换方向：积分换游戏币（1积分=rate游戏币），游戏币换积分（rate游戏币=1积分）
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = ? FOR UPDATE");
        $stmt->execute([$uid, $from]);
        $row = $stmt->fetch();
        if (!$row) { $pdo->rollBack(); json_response(['error' => '钱包不存在'], 400); }
        if ($from === 'points') {
            // 积分 -> 游戏币：消耗 amount 积分，得到 amount*rate 游戏币
            if ((int)$row['balance'] < $amount) { $pdo->rollBack(); json_response(['error' => '积分不足'], 400); }
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'points'");
            $stmt->execute([$amount, $uid]);
            $stmt = $pdo->prepare("INSERT INTO user_wallets (user_id, currency, balance) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE balance = balance + VALUES(balance)");
            $stmt->execute([$uid, $to, $amount * $rate]);
            log_tx($pdo, $uid, $uid, $from, $amount, 'exchange', "兑换 {$amount} {$from} -> " . ($amount * $rate) . " {$to}");
            log_tx($pdo, $uid, $uid, $to, $amount * $rate, 'exchange', "兑换入账");
        } else if ($to === 'points') {
            // 游戏币 -> 积分：消耗 amount 游戏币，得到 floor(amount/rate) 积分
            if ((int)$row['balance'] < $amount) { $pdo->rollBack(); json_response(['error' => '游戏币不足'], 400); }
            $gain = intdiv($amount, $rate);
            if ($gain <= 0) { $pdo->rollBack(); json_response(['error' => "至少需要 {$rate} 游戏币才能兑换"], 400); }
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = ?");
            $stmt->execute([$amount, $uid, $from]);
            $stmt = $pdo->prepare("INSERT INTO user_wallets (user_id, currency, balance) VALUES (?, 'points', ?) ON DUPLICATE KEY UPDATE balance = balance + VALUES(balance)");
            $stmt->execute([$uid, $gain]);
            log_tx($pdo, $uid, $uid, $from, $amount, 'exchange', "兑换 {$amount} {$from} -> {$gain} points");
            log_tx($pdo, $uid, $uid, 'points', $gain, 'exchange', "兑换入账");
        } else {
            // 游戏币 -> 游戏币：经积分中转
            $gain = intdiv($amount, $rate);
            if ($gain <= 0) { $pdo->rollBack(); json_response(['error' => "至少需要 {$rate} {$from} 才能兑换"], 400); }
            if ((int)$row['balance'] < $amount) { $pdo->rollBack(); json_response(['error' => "{$from} 不足"], 400); }
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = ?");
            $stmt->execute([$amount, $uid, $from]);
            $rate2 = EXCHANGE_RATE[$to] ?? 1;
            $stmt = $pdo->prepare("INSERT INTO user_wallets (user_id, currency, balance) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE balance = balance + VALUES(balance)");
            $stmt->execute([$uid, $to, $gain * $rate2]);
            log_tx($pdo, $uid, $uid, $from, $amount, 'exchange', "兑换 {$amount} {$from} -> " . ($gain * $rate2) . " {$to}");
        }
        $pdo->commit();
        json_response(['balances' => all_balances($pdo, $uid)]);
    } catch (Exception $e) {
        $pdo->rollBack();
        json_response(['error' => '兑换失败: ' . $e->getMessage()], 500);
    }
}

// ============ 玩家交易/赠送 ============
if ($method === 'POST' && $action === 'transfer') {
    $in = input();
    $to_username = trim($in['to_username'] ?? '');
    $amount = (int)($in['amount'] ?? 0);
    $currency = $in['currency'] ?? 'points';
    $memo = trim($in['memo'] ?? '');
    if (!in_array($currency, CURRENCIES, true)) json_response(['error' => '无效货币'], 400);
    if ($amount <= 0) json_response(['error' => '数量必须大于 0'], 400);
    if ($to_username === '') json_response(['error' => '请输入对方用户名'], 400);
    if ($to_username === $user['username']) json_response(['error' => '不能给自己转账'], 400);

    $stmt = $pdo->prepare("SELECT id, username, nickname FROM users WHERE username = ?");
    $stmt->execute([$to_username]);
    $target = $stmt->fetch();
    if (!$target) json_response(['error' => '用户不存在'], 404);

    $pdo->beginTransaction();
    try {
        ensure_wallet($pdo, $uid, $currency);
        ensure_wallet($pdo, (int)$target['id'], $currency);
        // 按固定顺序加锁防死锁：先锁较小 user_id
        $ids = [$uid, (int)$target['id']];
        sort($ids);
        foreach ($ids as $lock_id) {
            $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = ? FOR UPDATE");
            $stmt->execute([$lock_id, $currency]);
        }
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = ?");
        $stmt->execute([$uid, $currency]);
        $me = $stmt->fetch();
        if ((int)$me['balance'] < $amount) { $pdo->rollBack(); json_response(['error' => '余额不足'], 400); }
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = ?");
        $stmt->execute([$amount, $uid, $currency]);
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = ?");
        $stmt->execute([$amount, (int)$target['id'], $currency]);
        log_tx($pdo, $uid, (int)$target['id'], $currency, $amount, 'transfer', $memo ?: "转账给 {$target['nickname']}");
        $pdo->commit();
        json_response(['balances' => all_balances($pdo, $uid), 'to' => $target['nickname']]);
    } catch (Exception $e) {
        $pdo->rollBack();
        json_response(['error' => '转账失败: ' . $e->getMessage()], 500);
    }
}

// ============ 投骰子比大小 ============
if ($method === 'POST' && $action === 'dice') {
    $in = input();
    $bet = $in['bet'] ?? '';          // big / small
    $amount = (int)($in['amount'] ?? 0);
    if (!in_array($bet, ['big', 'small'], true)) json_response(['error' => '请选择比大或比小'], 400);
    if ($amount <= 0) json_response(['error' => '下注金额必须大于 0'], 400);

    $pdo->beginTransaction();
    try {
        ensure_wallet($pdo, $uid, 'casino');
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();
        if ((int)$me['balance'] < $amount) { $pdo->rollBack(); json_response(['error' => '赌场筹码不足'], 400); }
        // 扣除赌注
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
        $stmt->execute([$amount, $uid]);
        // 掷 3 颗骰子
        $d1 = random_int(1, 6);
        $d2 = random_int(1, 6);
        $d3 = random_int(1, 6);
        $sum = $d1 + $d2 + $d3;
        // 豹子（三颗相同）通杀：3(1-1-1)和18(6-6-6)既不算大也不算小
        $is_triple = ($d1 === $d2 && $d2 === $d3);
        // Sic Bo 规则：4-10 小，11-17 大，但豹子(2-2-2=6, 3-3-3=9, 4-4-4=12, 5-5-5=15)也通杀
        $is_big = ($sum >= 11 && $sum <= 17 && !$is_triple);
        $is_small = ($sum >= 4 && $sum <= 10 && !$is_triple);
        $win = ($bet === 'big' && $is_big) || ($bet === 'small' && $is_small);
        $payout = 0;
        if ($win) {
            $payout = $amount * 2;
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$payout, $uid]);
        }
        log_tx($pdo, null, $uid, 'casino', $amount, 'lose', "投骰子 压{$bet} 点数{$sum}", ['dice' => [$d1, $d2, $d3], 'bet' => $bet, 'sum' => $sum]);
        if ($win) {
            log_tx($pdo, null, $uid, 'casino', $payout, 'win', "投骰子中奖 点数{$sum}", ['dice' => [$d1, $d2, $d3], 'bet' => $bet, 'sum' => $sum]);
        }
        $pdo->commit();
        json_response([
            'dice' => [$d1, $d2, $d3], 'sum' => $sum, 'bet' => $bet,
            'win' => $win, 'payout' => $payout,
            'balance' => (int)$me['balance'] - $amount + $payout,
        ]);
    } catch (Exception $e) {
        $pdo->rollBack();
        json_response(['error' => '下注失败: ' . $e->getMessage()], 500);
    }
}

// ============ 俄罗斯轮盘赌 ============
if ($method === 'POST' && $action === 'roulette') {
    $in = input();
    $bullets = (int)($in['bullets'] ?? 0);
    $amount = (int)($in['amount'] ?? 0);
    if ($bullets < 1 || $bullets > 3) json_response(['error' => '子弹数量 1-3 发'], 400);
    if ($amount <= 0) json_response(['error' => '下注金额必须大于 0'], 400);
    // 赔率 = 6.3 / (6-bullets)，玩家优势约 5%
    $multiplier = 6.3 / (6 - $bullets);

    $pdo->beginTransaction();
    try {
        ensure_wallet($pdo, $uid, 'casino');
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();
        if ((int)$me['balance'] < $amount) { $pdo->rollBack(); json_response(['error' => '赌场筹码不足'], 400); }
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
        $stmt->execute([$amount, $uid]);
        // 随机弹巢位置（0-5），子弹装在前 bullets 个槽
        $chamber = random_int(0, 5);
        $fired = ($chamber < $bullets);
        $payout = 0;
        if (!$fired) {
            $payout = (int)round($amount * $multiplier);
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$payout, $uid]);
        }
        log_tx($pdo, null, $uid, 'casino', $amount, 'lose', "轮盘赌 {$bullets}发", ['bullets' => $bullets, 'chamber' => $chamber, 'fired' => $fired]);
        if (!$fired) {
            log_tx($pdo, null, $uid, 'casino', $payout, 'win', "轮盘赌中奖 {$bullets}发", ['bullets' => $bullets, 'chamber' => $chamber]);
        }
        $pdo->commit();
        json_response([
            'bullets' => $bullets, 'chamber' => $chamber, 'fired' => $fired,
            'win' => !$fired, 'payout' => $payout,
            'balance' => (int)$me['balance'] - $amount + $payout,
        ]);
    } catch (Exception $e) {
        $pdo->rollBack();
        json_response(['error' => '下注失败: ' . $e->getMessage()], 500);
    }
}

// ============ 交易记录 ============
if ($method === 'GET' && $action === 'history') {
    $stmt = $pdo->prepare("SELECT t.*, fu.nickname AS from_name, tu.nickname AS to_name
                          FROM point_transactions t
                          LEFT JOIN users fu ON fu.id = t.from_user_id
                          LEFT JOIN users tu ON tu.id = t.to_user_id
                          WHERE t.from_user_id = ? OR t.to_user_id = ?
                          ORDER BY t.created_at DESC LIMIT 50");
    $stmt->execute([$uid, $uid]);
    $rows = array_map(function ($r) {
        return [
            'id' => (int)$r['id'],
            'from' => $r['from_name'],
            'to' => $r['to_name'],
            'currency' => $r['currency'],
            'amount' => (int)$r['amount'],
            'type' => $r['type'],
            'memo' => $r['memo'],
            'detail' => $r['detail'] ? json_decode($r['detail'], true) : null,
            'time' => format_time($r['created_at']),
        ];
    }, $stmt->fetchAll());
    json_response(['history' => $rows]);
}

// ============ 后台：积分管理 ============
if ($method === 'GET' && $action === 'admin_points') {
    require_admin_permission($user, 'manage_users');
    $stmt = $pdo->query("SELECT u.id, u.username, u.nickname,
                                COALESCE(wp.balance, 0) AS points,
                                COALESCE(wg.balance, 0) AS gomoku,
                                COALESCE(wc.balance, 0) AS casino
                         FROM users u
                         LEFT JOIN user_wallets wp ON wp.user_id = u.id AND wp.currency = 'points'
                         LEFT JOIN user_wallets wg ON wg.user_id = u.id AND wg.currency = 'gomoku'
                         LEFT JOIN user_wallets wc ON wc.user_id = u.id AND wc.currency = 'casino'
                         ORDER BY u.id ASC");
    $users = [];
    $totals = ['points' => 0, 'gomoku' => 0, 'casino' => 0];
    while ($row = $stmt->fetch()) {
        foreach (['points', 'gomoku', 'casino'] as $c) {
            $row[$c] = (int)$row[$c];
            $totals[$c] += $row[$c];
        }
        $users[] = $row;
    }
    json_response(['users' => $users, 'totals' => $totals]);
}

if ($method === 'POST' && $action === 'admin_adjust_points') {
    require_admin_permission($user, 'manage_users');
    $in = input();
    $target_id = (int)($in['user_id'] ?? 0);
    $currency = $in['currency'] ?? '';
    $amount = (int)($in['amount'] ?? 0);
    $mode = ($in['mode'] ?? '') === 'add' ? 'add' : 'deduct';
    if (!in_array($currency, CURRENCIES, true)) json_response(['error' => '无效货币'], 400);
    if ($amount <= 0) json_response(['error' => '数量必须大于 0'], 400);
    if ($target_id <= 0) json_response(['error' => '无效用户'], 400);

    $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
    $stmt->execute([$target_id]);
    if (!$stmt->fetch()) json_response(['error' => '用户不存在'], 404);

    $pdo->beginTransaction();
    try {
        ensure_wallet($pdo, $target_id, $currency);
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = ? FOR UPDATE");
        $stmt->execute([$target_id, $currency]);
        $row = $stmt->fetch();
        $cur = (int)$row['balance'];
        if ($mode === 'add') {
            $new = $cur + $amount;
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = ?");
            $stmt->execute([$amount, $target_id, $currency]);
            log_tx($pdo, $uid, $target_id, $currency, $amount, 'transfer', "后台充值 {$amount} {$currency}");
        } else {
            if ($cur < $amount) { $pdo->rollBack(); json_response(['error' => '用户余额不足，当前 ' . $cur], 400); }
            $new = $cur - $amount;
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = ?");
            $stmt->execute([$amount, $target_id, $currency]);
            log_tx($pdo, $target_id, $uid, $currency, $amount, 'transfer', "后台扣除 {$amount} {$currency}");
        }
        $pdo->commit();
        json_response(['success' => true, 'balance' => $new]);
    } catch (Exception $e) {
        $pdo->rollBack();
        json_response(['error' => '操作失败: ' . $e->getMessage()], 500);
    }
}

// ============ 联机赌局：房主开局 ============
if ($method === 'POST' && $action === 'bet_create') {
    $in = input();
    $game_mode = $in['game_mode'] ?? '';
    $bet_amount = (int)($in['bet_amount'] ?? 0);
    $choice = $in['choice'] ?? [];
    if (!in_array($game_mode, ['dice', 'roulette', 'blackjack', 'liar', 'highlow'], true)) {
        json_response(['error' => '无效游戏模式'], 400);
    }
    if ($bet_amount <= 0) json_response(['error' => '赌注必须大于 0'], 400);

    $host_choice = [];
    if ($game_mode === 'dice') {
        $side = $choice['side'] ?? '';
        if (!in_array($side, ['big', 'small'], true)) json_response(['error' => '请选择比大或比小'], 400);
        $host_choice['side'] = $side;
    } elseif ($game_mode === 'roulette') {
        $bullets = (int)($choice['bullets'] ?? 0);
        if ($bullets < 1 || $bullets > 5) json_response(['error' => '子弹数量 1-5 发'], 400);
        $host_choice['bullets'] = $bullets;
    } elseif ($game_mode === 'liar') {
        // Liar's Deck: 开局无需选择，系统发牌
        $host_choice = [];
    } elseif ($game_mode === 'highlow') {
        $dir = $choice['direction'] ?? '';
        if (!in_array($dir, ['higher', 'lower'], true)) json_response(['error' => '请选择大或小'], 400);
        $host_choice['direction'] = $dir;
    }
    // blackjack: 无需房主选择

    $pdo->beginTransaction();
    try {
        // 先锁钱包行，串行化同用户并发开局（防双击双开）
        ensure_wallet($pdo, $uid, 'casino');
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        // 房主尚未结束的赌局
        $stmt = $pdo->prepare("SELECT id FROM casino_rooms WHERE host_id = ? AND status = 'waiting' FOR UPDATE");
        $stmt->execute([$uid]);
        if ($stmt->fetch()) { $pdo->rollBack(); json_response(['error' => '你已有一个等待中的赌局'], 400); }

        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino'");
        $stmt->execute([$uid]);
        $row = $stmt->fetch();
        if (!$row) {
            // 兜底：ensure_wallet 的 INSERT 未生效，直接插入
            $pdo->prepare("INSERT IGNORE INTO user_wallets (user_id, currency, balance) VALUES (?, 'casino', 0)")->execute([$uid]);
            $stmt->execute([$uid]);
            $row = $stmt->fetch();
        }
        if (!$row) { $pdo->rollBack(); json_response(['error' => '钱包初始化失败，请稍后重试'], 500); }
        if ((int)$row['balance'] < $bet_amount) { $pdo->rollBack(); json_response(['error' => '筹码不足，当前 ' . (int)$row['balance'] . '，下注 ' . $bet_amount], 400); }
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
        $stmt->execute([$bet_amount, $uid]);
        
        $gameState = null;
        $myCards = null;
        $tableType = null;
        
        if ($game_mode === 'liar') {
            // Liar's Deck: 构建20张牌发牌
            $deck = [];
            for ($i = 0; $i < 6; $i++) $deck[] = 'K';
            for ($i = 0; $i < 6; $i++) $deck[] = 'Q';
            for ($i = 0; $i < 6; $i++) $deck[] = 'A';
            $deck[] = '🃏'; $deck[] = '🃏';
            shuffle($deck);
            $tableTypes = ['K', 'Q', 'A'];
            $tableType = $tableTypes[random_int(0, 2)];
            $hostCards = array_slice($deck, 0, 5);
            $remainingDeck = array_slice($deck, 5);
            $myCards = $hostCards;
            $gameState = [
                'table_type' => $tableType,
                'players' => [strval($uid) => ['cards' => $hostCards, 'eliminated' => false]],
                'remaining_deck' => $remainingDeck,
                'pile' => [],
                'last_cards' => [],
                'current_player' => null,
                'turn' => 1,
                'revolver' => [strval($uid) => [1,1,1,1,1,0]],
            ];
        }
        
        $stmt = $pdo->prepare("INSERT INTO casino_rooms (game_mode, host_id, bet_amount, host_choice, game_state, players) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$game_mode, $uid, $bet_amount, json_encode($host_choice, JSON_UNESCAPED_UNICODE), 
            $gameState ? json_encode($gameState, JSON_UNESCAPED_UNICODE) : null,
            json_encode([$uid], JSON_UNESCAPED_UNICODE)]);
        $room_id = (int)$pdo->lastInsertId();
        log_tx($pdo, $uid, null, 'casino', $bet_amount, 'bet', "开赌局 #{$room_id}");
        $pdo->commit();
        
        if ($game_mode === 'liar') {
            json_response(['room_id' => $room_id, 'my_cards' => $myCards, 'table_type' => $tableType, 'status' => 'waiting']);
        }
        json_response(['room_id' => $room_id]);
    } catch (Exception $e) {
        $pdo->rollBack();
        json_response(['error' => '开局失败: ' . $e->getMessage()], 500);
    }
}

// 开放赌局列表
if ($method === 'GET' && $action === 'bet_list') {
    $stmt = $pdo->prepare("SELECT c.id, c.game_mode, c.bet_amount, c.host_choice, c.host_id, c.status, c.created_at,
                                  u.nickname AS host_name
                           FROM casino_rooms c JOIN users u ON u.id = c.host_id
                           WHERE c.status IN ('waiting','playing') ORDER BY c.created_at DESC LIMIT 50");
    $stmt->execute();
    $rooms = array_map(function ($r) {
        $r['host_choice'] = $r['host_choice'] ? json_decode($r['host_choice'], true) : null;
        return $r;
    }, $stmt->fetchAll());
    json_response(['rooms' => $rooms]);
}

// 加入赌局：自动结算
if ($method === 'POST' && $action === 'bet_join') {
    $in = input();
    $room_id = (int)($in['room_id'] ?? 0);
    $guest_choice = $in['choice'] ?? null;

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT * FROM casino_rooms WHERE id = ? FOR UPDATE");
        $stmt->execute([$room_id]);
        $room = $stmt->fetch();
        if (!$room || $room['status'] !== 'waiting') { $pdo->rollBack(); json_response(['error' => '赌局不存在或已开始'], 400); }
        if ((int)$room['host_id'] === $uid) { $pdo->rollBack(); json_response(['error' => '不能加入自己的赌局'], 400); }

        $bet = (int)$room['bet_amount'];
        $mode = $room['game_mode'];
        $host_choice = json_decode($room['host_choice'], true) ?: [];

        // 验证客方选择
        if ($mode === 'liar') {
            // Liar's Deck: 无需选择，系统发牌
        }
        if ($mode === 'highlow' && $guest_choice) {
            $gd = $guest_choice['direction'] ?? '';
            if (!in_array($gd, ['higher', 'lower'], true)) { $pdo->rollBack(); json_response(['error' => '请选择大或小'], 400); }
        }

        ensure_wallet($pdo, $uid, 'casino');
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();
        if ((int)$me['balance'] < $bet) { $pdo->rollBack(); json_response(['error' => '筹码不足'], 400); }
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
        $stmt->execute([$bet, $uid]);

        // Liar's Deck: 发牌给客方，开始回合制游戏
        if ($mode === 'liar') {
            $gs = json_decode($room['game_state'], true) ?: [];
            $remainingDeck = $gs['remaining_deck'] ?? [];
            $guestCards = array_slice($remainingDeck, 0, 5);
            $remainingDeck = array_slice($remainingDeck, 5);
            $gs['players'][strval($uid)] = ['cards' => $guestCards, 'eliminated' => false];
            $gs['remaining_deck'] = $remainingDeck;
            $gs['revolver'][strval($uid)] = [1,1,1,1,1,0];
            $gs['current_player'] = 'guest';
            $gs['turn'] = 1;
            $stmt = $pdo->prepare("UPDATE casino_rooms SET guest_id = ?, status = 'playing', game_state = ?, players = ? WHERE id = ?");
            $stmt->execute([$uid, json_encode($gs, JSON_UNESCAPED_UNICODE), 
                json_encode([$room['host_id'], $uid], JSON_UNESCAPED_UNICODE), $room_id]);
            log_tx($pdo, $uid, null, 'casino', $bet, 'bet', "加入赌局 #{$room_id}");
            $pdo->commit();
            json_response([
                'my_cards' => $guestCards,
                'table_type' => $gs['table_type'],
                'pile' => $gs['pile'],
                'my_turn' => true,
                'status' => 'playing',
                'room_id' => $room_id,
            ]);
        }

        // 服务端判定
        $result = [];
        $is_draw = 0;
        $winner_id = null;
        if ($mode === 'dice') {
            $d1 = random_int(1, 6); $d2 = random_int(1, 6); $d3 = random_int(1, 6);
            $sum = $d1 + $d2 + $d3;
            $host_side = $host_choice['side'] ?? 'big';
            $is_triple = ($d1 === $d2 && $d2 === $d3);
            $host_win = (!$is_triple && (($sum >= 4 && $sum <= 10 && $host_side === 'small')
                     || ($sum >= 11 && $sum <= 17 && $host_side === 'big')));
            $result = ['dice' => [$d1, $d2, $d3], 'sum' => $sum, 'host_side' => $host_side, 'is_triple' => $is_triple];
            if ($is_triple) {
                $is_draw = 1;
            } else {
                $winner_id = $host_win ? (int)$room['host_id'] : $uid;
            }
        } elseif ($mode === 'roulette') {
            $bullets = (int)($host_choice['bullets'] ?? 1);
            $chamber = random_int(0, 5);
            $host_fired = ($chamber < $bullets);
            $result = ['bullets' => $bullets, 'chamber' => $chamber, 'host_fired' => $host_fired];
            $winner_id = $host_fired ? $uid : (int)$room['host_id'];
        } elseif ($mode === 'blackjack') {
            $hCards = [random_int(1, 13), random_int(1, 13)];
            $gCards = [random_int(1, 13), random_int(1, 13)];
            $hTotal = bj_hand_val($hCards);
            $gTotal = bj_hand_val($gCards);
            $result = [
                'host_cards' => array_map(fn($r) => card_name($r), $hCards),
                'guest_cards' => array_map(fn($r) => card_name($r), $gCards),
                'host_total' => $hTotal, 'guest_total' => $gTotal,
            ];
            if ($hTotal === $gTotal) { $is_draw = 1; }
            else {
                $hBust = $hTotal > 21; $gBust = $gTotal > 21;
                if ($hBust && $gBust) $is_draw = 1;
                elseif ($hBust) $winner_id = $uid;
                elseif ($gBust) $winner_id = (int)$room['host_id'];
                else $winner_id = $gTotal > $hTotal ? $uid : (int)$room['host_id'];
            }
        } elseif ($mode === 'highlow') {
            $card1 = random_int(1, 13);
            $card2 = random_int(1, 13);
            $hDir = $host_choice['direction'] ?? 'higher';
            $gDir = $guest_choice['direction'] ?? 'higher';
            $hCorrect = ($hDir === 'higher' && $card2 > $card1) || ($hDir === 'lower' && $card2 < $card1);
            $gCorrect = ($gDir === 'higher' && $card2 > $card1) || ($gDir === 'lower' && $card2 < $card1);
            $result = [
                'card1' => card_name($card1), 'card2' => card_name($card2),
                'host_direction' => $hDir, 'guest_direction' => $gDir,
            ];
            if ($card1 === $card2) $is_draw = 1;
            elseif ($hCorrect === $gCorrect) $is_draw = 1;
            elseif ($gCorrect) $winner_id = $uid;
            else $winner_id = (int)$room['host_id'];
        }
        // 保存客方选择
        if ($guest_choice) {
            $stmt = $pdo->prepare("UPDATE casino_rooms SET guest_choice = ? WHERE id = ?");
            $stmt->execute([json_encode($guest_choice, JSON_UNESCAPED_UNICODE), $room_id]);
        }

        if ($is_draw) {
            $ids = [$uid, (int)$room['host_id']];
            sort($ids);
            foreach ($ids as $lock_id) {
                $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
                $stmt->execute([$lock_id]);
            }
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$bet, $uid]);
            $stmt->execute([$bet, (int)$room['host_id']]);
            $stmt = $pdo->prepare("UPDATE casino_rooms SET status = 'finished', guest_id = ?, result = ?, is_draw = 1, finished_at = NOW() WHERE id = ?");
            $stmt->execute([$uid, json_encode($result, JSON_UNESCAPED_UNICODE), $room_id]);
            log_tx($pdo, null, $uid, 'casino', $bet, 'win', "赌局 #{$room_id} 平局退回");
            log_tx($pdo, null, (int)$room['host_id'], 'casino', $bet, 'win', "赌局 #{$room_id} 平局退回");
            $pdo->commit();
            json_response(['draw' => true, 'result' => $result, 'bet' => $bet]);
        } else {
            $payout = $bet * 2;
            $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
            $stmt->execute([$winner_id]);
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$payout, $winner_id]);
            $stmt = $pdo->prepare("UPDATE casino_rooms SET status = 'finished', guest_id = ?, result = ?, winner_id = ?, finished_at = NOW() WHERE id = ?");
            $stmt->execute([$uid, json_encode($result, JSON_UNESCAPED_UNICODE), $winner_id, $room_id]);
            $loser_id = $winner_id === $uid ? (int)$room['host_id'] : $uid;
            log_tx($pdo, null, $winner_id, 'casino', $payout, 'win', "赌局 #{$room_id} 获胜");
            log_tx($pdo, $loser_id, null, 'casino', $bet, 'lose', "赌局 #{$room_id} 落败");
            $pdo->commit();
            json_response(['win' => $winner_id === $uid, 'result' => $result, 'payout' => $payout, 'bet' => $bet]);
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        json_response(['error' => '加入失败: ' . $e->getMessage()], 500);
    }
}

// 取消自己的等待中赌局（退回赌注）
if ($method === 'POST' && $action === 'bet_cancel') {
    $in = input();
    $room_id = (int)($in['room_id'] ?? 0);
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT * FROM casino_rooms WHERE id = ? FOR UPDATE");
        $stmt->execute([$room_id]);
        $room = $stmt->fetch();
        if (!$room || $room['status'] !== 'waiting') { $pdo->rollBack(); json_response(['error' => '赌局不存在或已开始'], 400); }
        if ((int)$room['host_id'] !== $uid) { $pdo->rollBack(); json_response(['error' => '只能取消自己的赌局'], 400); }
        $bet = (int)$room['bet_amount'];
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
        $stmt->execute([$bet, $uid]);
        $stmt = $pdo->prepare("DELETE FROM casino_rooms WHERE id = ?");
        $stmt->execute([$room_id]);
        log_tx($pdo, null, $uid, 'casino', $bet, 'win', "赌局 #{$room_id} 取消退回");
        $pdo->commit();
        json_response(['success' => true]);
    } catch (Exception $e) {
        $pdo->rollBack();
        json_response(['error' => '取消失败'], 500);
    }
}

// ============ Liar's Deck 联机回合制 ============
// 查询当前游戏状态
if ($method === 'GET' && $action === 'liar_mp_state') {
    $in = input();
    $room_id = (int)($in['room_id'] ?? 0);
    $stmt = $pdo->prepare("SELECT * FROM casino_rooms WHERE id = ?");
    $stmt->execute([$room_id]);
    $room = $stmt->fetch();
    // waiting 也允许查询：房主开局后停留在游戏页等待对手加入
    if (!$room || !in_array($room['status'], ['waiting', 'playing'], true)) json_response(['error' => '赌局不存在或已结束'], 400);
    $gs = json_decode($room['game_state'], true) ?: [];
    $players = json_decode($room['players'], true) ?: [];
    $isHost = ((int)$room['host_id'] === $uid);
    $myRole = $isHost ? 'host' : 'guest';
    $myCards = $gs['players'][strval($uid)]['cards'] ?? [];
    $myEliminated = $gs['players'][strval($uid)]['eliminated'] ?? false;
    $currentPlayer = $gs['current_player'] ?? null;
    $isPlaying = ($room['status'] === 'playing');
    $myTurn = ($isPlaying && $currentPlayer === $myRole && !$myEliminated);
    
    $otherId = $isHost ? (int)$room['guest_id'] : (int)$room['host_id'];
    $otherName = '';
    if ($otherId) {
        $stmt = $pdo->prepare("SELECT nickname FROM users WHERE id = ?");
        $stmt->execute([$otherId]);
        $r = $stmt->fetch();
        $otherName = $r['nickname'] ?? '对手';
    }
    
    json_response([
        'room_id' => $room_id,
        'table_type' => $gs['table_type'] ?? '',
        'pile' => $gs['pile'] ?? [],
        'last_cards' => $gs['last_cards'] ?? [],
        'my_cards' => $myCards,
        'my_turn' => $myTurn,
        'my_eliminated' => $myEliminated,
        'my_role' => $myRole,
        'opponent_name' => $otherName,
        'turn' => $gs['turn'] ?? 1,
        'bet_amount' => (int)$room['bet_amount'],
        'status' => $room['status'],
    ]);
}

// 玩家操作：出牌或喊"骗子"
if ($method === 'POST' && $action === 'liar_mp_action') {
    $in = input();
    $room_id = (int)($in['room_id'] ?? 0);
    $action_type = $in['action'] ?? '';
    $card_indices = $in['card_indices'] ?? null;
    
    if (!in_array($action_type, ['play', 'liar'], true)) json_response(['error' => '无效操作'], 400);
    
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT * FROM casino_rooms WHERE id = ? FOR UPDATE");
        $stmt->execute([$room_id]);
        $room = $stmt->fetch();
        if (!$room || $room['status'] !== 'playing') { $pdo->rollBack(); json_response(['error' => '赌局不存在或已结束'], 400); }
        
        $gs = json_decode($room['game_state'], true) ?: [];
        $players = json_decode($room['players'], true) ?: [];
        $bet = (int)$room['bet_amount'];
        
        $isHost = ((int)$room['host_id'] === $uid);
        $myRole = $isHost ? 'host' : 'guest';
        $myPlayerId = strval($uid);
        $myPlayer = $gs['players'][$myPlayerId] ?? null;
        if (!$myPlayer || $myPlayer['eliminated']) { $pdo->rollBack(); json_response(['error' => '你已被淘汰'], 400); }
        if ($gs['current_player'] !== $myRole) { $pdo->rollBack(); json_response(['error' => '还没轮到你了'], 400); }
        
        $tableType = $gs['table_type'] ?? '';
        $myCards = $myPlayer['cards'] ?? [];
        $result = [];
        $gameOver = false;
        $rrResult = null;
        $rrFired = null;
        $newPile = $gs['pile'] ?? [];
        $newLastCards = $gs['last_cards'] ?? [];
        $newCurrentPlayer = $myRole;
        $newTurn = $gs['turn'] ?? 1;
        
        if ($action_type === 'play') {
            // 出牌
            if (!is_array($card_indices) || count($card_indices) < 1 || count($card_indices) > 3) {
                $pdo->rollBack(); json_response(['error' => '请选择1-3张牌'], 400);
            }
            $playedCards = [];
            $remainingCards = [];
            foreach ($myCards as $idx => $card) {
                if (in_array($idx, $card_indices, true)) {
                    $playedCards[] = $card;
                } else {
                    $remainingCards[] = $card;
                }
            }
            if (count($playedCards) !== count($card_indices)) {
                $pdo->rollBack(); json_response(['error' => '无效的牌索引'], 400);
            }
            $gs['players'][$myPlayerId]['cards'] = $remainingCards;
            $newPile[] = $playedCards;
            $newLastCards = $playedCards;
            $newCurrentPlayer = $isHost ? 'guest' : 'host';
            $newTurn++;
            $result['played'] = $playedCards;
            $result['action'] = 'play';
        } else {
            // 喊"骗子" - 质疑上一个玩家
            $lastPlayerRole = $gs['current_player'] === 'host' ? 'guest' : 'host';
            // 检查是否有上一个玩家的牌可以质疑
            if (empty($gs['last_cards']) || empty($gs['pile'])) {
                $pdo->rollBack(); json_response(['error' => '还没有牌可以质疑'], 400);
            }
            $accusedCards = $gs['last_cards'];
            // 检查是否有谎言
            $hasLie = false;
            foreach ($accusedCards as $card) {
                if ($card !== $tableType && $card !== '🃏') { $hasLie = true; break; }
            }
            
            // 谁玩左轮？
            if ($hasLie) {
                // 上一个玩家撒谎了，上一个玩家玩左轮
                $rrPlayerRole = $lastPlayerRole;
                $result['called_correctly'] = true;
                $result['message'] = '质疑成功！' . ($lastPlayerRole === 'host' ? '房主' : '对手') . '撒谎了！';
            } else {
                // 喊错了，当前玩家玩左轮
                $rrPlayerRole = $myRole;
                $result['called_correctly'] = false;
                $result['message'] = '质疑失败！你的牌全是真话。';
            }
            
            $result['accused_cards'] = $accusedCards;
            $result['accused_role'] = $lastPlayerRole;
            $result['has_lie'] = $hasLie;
            
            // 左轮俄罗斯轮盘：1/6概率"死亡"（双倍损失）
            // 上场玩左轮的是被质疑方或质疑方，必须取对应玩家的左轮
            $rrPlayerId = ($rrPlayerRole === 'host') ? (int)$room['host_id'] : (int)$room['guest_id'];
            $rr = $gs['revolver'][strval($rrPlayerId)] ?? [1,1,1,1,1,0];
            $chamberIdx = random_int(0, 5);
            $fired = ($rr[$chamberIdx] === 0); // 0 = Death
            $rrResult = $fired ? 'dead' : 'blank';
            $rrFired = $fired;
            
            if ($fired) {
                // 死亡 = 双倍损失
                $loserRole = $rrPlayerRole;
                $loserIsHost = ($loserRole === 'host');
                $loserId = $loserIsHost ? (int)$room['host_id'] : (int)$room['guest_id'];
                $winnerId = $loserIsHost ? (int)$room['guest_id'] : (int)$room['host_id'];
                
                // 扣双倍
                $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
                $stmt->execute([$loserId]);
                $loserBal = $stmt->fetch();
                $loseAmount = $bet * 2;
                if ($loserBal && (int)$loserBal['balance'] >= $loseAmount) {
                    $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
                    $stmt->execute([$loseAmount, $loserId]);
                    log_tx($pdo, $loserId, null, 'casino', $loseAmount, 'lose', "赌局 #{$room_id} 左轮死亡 双倍损失");
                }
                // 赢家得双倍+双倍罚金=4倍
                $payout = $bet * 4;
                $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
                $stmt->execute([$payout, $winnerId]);
                log_tx($pdo, null, $winnerId, 'casino', $payout, 'win', "赌局 #{$room_id} 获胜 (左轮双倍)");
                
                // 标记淘汰
                $gs['players'][strval($loserId)]['eliminated'] = true;
                $gameOver = true;
                $result['revolver'] = 'dead';
                $result['eliminated'] = $loserRole;
                $result['winner'] = $myRole;
                $result['payout'] = $payout;
                
                $stmt = $pdo->prepare("UPDATE casino_rooms SET status = 'finished', winner_id = ?, result = ?, game_state = ?, finished_at = NOW() WHERE id = ?");
                $stmt->execute([$winnerId, json_encode($result, JSON_UNESCAPED_UNICODE), json_encode($gs, JSON_UNESCAPED_UNICODE), $room_id]);
            } else {
                // 存活，继续游戏
                $gs['revolver'][strval($rrPlayerId)] = $rr;
                // 清空牌堆，重新出牌
                $newPile = [];
                $newLastCards = [];
                $newTurn++;
                // 轮到上一个人出牌
                $newCurrentPlayer = $lastPlayerRole;
                $result['revolver'] = 'blank';
                $result['survived'] = true;
            }
        }

        // 出牌与喊骗子两条分支都必须落盘：牌堆/上一手/回合/当前行动方
        $gs['pile'] = $newPile;
        $gs['last_cards'] = $newLastCards;
        $gs['current_player'] = $newCurrentPlayer;
        $gs['turn'] = $newTurn;
        
        $stmt = $pdo->prepare("UPDATE casino_rooms SET game_state = ? WHERE id = ?");
        $stmt->execute([json_encode($gs, JSON_UNESCAPED_UNICODE), $room_id]);
        $pdo->commit();
        
        // 返回更新后的状态
        $response = [
            'action' => $action_type,
            'result' => $result,
            'game_over' => $gameOver,
            'my_cards' => $gs['players'][$myPlayerId]['cards'] ?? [],
            'pile' => $gs['pile'] ?? [],
            'last_cards' => $gs['last_cards'] ?? [],
            'my_turn' => ($gs['current_player'] === $myRole && !$gs['players'][$myPlayerId]['eliminated']),
            'turn' => $gs['turn'] ?? 1,
            'table_type' => $gs['table_type'] ?? '',
        ];
        if ($rrResult) $response['rr_result'] = $rrResult;
        json_response($response);
    } catch (Exception $e) { $pdo->rollBack(); json_response(['error' => '操作失败: ' . $e->getMessage()], 500); }
}

// ============ 扑克牌工具 ============
function card_val($r) { return $r > 10 ? 10 : $r; }
function card_name($r) {
    $names = ['', 'A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    return $names[$r];
}
function bj_hand_val($cards) {
    $total = 0; $aces = 0;
    foreach ($cards as $c) { $total += card_val($c); if ($c === 1) $aces++; }
    while ($aces > 0 && $total + 10 <= 21) { $total += 10; $aces--; }
    return $total;
}
function bj_is_blackjack($cards) { return count($cards) === 2 && bj_hand_val($cards) === 21; }

// 21点进行中的牌局：DB 托管，token 客户端（无浏览器会话）同样可续局
// 注意：必须在任何事务之外建表，DDL 会隐式提交事务
function bj_ensure_table($pdo) {
    static $done = false;
    if ($done) return;
    $pdo->exec("CREATE TABLE IF NOT EXISTS bj_rounds (
        user_id INT NOT NULL PRIMARY KEY,
        state JSON DEFAULT NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $done = true;
}
function bj_load($pdo, $uid) {
    bj_ensure_table($pdo);
    $stmt = $pdo->prepare("SELECT state FROM bj_rounds WHERE user_id = ?");
    $stmt->execute([$uid]);
    $raw = $stmt->fetchColumn();
    if (!$raw) return null;
    $s = json_decode($raw, true);
    return is_array($s) ? $s : null;
}
function bj_save($pdo, $uid, $state) {
    bj_ensure_table($pdo);
    $stmt = $pdo->prepare("INSERT INTO bj_rounds (user_id, state) VALUES (?, ?) ON DUPLICATE KEY UPDATE state = VALUES(state)");
    $stmt->execute([$uid, json_encode($state, JSON_UNESCAPED_UNICODE)]);
}
function bj_clear($pdo, $uid) {
    bj_ensure_table($pdo);
    $pdo->prepare("DELETE FROM bj_rounds WHERE user_id = ?")->execute([$uid]);
}

// ============ 21点 Blackjack ============
if ($method === 'POST' && $action === 'blackjack') {
    $in = input();
    $bet = (int)($in['bet'] ?? 0);
    $op = $in['action'] ?? 'start';
    if (!in_array($op, ['start', 'hit', 'stand', 'double'], true)) {
        json_response(['error' => '无效操作'], 400);
    }
    if ($op === 'start' && $bet <= 0) json_response(['error' => '下注必须大于 0'], 400);

    // 开始新一局
    if ($op === 'start') {
        $oldState = bj_load($pdo, $uid);
        if ($oldState && $oldState['phase'] === 'player') {
            json_response(['error' => '已有一局正在进行中'], 400);
        }
        $pdo->beginTransaction();
        try {
            ensure_wallet($pdo, $uid, 'casino');
            $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
            $stmt->execute([$uid]);
            $me = $stmt->fetch();
            if ((int)$me['balance'] < $bet) { $pdo->rollBack(); json_response(['error' => '筹码不足'], 400); }
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$bet, $uid]);
            // 发牌
            $pcards = [random_int(1, 13), random_int(1, 13)];
            $dcard = random_int(1, 13);
            bj_save($pdo, $uid, ['player' => $pcards, 'dealer' => [$dcard], 'bet' => $bet, 'doubled' => false, 'phase' => 'player', 'uid' => $uid]);
            log_tx($pdo, null, $uid, 'casino', $bet, 'bet', "21点开局 下注{$bet}");
            $pdo->commit();
            json_response(['phase' => 'player', 'player_cards' => $pcards, 'dealer_cards' => [$dcard], 'dealer_hole' => true, 'bet' => $bet, 'balance' => (int)$me['balance'] - $bet]);
        } catch (Exception $e) { $pdo->rollBack(); json_response(['error' => '开局失败: ' . $e->getMessage()], 500); }
    }

    // 读取当前局状态
    $state = bj_load($pdo, $uid);
    if (!$state || $state['phase'] === 'done') {
        json_response(['error' => '没有进行中的21点游戏'], 400);
    }
    if ((int)$state['uid'] !== $uid) {
        json_response(['error' => '不是你的游戏'], 403);
    }

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();

        if ($op === 'hit') {
            $state['player'][] = random_int(1, 13);
            $pval = bj_hand_val($state['player']);
            if ($pval > 21) {
                // 玩家爆牌
                $state['phase'] = 'done';
                bj_save($pdo, $uid, $state);
                log_tx($pdo, null, $uid, 'casino', $state['bet'], 'lose', "21点爆牌 ({$pval})");
                $pdo->commit();
                json_response(['phase' => 'done', 'result' => 'bust', 'payout' => 0, 'balance' => (int)$me['balance'], 'player_cards' => $state['player'], 'dealer_cards' => $state['dealer'], 'player_val' => $pval, 'bet' => $state['bet']]);
            }
            bj_save($pdo, $uid, $state);
            $pdo->commit();
            json_response(['phase' => 'player', 'player_cards' => $state['player'], 'dealer_cards' => $state['dealer'], 'dealer_hole' => true, 'player_val' => $pval, 'bet' => $state['bet'], 'balance' => (int)$me['balance']]);
        }

        if ($op === 'double') {
            if ($state['doubled'] || count($state['player']) !== 2) {
                $pdo->rollBack(); json_response(['error' => '只能在初始两牌后加倍'], 400);
            }
            $origBet = $state['bet'];
            $newBet = $origBet * 2;
            if ((int)$me['balance'] < $origBet) { $pdo->rollBack(); json_response(['error' => '筹码不足，无法加倍'], 400); }
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$origBet, $uid]);
            $state['doubled'] = true;
            $state['bet'] = $newBet;
            $state['player'][] = random_int(1, 13);
            $pval = bj_hand_val($state['player']);
            $state['phase'] = 'done';
            while (bj_hand_val($state['dealer']) < 17) $state['dealer'][] = random_int(1, 13);
            $dval = bj_hand_val($state['dealer']);
            $payout = 0; $result = '';
            $pBJ = bj_is_blackjack($state['player']);
            $dBJ = bj_is_blackjack($state['dealer']);
            if ($pval > 21) { $result = 'bust'; }
            elseif ($pBJ && $dBJ) { $payout = $newBet; $result = 'push'; }
            elseif ($dBJ) { $result = 'dealer_blackjack'; }
            elseif ($pBJ) { $payout = (int)round($newBet * 2.5); $result = 'blackjack'; }
            elseif ($pval > $dval) { $payout = $newBet * 2; $result = 'win'; }
            elseif ($pval === $dval) { $payout = $newBet; $result = 'push'; }
            else { $result = 'lose'; }
            if ($payout > 0) {
                $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
                $stmt->execute([$payout, $uid]);
            }
            log_tx($pdo, null, $uid, 'casino', $newBet, 'lose', "21点加倍 {$result} 玩家{$pval} 庄家{$dval}");
            if ($payout > 0) {
                log_tx($pdo, null, $uid, 'casino', $payout, 'win', "21点加倍中奖 {$result}");
            }
            bj_save($pdo, $uid, $state);
            $pdo->commit();
            $finalBalance = (int)$me['balance'] - $origBet + $payout;
            json_response(['phase' => 'done', 'result' => $result, 'payout' => $payout, 'balance' => $finalBalance, 'player_cards' => $state['player'], 'dealer_cards' => $state['dealer'], 'player_val' => $pval, 'dealer_val' => $dval, 'bet' => $newBet]);
        }

        if ($op === 'stand') {
            $state['phase'] = 'done';
            while (bj_hand_val($state['dealer']) < 17) $state['dealer'][] = random_int(1, 13);
            $pval = bj_hand_val($state['player']);
            $dval = bj_hand_val($state['dealer']);
            $payout = 0; $result = '';
            $pBJ = bj_is_blackjack($state['player']);
            $dBJ = bj_is_blackjack($state['dealer']);
            if ($pval > 21) { $result = 'bust'; }
            elseif ($pBJ && $dBJ) { $payout = $state['bet']; $result = 'push'; }
            elseif ($dBJ) { $result = 'dealer_blackjack'; }
            elseif ($pBJ) { $payout = (int)round($state['bet'] * 2.5); $result = 'blackjack'; }
            elseif ($pval > $dval) { $payout = $state['bet'] * 2; $result = 'win'; }
            elseif ($pval === $dval) { $payout = $state['bet']; $result = 'push'; }
            else { $result = 'lose'; }
            if ($payout > 0) {
                $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
                $stmt->execute([$payout, $uid]);
            }
            log_tx($pdo, null, $uid, 'casino', $state['bet'], 'lose', "21点结算 {$result} 玩家{$pval} 庄家{$dval}");
            if ($payout > 0) {
                log_tx($pdo, null, $uid, 'casino', $payout, 'win', "21点结算中奖 {$result}");
            }
            bj_save($pdo, $uid, $state);
            $pdo->commit();
            $finalBalance = (int)$me['balance'] + $payout;
            json_response(['phase' => 'done', 'result' => $result, 'payout' => $payout, 'balance' => $finalBalance, 'player_cards' => $state['player'], 'dealer_cards' => $state['dealer'], 'player_val' => $pval, 'dealer_val' => $dval, 'bet' => $state['bet']]);
        }

        $pdo->rollBack();
        json_response(['error' => '未知操作'], 400);
    } catch (Exception $e) { $pdo->rollBack(); json_response(['error' => '操作失败: ' . $e->getMessage()], 500); }
}

// 21点：放弃当前局（退回赌注）
if ($method === 'POST' && $action === 'bj_forfeit') {
    $state = bj_load($pdo, $uid);
    if (!$state || $state['phase'] === 'done') {
        json_response(['error' => '没有进行中的21点游戏'], 400);
    }
    $bet = (int)$state['bet'];
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();
        if ($bet > 0) {
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$bet, $uid]);
            log_tx($pdo, null, $uid, 'casino', $bet, 'win', "21点弃权退回");
        }
        bj_clear($pdo, $uid);
        $pdo->commit();
        json_response(['success' => true, 'balance' => (int)$me['balance'] + $bet]);
    } catch (Exception $e) { $pdo->rollBack(); json_response(['error' => '操作失败'], 500); }
}

// 21点：查询当前局状态
if ($method === 'GET' && $action === 'bj_state') {
    $state = bj_load($pdo, $uid);
    if (!$state || $state['phase'] === 'done') {
        json_response(['has_game' => false]);
    }
    $playerVal = bj_hand_val($state['player']);
    $dealerVal = null;
    if ($state['phase'] === 'done') $dealerVal = bj_hand_val($state['dealer']);
    json_response([
        'has_game' => true,
        'phase' => $state['phase'],
        'player_cards' => $state['player'],
        'dealer_cards' => $state['dealer'],
        'dealer_hole' => ($state['phase'] === 'player' && count($state['dealer']) < 2),
        'bet' => $state['bet'],
        'doubled' => $state['doubled'],
        'player_val' => $playerVal,
        'dealer_val' => $dealerVal,
    ]);
}

// ============ 老虎机 Slot Machine ============
if ($method === 'POST' && $action === 'slot') {
    $in = input();
    $amount = (int)($in['amount'] ?? 0);
    if ($amount <= 0) json_response(['error' => '下注金额必须大于 0'], 400);

    $pdo->beginTransaction();
    try {
        ensure_wallet($pdo, $uid, 'casino');
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();
        if ((int)$me['balance'] < $amount) { $pdo->rollBack(); json_response(['error' => '筹码不足'], 400); }
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
        $stmt->execute([$amount, $uid]);
        // 3 个卷轴，20 个符号，仅检中轴线
        $symbols = ['🍒', '🍋', '🔔', '⭐', '💎', '7️⃣', '🎯', '💰', '🍀', '🎲',
                     '🃏', '🎪', '🍉', '🍇', '🍑', '🍓', '🥝', '🍊', '🍌', '🍐'];
        $reels = [random_int(0, 19), random_int(0, 19), random_int(0, 19)];
        $reelSymbols = array_map(fn($r) => $symbols[$r], $reels);
        // 中轴线：三连=全相同，两连=相邻两卷相同
        $triple = ($reels[0] === $reels[1] && $reels[1] === $reels[2]);
        $pair = (!$triple && ($reels[0] === $reels[1] || $reels[1] === $reels[2]));
        $payout = 0;
        if ($triple) { $payout = $amount * 15; }
        elseif ($pair) { $payout = (int)round($amount * 1.5); }
        if ($payout > 0) {
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$payout, $uid]);
        }
        $msg = $triple ? '三连中!' : ($pair ? '两连中!' : '差一点');
        log_tx($pdo, null, $uid, 'casino', $amount, 'lose', "老虎机 {$msg} " . implode('+', $reels));
        if ($payout > 0) {
            log_tx($pdo, null, $uid, 'casino', $payout, 'win', "老虎机中奖 {$msg}");
        }
        $pdo->commit();
        json_response([
            'reels' => $reelSymbols, 'win' => $payout > 0, 'payout' => $payout,
            'balance' => (int)$me['balance'] - $amount + $payout,
        ]);
    } catch (Exception $e) { $pdo->rollBack(); json_response(['error' => '操作失败: ' . $e->getMessage()], 500); }
}

// ============ 猜大小 High/Low ============
if ($method === 'POST' && $action === 'highlow') {
    $in = input();
    $amount = (int)($in['amount'] ?? 0);
    $dir = $in['direction'] ?? '';
    if ($amount <= 0) json_response(['error' => '下注金额必须大于 0'], 400);
    if (!in_array($dir, ['higher', 'lower'], true)) json_response(['error' => '请选择大或小'], 400);

    $pdo->beginTransaction();
    try {
        ensure_wallet($pdo, $uid, 'casino');
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();
        if ((int)$me['balance'] < $amount) { $pdo->rollBack(); json_response(['error' => '筹码不足'], 400); }
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
        $stmt->execute([$amount, $uid]);
        // 生成两张牌
        $card1 = random_int(1, 13);
        $card2 = random_int(1, 13);
        $win = ($dir === 'higher' && $card2 > $card1) || ($dir === 'lower' && $card2 < $card1);
        $payout = 0;
        if ($win) { $payout = $amount * 2; }
        // 平局（同数字）不退不赔
        if ($card2 === $card1) $win = false;
        if ($payout > 0) {
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$payout, $uid]);
        }
        log_tx($pdo, null, $uid, 'casino', $amount, 'lose', "猜大小 压" . ($dir === 'higher' ? '大' : '小') . " {$card1}→{$card2}");
        if ($payout > 0) {
            log_tx($pdo, null, $uid, 'casino', $payout, 'win', "猜大小中奖");
        }
        $pdo->commit();
        json_response([
            'card1' => $card1, 'card2' => $card2, 'direction' => $dir,
            'win' => $win, 'payout' => $payout,
            'balance' => (int)$me['balance'] - $amount + $payout,
        ]);
    } catch (Exception $e) { $pdo->rollBack(); json_response(['error' => '操作失败: ' . $e->getMessage()], 500); }
}

// ============ 骗子酒馆 Liar's Bar (Liar's Deck 规则) ============
// 20张牌：6K + 6Q + 6A + 2🃏
// 每局抽一个"桌面类型"(K/Q/A)，桌面类型牌+🃏=真话(Truth)，其余=谎言(Lie)
// 玩家选1-3张牌打出去，声明其中几张是真话（可说谎）
// 庄家AI决定是否喊"骗子"
// 被喊+有谎言→输，被喊+全真话→赢2x
// 没被喊+真话→保本，没被喊+说谎→诈唬成功赢1.5x
if ($method === 'POST' && $action === 'liar_start') {
    $in = input();
    $amount = (int)($in['amount'] ?? 0);
    $playerCount = (int)($in['player_count'] ?? 2);
    if ($amount <= 0) json_response(['error' => '下注金额必须大于 0'], 400);
    if ($playerCount < 2 || $playerCount > 4) $playerCount = 2;

    $oldState = $_SESSION['liar_state'] ?? null;
    if ($oldState) json_response(['error' => '已有一局正在进行中'], 400);

    $pdo->beginTransaction();
    try {
        ensure_wallet($pdo, $uid, 'casino');
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();
        if ((int)$me['balance'] < $amount) { $pdo->rollBack(); json_response(['error' => '筹码不足'], 400); }
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
        $stmt->execute([$amount, $uid]);

        // 构建20张牌：6K + 6Q + 6A + 2🃏
        $deck = [];
        for ($i = 0; $i < 6; $i++) $deck[] = 'K';
        for ($i = 0; $i < 6; $i++) $deck[] = 'Q';
        for ($i = 0; $i < 6; $i++) $deck[] = 'A';
        $deck[] = '🃏'; $deck[] = '🃏';
        // 洗牌
        for ($i = count($deck) - 1; $i > 0; $i--) {
            $j = random_int(0, $i);
            [$deck[$i], $deck[$j]] = [$deck[$j], $deck[$i]];
        }
        // 抽桌面类型
        $tableTypes = ['K', 'Q', 'A'];
        $tableType = $tableTypes[random_int(0, 2)];
        // 发5张牌给玩家
        $cards = array_slice($deck, 0, 5);

        // 生成AI对手信息
        $aiNames = ['Scabby', 'Foxy', 'Bristol', 'Thor'];
        $aiEmojis = ['🐕', '🦊', '🐷', '🐂'];
        $aiList = [];
        for ($i = 0; $i < $playerCount - 1; $i++) {
            $idx = random_int(0, 3);
            $aiList[] = ['name' => $aiNames[$idx], 'emoji' => $aiEmojis[$idx]];
        }

        $_SESSION['liar_state'] = [
            'cards' => $cards, 'bet' => $amount, 'uid' => $uid,
            'table_type' => $tableType, 'player_count' => $playerCount,
            'ai_list' => $aiList,
        ];
        log_tx($pdo, null, $uid, 'casino', $amount, 'bet', "骗子酒馆 开局 {$playerCount}人局 桌面类型{$tableType} 下注{$amount}");
        $pdo->commit();
        json_response([
            'table_type' => $tableType,
            'cards' => $cards,
            'bet' => $amount,
            'player_count' => $playerCount,
            'ai_list' => $aiList,
            'balance' => (int)$me['balance'] - $amount,
            'hint' => "{$playerCount}人对局，桌面类型：{$tableType}。选1-3张牌打出，声明其中几张是真话（{$tableType}和🃏=真话，其余=谎言，可说谎）",
        ]);
    } catch (Exception $e) { $pdo->rollBack(); json_response(['error' => '开局失败: ' . $e->getMessage()], 500); }
}

// 出牌+声明
if ($method === 'POST' && $action === 'liar_play') {
    $state = $_SESSION['liar_state'] ?? null;
    if (!$state) json_response(['error' => '没有进行中的游戏'], 400);
    if ((int)$state['uid'] !== $uid) json_response(['error' => '不是你的游戏'], 403);

    $in = input();
    $cardIndices = $in['card_indices'] ?? [];
    $claimedTruths = (int)($in['claimed_truths'] ?? -1);
    if (!is_array($cardIndices) || count($cardIndices) < 1 || count($cardIndices) > 3) json_response(['error' => '请选择1-3张牌'], 400);
    if ($claimedTruths < 0 || $claimedTruths > count($cardIndices)) json_response(['error' => '声明数量无效'], 400);
    // 验证索引不重复且有效
    $cards = $state['cards'];
    $played = [];
    foreach ($cardIndices as $idx) {
        $idx = (int)$idx;
        if ($idx < 0 || $idx >= 5 || in_array($idx, $played)) json_response(['error' => '无效的牌选择'], 400);
        $played[] = $idx;
    }

    $amount = $state['bet'];
    $tableType = $state['table_type'];
    $playedCards = array_map(fn($i) => $cards[$i], $played);

    // 计算实际真话数：桌面类型牌 + 🃏 = 真话
    $actualTruths = count(array_filter($playedCards, fn($c) => $c === $tableType || $c === '🃏'));
    $actualLies = count($playedCards) - $actualTruths;
    $wasLying = ($claimedTruths !== $actualTruths);

    // 庄家AI决定是否喊"骗子"
    // 基础质疑率30%，随出牌数增加，声明极端值也增加
    $numCards = count($playedCards);
    $playerCount = $state['player_count'] ?? 2;
    $callChance = 0.30;
    $callChance += ($numCards - 1) * 0.10;          // 出2张+10%，出3张+20%
    $callChance += abs($claimedTruths - $actualTruths) * 0.12; // 说谎越多越可疑
    if ($claimedTruths === $numCards) $callChance += 0.08; // 声明全真话=高风险声明
    if ($claimedTruths === 0 && $numCards >= 2) $callChance += 0.05; // 声明0真话从2张起可疑
    // 人数越多，越多人喊"骗子"的概率越高
    $callChance += ($playerCount - 2) * 0.12;      // 3人+12%，4人+24%
    $callChance = max(0.15, min(0.90, $callChance));
    $called = (mt_rand(1, 10000) / 10000.0) < $callChance;

    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();
        $payout = 0; $win = false; $push = false;
        if ($called) {
            // 被喊"骗子"
            if ($actualLies > 0) {
                // 确实有谎言，被抓住→输
                $win = false;
            } else {
                // 全是真话，错喊→赢2x
                $win = true; $payout = $amount * 2;
            }
        } else {
            // 没被喊
            if ($wasLying) {
                // 说谎成功→赢1.5x
                $win = true; $payout = (int)round($amount * 1.5);
            } else {
                // 真话被信→保本
                $push = true; $payout = $amount;
            }
        }
        if ($payout > 0) {
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$payout, $uid]);
        }
        // 标记每张牌的真假
        $playedInfo = array_map(fn($c) => [
            'card' => $c,
            'is_truth' => ($c === $tableType || $c === '🃏'),
        ], $playedCards);

        $resultTxt = $called
            ? ($win ? '质疑失败！你全是真话，2倍奖励' : '被抓住撒谎！')
            : ($win ? '诈唬成功！对方信了' : '真话被信，保本');

        // 左轮俄罗斯轮盘：输了要玩左轮（1/6概率双倍损失）
        $revolver = false; $revolverDead = false; $totalLoss = 0;
        if (!$win && !$push) {
            $revolver = true;
            $revolverDead = (mt_rand(1, 6) === 1);
            if ($revolverDead) {
                $totalLoss = $amount * 2;
                $resultTxt .= ' 🔄 左轮开了！双倍损失！';
            } else {
                $resultTxt .= ' 🔄 左轮空响，你活下来了。';
            }
        }

        log_tx($pdo, null, $uid, 'casino', $amount, 'lose', "骗子酒馆 桌面{$tableType} 出{$numCards}张 声明{$claimedTruths}真话 {$resultTxt}");
        if ($payout > 0) log_tx($pdo, null, $uid, 'casino', $payout, 'win', "骗子酒馆中奖 {$resultTxt}");
        if ($revolverDead) log_tx($pdo, null, $uid, 'casino', $amount, 'lose', "骗子酒馆 左轮死亡 双倍损失");
        $pdo->commit();
        $_SESSION['liar_state'] = null;
        json_response([
            'table_type' => $tableType,
            'played' => $playedInfo,
            'claimed_truths' => $claimedTruths,
            'actual_truths' => $actualTruths,
            'called' => $called,
            'win' => $win,
            'payout' => $payout,
            'revolver' => $revolver,
            'revolver_dead' => $revolverDead,
            'balance' => (int)$me['balance'] + $payout,
        ]);
    } catch (Exception $e) { $pdo->rollBack(); json_response(['error' => '操作失败: ' . $e->getMessage()], 500); }
}

// 骗子酒馆：放弃当前局（退回赌注）
if ($method === 'POST' && $action === 'liar_forfeit') {
    $state = $_SESSION['liar_state'] ?? null;
    if (!$state) json_response(['error' => '没有进行中的游戏'], 400);
    if ((int)$state['uid'] !== $uid) json_response(['error' => '不是你的游戏'], 403);
    $bet = $state['bet'];
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();
        if ($bet > 0) {
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$bet, $uid]);
            log_tx($pdo, null, $uid, 'casino', $bet, 'win', "骗子酒馆 弃权退回");
        }
        $_SESSION['liar_state'] = null;
        $pdo->commit();
        json_response(['success' => true, 'balance' => (int)$me['balance'] + $bet]);
    } catch (Exception $e) { $pdo->rollBack(); json_response(['error' => '操作失败'], 500); }
}

// 骗子酒馆：查询当前局状态
if ($method === 'GET' && $action === 'liar_state') {
    $state = $_SESSION['liar_state'] ?? null;
    if (!$state) json_response(['has_game' => false]);
    json_response([
        'has_game' => true,
        'cards' => $state['cards'],
        'bet' => $state['bet'],
        'table_type' => $state['table_type'] ?? '',
        'player_count' => $state['player_count'] ?? 2,
        'ai_list' => $state['ai_list'] ?? [],
    ]);
}

// 旧版骗子酒馆（单人兼容）
if ($method === 'POST' && $action === 'liar') {
    $in = input();
    $amount = (int)($in['amount'] ?? 0);
    $claimed_value = (int)($in['claimed_value'] ?? 0);
    $claimed_count = (int)($in['claimed_count'] ?? -1);
    if ($amount <= 0) json_response(['error' => '下注金额必须大于 0'], 400);
    if ($claimed_value < 1 || $claimed_value > 13) json_response(['error' => '无效的牌面值'], 400);
    if ($claimed_count < 1 || $claimed_count > 5) json_response(['error' => '声明数量 1-5'], 400);

    $pdo->beginTransaction();
    try {
        ensure_wallet($pdo, $uid, 'casino');
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();
        if ((int)$me['balance'] < $amount) { $pdo->rollBack(); json_response(['error' => '筹码不足'], 400); }
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
        $stmt->execute([$amount, $uid]);
        // 发 5 张牌
        $cards = [];
        for ($i = 0; $i < 5; $i++) $cards[] = random_int(1, 13);
        $actual_count = count(array_filter($cards, fn($c) => $c === $claimed_value));
        // 庄家决定是否质疑（极端声明更易被抓）
        $callChance = 0.5 + abs($claimed_count - 1) * 0.1;
        $callChance = min($callChance, 0.85);
        $called = (mt_rand(1, 10000) / 10000.0) < $callChance;
        $payout = 0; $win = false; $push = false;
        if ($called) {
            if ($actual_count === $claimed_count) { $win = true; $payout = $amount * 2; }
        } else {
            if ($actual_count !== $claimed_count) { $win = true; $payout = (int)round($amount * 1.5); }
            else { $push = true; $payout = $amount; }
        }
        if ($payout > 0) {
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$payout, $uid]);
        }
        $claimTxt = card_name($claimed_value) . '×' . $claimed_count;
        if ($called) {
            $resultTxt = $win ? '质疑成立！你说对了' : '被抓住了！';
        } else {
            $resultTxt = $win ? '诈唬成功！' : '实话被信了（保本）';
        }
        log_tx($pdo, null, $uid, 'casino', $amount, 'lose', "骗子酒馆 声明{$claimTxt} {$resultTxt}");
        if ($payout > 0) {
            log_tx($pdo, null, $uid, 'casino', $payout, 'win', "骗子酒馆中奖 {$resultTxt}");
        }
        $pdo->commit();
        json_response([
            'cards' => $cards, 'claimed_value' => $claimed_value, 'claimed_count' => $claimed_count,
            'actual_count' => $actual_count, 'called' => $called, 'win' => $win, 'payout' => $payout,
            'balance' => (int)$me['balance'] - $amount + $payout,
        ]);
    } catch (Exception $e) { $pdo->rollBack(); json_response(['error' => '操作失败: ' . $e->getMessage()], 500); }
}

// ============ 刮刮乐 Scratch Card ============
if ($method === 'POST' && $action === 'scratch') {
    $in = input();
    $amount = (int)($in['amount'] ?? 0);
    if ($amount <= 0) json_response(['error' => '下注金额必须大于 0'], 400);

    $pdo->beginTransaction();
    try {
        ensure_wallet($pdo, $uid, 'casino');
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();
        if ((int)$me['balance'] < $amount) { $pdo->rollBack(); json_response(['error' => '筹码不足'], 400); }
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
        $stmt->execute([$amount, $uid]);
        // 生成 3x3 网格，10 个符号，检查全部 8 条线（3行+3列+2对角线）
        $symbols = ['🍒', '🍋', '🔔', '⭐', '💎', '7️⃣', '🎯', '💰', '🍀', '🎲'];
        $grid = [];
        for ($i = 0; $i < 9; $i++) $grid[] = $symbols[random_int(0, 9)];
        // 全部 8 条线
        $lines = [];
        // 行
        for ($r = 0; $r < 3; $r++) $lines[] = [$grid[$r * 3], $grid[$r * 3 + 1], $grid[$r * 3 + 2]];
        // 列
        for ($c = 0; $c < 3; $c++) $lines[] = [$grid[$c], $grid[3 + $c], $grid[6 + $c]];
        // 对角线
        $lines[] = [$grid[0], $grid[4], $grid[8]];
        $lines[] = [$grid[2], $grid[4], $grid[6]];
        $maxMatch = 0; $matchSymbol = '';
        foreach ($lines as $line) {
            $counts = array_count_values($line);
            foreach ($counts as $sym => $cnt) {
                if ($cnt > $maxMatch) { $maxMatch = $cnt; $matchSymbol = $sym; }
            }
        }
        $payout = 0;
        if ($maxMatch >= 3) $payout = $amount * 5;
        elseif ($maxMatch === 2) $payout = (int)round($amount * 1.5);
        if ($payout > 0) {
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$payout, $uid]);
        }
        $msg = $maxMatch >= 3 ? '三连奖!' : ($maxMatch === 2 ? '小奖!' : '差一点');
        log_tx($pdo, null, $uid, 'casino', $amount, 'lose', "刮刮乐 {$msg} 最大{$maxMatch}连");
        if ($payout > 0) {
            log_tx($pdo, null, $uid, 'casino', $payout, 'win', "刮刮乐中奖 {$msg}");
        }
        $pdo->commit();
        json_response([
            'grid' => $grid, 'max_match' => $maxMatch, 'match_symbol' => $matchSymbol,
            'win' => $payout > 0, 'payout' => $payout,
            'balance' => (int)$me['balance'] - $amount + $payout,
        ]);
    } catch (Exception $e) { $pdo->rollBack(); json_response(['error' => '操作失败: ' . $e->getMessage()], 500); }
}

// ============ 幸运转盘 Lucky Wheel ============
if ($method === 'POST' && $action === 'wheel') {
    $in = input();
    $amount = (int)($in['amount'] ?? 0);
    if ($amount <= 0) json_response(['error' => '下注金额必须大于 0'], 400);

    $pdo->beginTransaction();
    try {
        ensure_wallet($pdo, $uid, 'casino');
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();
        if ((int)$me['balance'] < $amount) { $pdo->rollBack(); json_response(['error' => '筹码不足'], 400); }
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
        $stmt->execute([$amount, $uid]);
        // 转盘分区（权重 + 倍数）- 庄家优势约 6.5%
        $sectors = [
            ['label' => '0x',  'mult' => 0,    'weight' => 60],
            ['label' => '1x',  'mult' => 1,    'weight' => 18],
            ['label' => '2x',  'mult' => 2,    'weight' => 10],
            ['label' => '3x',  'mult' => 3,    'weight' => 5],
            ['label' => '5x',  'mult' => 5,    'weight' => 4],
            ['label' => '10x', 'mult' => 10,   'weight' => 2],
            ['label' => '0.5x','mult' => 0.5,  'weight' => 1],
        ];
        $totalWeight = array_sum(array_column($sectors, 'weight'));
        $roll = mt_rand(1, $totalWeight);
        $acc = 0; $sector = $sectors[0];
        foreach ($sectors as $s) { $acc += $s['weight']; if ($roll <= $acc) { $sector = $s; break; } }
        $payout = $sector['mult'] > 0 ? (int)round($amount * $sector['mult']) : 0;
        if ($payout > 0) {
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$payout, $uid]);
        }
        log_tx($pdo, null, $uid, 'casino', $amount, 'lose', "幸运转盘 {$sector['label']} 赔率{$sector['mult']}x");
        if ($payout > 0) {
            log_tx($pdo, null, $uid, 'casino', $payout, 'win', "幸运转盘中奖 {$sector['label']}");
        }
        $pdo->commit();
        json_response([
            'sector' => $sector['label'], 'multiplier' => $sector['mult'],
            'win' => $payout > 0, 'payout' => $payout,
            'balance' => (int)$me['balance'] - $amount + $payout,
        ]);
    } catch (Exception $e) { $pdo->rollBack(); json_response(['error' => '操作失败: ' . $e->getMessage()], 500); }
}

// ============ 赌场排行榜 ============
if ($method === 'GET' && $action === 'leaderboard') {
    $period = $_GET['period'] ?? 'all';
    $where = ''; $params = [];
    if ($period === 'today') {
        $where = "WHERE pt.created_at >= CURDATE()";
    } elseif ($period === 'week') {
        $where = "WHERE pt.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
    }
    $stmt = $pdo->prepare("
        SELECT u.id, u.nickname, u.avatar, u.level,
            COALESCE(SUM(CASE WHEN pt.to_user_id = u.id AND pt.type = 'win' THEN pt.amount ELSE 0 END), 0) AS total_win,
            COALESCE(SUM(CASE WHEN pt.from_user_id = u.id THEN pt.amount ELSE 0 END), 0) AS total_lose,
            COUNT(*) AS total_games
        FROM users u
        JOIN point_transactions pt ON (pt.from_user_id = u.id OR pt.to_user_id = u.id) AND pt.currency = 'casino'
        $where
        GROUP BY u.id, u.nickname, u.avatar, u.level
        HAVING COUNT(*) > 0
        ORDER BY (COALESCE(SUM(CASE WHEN pt.to_user_id = u.id AND pt.type = 'win' THEN pt.amount ELSE 0 END), 0)
                  - COALESCE(SUM(CASE WHEN pt.from_user_id = u.id THEN pt.amount ELSE 0 END), 0)) DESC
        LIMIT 20
    ");
    $stmt->execute($params);
    json_response(['leaderboard' => $stmt->fetchAll()]);
}

// ============ 幸运抽奖 Lucky Draw ============
if ($method === 'POST' && $action === 'luckydraw') {
    $in = input();
    $amount = (int)($in['amount'] ?? 0);
    if ($amount <= 0) json_response(['error' => '下注金额必须大于 0'], 400);
    if ($amount > 10000) json_response(['error' => '单次最多下注 10000'], 400);

    $pdo->beginTransaction();
    try {
        ensure_wallet($pdo, $uid, 'casino');
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'casino' FOR UPDATE");
        $stmt->execute([$uid]);
        $me = $stmt->fetch();
        if ((int)$me['balance'] < $amount) { $pdo->rollBack(); json_response(['error' => '筹码不足'], 400); }
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'casino'");
        $stmt->execute([$amount, $uid]);

        // 抽奖箱：20 个格子，部分中奖
        $prizes = [
            ['num' => '谢谢参与', 'mult' => 0, 'count' => 30],
            ['num' => '50%返还', 'mult' => 0.5, 'count' => 20],
            ['num' => '100%返还', 'mult' => 1, 'count' => 15],
            ['num' => '2倍中奖', 'mult' => 2, 'count' => 15],
            ['num' => '3倍中奖', 'mult' => 3, 'count' => 10],
            ['num' => '5倍中奖', 'mult' => 5, 'count' => 6],
            ['num' => '10倍大奖', 'mult' => 10, 'count' => 3],
            ['num' => '50倍 Jackpot!', 'mult' => 50, 'count' => 1],
        ];
        $total = array_sum(array_column($prizes, 'count'));
        $roll = mt_rand(1, $total);
        $acc = 0; $prize = $prizes[0];
        foreach ($prizes as $p) { $acc += $p['count']; if ($roll <= $acc) { $prize = $p; break; } }
        $payout = $prize['mult'] > 0 ? (int)round($amount * $prize['mult']) : 0;
        if ($payout > 0) {
            $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance + ? WHERE user_id = ? AND currency = 'casino'");
            $stmt->execute([$payout, $uid]);
        }
        log_tx($pdo, null, $uid, 'casino', $amount, 'lose', "幸运抽奖 {$prize['num']}");
        if ($payout > 0) {
            log_tx($pdo, null, $uid, 'casino', $payout, 'win', "幸运抽奖中奖 {$prize['num']}");
        }
        $pdo->commit();
        json_response([
            'prize' => $prize['num'], 'multiplier' => $prize['mult'],
            'win' => $payout > 0, 'payout' => $payout,
            'balance' => (int)$me['balance'] - $amount + $payout,
        ]);
    } catch (Exception $e) { $pdo->rollBack(); json_response(['error' => '操作失败: ' . $e->getMessage()], 500); }
}

json_response(['error' => '未知操作'], 400);
