<?php
require_once __DIR__ . '/../functions.php';
$pdo = db_connect();
$user = require_auth();

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$uid = (int)$user['id'];

// 表自愈：缺表时自动创建（兼容未升级的老库）
ensure_game_tables($pdo);

function ensure_game_tables($pdo) {
    // 逐表检查，避免 game_rooms 存在但其他表缺失
    $existing = [];
    $stmt = $pdo->query("SHOW TABLES");
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $t) $existing[$t] = true;

    if (!isset($existing['game_rooms'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS game_rooms (
            id INT AUTO_INCREMENT PRIMARY KEY,
            game_type ENUM('gomoku') NOT NULL,
            status ENUM('waiting','playing','finished') DEFAULT 'waiting',
            host_id INT NOT NULL,
            seed INT NOT NULL DEFAULT 0,
            max_players TINYINT NOT NULL DEFAULT 2,
            current_seat TINYINT NOT NULL DEFAULT 0,
            board_state JSON DEFAULT NULL,
            winner_id INT DEFAULT NULL,
            started_at DATETIME DEFAULT NULL,
            finished_at DATETIME DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (host_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_status (status),
            INDEX idx_host (host_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($existing['game_players'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS game_players (
            id INT AUTO_INCREMENT PRIMARY KEY,
            room_id INT NOT NULL,
            user_id INT NOT NULL,
            seat TINYINT NOT NULL,
            progress INT NOT NULL DEFAULT 0,
            finished_at DATETIME DEFAULT NULL,
            status ENUM('active','resigned') DEFAULT 'active',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_room_user (room_id, user_id),
            FOREIGN KEY (room_id) REFERENCES game_rooms(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_room (room_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($existing['game_moves'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS game_moves (
            id INT AUTO_INCREMENT PRIMARY KEY,
            room_id INT NOT NULL,
            user_id INT NOT NULL,
            seat TINYINT NOT NULL,
            move_data JSON NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (room_id) REFERENCES game_rooms(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_room_time (room_id, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($existing['game_stats'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS game_stats (
            user_id INT PRIMARY KEY,
            wins INT NOT NULL DEFAULT 0,
            losses INT NOT NULL DEFAULT 0,
            draws INT NOT NULL DEFAULT 0,
            rating INT NOT NULL DEFAULT 1000,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
}

function room_state($pdo, $room_id) {
    $stmt = $pdo->prepare("SELECT * FROM game_rooms WHERE id = ?");
    $stmt->execute([$room_id]);
    return $stmt->fetch();
}

function players_state($pdo, $room_id) {
    $stmt = $pdo->prepare("SELECT gp.user_id, gp.seat, gp.progress, gp.status, u.username, u.nickname, u.avatar
                          FROM game_players gp JOIN users u ON u.id = gp.user_id
                          WHERE gp.room_id = ? ORDER BY gp.seat");
    $stmt->execute([$room_id]);
    return $stmt->fetchAll();
}

function apply_elo($pdo, $winner_id, $loser_id, $draw = false) {
    foreach ([[$winner_id, $loser_id]] as $pair) {
        $a = $pair[0]; $b = $pair[1];
        $pdo->prepare("INSERT IGNORE INTO game_stats (user_id) VALUES (?),(?)")->execute([$a, $b]);
        $stmt = $pdo->prepare("SELECT rating FROM game_stats WHERE user_id = ?");
        $stmt->execute([$a]); $ra = (int)$stmt->fetchColumn();
        $stmt->execute([$b]); $rb = (int)$stmt->fetchColumn();
        $ea = 1 / (1 + pow(10, ($rb - $ra) / 400));
        $sa = $draw ? 0.5 : 1.0;
        $k = 24;
        $upd = $pdo->prepare("UPDATE game_stats SET rating = GREATEST(100, rating + ?), wins = wins + ?, losses = losses + ?, draws = draws + ? WHERE user_id = ?");
        $upd->execute([round($k * ($sa - $ea)), $draw ? 0 : ($sa > 0.5 ? 1 : 0), $draw ? 0 : ($sa < 0.5 ? 1 : 0), $draw ? 1 : 0, $a]);
        $upd->execute([round($k * ((1 - $sa) - (1 - $ea))), $draw ? 0 : ($sa < 0.5 ? 1 : 0), $draw ? 0 : ($sa > 0.5 ? 1 : 0), $draw ? 1 : 0, $b]);
    }
}

// 大厅：开放房间列表
if ($method === 'GET' && $action === 'rooms') {
    $game_type = $_GET['game_type'] ?? '';
    $sql = "SELECT r.id, r.game_type, r.status, r.host_id, r.max_players, r.created_at,
                   (SELECT COUNT(*) FROM game_players WHERE room_id = r.id) AS player_count,
                   u.nickname AS host_name
            FROM game_rooms r JOIN users u ON u.id = r.host_id
            WHERE r.status = 'waiting'";
    $params = [];
    if ($game_type === 'gomoku') {
        $sql .= " AND r.game_type = ?";
        $params[] = $game_type;
    }
    $sql .= " ORDER BY r.created_at DESC LIMIT 50";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    json_response(['rooms' => $stmt->fetchAll()]);
}

// 创建房间
if ($method === 'POST' && $action === 'create') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $game_type = $input['game_type'] ?? '';
    if (!in_array($game_type, ['gomoku'], true)) {
        json_response(['error' => '无效的游戏类型'], 400);
    }
    try {
        // 清理自己名下残留的 waiting 房间（上次未正常关闭）
        $stmt = $pdo->prepare("SELECT id FROM game_rooms WHERE host_id = ? AND status = 'waiting'");
        $stmt->execute([$uid]);
        while ($stale = $stmt->fetch()) {
            $stale_id = (int)$stale['id'];
            $pdo->prepare("DELETE FROM game_players WHERE room_id = ?")->execute([$stale_id]);
            $pdo->prepare("DELETE FROM game_moves WHERE room_id = ?")->execute([$stale_id]);
            $pdo->prepare("DELETE FROM game_rooms WHERE id = ?")->execute([$stale_id]);
        }
        // 只拦截真正进行中的房间
        $stmt = $pdo->prepare("SELECT id FROM game_rooms WHERE host_id = ? AND status = 'playing'");
        $stmt->execute([$uid]);
        if ($stmt->fetch()) {
            json_response(['error' => '你有一局游戏正在进行中，请先完成或认输'], 400);
        }
        $seed = random_int(1, 999999999);
        $stmt = $pdo->prepare("INSERT INTO game_rooms (game_type, host_id, seed, max_players) VALUES (?, ?, ?, 2)");
        $stmt->execute([$game_type, $uid, $seed]);
        $room_id = (int)$pdo->lastInsertId();
        $stmt = $pdo->prepare("INSERT INTO game_players (room_id, user_id, seat) VALUES (?, ?, 0)");
        $stmt->execute([$room_id, $uid]);
        json_response(['room_id' => $room_id, 'seed' => $seed]);
    } catch (Exception $e) {
        json_response(['error' => '创建房间失败: ' . $e->getMessage()], 500);
    }
}

// 加入房间
if ($method === 'POST' && $action === 'join') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $room_id = (int)($input['room_id'] ?? 0);

    $pdo->beginTransaction();
    try {
        // 锁房间行，防并发超员加入
        $stmt = $pdo->prepare("SELECT * FROM game_rooms WHERE id = ? FOR UPDATE");
        $stmt->execute([$room_id]);
        $room = $stmt->fetch();
        if (!$room || $room['status'] !== 'waiting') {
            $pdo->rollBack(); json_response(['error' => '房间不存在或已开始'], 400);
        }
        $players = players_state($pdo, $room_id);
        if (count($players) >= (int)$room['max_players']) {
            $pdo->rollBack(); json_response(['error' => '房间已满'], 400);
        }
        foreach ($players as $p) {
            if ((int)$p['user_id'] === $uid) {
                $pdo->rollBack(); json_response(['error' => '你已在房间中'], 400);
            }
        }
        $seat = count($players);
        $stmt = $pdo->prepare("INSERT INTO game_players (room_id, user_id, seat) VALUES (?, ?, ?)");
        $stmt->execute([$room_id, $uid, $seat]);
        $players = players_state($pdo, $room_id);
        if (count($players) >= (int)$room['max_players']) {
            $pdo->prepare("UPDATE game_rooms SET status = 'playing', current_seat = 0, started_at = NOW() WHERE id = ?")->execute([$room_id]);
        }
        $pdo->commit();
        json_response(['room_id' => $room_id]);
    } catch (Exception $e) {
        $pdo->rollBack();
        json_response(['error' => '加入失败: ' . $e->getMessage()], 500);
    }
}

// 房间状态（轮询）
if ($method === 'GET' && $action === 'state') {
    $room_id = (int)($_GET['room_id'] ?? 0);
    $room = room_state($pdo, $room_id);
    if (!$room) {
        json_response(['error' => '房间不存在'], 404);
    }
    $players = players_state($pdo, $room_id);
    $moves = [];
    if ($room['game_type'] === 'gomoku') {
        $stmt = $pdo->prepare("SELECT user_id, seat, move_data, created_at FROM game_moves WHERE room_id = ? ORDER BY id ASC");
        $stmt->execute([$room_id]);
        $moves = $stmt->fetchAll();
    }
    json_response([
        'room' => [
            'id' => (int)$room['id'],
            'game_type' => $room['game_type'],
            'status' => $room['status'],
            'seed' => (int)$room['seed'],
            'current_seat' => (int)$room['current_seat'],
            'winner_id' => $room['winner_id'] !== null ? (int)$room['winner_id'] : null,
            'host_id' => (int)$room['host_id'],
            'max_players' => (int)$room['max_players'],
            'board_state' => $room['board_state'] ? json_decode($room['board_state'], true) : null,
            'finished_at' => $room['finished_at'] ?? null,
        ],
        'players' => array_map(function ($p) {
            return [
                'user_id' => (int)$p['user_id'],
                'seat' => (int)$p['seat'],
                'progress' => (int)$p['progress'],
                'status' => $p['status'],
                'nickname' => $p['nickname'] ?: $p['username'],
                'avatar' => $p['avatar'],
                'finished_at' => $p["finished_at"] ?? null,
            ];
        }, $players),
        'moves' => $moves,
        'my_id' => $uid,
    ]);
}

// 离开房间
if ($method === 'POST' && $action === 'leave') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $room_id = (int)($input['room_id'] ?? 0);
    $room = room_state($pdo, $room_id);
    if (!$room) json_response(['error' => '房间不存在'], 404);
    $stmt = $pdo->prepare("SELECT seat FROM game_players WHERE room_id = ? AND user_id = ?");
    $stmt->execute([$room_id, $uid]);
    $me = $stmt->fetch();
    if (!$me) json_response(['error' => '你不在房间中'], 400);

    if ($room['status'] === 'playing') {
        // 进行中离开 = 认输
        $stmt = $pdo->prepare("SELECT user_id FROM game_players WHERE room_id = ? AND user_id != ? AND status = 'active'");
        $stmt->execute([$room_id, $uid]);
        $other = $stmt->fetch();
        if ($other) {
            $pdo->prepare("UPDATE game_rooms SET status = 'finished', winner_id = ?, finished_at = NOW() WHERE id = ?")->execute([(int)$other['user_id'], $room_id]);
            $pdo->prepare("UPDATE game_players SET status = 'resigned' WHERE room_id = ? AND user_id = ?")->execute([$room_id, $uid]);
            apply_elo($pdo, (int)$other['user_id'], $uid);
        }
    } else {
        $pdo->prepare("DELETE FROM game_players WHERE room_id = ? AND user_id = ?")->execute([$room_id, $uid]);
        $left = players_state($pdo, $room_id);
        if (empty($left)) {
            $pdo->prepare("DELETE FROM game_rooms WHERE id = ?")->execute([$room_id]);
        } else if ((int)$room['host_id'] === $uid) {
            $pdo->prepare("UPDATE game_rooms SET host_id = ? WHERE id = ?")->execute([(int)$left[0]['user_id'], $room_id]);
        }
    }
    json_response(['success' => true]);
}

// ============ 五子棋：落子 ============
if ($method === 'POST' && $action === 'move') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $room_id = (int)($input['room_id'] ?? 0);
    $x = (int)($input['x'] ?? -1);
    $y = (int)($input['y'] ?? -1);

    $pdo->beginTransaction();
    try {
        // 锁房间行，防双击连下两子
        $stmt = $pdo->prepare("SELECT * FROM game_rooms WHERE id = ? FOR UPDATE");
        $stmt->execute([$room_id]);
        $room = $stmt->fetch();
        if (!$room || $room['game_type'] !== 'gomoku') {
            $pdo->rollBack(); json_response(['error' => '房间不存在'], 404);
        }
        if ($room['status'] !== 'playing') {
            $pdo->rollBack(); json_response(['error' => '游戏未开始或已结束'], 400);
        }
    $players = players_state($pdo, $room_id);
    $my_seat = null;
    foreach ($players as $p) {
        if ((int)$p['user_id'] === $uid) $my_seat = (int)$p['seat'];
    }
    if ($my_seat === null) json_response(['error' => '你不在房间中'], 400);
    if ((int)$room['current_seat'] !== $my_seat) {
        json_response(['error' => '还没轮到你'], 400);
    }
    if ($x < 0 || $x > 14 || $y < 0 || $y > 14) {
        json_response(['error' => '坐标越界'], 400);
    }

    // 重建当前棋盘
    $board = array_fill(0, 15, array_fill(0, 15, -1));
    $stmt = $pdo->prepare("SELECT seat, move_data FROM game_moves WHERE room_id = ?");
    $stmt->execute([$room_id]);
    while ($row = $stmt->fetch()) {
        $m = json_decode($row['move_data'], true);
        $board[(int)$m['y']][(int)$m['x']] = (int)$row['seat'];
    }
    if ($board[$y][$x] !== -1) {
        $pdo->rollBack(); json_response(['error' => '该位置已有棋子'], 400);
    }
    $board[$y][$x] = $my_seat;

    $stmt = $pdo->prepare("INSERT INTO game_moves (room_id, user_id, seat, move_data) VALUES (?, ?, ?, ?)");
    $stmt->execute([$room_id, $uid, $my_seat, json_encode(['x' => $x, 'y' => $y])]);

    $win = check_gomoku_win($board, $x, $y, $my_seat);
    $total_moves = (int)$pdo->query("SELECT COUNT(*) FROM game_moves WHERE room_id = " . $room_id)->fetchColumn();
    $next_seat = ($my_seat + 1) % count($players);

    if ($win) {
        $pdo->prepare("UPDATE game_rooms SET status = 'finished', winner_id = ?, finished_at = NOW() WHERE id = ?")->execute([$uid, $room_id]);
        $loser = null;
        foreach ($players as $p) if ((int)$p['user_id'] !== $uid) $loser = (int)$p['user_id'];
        if ($loser) apply_elo($pdo, $uid, $loser);
        $pdo->commit();
        json_response(['ok' => true, 'win' => true, 'winner_id' => $uid, 'x' => $x, 'y' => $y]);
    } else if ($total_moves >= 225) {
        $pdo->prepare("UPDATE game_rooms SET status = 'finished', winner_id = NULL, finished_at = NOW() WHERE id = ?")->execute([$room_id]);
        $pdo->commit();
        json_response(['ok' => true, 'draw' => true, 'x' => $x, 'y' => $y]);
    } else {
        $pdo->prepare("UPDATE game_rooms SET current_seat = ?, board_state = ? WHERE id = ?")->execute([$next_seat, json_encode($board), $room_id]);
        $pdo->commit();
        json_response(['ok' => true, 'x' => $x, 'y' => $y, 'next_seat' => $next_seat]);
    }
    } catch (Exception $e) {
        $pdo->rollBack();
        json_response(['error' => '落子失败: ' . $e->getMessage()], 500);
    }
}

// 五子棋判胜：四个方向五连
function check_gomoku_win($board, $x, $y, $seat) {
    $dirs = [[1, 0], [0, 1], [1, 1], [1, -1]];
    foreach ($dirs as [$dx, $dy]) {
        $count = 1;
        for ($i = 1; $i < 5; $i++) {
            $nx = $x + $dx * $i; $ny = $y + $dy * $i;
            if ($nx < 0 || $nx > 14 || $ny < 0 || $ny > 14 || $board[$ny][$nx] !== $seat) break;
            $count++;
        }
        for ($i = 1; $i < 5; $i++) {
            $nx = $x - $dx * $i; $ny = $y - $dy * $i;
            if ($nx < 0 || $nx > 14 || $ny < 0 || $ny > 14 || $board[$ny][$nx] !== $seat) break;
            $count++;
        }
        if ($count >= 5) return true;
    }
    return false;
}

// 排行榜
if ($method === 'GET' && $action === 'leaderboard') {
    $stmt = $pdo->query("SELECT gs.user_id, gs.wins, gs.losses, gs.draws, gs.rating,
                                u.username, u.nickname, u.avatar
                         FROM game_stats gs JOIN users u ON u.id = gs.user_id
                         ORDER BY gs.rating DESC LIMIT 50");
    json_response(['leaderboard' => $stmt->fetchAll()]);
}

json_response(['error' => '未知操作'], 400);
