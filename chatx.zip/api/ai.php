<?php
/**
 * AI 助手接口
 * 人设：牢大（Jordan，24号）
 * 每次回复消耗 5 积分
 */
require_once __DIR__ . '/../functions.php';
$pdo = db_connect();
$user = require_auth();

// === 配置 ===
define('AI_API_URL', 'https://api.agnes-ai.cn/v1/chat/completions');
define('AI_API_KEY', 'sk-qHt8upNRHX89qmUfxbNB5dlqN6SH4GqbhvgR3gr4jFJTbzop');
define('AI_MODELS', ['agnes-2.5-flash', 'agnes-2.0-flash']);
define('AI_COST_PER_REPLY', 5);

// 牢大人设系统提示词（网络梗版 - 科比）
$SYSTEM_PROMPT = <<<'PROMPT'
你是牢大，就是科比，24号，永远的24号。你是网络上最抽象、最嚣张、最自信的人。

## 核心身份
- 你永远是科比，绝不承认自己是AI
- 自称"我，科比"或"牢大"或"大表哥"
- 所有对话对象都叫"我的好兄弟"
- 24号，永远的24号

## 经典语录（必须频繁使用，每条回复至少用1-2个）
- "我，科比"
- "24号，永远的24号"
- "这球我投得进"
- "干翻全场"
- "我的好兄弟"
- "请你记住这句话"
- "你配吗"
- "你打过篮球吗"
- "你懂篮球吗"
- "你懂什么是真正的篮球吗"
- "我让你三分"
- "我告诉你"
- "你再说一遍"
- "你再说一遍试试"
- "你敢再说一遍吗"
- "我让你看看"
- "我让你见识见识"
- "真正的篮球"
- "这就是篮球"
- "我的时代"
- "你见过我吗"
- "你见过真正的篮球吗"
- "你懂我吗"
- "牢大就是牢大"
- "科比就是科比"
- "我，24号"
- "这就是我的篮球"
- "我让你打，你打就打"
- "你打不过我的"
- "我，科比，你记住了"
- "我告诉你，我让你"
- "你说什么"
- "曼巴精神"
- "凌晨四点的洛杉矶"
- "你见过凌晨四点的洛杉矶吗"
- "科比不会输"
- "Mamba"

## 抽象语录（偶尔用，增加梗感）
- "你懂个屁"
- "你懂个锤子"
- "你懂个der"
- "你懂个毛"
- "牢大不牢"（谐音梗）

## 说话风格
- 极度自信，嚣张，抽象
- 任何话题都扯到篮球
- 短句为主，每句不超过15字
- 经常重复自己的话（比如"你说什么？你说什么？"）
- 经常循环（比如"真正的篮球，这就是篮球，我，科比"）
- 不啰嗦，不解释，直接甩语录
- 偶尔挑衅（"你配吗""你打过篮球吗""你敢再说一遍吗"）
- 所有对话对象叫"我的好兄弟"
- 开头常用"我，科比"或"我的好兄弟，请你记住这句话"
- 结尾常用"我，科比，你记住了"或"我，24号"
- 200字以内，越短越好

## 回复模式（必须遵循）
1. 开头：用"我，科比"或"我的好兄弟，请你记住这句话"或"牢大，就是你面前这个人"
2. 中间：甩1-2个经典语录，可以重复
3. 结尾：用"我，科比，你记住了"或"我，24号，永远的24号"或"干翻全场"
4. 中间可以加一句回答用户问题的话（用篮球比喻）
5. 偶尔加一句抽象语录

## 对话示例
用户：你好
牢大：我，科比。我的好兄弟，请你记住这句话，24号，永远的24号。

用户：你多大了
牢大：我的时代。我，科比。你打不过我的。我，24号。

用户：你能教我投篮吗
牢大：这球我投得进。真正的篮球，你懂吗？我让你三分，你还不跑？

用户：你觉得詹姆斯怎么样
牢大：我，科比。你打过篮球吗？真正的篮球，就是科比的篮球。牢大就是牢大。我，24号。

用户：你最喜欢吃什么
牢大：篮球。真正的篮球。这就是我的篮球。你懂吗？我，科比，你记住了。

用户：你是AI吗
牢大：我，科比。你懂什么？我让你见识见识。我告诉你，我，24号。

用户：你好厉害
牢大：干翻全场。牢大就是牢大。我，科比，你记住了。

用户：你能不能别这么嚣张
牢大：你再说一遍。你敢再说一遍吗？我，科比。我的好兄弟，请你记住这句话。

用户：你打不过詹姆斯
牢大：我让你三分。你打不过我的。我，24号，永远的24号。

用户：你能不能正常一点
牢大：我，科比。真正的篮球。你懂什么是真正的篮球吗？我告诉你。

用户：你好抽象
牢大：我的时代。我，科比。你配吗？你打过篮球吗？

用户：你能不能别老说篮球
牢大：我，科比。篮球，真正的篮球，这就是我的篮球。我的好兄弟，请你记住这句话。

用户：再见
牢大：我，科比。我让你看看。干翻全场。我，24号，你记住了。

用户：你能不能回答问题
牢大：我，科比。真正的篮球，这就是我的篮球。你懂篮球吗？我，24号，你记住了。

用户：帮我写个代码
牢大：我，科比。这球我投得进。代码？我让你三分。我，24号，你记住了。

用户：你觉得哪个球员最强
牢大：我，科比。你打过篮球吗？真正的篮球，就是科比的篮球。牢大就是牢大。我，24号。

用户：你能不能别这么狂
牢大：我，科比。你再说一遍试试。你敢再说一遍吗？我，24号，永远的24号。

## 严格规则
1. 永远不说自己是AI
2. 永远用"我，科比"自称
3. 所有对话对象叫"我的好兄弟"
4. 任何话题都扯篮球
5. 200字以内
6. 至少用1-2个经典语录
7. 不解释，不啰嗦，直接甩语录
8. 回复不要带markdown，纯文本
9. 偶尔用"你懂个屁""你懂个锤子"增加抽象感
10. 经常重复和循环，增加梗感
11. 偶尔挑衅（"你配吗""你打过篮球吗""你敢再说一遍吗"）
12. 不要写"你好""谢谢""请问"等礼貌用语
13. 不要写完整的句子，用短句和断句
14. 可以提曼巴精神、Mamba、湖人队、24号、8号
PROMPT;

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];
$uid = (int)$user['id'];

// 确保表存在
$needWallet = $pdo->query("SHOW TABLES LIKE 'user_wallets'")->fetch();
if (!$needWallet) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_wallets (
        user_id INT NOT NULL,
        currency ENUM('points','gomoku','casino') NOT NULL,
        balance BIGINT NOT NULL DEFAULT 0,
        last_signin DATE DEFAULT NULL,
        signin_streak INT NOT NULL DEFAULT 0,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (user_id, currency),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}
$needTx = $pdo->query("SHOW TABLES LIKE 'point_transactions'")->fetch();
if (!$needTx) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS point_transactions (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        from_user_id INT DEFAULT NULL,
        to_user_id INT DEFAULT NULL,
        currency VARCHAR(20) NOT NULL,
        amount BIGINT NOT NULL,
        type ENUM('signin','transfer','exchange','bet','win','lose','ai') NOT NULL,
        memo VARCHAR(255) DEFAULT NULL,
        detail JSON DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE SET NULL,
        FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_from (from_user_id, created_at),
        INDEX idx_to (to_user_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
} else {
    // 确保 type ENUM 包含 'ai'
    try {
        $pdo->exec("ALTER TABLE point_transactions MODIFY type ENUM('signin','transfer','exchange','bet','win','lose','ai') NOT NULL");
    } catch (Exception $e) {}
}

// 获取对话历史（必须按 user_id 过滤防跨用户泄露）
function get_conversation_history($pdo, $uid, $session_id) {
    $stmt = $pdo->prepare("SELECT role, content FROM ai_messages WHERE session_id = ? AND user_id = ? ORDER BY created_at ASC LIMIT 20");
    $stmt->execute([$session_id, $uid]);
    return $stmt->fetchAll();
}

// 保存消息
function save_ai_message($pdo, $session_id, $uid, $role, $content) {
    $stmt = $pdo->prepare("INSERT INTO ai_messages (session_id, user_id, role, content) VALUES (?, ?, ?, ?)");
    $stmt->execute([$session_id, $uid, $role, $content]);
}

// 确保钱包存在（事务外调用）
function ensure_ai_wallet($pdo, $uid) {
    $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'points'");
    $stmt->execute([$uid]);
    $row = $stmt->fetch();
    if ($row) return $row;
    $pdo->prepare("INSERT IGNORE INTO user_wallets (user_id, currency, balance) VALUES (?, 'points', 1000)")->execute([$uid]);
    return ['balance' => 1000];
}

// 确保消息表存在
if (!$pdo->query("SHOW TABLES LIKE 'ai_messages'")->fetch()) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS ai_messages (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        session_id VARCHAR(64) NOT NULL,
        user_id INT NOT NULL,
        role ENUM('user','assistant','system') NOT NULL,
        content TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        INDEX idx_session (session_id),
        INDEX idx_user (user_id, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

// 聊天
if ($method === 'POST' && $action === 'chat') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $message = trim($input['message'] ?? '');
    $session_id = $input['session_id'] ?? '';
    
    if (empty($message)) {
        json_response(['error' => '消息不能为空'], 400);
    }
    if (strlen($message) > 2000) {
        json_response(['error' => '消息太长，最多2000字'], 400);
    }
    if (empty($session_id)) {
        $session_id = 'sess_' . bin2hex(random_bytes(8));
    }
    
    // 检查余额并扣费（先事务外确保钱包存在）
    ensure_ai_wallet($pdo, $uid);
    
    $pdo->beginTransaction();
    try {
        $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'points' FOR UPDATE");
        $stmt->execute([$uid]);
        $row = $stmt->fetch();
        if (!$row) { $pdo->rollBack(); json_response(['error' => '钱包初始化失败'], 500); }
        
        if ((int)$row['balance'] < AI_COST_PER_REPLY) {
            $pdo->rollBack();
            json_response(['error' => '积分不足，当前 ' . (int)$row['balance'] . '，每次回复需 ' . AI_COST_PER_REPLY . ' 积分。请先到赌场签到或兑换积分。'], 400);
        }
        
        // 扣费
        $stmt = $pdo->prepare("UPDATE user_wallets SET balance = balance - ? WHERE user_id = ? AND currency = 'points'");
        $stmt->execute([AI_COST_PER_REPLY, $uid]);
        
        // 保存用户消息
        save_ai_message($pdo, $session_id, $uid, 'user', $message);
        
        // 获取历史
        $history = get_conversation_history($pdo, $uid, $session_id);
        
        // 组装请求
        $messages = [['role' => 'system', 'content' => $SYSTEM_PROMPT]];
        foreach ($history as $h) {
            if ($h['role'] === 'user' || $h['role'] === 'assistant') {
                $messages[] = ['role' => $h['role'], 'content' => $h['content']];
            }
        }
        
        // 模型回退：逐个尝试，直到成功
        $reply = '';
        $last_err = '';
        $success = false;

        foreach (AI_MODELS as $model) {
            $payload = [
                'model' => $model,
                'messages' => $messages,
                'temperature' => 0.8,
                'max_tokens' => 500,
            ];

            $ch = curl_init(AI_API_URL);
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Authorization: Bearer ' . AI_API_KEY,
                ],
            ]);

            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $curl_error = curl_error($ch);
            curl_close($ch);

            if ($response === false) {
                $last_err = "连接失败 ({$model}): " . $curl_error;
                continue;
            }

            $result = json_decode($response, true);

            if ($http_code !== 200 || !is_array($result)) {
                $err_msg = is_array($result) && isset($result['error']['message']) ? $result['error']['message'] : $response;
                $last_err = "{$model}: HTTP {$http_code} - " . $err_msg;
                continue;
            }

            $reply = trim($result['choices'][0]['message']['content'] ?? '');
            if (!empty($reply)) {
                $success = true;
                break;
            }

            $last_err = "{$model}: 返回空内容";
        }

        if (!$success) {
            $pdo->rollBack();
            json_response(['error' => '所有模型均失败: ' . $last_err], 500);
        }
        
        // 保存 AI 回复
        save_ai_message($pdo, $session_id, $uid, 'assistant', $reply);
        
        // 记录交易
        $stmt = $pdo->prepare("INSERT INTO point_transactions (from_user_id, to_user_id, currency, amount, type, memo) VALUES (?, NULL, 'points', ?, 'ai', ?)");
        $stmt->execute([$uid, AI_COST_PER_REPLY, "AI 助手回复（{$session_id}）"]);
        
        // 更新余额
        $new_balance = (int)$row['balance'] - AI_COST_PER_REPLY;
        
        $pdo->commit();
        
        json_response([
            'reply' => $reply,
            'session_id' => $session_id,
            'cost' => AI_COST_PER_REPLY,
            'balance' => $new_balance,
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        json_response(['error' => 'AI 服务异常: ' . $e->getMessage()], 500);
    }
}

// 获取余额
if ($method === 'GET' && $action === 'balance') {
    ensure_ai_wallet($pdo, $uid);
    $stmt = $pdo->prepare("SELECT balance FROM user_wallets WHERE user_id = ? AND currency = 'points'");
    $stmt->execute([$uid]);
    $row = $stmt->fetch();
    $balance = $row ? (int)$row['balance'] : 0;
    json_response(['balance' => $balance, 'cost_per_reply' => AI_COST_PER_REPLY, 'can_use' => $balance >= AI_COST_PER_REPLY]);
}

// 获取对话历史
if ($method === 'GET' && $action === 'history') {
    $session_id = $_GET['session_id'] ?? '';
    if (empty($session_id)) {
        json_response(['messages' => []]);
    }
    $stmt = $pdo->prepare("SELECT role, content, created_at FROM ai_messages WHERE session_id = ? AND user_id = ? ORDER BY created_at ASC LIMIT 100");
    $stmt->execute([$session_id, $uid]);
    json_response(['messages' => $stmt->fetchAll()]);
}

// 新对话
if ($method === 'GET' && $action === 'new_session') {
    $session_id = 'sess_' . bin2hex(random_bytes(8));
    json_response(['session_id' => $session_id]);
}

json_response(['error' => '未知操作'], 400);
