<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../functions.php';
$pdo = db_connect();
$user = require_auth();

// Ensure core tables exist
$missing = [];
$stmt = $pdo->query("SHOW TABLES LIKE 'messages'");
if (!$stmt->fetch()) $missing[] = 'messages';
$stmt = $pdo->query("SHOW TABLES LIKE 'groups'");
if (!$stmt->fetch()) $missing[] = 'groups';
if ($missing) {
    json_response(['error' => '缺少数据表: ' . implode(', ', $missing) . '，请运行 install.php'], 500);
}

function message_column_exists($pdo, $column) {
    static $cache = [];
    $key = 'messages.' . $column;
    if (!isset($cache[$key])) {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'messages' AND column_name = ?");
        $stmt->execute([$column]);
        $cache[$key] = (bool)$stmt->fetchColumn();
    }
    return $cache[$key];
}

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST' && $action === 'send') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $to = (int)($input['to'] ?? 0);           // private: friend_id
    $group_id = (int)($input['group_id'] ?? 0); // group: group_id
    $type = $input['type'] ?? 'text';
    $content = trim($input['content'] ?? '');
    $file_path = trim($input['file_path'] ?? '');

    if ($type === 'text' && empty($content)) {
        json_response(['error' => '消息内容不能为空'], 400);
    }

    if ($to > 0 && $group_id > 0) {
        json_response(['error' => '私聊和群聊不能同时指定'], 400);
    }
    if ($to === 0 && $group_id === 0) {
        json_response(['error' => '请指定接收者或群组'], 400);
    }

    if ($to > 0) {
        $stmt = $pdo->prepare("SELECT status FROM friendships WHERE ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)) AND status = 'accepted' LIMIT 1");
        $stmt->execute([$user['id'], $to, $to, $user['id']]);
        if (!$stmt->fetch()) {
            json_response(['error' => '你们还不是好友，无法发送消息'], 403);
        }
    }

    if ($group_id > 0 && $group_id !== 1) {
        $stmt = $pdo->prepare("SELECT role FROM group_members WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$group_id, $user['id']]);
        if (!$stmt->fetch()) {
            json_response(['error' => '你不在该群组中'], 403);
        }
    }

    if ($type === 'text' && $content !== '') {
        $stmt = $pdo->query("SELECT word FROM sensitive_words");
        $words = $stmt->fetchAll(PDO::FETCH_COLUMN);
        if ($words) {
            $found = array_filter($words, function($w) use ($content) {
                return $w !== '' && stripos($content, $w) !== false;
            });
            if (!empty($found)) {
                json_response(['error' => '内容包含敏感词，请修改后发送'], 400);
            }
        }
    }

    $stmt = $pdo->prepare("INSERT INTO messages (sender_id, receiver_id, group_id, type, content, file_path) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$user['id'], $to > 0 ? $to : null, $group_id > 0 ? $group_id : null, $type, $content, $file_path ?: null]);
    $msg_id = $pdo->lastInsertId();
    record_task($pdo, $user['id'], 'chat');

    $stmt = $pdo->prepare("SELECT m.*, u.username, u.nickname FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.id = ?");
    $stmt->execute([$msg_id]);
    $msg = $stmt->fetch();

    json_response(['message' => format_message($msg, $user['id'])]);
}

if ($method === 'GET' && $action === 'history') {
    $with = (int)($_GET['with'] ?? 0);       // private: friend_id
    $group_id = (int)($_GET['group_id'] ?? 0);
    $page = (int)($_GET['page'] ?? 1);
    [$page, $per_page, $offset] = paginate($page, 30);

    if ($with > 0 && $group_id > 0) {
        json_response(['error' => '参数冲突'], 400);
    }

    if ($with > 0) {
        // Mark as read
        if (message_column_exists($pdo, 'is_read')) {
            $stmt = $pdo->prepare("UPDATE messages SET is_read = 1 WHERE receiver_id = ? AND sender_id = ? AND is_read = 0");
            $stmt->execute([$user['id'], $with]);
        }

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM messages WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)) AND is_recall = 0");
        $stmt->execute([$user['id'], $with, $with, $user['id']]);
        $total = (int)$stmt->fetchColumn();
        $pages = max(1, (int)ceil($total / $per_page));

        $stmt = $pdo->prepare("SELECT m.*, u.username, u.nickname, u.avatar_frame FROM messages m JOIN users u ON u.id = m.sender_id WHERE ((m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?)) AND m.is_recall = 0 ORDER BY m.created_at DESC LIMIT $offset, $per_page");
        $stmt->execute([$user['id'], $with, $with, $user['id']]);
    } elseif ($group_id > 0) {
        if ($group_id !== 1) {
            $stmt = $pdo->prepare("SELECT role FROM group_members WHERE group_id = ? AND user_id = ?");
            $stmt->execute([$group_id, $user['id']]);
            if (!$stmt->fetch()) {
                json_response(['error' => '无权访问'], 403);
            }
        }

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM messages WHERE group_id = ? AND is_recall = 0");
        $stmt->execute([$group_id]);
        $total = (int)$stmt->fetchColumn();
        $pages = max(1, (int)ceil($total / $per_page));

        $stmt = $pdo->prepare("SELECT m.*, u.username, u.nickname, u.avatar_frame FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.group_id = ? AND m.is_recall = 0 ORDER BY m.created_at DESC LIMIT $offset, $per_page");
        $stmt->execute([$group_id]);
    } else {
        json_response(['error' => '缺少参数'], 400);
    }

    $messages = [];
    while ($row = $stmt->fetch()) {
        $messages[] = $row;
    }

    if ($messages) {
        $ids = array_column($messages, 'id');
        $in = implode(',', array_map('intval', $ids));
        $stmt = $pdo->query("SELECT message_id, emoji, COUNT(*) AS count, GROUP_CONCAT(nickname SEPARATOR ',') AS users FROM message_reactions mr JOIN users u ON u.id = mr.user_id WHERE message_id IN ($in) GROUP BY message_id, emoji");
        $reactionMap = [];
        while ($row = $stmt->fetch()) {
            $reactionMap[$row['message_id']][] = [
                'emoji' => $row['emoji'],
                'count' => (int)$row['count'],
                'users' => $row['users'] ? explode(',', $row['users']) : []
            ];
        }
        $chatType = $with > 0 ? 'private' : 'group';
        $chatId = $with > 0 ? $with : $group_id;
        $pinnedSet = [];
        if ($with > 0 || $group_id > 0) {
            $stmt = $pdo->prepare("SELECT message_id FROM pinned_messages WHERE chat_type = ? AND chat_id = ?");
            $stmt->execute([$chatType, $chatId]);
            while ($row = $stmt->fetch()) $pinnedSet[(int)$row['message_id']] = true;
        }
        foreach ($messages as $i => $row) {
            $row['reactions'] = $reactionMap[$row['id']] ?? [];
            $row['pinned'] = isset($pinnedSet[$row['id']]);
            $messages[$i] = format_message($row, $user['id']);
        }
    }

    json_response(['messages' => array_reverse($messages), 'pages' => $pages, 'page' => $page, 'total' => $total]);
}

if ($method === 'POST' && $action === 'read') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    if (message_column_exists($pdo, 'is_read')) {
        $msg_id = (int)($input['message_id'] ?? 0);
        if ($msg_id > 0) {
            $stmt = $pdo->prepare("UPDATE messages SET is_read = 1 WHERE id = ? AND receiver_id = ?");
            $stmt->execute([$msg_id, $user['id']]);
        } else {
            $with = (int)($input['with'] ?? 0);
            $group_id = (int)($input['group_id'] ?? 0);
            if ($with > 0) {
                $stmt = $pdo->prepare("UPDATE messages SET is_read = 1 WHERE receiver_id = ? AND sender_id = ? AND is_read = 0");
                $stmt->execute([$user['id'], $with]);
            } elseif ($group_id > 0) {
                $stmt = $pdo->prepare("UPDATE messages SET is_read = 1 WHERE group_id = ? AND sender_id != ? AND is_read = 0");
                $stmt->execute([$group_id, $user['id']]);
            }
        }
    }
    json_response(['success' => true]);
}

if ($method === 'POST' && $action === 'recall') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $msg_id = (int)($input['message_id'] ?? 0);
    $stmt = $pdo->prepare("SELECT sender_id, created_at FROM messages WHERE id = ?");
    $stmt->execute([$msg_id]);
    $msg = $stmt->fetch();
    if (!$msg) {
        json_response(['error' => '消息不存在'], 404);
    }
    if ($msg['sender_id'] != $user['id']) {
        json_response(['error' => '无权撤回他人消息'], 403);
    }
    if (strtotime($msg['created_at']) < time() - 120) {
        json_response(['error' => '只能撤回2分钟内的消息'], 403);
    }
    $stmt = $pdo->prepare("UPDATE messages SET is_recall = 1, recall_time = NOW() WHERE id = ?");
    $stmt->execute([$msg_id]);
    json_response(['success' => true]);
}

if ($method === 'GET' && $action === 'unread') {
    $unread = 0;
    if (message_column_exists($pdo, 'is_read')) {
        // Private messages unread
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0");
        $stmt->execute([$user['id']]);
        $unread = (int)$stmt->fetchColumn();
        // Group messages unread (not sent by me, in groups I'm a member of)
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM messages m
            WHERE m.group_id IN (SELECT group_id FROM group_members WHERE user_id = ?)
            AND m.sender_id != ? AND m.is_read = 0
        ");
        $stmt->execute([$user['id'], $user['id']]);
        $unread += (int)$stmt->fetchColumn();
    }
    json_response(['unread' => $unread]);
}

if ($method === 'POST' && $action === 'reaction') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $msg_id = (int)($input['message_id'] ?? 0);
    $emoji = trim((string)($input['emoji'] ?? ''));
    $remove = !empty($input['remove']);

    if ($msg_id <= 0 || $emoji === '') {
        json_response(['error' => '参数无效'], 400);
    }

    $stmt = $pdo->prepare("SELECT sender_id, receiver_id, group_id FROM messages WHERE id = ?");
    $stmt->execute([$msg_id]);
    $msg = $stmt->fetch();
    if (!$msg) {
        json_response(['error' => '消息不存在'], 404);
    }

    $allowed = false;
    if ($msg['sender_id'] == $user['id']) $allowed = true;
    if ($msg['receiver_id'] == $user['id']) $allowed = true;
    if ($msg['group_id'] && $msg['group_id'] !== 1) {
        $stmt = $pdo->prepare("SELECT role FROM group_members WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$msg['group_id'], $user['id']]);
        if ($stmt->fetch()) $allowed = true;
    }
    if ($msg['group_id'] == 1) $allowed = true;
    if (!$allowed) json_response(['error' => '无权操作'], 403);

    if ($remove) {
        $stmt = $pdo->prepare("DELETE FROM message_reactions WHERE message_id = ? AND user_id = ? AND emoji = ?");
        $stmt->execute([$msg_id, $user['id'], $emoji]);
    } else {
        $stmt = $pdo->prepare("INSERT IGNORE INTO message_reactions (message_id, user_id, emoji) VALUES (?, ?, ?)");
        $stmt->execute([$msg_id, $user['id'], $emoji]);
    }

    $stmt = $pdo->prepare("
        SELECT mr.emoji, COUNT(*) AS count, GROUP_CONCAT(u.nickname SEPARATOR ',') AS users
        FROM message_reactions mr
        JOIN users u ON u.id = mr.user_id
        WHERE mr.message_id = ?
        GROUP BY mr.emoji
    ");
    $stmt->execute([$msg_id]);
    $reactions = [];
    while ($row = $stmt->fetch()) {
        $reactions[] = [
            'emoji' => $row['emoji'],
            'count' => (int)$row['count'],
            'users' => $row['users'] ? explode(',', $row['users']) : []
        ];
    }
    json_response(['reactions' => $reactions]);
}

if ($method === 'POST' && $action === 'pin') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $msg_id = (int)($input['message_id'] ?? 0);
    $chat_type = $input['chat_type'] ?? '';
    $chat_id = (int)($input['chat_id'] ?? 0);
    $remove = !empty($input['remove']);

    if ($msg_id <= 0 || !in_array($chat_type, ['private','group','world'], true) || $chat_id <= 0) {
        json_response(['error' => '参数无效'], 400);
    }

    if ($chat_type === 'private') {
        $stmt = $pdo->prepare("SELECT id FROM friendships WHERE ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)) AND status = 'accepted' LIMIT 1");
        $stmt->execute([$user['id'], $chat_id, $chat_id, $user['id']]);
        if (!$stmt->fetch()) json_response(['error' => '无权操作'], 403);
    } elseif ($chat_type === 'group') {
        $stmt = $pdo->prepare("SELECT role FROM group_members WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$chat_id, $user['id']]);
        if (!$stmt->fetch()) json_response(['error' => '无权操作'], 403);
    }

    if ($remove) {
        $stmt = $pdo->prepare("DELETE FROM pinned_messages WHERE chat_type = ? AND chat_id = ? AND message_id = ?");
        $stmt->execute([$chat_type, $chat_id, $msg_id]);
    } else {
        $stmt = $pdo->prepare("INSERT IGNORE INTO pinned_messages (chat_type, chat_id, message_id, pinned_by) VALUES (?, ?, ?, ?)");
        $stmt->execute([$chat_type, $chat_id, $msg_id, $user['id']]);
    }

    $stmt = $pdo->prepare("
        SELECT pm.id, pm.message_id, pm.pinned_by, pm.pinned_at, u.nickname, m.content, m.type, m.file_path, m.sender_id
        FROM pinned_messages pm
        JOIN messages m ON m.id = pm.message_id
        JOIN users u ON u.id = pm.pinned_by
        WHERE pm.chat_type = ? AND pm.chat_id = ?
        ORDER BY pm.pinned_at DESC
    ");
    $stmt->execute([$chat_type, $chat_id]);
    $pinned = [];
    while ($row = $stmt->fetch()) {
        $pinned[] = [
            'id' => (int)$row['id'],
            'message_id' => (int)$row['message_id'],
            'pinned_by' => (int)$row['pinned_by'],
            'pinned_at' => $row['pinned_at'],
            'nickname' => $row['nickname'],
            'content' => $row['content'],
            'type' => $row['type'],
            'file_path' => $row['file_path'],
            'sender_id' => (int)$row['sender_id']
        ];
    }
    json_response(['pinned' => $pinned]);
}

if ($method === 'POST' && $action === 'typing') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $chat_type = $input['chat_type'] ?? '';
    $chat_id = (int)($input['chat_id'] ?? 0);
    $cacheFile = sys_get_temp_dir() . '/chatx_typing_' . md5($chat_type . '_' . $chat_id) . '.json';
    $data = ['user_id' => $user['id'], 'nickname' => $user['nickname'] ?? '', 'ts' => time()];
    file_put_contents($cacheFile, json_encode($data));
    json_response(['success' => true]);
}

if ($method === 'GET' && $action === 'typing') {
    $chat_type = $_GET['chat_type'] ?? '';
    $chat_id = (int)($_GET['chat_id'] ?? 0);
    $cacheFile = sys_get_temp_dir() . '/chatx_typing_' . md5($chat_type . '_' . $chat_id) . '.json';
    if (!file_exists($cacheFile) || (time() - filemtime($cacheFile)) > 4) {
        json_response(['typing' => null]);
    }
    $data = json_decode(file_get_contents($cacheFile), true);
    if (!$data || ($data['user_id'] ?? 0) == $user['id']) {
        json_response(['typing' => null]);
    }
    json_response(['typing' => ['user_id' => (int)$data['user_id'], 'nickname' => $data['nickname'] ?? '']]);
}

if ($method === 'POST' && $action === 'forward') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $message_id = (int)($input['message_id'] ?? 0);
    $to = (int)($input['to'] ?? 0);
    $group_id = (int)($input['group_id'] ?? 0);

    if ($message_id <= 0 || ($to <= 0 && $group_id <= 0)) {
        json_response(['error' => '参数无效'], 400);
    }

    $stmt = $pdo->prepare("SELECT * FROM messages WHERE id = ?");
    $stmt->execute([$message_id]);
    $src = $stmt->fetch();
    if (!$src) json_response(['error' => '消息不存在'], 404);

    if ($to > 0) {
        $stmt = $pdo->prepare("SELECT status FROM friendships WHERE ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)) AND status = 'accepted' LIMIT 1");
        $stmt->execute([$user['id'], $to, $to, $user['id']]);
        if (!$stmt->fetch()) json_response(['error' => '你们还不是好友'], 403);
    }
    if ($group_id > 0 && $group_id !== 1) {
        $stmt = $pdo->prepare("SELECT role FROM group_members WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$group_id, $user['id']]);
        if (!$stmt->fetch()) json_response(['error' => '你不在该群组中'], 403);
    }

    $forward_note = '[转发] ' . ($src['type'] === 'text' ? $src['content'] : ('[' . $src['type'] . ']'));
    $stmt = $pdo->prepare("INSERT INTO messages (sender_id, receiver_id, group_id, type, content, file_path, extra) VALUES (?, ?, ?, 'text', ?, ?, ?)");
    $stmt->execute([
        $user['id'],
        $to > 0 ? $to : null,
        $group_id > 0 ? $group_id : null,
        mb_strlen($forward_note) > 200 ? mb_substr($forward_note, 0, 200) . '...' : $forward_note,
        $src['file_path'],
        json_encode(['forward_from_message_id' => (int)$src['id'], 'forward_from_sender_id' => (int)$src['sender_id']], JSON_UNESCAPED_UNICODE)
    ]);
    $msg_id = $pdo->lastInsertId();
    $stmt = $pdo->prepare("SELECT m.*, u.username, u.nickname FROM messages m JOIN users u ON u.id = m.sender_id WHERE m.id = ?");
    $stmt->execute([$msg_id]);
    $msg = $stmt->fetch();
    json_response(['message' => format_message($msg, $user['id'])]);
}

// ============ 消息搜索 ============
if ($method === 'GET' && $action === 'search') {
    $q = trim($_GET['q'] ?? '');
    $scope = $_GET['scope'] ?? 'all'; // all | private | group
    $limit = min(50, max(1, (int)($_GET['limit'] ?? 20)));
    if (mb_strlen($q) < 1) json_response(['error' => '请输入搜索关键词'], 400);
    
    $conditions = ["m.is_recall = 0"];
    $params = [];
    
    if ($scope === 'private') {
        $conditions[] = "(m.sender_id = ? OR m.receiver_id = ?) AND m.group_id IS NULL";
        $params[] = $uid; $params[] = $uid;
    } elseif ($scope === 'group') {
        $conditions[] = "m.group_id IS NOT NULL";
        // Only groups the user belongs to
        $conditions[] = "m.group_id IN (SELECT group_id FROM group_members WHERE user_id = ?)";
        $params[] = $uid;
    }
    
    $conditions[] = "m.content LIKE ?";
    $params[] = '%' . $q . '%';
    
    $where = implode(' AND ', $conditions);
    $sql = "SELECT m.*, u.username, u.nickname FROM messages m 
            JOIN users u ON u.id = m.sender_id 
            WHERE $where 
            ORDER BY m.created_at DESC 
            LIMIT $limit";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    $results = [];
    foreach ($stmt->fetchAll() as $row) {
        $results[] = [
            'id' => (int)$row['id'],
            'sender_name' => $row['nickname'] ?: $row['username'],
            'content' => mb_substr($row['content'], 0, 200),
            'type' => $row['type'],
            'is_me' => (int)$row['sender_id'] === $uid,
            'group_id' => $row['group_id'] ? (int)$row['group_id'] : null,
            'receiver_id' => $row['receiver_id'] ? (int)$row['receiver_id'] : null,
            'created_at' => $row['created_at'],
            'chat_type' => $row['group_id'] ? 'group' : 'private',
        ];
    }
    json_response(['results' => $results, 'total' => count($results)]);
}

json_response(['error' => '未知操作'], 400);

function format_message($msg, $current_user_id) {
    $is_me = $msg['sender_id'] == $current_user_id;
    return [
        'id' => (int)$msg['id'],
        'sender_id' => (int)$msg['sender_id'],
        'receiver_id' => $msg['receiver_id'] ? (int)$msg['receiver_id'] : null,
        'group_id' => $msg['group_id'] ? (int)$msg['group_id'] : null,
        'type' => $msg['type'],
        'content' => $msg['content'],
        'file_path' => $msg['file_path'],
        'is_me' => $is_me,
        'is_recall' => (bool)$msg['is_recall'],
        'is_read' => !empty($msg['is_read']),
        'created_at' => $msg['created_at'],
        'formatted_time' => format_message_time($msg['created_at']),
        'sender_name' => $is_me ? '' : ($msg['nickname'] ?: $msg['username']),
        'avatar_frame' => $msg['avatar_frame'] ?? null,
        'reactions' => $msg['reactions'] ?? [],
        'pinned' => !empty($msg['pinned']),
        'forward_from_message_id' => $msg['forward_from_message_id'] ?? null
    ];
}
