<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../functions.php';
$pdo = db_connect();
$user = require_auth();

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

// 权限函数已移至 functions.php

if ($method === 'GET' && $action === 'search') {
    $q = trim($_GET['q'] ?? '');
    if (strlen($q) < 2) {
        json_response(['error' => '搜索关键词至少2个字符'], 400);
    }
    $stmt = $pdo->prepare("SELECT id, username, nickname, avatar, avatar_frame, status, last_seen FROM users WHERE (username LIKE ? OR nickname LIKE ?) AND id != ? LIMIT 20");
    $stmt->execute(["%$q%", "%$q%", $user['id']]);
    $results = [];
    while ($row = $stmt->fetch()) {
        $results[] = [
            'id' => (int)$row['id'],
            'username' => $row['username'],
            'nickname' => $row['nickname'],
            'avatar' => $row['avatar'],
            'avatar_frame' => $row['avatar_frame'],
            'status' => $row['status'],
            'last_seen' => format_time($row['last_seen'])
        ];
    }
    json_response(['users' => $results]);
}

if ($method === 'GET' && $action === 'list') {
    $type = $_GET['type'] ?? 'friends'; // friends, requests, online

    if ($type === 'friends') {
        $stmt = $pdo->prepare("
            SELECT u.id, u.username, u.nickname, u.avatar, u.avatar_frame, u.status, u.last_seen,
                   (SELECT content FROM messages WHERE (sender_id = ? AND receiver_id = u.id) OR (sender_id = u.id AND receiver_id = ?) ORDER BY created_at DESC LIMIT 1) as last_msg,
                   (SELECT created_at FROM messages WHERE (sender_id = ? AND receiver_id = u.id) OR (sender_id = u.id AND receiver_id = ?) ORDER BY created_at DESC LIMIT 1) as last_time,
                   (SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND sender_id = u.id AND is_read = 0) as unread_cnt
            FROM users u
            JOIN friendships f ON (
                (f.user_id = ? AND u.id = f.friend_id) OR
                (f.friend_id = ? AND u.id = f.user_id)
            )
            WHERE f.status = 'accepted'
            ORDER BY COALESCE((SELECT MAX(created_at) FROM messages WHERE (sender_id = ? AND receiver_id = u.id) OR (sender_id = u.id AND receiver_id = ?)), '1970-01-01 00:00:00') DESC, u.last_seen DESC
        ");
        $stmt->execute([$user['id'], $user['id'], $user['id'], $user['id'], $user['id'], $user['id'], $user['id'], $user['id'], $user['id']]);
        $friends = [];
        while ($row = $stmt->fetch()) {
            $friends[] = [
                'id' => (int)$row['id'],
                'username' => $row['username'],
                'nickname' => $row['nickname'],
                'avatar' => $row['avatar'],
                'avatar_frame' => $row['avatar_frame'],
                'status' => $row['status'],
                'last_seen' => format_time($row['last_seen']),
                'last_message' => $row['last_msg'] ?: '点击开始聊天',
                'last_time' => $row['last_time'] ? format_message_time($row['last_time']) : '',
                'unread' => (int)$row['unread_cnt']
            ];
        }
        json_response(['friends' => $friends]);
    }

    if ($type === 'requests') {
        $stmt = $pdo->prepare("
            SELECT f.id, f.user_id, u.username, u.nickname, u.avatar, u.avatar_frame, u.status, f.created_at
            FROM friendships f
            JOIN users u ON u.id = f.user_id
            WHERE f.friend_id = ? AND f.status = 'pending'
            ORDER BY f.created_at DESC
        ");
        $stmt->execute([$user['id']]);
        $requests = [];
        while ($row = $stmt->fetch()) {
            $requests[] = [
                'id' => (int)$row['id'],
                'user_id' => (int)$row['user_id'],
                'username' => $row['username'],
                'nickname' => $row['nickname'],
                'avatar' => $row['avatar'],
                'avatar_frame' => $row['avatar_frame'],
                'avatar_frame' => $row['avatar_frame'],
                'status' => $row['status'],
                'created_at' => format_time($row['created_at'])
            ];
        }
        json_response(['requests' => $requests]);
    }

    if ($type === 'online') {
        $stmt = $pdo->prepare("
            SELECT u.id, u.username, u.nickname, u.avatar, u.status, u.last_seen
            FROM friendships f
            JOIN users u ON u.id = CASE WHEN f.user_id = ? THEN f.friend_id ELSE f.user_id END
            WHERE (f.user_id = ? OR f.friend_id = ?) AND f.status = 'accepted' AND u.status = 'online'
            ORDER BY u.last_seen DESC
        ");
        $stmt->execute([$user['id'], $user['id'], $user['id']]);
        $online = [];
        while ($row = $stmt->fetch()) {
            $online[] = [
                'id' => (int)$row['id'],
                'username' => $row['username'],
                'nickname' => $row['nickname'],
                'avatar' => $row['avatar'],
                'avatar_frame' => $row['avatar_frame'],
                'status' => $row['status'],
                'last_seen' => format_time($row['last_seen'])
            ];
        }
        json_response(['online' => $online]);
    }

    json_response(['error' => '未知类型'], 400);
}

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;

    if ($action === 'add') {
        $friend_id = (int)($input['friend_id'] ?? 0);
        if ($friend_id <= 0) {
            json_response(['error' => '无效的用户ID'], 400);
        }
        if ($friend_id == $user['id']) {
            json_response(['error' => '不能添加自己为好友'], 400);
        }

        $stmt = $pdo->prepare("SELECT id FROM friendships WHERE ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?))");
        $stmt->execute([$user['id'], $friend_id, $friend_id, $user['id']]);
        if ($stmt->fetch()) {
            json_response(['error' => '好友关系已存在'], 409);
        }

        $stmt = $pdo->prepare("INSERT INTO friendships (user_id, friend_id, status) VALUES (?, ?, 'pending')");
        $stmt->execute([$user['id'], $friend_id]);

        // Notification
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, type, title, content, related_id) VALUES (?, 'friend_request', ?, ?, ?)");
        $stmt->execute([$friend_id, '新的好友请求', $user['nickname'] . ' (' . $user['username'] . ') 请求添加你为好友', $user['id']]);

        json_response(['success' => true, 'message' => '好友请求已发送']);
    }

    if ($action === 'accept') {
        $request_id = (int)($input['request_id'] ?? 0);
        $stmt = $pdo->prepare("SELECT * FROM friendships WHERE id = ? AND friend_id = ? AND status = 'pending'");
        $stmt->execute([$request_id, $user['id']]);
        $req = $stmt->fetch();
        if (!$req) {
            json_response(['error' => '请求不存在'], 404);
        }

        $pdo->beginTransaction();
        $stmt = $pdo->prepare("UPDATE friendships SET status = 'accepted' WHERE id = ?");
        $stmt->execute([$request_id]);

        $pdo->commit();
        record_task($pdo, $user['id'], 'friend');
        json_response(['success' => true, 'message' => '已接受好友请求']);
    }

    if ($action === 'reject') {
        $request_id = (int)($input['request_id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM friendships WHERE id = ? AND friend_id = ? AND status = 'pending'");
        $stmt->execute([$request_id]);
        json_response(['success' => true, 'message' => '已拒绝好友请求']);
    }

    if ($action === 'remove') {
        $friend_id = (int)($input['friend_id'] ?? 0);
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("DELETE FROM friendships WHERE ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?))");
        $stmt->execute([$user['id'], $friend_id, $friend_id, $user['id']]);
        $pdo->commit();
        json_response(['success' => true, 'message' => '好友已删除']);
    }

    if ($action === 'status') {
        $status = $input['status'] ?? '';
        $allowed = ['online', 'offline', 'away', 'busy'];
        if (!in_array($status, $allowed, true)) {
            json_response(['error' => '无效状态'], 400);
        }
        $stmt = $pdo->prepare("UPDATE users SET status = ?, last_seen = NOW() WHERE id = ?");
        $stmt->execute([$status, $user['id']]);
        json_response(['success' => true, 'status' => $status]);
    }

    if ($method === 'POST' && $action === 'upload_avatar') {
        if (!isset($_FILES['avatar'])) {
            json_response(['error' => '请选择图片文件'], 400);
        }
        $file = $_FILES['avatar'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            json_response(['error' => '文件上传失败，错误码: ' . $file['error']], 400);
        }
        $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        if (!in_array($mime, $allowed, true)) {
            json_response(['error' => '仅支持 JPG/PNG/GIF/WebP 格式'], 400);
        }
        if ($file['size'] > 2 * 1024 * 1024) {
            json_response(['error' => '图片大小不能超过 2MB'], 400);
        }
        $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp'][$mime];
        $filename = 'avatar_' . $user['id'] . '_' . time() . '.' . $ext;
        $dst = __DIR__ . '/../uploads/avatars/' . $filename;
        if (!move_uploaded_file($file['tmp_name'], $dst)) {
            json_response(['error' => '文件保存失败，请检查目录权限'], 500);
        }
        $old = $user['avatar'] ?? '';
        if ($old && $old !== 'default.png' && file_exists(__DIR__ . '/../uploads/avatars/' . $old)) {
            @unlink(__DIR__ . '/../uploads/avatars/' . $old);
        }
        $stmt = $pdo->prepare("UPDATE users SET avatar = ? WHERE id = ?");
        $stmt->execute([$filename, $user['id']]);
        $_SESSION['avatar'] = $filename;
        json_response(['avatar' => 'uploads/avatars/' . $filename, 'message' => '头像已更新']);
    }
}

// Admin actions
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_stats') {
    require_admin_permission($user, 'manage_users');

    $stats = [];
    $stats['users'] = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $stats['groups'] = (int)$pdo->query("SELECT COUNT(*) FROM `groups`")->fetchColumn();
    $stats['messages'] = (int)$pdo->query("SELECT COUNT(*) FROM messages")->fetchColumn();
    $stats['online'] = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE status = 'online'")->fetchColumn();
    $stats['friendships'] = (int)$pdo->query("SELECT COUNT(*) FROM friendships WHERE status = 'accepted'")->fetchColumn();

    json_response(['stats' => $stats]);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_users') {
    require_admin_permission($user, 'manage_users');

    $page = (int)($_GET['page'] ?? 1);
    [$page, $per_page, $offset] = paginate($page, 20);

    $stmt = $pdo->prepare("SELECT id, username, nickname, role, status, last_seen, created_at, signature, bio FROM users ORDER BY created_at DESC LIMIT $offset, $per_page");
    $stmt->execute();
    $users = [];
    while ($row = $stmt->fetch()) {
        $users[] = [
            'id' => (int)$row['id'],
            'username' => $row['username'],
            'nickname' => $row['nickname'],
            'role' => $row['role'],
            'status' => $row['status'],
            'last_seen' => format_time($row['last_seen']),
            'created_at' => $row['created_at'],
            'signature' => $row['signature'] ?: '',
            'bio' => $row['bio'] ?: ''
        ];
    }

    $total = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $pages = max(1, (int)ceil($total / $per_page));

    json_response(['users' => $users, 'pages' => $pages, 'page' => $page, 'total' => $total]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_delete_user') {
    require_admin_permission($user, 'manage_users');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $target_id = (int)($input['user_id'] ?? 0);

    if ($target_id <= 0) {
        json_response(['error' => '无效的用户ID'], 400);
    }
    if ($target_id == $user['id']) {
        json_response(['error' => '不能删除自己'], 400);
    }

    $pdo->beginTransaction();
    $pdo->exec("DELETE FROM sessions WHERE user_id = $target_id");
    $pdo->exec("DELETE FROM messages WHERE sender_id = $target_id OR receiver_id = $target_id");
    $pdo->exec("DELETE FROM friendships WHERE user_id = $target_id OR friend_id = $target_id");
    $pdo->exec("DELETE FROM group_members WHERE user_id = $target_id");
    $pdo->exec("DELETE FROM users WHERE id = $target_id");
    $pdo->commit();

    json_response(['success' => true, 'message' => '用户已删除']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_ban_user') {
    require_admin_permission($user, 'manage_users');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $target_id = (int)($input['user_id'] ?? 0);
    $days = (int)($input['days'] ?? 7);

    if ($target_id <= 0) {
        json_response(['error' => '无效的用户ID'], 400);
    }
    if ($target_id == $user['id']) {
        json_response(['error' => '不能封禁自己'], 400);
    }

    $until = date('Y-m-d H:i:s', time() + $days * 86400);
    $stmt = $pdo->prepare("UPDATE users SET status = 'banned' WHERE id = ?");
    $stmt->execute([$target_id]);

    json_response(['success' => true, 'message' => "用户已封禁 {$days} 天", 'until' => $until]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_unban_user') {
    require_admin_permission($user, 'manage_users');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $target_id = (int)($input['user_id'] ?? 0);

    if ($target_id <= 0) {
        json_response(['error' => '无效的用户ID'], 400);
    }

    $stmt = $pdo->prepare("UPDATE users SET status = 'online' WHERE id = ?");
    $stmt->execute([$target_id]);

    json_response(['success' => true, 'message' => '用户已解封']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_update_feedback_status') {
    require_admin_permission($user, 'manage_feedbacks');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $id = (int)($input['id'] ?? 0);
    $status = $input['status'] ?? '';

    if ($id <= 0 || !in_array($status, ['pending','processing','resolved','closed'], true)) {
        json_response(['error' => '参数无效'], 400);
    }

    $stmt = $pdo->prepare("UPDATE feedbacks SET status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$status, $id]);

    json_response(['success' => true, 'message' => '状态已更新']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_import_sensitive_words') {
    require_admin_permission($user, 'manage_sensitive_words');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $words = explode("\n", trim($input['words'] ?? ''));
    $category = trim($input['category'] ?? 'custom');

    $count = 0;
    $stmt = $pdo->prepare("INSERT IGNORE INTO sensitive_words (word, category, created_by) VALUES (?, ?, ?)");
    foreach ($words as $w) {
        $w = trim($w);
        if ($w === '') continue;
        $stmt->execute([$w, $category, $user['id']]);
        $count++;
    }

    json_response(['success' => true, 'message' => "已导入 {$count} 个敏感词"]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_delete_message') {
    require_admin_permission($user, 'view_messages');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $message_id = (int)($input['message_id'] ?? 0);

    if ($message_id <= 0) {
        json_response(['error' => '无效的消息ID'], 400);
    }

    $stmt = $pdo->prepare("DELETE FROM messages WHERE id = ?");
    $stmt->execute([$message_id]);

    json_response(['success' => true, 'message' => '消息已删除']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_recall_message') {
    require_admin_permission($user, 'view_messages');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $message_id = (int)($input['message_id'] ?? 0);

    if ($message_id <= 0) {
        json_response(['error' => '无效的消息ID'], 400);
    }

    $stmt = $pdo->prepare("UPDATE messages SET is_recall = 1, recall_time = NOW() WHERE id = ?");
    $stmt->execute([$message_id]);

    json_response(['success' => true, 'message' => '消息已撤回']);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_group_members') {
    require_admin_permission($user, 'manage_groups');

    $group_id = (int)($_GET['group_id'] ?? 0);
    if ($group_id <= 0) {
        json_response(['error' => '无效的群组ID'], 400);
    }

    $stmt = $pdo->prepare("
        SELECT gm.id, gm.user_id, gm.role, gm.muted_until, gm.joined_at, u.username, u.nickname, u.status
        FROM group_members gm
        JOIN users u ON u.id = gm.user_id
        WHERE gm.group_id = ?
        ORDER BY gm.joined_at DESC
    ");
    $stmt->execute([$group_id]);
    $members = [];
    while ($row = $stmt->fetch()) {
        $members[] = [
            'id' => (int)$row['id'],
            'user_id' => (int)$row['user_id'],
            'username' => $row['username'],
            'nickname' => $row['nickname'],
            'role' => $row['role'],
            'muted_until' => $row['muted_until'],
            'joined_at' => $row['joined_at'],
            'status' => $row['status']
        ];
    }

    json_response(['members' => $members]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_remove_group_member') {
    require_admin_permission($user, 'manage_groups');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $group_id = (int)($input['group_id'] ?? 0);
    $user_id = (int)($input['user_id'] ?? 0);

    if ($group_id <= 0 || $user_id <= 0) {
        json_response(['error' => '参数无效'], 400);
    }

    $stmt = $pdo->prepare("DELETE FROM group_members WHERE group_id = ? AND user_id = ?");
    $stmt->execute([$group_id, $user_id]);

    json_response(['success' => true, 'message' => '成员已移除']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_set_role') {
    require_admin_permission($user, 'manage_roles');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $target_id = (int)($input['user_id'] ?? 0);
    $role = $input['role'] ?? '';

    if ($target_id <= 0 || !in_array($role, ['user', 'admin', 'super_admin'], true)) {
        json_response(['error' => '参数无效'], 400);
    }

    if (in_array($role, ['admin', 'super_admin'], true) && !is_super_admin($user)) {
        json_response(['error' => '仅超级管理员可授予管理员或超级管理员角色'], 403);
    }

    $stmt = $pdo->prepare("UPDATE users SET role = ? WHERE id = ?");
    $stmt->execute([$role, $target_id]);

    json_response(['success' => true, 'message' => '角色已更新']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_update_user_profile') {
    require_admin_permission($user, 'manage_users');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $target_id = (int)($input['user_id'] ?? 0);
    $nickname = trim($input['nickname'] ?? '');
    $signature = trim($input['signature'] ?? '');
    $bio = trim($input['bio'] ?? '');

    if ($target_id <= 0) {
        json_response(['error' => '无效的用户ID'], 400);
    }

    $sets = [];
    $params = [];
    if ($nickname !== '') { $sets[] = 'nickname = ?'; $params[] = $nickname; }
    if ($signature !== '') { $sets[] = 'signature = ?'; $params[] = $signature; }
    if ($bio !== '') { $sets[] = 'bio = ?'; $params[] = $bio; }
    if (!$sets) {
        json_response(['error' => '没有可更新的字段'], 400);
    }

    $params[] = $target_id;
    $sql = 'UPDATE users SET ' . implode(', ', $sets) . ' WHERE id = ?';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    json_response(['success' => true, 'message' => '用户资料已更新']);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_groups') {
    require_admin_permission($user, 'manage_groups');

    $stmt = $pdo->prepare("
        SELECT g.id, g.name, g.avatar, g.description, g.owner_id,
               (SELECT COUNT(*) FROM group_members WHERE group_id = g.id) as member_count,
               (SELECT content FROM messages WHERE group_id = g.id ORDER BY created_at DESC LIMIT 1) as last_message,
               (SELECT created_at FROM messages WHERE group_id = g.id ORDER BY created_at DESC LIMIT 1) as last_time
        FROM `groups` g
        ORDER BY last_time DESC
    ");
    $stmt->execute();
    $groups = [];
    while ($row = $stmt->fetch()) {
        $groups[] = [
            'id' => (int)$row['id'],
            'name' => $row['name'],
            'avatar' => $row['avatar'],
            'description' => $row['description'],
            'owner_id' => (int)$row['owner_id'],
            'member_count' => (int)$row['member_count'],
            'last_message' => $row['last_message'] ?: '',
            'last_time' => $row['last_time'] ? format_message_time($row['last_time']) : ''
        ];
    }
    json_response(['groups' => $groups]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_update_group') {
    require_admin_permission($user, 'manage_groups');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $group_id = (int)($input['group_id'] ?? 0);
    $name = trim($input['name'] ?? '');
    $description = trim($input['description'] ?? '');
    $is_private = !empty($input['is_private']) ? 1 : 0;

    if ($group_id <= 0 || $name === '') {
        json_response(['error' => '参数无效'], 400);
    }

    $stmt = $pdo->prepare("UPDATE `groups` SET name = ?, description = ?, is_private = ? WHERE id = ?");
    $stmt->execute([$name, $description ?: null, $is_private, $group_id]);

    json_response(['success' => true, 'message' => '群组已更新']);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_friendships') {
    require_admin_permission($user, 'manage_users');

    $stmt = $pdo->prepare("
        SELECT f.id, f.user_id, f.friend_id, f.status, f.created_at,
               u1.username as user_name, u1.nickname as user_nickname,
               u2.username as friend_name, u2.nickname as friend_nickname
        FROM friendships f
        JOIN users u1 ON u1.id = f.user_id
        JOIN users u2 ON u2.id = f.friend_id
        ORDER BY f.created_at DESC
        LIMIT 100
    ");
    $stmt->execute();
    $friendships = [];
    while ($row = $stmt->fetch()) {
        $friendships[] = [
            'id' => (int)$row['id'],
            'user_id' => (int)$row['user_id'],
            'friend_id' => (int)$row['friend_id'],
            'status' => $row['status'],
            'created_at' => $row['created_at'],
            'user_name' => $row['user_name'],
            'user_nickname' => $row['user_nickname'],
            'friend_name' => $row['friend_name'],
            'friend_nickname' => $row['friend_nickname']
        ];
    }
    json_response(['friendships' => $friendships]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_approve_friendship') {
    require_admin_permission($user, 'manage_users');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $friendship_id = (int)($input['friendship_id'] ?? 0);

    if ($friendship_id <= 0) {
        json_response(['error' => '参数无效'], 400);
    }

    $stmt = $pdo->prepare("UPDATE friendships SET status = 'accepted' WHERE id = ?");
    $stmt->execute([$friendship_id]);

    json_response(['success' => true, 'message' => '好友请求已通过']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_reject_friendship') {
    require_admin_permission($user, 'manage_users');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $friendship_id = (int)($input['friendship_id'] ?? 0);

    if ($friendship_id <= 0) {
        json_response(['error' => '参数无效'], 400);
    }

    $stmt = $pdo->prepare("UPDATE friendships SET status = 'blocked' WHERE id = ?");
    $stmt->execute([$friendship_id]);

    json_response(['success' => true, 'message' => '好友请求已拒绝']);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_settings') {
    require_admin_permission($user, 'manage_settings');

    $settings = [];
    $stmt = $pdo->query("SHOW VARIABLES LIKE 'version'");
    if ($row = $stmt->fetch()) $settings['mysql_version'] = $row['Value'];
    $settings['allow_register'] = true;
    $settings['site_name'] = 'ChatX';

    // Load persisted settings if table exists
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE 'settings'");
        if ($stmt->fetch()) {
            $stmt = $pdo->query("SELECT name, value FROM settings");
            while ($row = $stmt->fetch()) {
                $settings[$row['name']] = $row['value'];
            }
        }
    } catch (Exception $e) {}

    json_response(['settings' => $settings]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_save_settings') {
    require_admin_permission($user, 'manage_settings');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $site_name = trim($input['site_name'] ?? 'ChatX');
    $allow_register = !empty($input['allow_register']) ? 1 : 0;

    try {
        $stmt = $pdo->query("SHOW TABLES LIKE 'settings'");
        if (!$stmt->fetch()) {
            $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
                name VARCHAR(100) PRIMARY KEY,
                value TEXT DEFAULT NULL,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        }
    } catch (Exception $e) {}

    $pdo->beginTransaction();
    $stmt = $pdo->prepare("INSERT INTO settings (name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = VALUES(value)");
    $stmt->execute(['site_name', $site_name]);
    $stmt->execute(['allow_register', $allow_register ? '1' : '0']);
    $pdo->commit();

    json_response(['success' => true, 'message' => '设置已保存']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_delete_group') {
    require_admin_permission($user, 'manage_groups');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $group_id = (int)($input['group_id'] ?? 0);

    if ($group_id <= 0) {
        json_response(['error' => '无效的群组ID'], 400);
    }

    $pdo->beginTransaction();
    $stmt = $pdo->prepare("DELETE FROM group_members WHERE group_id = ?");
    $stmt->execute([$group_id]);
    $stmt = $pdo->prepare("DELETE FROM `groups` WHERE id = ?");
    $stmt->execute([$group_id]);
    $pdo->commit();

    json_response(['success' => true, 'message' => '群组已删除']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_delete_friendship') {
    require_admin_permission($user, 'manage_users');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $friendship_id = (int)($input['friendship_id'] ?? 0);

    if ($friendship_id <= 0) {
        json_response(['error' => '无效的好友关系ID'], 400);
    }

    $stmt = $pdo->prepare("DELETE FROM friendships WHERE id = ?");
    $stmt->execute([$friendship_id]);

    json_response(['success' => true, 'message' => '好友关系已删除']);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_messages') {
    require_admin_permission($user, 'view_messages');

    $keyword = trim($_GET['keyword'] ?? '');
    $limit = min(max((int)($_GET['limit'] ?? 200), 1), 1000);
    $offset = max((int)($_GET['offset'] ?? 0), 0);

    $where = [];
    $params = [];

    if ($keyword !== '') {
        $where[] = "(m.content LIKE ? OR su.username LIKE ? OR ru.username LIKE ? OR sg.name LIKE ?)";
        $params[] = "%$keyword%";
        $params[] = "%$keyword%";
        $params[] = "%$keyword%";
        $params[] = "%$keyword%";
    }

    $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $totalStmt = $pdo->prepare("SELECT COUNT(*) FROM messages m LEFT JOIN users su ON su.id = m.sender_id LEFT JOIN users ru ON ru.id = m.receiver_id LEFT JOIN `groups` sg ON sg.id = m.group_id $whereSql");
    $totalStmt->execute($params);
    $total = (int)$totalStmt->fetchColumn();

    $orderBy = 'ORDER BY m.created_at DESC';

    $sql = "
        SELECT m.id, m.sender_id, m.receiver_id, m.group_id, m.type, m.content,
               m.is_recall, m.created_at,
               su.username as sender_name, su.nickname as sender_nickname, su.avatar as sender_avatar,
               ru.username as receiver_name, ru.nickname as receiver_nickname,
               sg.name as group_name
        FROM messages m
        LEFT JOIN users su ON su.id = m.sender_id
        LEFT JOIN users ru ON ru.id = m.receiver_id
        LEFT JOIN `groups` sg ON sg.id = m.group_id
        $whereSql
        $orderBy
        LIMIT $limit OFFSET $offset
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $messages = [];
    while ($row = $stmt->fetch()) {
        $messages[] = [
            'id' => (int)$row['id'],
            'sender_id' => (int)$row['sender_id'],
            'receiver_id' => $row['receiver_id'] ? (int)$row['receiver_id'] : null,
            'group_id' => $row['group_id'] ? (int)$row['group_id'] : null,
            'type' => $row['type'],
            'content' => $row['content'],
            'is_recall' => (bool)$row['is_recall'],
            'created_at' => $row['created_at'],
            'sender_name' => $row['sender_nickname'] ?: $row['sender_name'],
            'receiver_name' => $row['receiver_nickname'] ?: $row['receiver_name'],
            'group_name' => $row['group_name'] ?: '',
            'target_label' => $row['group_id'] ? ('群组:' . ($row['group_name'] ?: ('#' . $row['group_id']))) : ($row['receiver_name'] ?: ('用户#' . $row['receiver_id']))
        ];
    }
    json_response([
        'messages' => $messages,
        'total' => $total,
        'limit' => $limit,
        'offset' => $offset
    ]);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_roles') {
    require_admin_permission($user, 'manage_roles');

    $stmt = $pdo->query("SELECT id, username, nickname, role FROM users ORDER BY FIELD(role, 'super_admin', 'admin', 'user'), username");
    $roles = [];
    while ($row = $stmt->fetch()) {
        $roles[] = [
            'id' => (int)$row['id'],
            'username' => $row['username'],
            'nickname' => $row['nickname'],
            'role' => $row['role']
        ];
    }

    $permissions = [
        '用户与群组' => [
            'manage_users' => '用户管理',
            'manage_groups' => '群组管理'
        ],
        '内容审核' => [
            'view_messages' => '查看消息',
            'manage_feedbacks' => '用户反馈',
            'manage_sensitive_words' => '敏感词管理',
            'manage_forum' => '论坛管理'
        ],
        '系统管理' => [
            'manage_settings' => '系统设置',
            'manage_roles' => '角色权限'
        ],
        '审计与安全' => [
            'view_login_logs' => '登录日志',
            'manage_sessions' => '会话管理',
            'view_reports' => '数据统计'
        ]
    ];
    $presets = [
        'content_moderator' => '内容审核员',
        'user_manager' => '用户管理员',
        'group_manager' => '群组管理员',
        'full_access' => '全量管理员'
    ];
    $presetMap = [
        'content_moderator' => ['view_messages','manage_feedbacks','manage_sensitive_words','manage_forum'],
        'user_manager' => ['manage_users','view_login_logs','manage_sessions'],
        'group_manager' => ['manage_groups','view_messages'],
        'full_access' => ['manage_users','manage_groups','view_messages','manage_settings','manage_roles','manage_feedbacks','manage_sensitive_words','manage_forum','view_login_logs','manage_sessions','view_reports']
    ];
    json_response(['users' => $roles, 'permissions' => $permissions, 'presets' => $presets, 'presetMap' => $presetMap]);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_permissions') {
    require_admin_permission($user, 'manage_roles');

    $userId = (int)($_GET['user_id'] ?? 0);
    if ($userId <= 0) {
        json_response(['error' => '无效的用户ID'], 400);
    }

    $stmt = $pdo->prepare("SELECT permission FROM admin_permissions WHERE user_id = ?");
    $stmt->execute([$userId]);
    $perms = [];
    while ($row = $stmt->fetch()) {
        $perms[] = $row['permission'];
    }
    json_response(['permissions' => $perms]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_save_permissions') {
    require_admin_permission($user, 'manage_roles');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $target_id = (int)($input['user_id'] ?? 0);
    $permissions = $input['permissions'] ?? [];

    if ($target_id <= 0) {
        json_response(['error' => '无效的用户ID'], 400);
    }

    $stmt = $pdo->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$target_id]);
    $role = $stmt->fetchColumn();
    if ($role !== 'admin') {
        json_response(['error' => '仅可为普通管理员分配权限'], 400);
    }

    $allowed = [
        'manage_users',
        'manage_groups',
        'view_messages',
        'manage_settings',
        'manage_roles',
        'manage_feedbacks',
        'manage_sensitive_words',
        'view_login_logs',
        'manage_sessions',
        'view_reports'
    ];
    $sensitive = ['manage_roles', 'manage_settings'];
    $permissions = array_values(array_intersect($permissions, $allowed));
    if (array_intersect($permissions, $sensitive) && !is_super_admin($user)) {
        json_response(['error' => '仅超级管理员可分配系统管理类权限'], 403);
    }

    $pdo->beginTransaction();
    $stmt = $pdo->prepare("DELETE FROM admin_permissions WHERE user_id = ?");
    $stmt->execute([$target_id]);
    if (!empty($permissions) && is_array($permissions)) {
        $stmt = $pdo->prepare("INSERT INTO admin_permissions (user_id, permission) VALUES (?, ?)");
        foreach ($permissions as $perm) {
            $perm = trim($perm);
            if ($perm !== '') {
                $stmt->execute([$target_id, $perm]);
            }
        }
    }
    $pdo->commit();

    json_response(['success' => true, 'message' => '权限已更新']);
}

$presetMap = [
    'content_moderator' => ['view_messages','manage_feedbacks','manage_sensitive_words'],
    'user_manager' => ['manage_users','view_login_logs','manage_sessions'],
    'group_manager' => ['manage_groups','view_messages'],
    'full_access' => ['manage_users','manage_groups','view_messages','manage_settings','manage_roles','manage_feedbacks','manage_sensitive_words','view_login_logs','manage_sessions','view_reports']
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_apply_preset') {
    require_admin_permission($user, 'manage_roles');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $target_id = (int)($input['user_id'] ?? 0);
    $preset = $input['preset'] ?? '';

    if ($target_id <= 0 || !isset($presetMap[$preset])) {
        json_response(['error' => '参数无效'], 400);
    }

    $stmt = $pdo->prepare("SELECT role FROM users WHERE id = ?");
    $stmt->execute([$target_id]);
    $role = $stmt->fetchColumn();
    if ($role !== 'admin') {
        json_response(['error' => '仅可为普通管理员应用预设'], 400);
    }

    $permissions = $presetMap[$preset];
    $sensitive = ['manage_roles', 'manage_settings'];
    if (array_intersect($permissions, $sensitive) && !is_super_admin($user)) {
        json_response(['error' => '该预设包含仅超级管理员可分配的权限'], 403);
    }

    $pdo->beginTransaction();
    $stmt = $pdo->prepare("DELETE FROM admin_permissions WHERE user_id = ?");
    $stmt->execute([$target_id]);
    if (!empty($permissions)) {
        $stmt = $pdo->prepare("INSERT INTO admin_permissions (user_id, permission) VALUES (?, ?)");
        foreach ($permissions as $perm) {
            $stmt->execute([$target_id, $perm]);
        }
    }
    $pdo->commit();

    json_response(['success' => true, 'message' => '预设已应用']);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_logs') {
    require_admin_permission($user, 'view_messages');

    $limit = min(max((int)($_GET['limit'] ?? 100), 1), 500);
    $stmt = $pdo->query("
        SELECT m.id, m.type, m.content, m.created_at,
               su.username as sender_name, su.nickname as sender_nickname,
               sg.name as group_name
        FROM messages m
        LEFT JOIN users su ON su.id = m.sender_id
        LEFT JOIN `groups` sg ON sg.id = m.group_id
        WHERE m.type = 'system'
        ORDER BY m.created_at DESC
        LIMIT $limit
    ");
    $logs = [];
    while ($row = $stmt->fetch()) {
        $logs[] = [
            'id' => (int)$row['id'],
            'type' => $row['type'],
            'content' => $row['content'],
            'created_at' => $row['created_at'],
            'sender_name' => $row['sender_name'] ?: ($row['sender_nickname'] ?: '系统'),
            'group_name' => $row['group_name'] ?: ''
        ];
    }
    json_response(['logs' => $logs]);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_announcements') {
    require_admin_permission($user, 'manage_settings');

    $stmt = $pdo->query("SELECT a.id, a.title, a.content, a.created_at, u.username as creator FROM announcements a JOIN users u ON u.id = a.created_by ORDER BY a.created_at DESC");
    $announcements = [];
    while ($row = $stmt->fetch()) {
        $announcements[] = [
            'id' => (int)$row['id'],
            'title' => $row['title'],
            'content' => $row['content'],
            'created_at' => $row['created_at'],
            'creator' => $row['creator']
        ];
    }
    json_response(['announcements' => $announcements]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_create_announcement') {
    require_admin_permission($user, 'manage_settings');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $title = trim($input['title'] ?? '');
    $content = trim($input['content'] ?? '');

    if ($title === '' || $content === '') {
        json_response(['error' => '标题和内容不能为空'], 400);
    }

    $stmt = $pdo->prepare("INSERT INTO announcements (title, content, created_by) VALUES (?, ?, ?)");
    $stmt->execute([$title, $content, $user['id']]);
    json_response(['success' => true, 'message' => '公告已发布']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_delete_announcement') {
    require_admin_permission($user, 'manage_settings');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $id = (int)($input['id'] ?? 0);

    if ($id <= 0) {
        json_response(['error' => '无效的公告ID'], 400);
    }

    $stmt = $pdo->prepare("DELETE FROM announcements WHERE id = ?");
    $stmt->execute([$id]);
    json_response(['success' => true, 'message' => '公告已删除']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_update_announcement') {
    require_admin_permission($user, 'manage_settings');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $id = (int)($input['id'] ?? 0);
    $title = trim($input['title'] ?? '');
    $content = trim($input['content'] ?? '');

    if ($id <= 0 || $title === '' || $content === '') {
        json_response(['error' => '参数无效'], 400);
    }

    $stmt = $pdo->prepare("UPDATE announcements SET title = ?, content = ? WHERE id = ?");
    $stmt->execute([$title, $content, $id]);

    json_response(['success' => true, 'message' => '公告已更新']);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_friend_requests') {
    require_admin_permission($user, 'manage_users');

    $stmt = $pdo->prepare("
        SELECT f.id, f.user_id, f.friend_id, f.status, f.created_at,
               u1.username as user_name, u1.nickname as user_nickname,
               u2.username as friend_name, u2.nickname as friend_nickname
        FROM friendships f
        JOIN users u1 ON u1.id = f.user_id
        JOIN users u2 ON u2.id = f.friend_id
        WHERE f.status = 'pending'
        ORDER BY f.created_at DESC
        LIMIT 100
    ");
    $stmt->execute();
    $requests = [];
    while ($row = $stmt->fetch()) {
        $requests[] = [
            'id' => (int)$row['id'],
            'user_id' => (int)$row['user_id'],
            'friend_id' => (int)$row['friend_id'],
            'status' => $row['status'],
            'created_at' => $row['created_at'],
            'user_name' => $row['user_name'],
            'user_nickname' => $row['user_nickname'],
            'friend_name' => $row['friend_name'],
            'friend_nickname' => $row['friend_nickname']
        ];
    }
    json_response(['requests' => $requests]);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_feedbacks') {
    require_admin_permission($user, 'manage_feedbacks');

    $status = $_GET['status'] ?? '';
    $where = '';
    $params = [];
    if ($status !== '') {
        $where = 'WHERE f.status = ?';
        $params[] = $status;
    }

    $stmt = $pdo->prepare("
        SELECT f.id, f.user_id, u.username, u.nickname, f.type, f.content, f.status, f.reply, f.created_at
        FROM feedbacks f
        JOIN users u ON u.id = f.user_id
        $where
        ORDER BY f.created_at DESC
        LIMIT 200
    ");
    $stmt->execute($params);
    $feedbacks = [];
    while ($row = $stmt->fetch()) {
        $feedbacks[] = [
            'id' => (int)$row['id'],
            'user_id' => (int)$row['user_id'],
            'username' => $row['username'],
            'nickname' => $row['nickname'],
            'type' => $row['type'],
            'content' => $row['content'],
            'status' => $row['status'],
            'reply' => $row['reply'],
            'created_at' => $row['created_at']
        ];
    }
    json_response(['feedbacks' => $feedbacks]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_reply_feedback') {
    require_admin_permission($user, 'manage_feedbacks');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $id = (int)($input['id'] ?? 0);
    $reply = trim($input['reply'] ?? '');
    $status = $input['status'] ?? 'resolved';

    if ($id <= 0 || $reply === '') {
        json_response(['error' => '参数无效'], 400);
    }

    $stmt = $pdo->prepare("UPDATE feedbacks SET reply = ?, status = ?, updated_at = NOW() WHERE id = ?");
    $stmt->execute([$reply, $status, $id]);

    // Send notification to the user who submitted the feedback
    $stmt = $pdo->prepare("SELECT user_id, content FROM feedbacks WHERE id = ?");
    $stmt->execute([$id]);
    $fb = $stmt->fetch();
    if ($fb) {
        $stmt = $pdo->prepare("INSERT INTO notifications (user_id, type, title, content, related_id) VALUES (?, 'system', ?, ?, ?)");
        $stmt->execute([$fb['user_id'], '反馈已回复', '您的反馈「' . mb_substr($fb['content'], 0, 30) . '...」已收到回复，请查看。', $id]);
    }

    json_response(['success' => true, 'message' => '回复已保存']);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_sensitive_words') {
    require_admin_permission($user, 'manage_sensitive_words');

    $stmt = $pdo->prepare("SELECT sw.id, sw.word, sw.category, sw.created_at, u.username as creator FROM sensitive_words sw JOIN users u ON u.id = sw.created_by ORDER BY sw.word ASC");
    $stmt->execute();
    $words = [];
    while ($row = $stmt->fetch()) {
        $words[] = [
            'id' => (int)$row['id'],
            'word' => $row['word'],
            'category' => $row['category'],
            'created_at' => $row['created_at'],
            'creator' => $row['creator']
        ];
    }
    json_response(['words' => $words]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_add_sensitive_word') {
    require_admin_permission($user, 'manage_sensitive_words');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $word = trim($input['word'] ?? '');
    $category = trim($input['category'] ?? 'custom');

    if ($word === '') {
        json_response(['error' => '敏感词不能为空'], 400);
    }

    $stmt = $pdo->prepare("INSERT INTO sensitive_words (word, category, created_by) VALUES (?, ?, ?)");
    $stmt->execute([$word, $category, $user['id']]);
    json_response(['success' => true, 'message' => '敏感词已添加']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_delete_sensitive_word') {
    require_admin_permission($user, 'manage_sensitive_words');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $id = (int)($input['id'] ?? 0);

    if ($id <= 0) {
        json_response(['error' => '参数无效'], 400);
    }

    $stmt = $pdo->prepare("DELETE FROM sensitive_words WHERE id = ?");
    $stmt->execute([$id]);
    json_response(['success' => true, 'message' => '敏感词已删除']);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_login_logs') {
    require_admin_permission($user, 'view_login_logs');

    $userId = (int)($_GET['user_id'] ?? 0);
    $limit = min(max((int)($_GET['limit'] ?? 100), 1), 500);
    $offset = max((int)($_GET['offset'] ?? 0), 0);

    $where = '';
    $params = [];
    if ($userId > 0) {
        $where = 'WHERE l.user_id = ?';
        $params[] = $userId;
    }

    $stmt = $pdo->prepare("
        SELECT l.id, l.user_id, l.username, l.ip, l.user_agent, l.status, l.created_at
        FROM login_logs l
        $where
        ORDER BY l.created_at DESC
        LIMIT $limit OFFSET $offset
    ");
    $stmt->execute($params);
    $logs = [];
    while ($row = $stmt->fetch()) {
        $logs[] = [
            'id' => (int)$row['id'],
            'user_id' => (int)$row['user_id'],
            'username' => $row['username'],
            'ip' => $row['ip'],
            'user_agent' => $row['user_agent'],
            'status' => $row['status'],
            'created_at' => $row['created_at']
        ];
    }
    json_response(['logs' => $logs]);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_sessions') {
    require_admin_permission($user, 'manage_sessions');

    $stmt = $pdo->prepare("
        SELECT s.id, s.user_id, u.username, u.nickname, u.status, s.ip, s.user_agent, s.last_activity, s.expires_at
        FROM sessions s
        JOIN users u ON u.id = s.user_id
        WHERE s.expires_at > NOW()
        ORDER BY s.last_activity DESC
    ");
    $stmt->execute();
    $sessions = [];
    while ($row = $stmt->fetch()) {
        $sessions[] = [
            'id' => (int)$row['id'],
            'user_id' => (int)$row['user_id'],
            'username' => $row['username'],
            'nickname' => $row['nickname'],
            'status' => $row['status'],
            'ip' => $row['ip'],
            'user_agent' => $row['user_agent'],
            'last_activity' => $row['last_activity'],
            'expires_at' => $row['expires_at']
        ];
    }
    json_response(['sessions' => $sessions]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'admin_kick_session') {
    require_admin_permission($user, 'manage_sessions');

    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $sessionId = (int)($input['session_id'] ?? 0);

    if ($sessionId <= 0) {
        json_response(['error' => '参数无效'], 400);
    }

    $stmt = $pdo->prepare("DELETE FROM sessions WHERE id = ?");
    $stmt->execute([$sessionId]);
    json_response(['success' => true, 'message' => '会话已踢下线']);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_reports') {
    require_admin_permission($user, 'view_reports');

    $stats = [];
    $stats['users'] = (int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $stats['groups'] = (int)$pdo->query("SELECT COUNT(*) FROM `groups`")->fetchColumn();
    $stats['messages'] = (int)$pdo->query("SELECT COUNT(*) FROM messages")->fetchColumn();
    $stats['online'] = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE status = 'online'")->fetchColumn();
    $stats['friendships'] = (int)$pdo->query("SELECT COUNT(*) FROM friendships WHERE status = 'accepted'")->fetchColumn();
    $stats['feedbacks'] = (int)$pdo->query("SELECT COUNT(*) FROM feedbacks")->fetchColumn();
    $stats['pending_feedbacks'] = (int)$pdo->query("SELECT COUNT(*) FROM feedbacks WHERE status = 'pending'")->fetchColumn();
    $stats['sensitive_words'] = (int)$pdo->query("SELECT COUNT(*) FROM sensitive_words")->fetchColumn();
    $stats['active_sessions'] = (int)$pdo->query("SELECT COUNT(*) FROM sessions WHERE expires_at > NOW()")->fetchColumn();
    try {
        $stats['forum_posts'] = (int)$pdo->query("SELECT COUNT(*) FROM forum_posts")->fetchColumn();
        $stats['forum_comments'] = (int)$pdo->query("SELECT COUNT(*) FROM forum_comments")->fetchColumn();
    } catch (Exception $e) {
        $stats['forum_posts'] = 0;
        $stats['forum_comments'] = 0;
    }

    $dailyStats = [];
    for ($i = 6; $i >= 0; $i--) {
        $date = date('Y-m-d', strtotime("-$i days"));
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM messages WHERE DATE(created_at) = ?");
        $stmt->execute([$date]);
        $dailyStats[] = ['date' => $date, 'messages' => (int)$stmt->fetchColumn()];
    }

    json_response(['stats' => $stats, 'daily' => $dailyStats]);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'admin_export') {
    require_admin_permission($user, 'view_reports');

    $type = $_GET['type'] ?? 'users';
    $format = $_GET['format'] ?? 'csv';

    $allowed = ['users','groups','messages','feedbacks'];
    if (!in_array($type, $allowed, true)) {
        json_response(['error' => '不支持的导出类型'], 400);
    }

    $filename = $type . '.' . ($format === 'json' ? 'json' : 'csv');
    header('Content-Type: ' . ($format === 'json' ? 'application/json' : 'text/csv'));
    header('Content-Disposition: attachment; filename=' . $filename);

    if ($type === 'users') {
        $stmt = $pdo->query("SELECT id, username, nickname, role, status, last_seen, created_at FROM users ORDER BY created_at DESC");
        $rows = $stmt->fetchAll();
        if ($format === 'json') {
            echo json_encode($rows, JSON_UNESCAPED_UNICODE);
            exit;
        }
        $out = fopen('php://output', 'w');
        fputcsv($out, ['ID','用户名','昵称','角色','状态','最后上线','注册时间']);
        foreach ($rows as $r) fputcsv($out, $r);
        fclose($out);
        exit;
    }

    if ($type === 'groups') {
        $stmt = $pdo->query("SELECT g.id, g.name, g.owner_id, g.description, g.created_at, COUNT(gm.user_id) as members FROM `groups` g LEFT JOIN group_members gm ON gm.group_id = g.id GROUP BY g.id ORDER BY g.created_at DESC");
        $rows = $stmt->fetchAll();
        if ($format === 'json') {
            echo json_encode($rows, JSON_UNESCAPED_UNICODE);
            exit;
        }
        $out = fopen('php://output', 'w');
        fputcsv($out, ['ID','群名称','群主ID','描述','创建时间','成员数']);
        foreach ($rows as $r) fputcsv($out, $r);
        fclose($out);
        exit;
    }

    if ($type === 'messages') {
        $stmt = $pdo->query("SELECT m.id, m.sender_id, m.receiver_id, m.group_id, m.type, m.content, m.is_recall, m.created_at FROM messages m ORDER BY m.created_at DESC LIMIT 5000");
        $rows = $stmt->fetchAll();
        if ($format === 'json') {
            echo json_encode($rows, JSON_UNESCAPED_UNICODE);
            exit;
        }
        $out = fopen('php://output', 'w');
        fputcsv($out, ['ID','发送人','接收人','群组','类型','内容','撤回','时间']);
        foreach ($rows as $r) fputcsv($out, $r);
        fclose($out);
        exit;
    }

    if ($type === 'feedbacks') {
        $stmt = $pdo->query("SELECT f.id, f.user_id, f.type, f.content, f.status, f.created_at FROM feedbacks f ORDER BY f.created_at DESC LIMIT 2000");
        $rows = $stmt->fetchAll();
        if ($format === 'json') {
            echo json_encode($rows, JSON_UNESCAPED_UNICODE);
            exit;
        }
        $out = fopen('php://output', 'w');
        fputcsv($out, ['ID','用户ID','类型','内容','状态','时间']);
        foreach ($rows as $r) fputcsv($out, $r);
        fclose($out);
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $action === 'submit_feedback') {
    if (!$user) json_response(['error' => '未登录'], 401);
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $content = trim($input['content'] ?? '');
    $contact = trim($input['contact'] ?? '');
    if ($content === '') json_response(['error' => '内容不能为空'], 422);
    $stmt = $pdo->prepare("INSERT INTO feedbacks (user_id, content, contact, status) VALUES (?, ?, ?, 'pending')");
    $stmt->execute([$user['id'], $content, $contact]);
    json_response(['success' => true]);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'my_feedbacks') {
    if (!$user) json_response(['error' => '未登录'], 401);
    $stmt = $pdo->prepare("SELECT id, content, contact, status, reply, created_at, updated_at FROM feedbacks WHERE user_id = ? ORDER BY created_at DESC LIMIT 50");
    $stmt->execute([$user['id']]);
    $feedbacks = [];
    while ($row = $stmt->fetch()) {
        $feedbacks[] = [
            'id' => (int)$row['id'],
            'content' => $row['content'],
            'contact' => $row['contact'],
            'status' => $row['status'],
            'reply' => $row['reply'],
            'has_reply' => !empty($row['reply']),
            'created_at' => $row['created_at'],
            'updated_at' => $row['updated_at']
        ];
    }
    json_response(['feedbacks' => $feedbacks]);
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'user_announcements') {
    if (!$user) json_response(['error' => '未登录'], 401);
    $stmt = $pdo->prepare("SELECT a.id, a.title, a.content, a.created_at FROM announcements a WHERE a.created_at > ? ORDER BY a.created_at DESC");
    $since = $_GET['since'] ?? date('Y-m-d H:i:s', time() - 86400 * 30);
    $stmt->execute([$since]);
    $announcements = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $announcements[] = [
            'id' => (int)$row['id'],
            'title' => $row['title'],
            'content' => $row['content'],
            'created_at' => $row['created_at']
        ];
    }
    json_response(['announcements' => $announcements]);
}

json_response(['error' => '未知操作'], 400);
