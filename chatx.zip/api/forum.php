<?php
session_start();
require_once __DIR__ . '/../functions.php';
$pdo = db_connect();
$user = require_auth();

$action = $_GET['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'];

// Helper: JSON body
function forum_input() {
    $input = json_decode(file_get_contents('php://input'), true);
    if ($input) return $input;
    return $_POST;
}

// 自动建表/补字段：保证论坛所需的表和列都存在
function ensure_forum_tables($pdo) {
    $t = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $has = array_flip($t);

    if (!isset($has['forum_categories'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS forum_categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(50) NOT NULL,
            description VARCHAR(255) DEFAULT NULL,
            icon VARCHAR(10) DEFAULT '📁',
            sort_order INT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($has['forum_posts'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS forum_posts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            title VARCHAR(200) NOT NULL,
            content TEXT NOT NULL,
            category_id INT NOT NULL DEFAULT 1,
            likes_count INT DEFAULT 0,
            replies_count INT DEFAULT 0,
            view_count INT DEFAULT 0,
            is_pinned TINYINT NOT NULL DEFAULT 0,
            is_archived TINYINT NOT NULL DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user (user_id),
            INDEX idx_category (category_id),
            INDEX idx_created (created_at),
            INDEX idx_pinned (is_pinned),
            INDEX idx_archived (is_archived)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } else {
        // 补缺失的列（view_count / is_archived）
        foreach (['view_count' => "ADD COLUMN view_count INT DEFAULT 0",
                  'is_archived' => "ADD COLUMN is_archived TINYINT NOT NULL DEFAULT 0"] as $col => $ddl) {
            $c = $pdo->query("SHOW COLUMNS FROM forum_posts LIKE '$col'")->fetch();
            if (!$c) { $pdo->exec("ALTER TABLE forum_posts $ddl"); }
        }
    }
    if (!isset($has['forum_comments'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS forum_comments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            post_id INT NOT NULL,
            user_id INT NOT NULL,
            parent_id INT DEFAULT NULL,
            content TEXT NOT NULL,
            likes_count INT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_post (post_id),
            INDEX idx_user (user_id),
            INDEX idx_parent (parent_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($has['forum_likes'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS forum_likes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            post_id INT DEFAULT NULL,
            comment_id INT DEFAULT NULL,
            user_id INT NOT NULL,
            type ENUM('post','comment') NOT NULL DEFAULT 'post',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_post_type (post_id, type),
            INDEX idx_comment_type (comment_id, type),
            INDEX idx_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($has['forum_reactions'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS forum_reactions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            target_type ENUM('post','comment') NOT NULL DEFAULT 'post',
            target_id INT NOT NULL,
            user_id INT NOT NULL,
            emoji VARCHAR(32) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY uq_react (target_type, target_id, user_id, emoji),
            INDEX idx_target (target_type, target_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($has['forum_tags'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS forum_tags (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(50) NOT NULL,
            sort_order INT DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_tag_name (name)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($has['forum_post_tags'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS forum_post_tags (
            id INT AUTO_INCREMENT PRIMARY KEY,
            post_id INT NOT NULL,
            tag_id INT NOT NULL,
            FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE,
            FOREIGN KEY (tag_id) REFERENCES forum_tags(id) ON DELETE CASCADE,
            UNIQUE KEY uq_post_tag (post_id, tag_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($has['forum_polls'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS forum_polls (
            id INT AUTO_INCREMENT PRIMARY KEY,
            post_id INT NOT NULL,
            question VARCHAR(255) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($has['forum_poll_options'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS forum_poll_options (
            id INT AUTO_INCREMENT PRIMARY KEY,
            poll_id INT NOT NULL,
            option_text VARCHAR(200) NOT NULL,
            FOREIGN KEY (poll_id) REFERENCES forum_polls(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($has['forum_poll_votes'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS forum_poll_votes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            poll_id INT NOT NULL,
            option_id INT NOT NULL,
            user_id INT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (poll_id) REFERENCES forum_polls(id) ON DELETE CASCADE,
            FOREIGN KEY (option_id) REFERENCES forum_poll_options(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY uq_poll_vote (poll_id, user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($has['forum_subscriptions'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS forum_subscriptions (
            id INT AUTO_INCREMENT PRIMARY KEY,
            post_id INT NOT NULL,
            user_id INT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY uq_sub (post_id, user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    if (!isset($has['forum_reports'])) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS forum_reports (
            id INT AUTO_INCREMENT PRIMARY KEY,
            reporter_id INT NOT NULL,
            target_type ENUM('post','comment') NOT NULL,
            target_id INT NOT NULL,
            reason VARCHAR(255) NOT NULL,
            status ENUM('pending','resolved','dismissed') DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    // 默认分类
    $cnt = (int)$pdo->query("SELECT COUNT(*) FROM forum_categories")->fetchColumn();
    if ($cnt === 0) {
        $cats = [
            [1,'综合讨论','什么都可以聊','💬',1],
            [2,'技术交流','技术分享与讨论','💻',2],
            [3,'生活随笔','分享生活中的点滴','🌸',3],
            [4,'公告新闻','重要公告和资讯','📢',4],
            [5,'求助问答','有问题就问，有问必答','❓',5],
            [6,'娱乐休闲','轻松一刻，休闲娱乐','🎮',6],
        ];
        $ins = $pdo->prepare("INSERT IGNORE INTO forum_categories (id, name, description, icon, sort_order) VALUES (?,?,?,?,?)");
        foreach ($cats as $c) $ins->execute($c);
    }
}

// 表自愈
try {
    ensure_forum_tables($pdo);
} catch (Throwable $e) {
    json_response(['error' => '论坛数据初始化失败: ' . $e->getMessage()], 500);
}

// Helper: avatar HTML for user
function user_avatar($user, $size = 32) {
    $name = $user['nickname'] ?? $user['username'] ?? '?';
    $avatar = $user['avatar'] ?? '';
    $isDefault = !$avatar || $avatar === 'default.png';
    $letter = mb_substr($name, 0, 1);
    $hash = mb_strpos($name, '', 0, 'UTF-8') !== false ? mb_strlen($name, 'UTF-8') : strlen($name);
    $colors = ['#ff9a9e','#fad0c4','#a18cd1','#fbc2eb','#8fd3f4','#84fab0','#fccb90','#e0c3fc'];
    $bg = 'linear-gradient(135deg, ' . $colors[$hash % count($colors)] . ', ' . $colors[($hash+3) % count($colors)] . ')';
    $id = (int)($user['id'] ?? 0);
    $click = $id ? "onclick=\"window.location.href='profile.php?user_id={$id}'\" style=\"cursor:pointer;\"" : '';
    if (!$isDefault) {
        return '<img src="' . htmlspecialchars($avatar) . '" style="width:'.$size.'px;height:'.$size.'px;border-radius:50%;object-fit:cover;flex-shrink:0;border:2px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.1);cursor:pointer;" ' . ($id ? "onclick=\"window.location.href='profile.php?user_id={$id}'\"" : '') . ">";
    }
    return '<div style="width:'.$size.'px;height:'.$size.'px;background:'.$bg.';color:#fff;display:flex;align-items:center;justify-content:center;border-radius:50%;font-size:'.($size*0.4).'px;font-weight:600;flex-shrink:0;border:2px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.1);'.$click.'">'.$letter.'</div>';
}

// ============ GET: Categories ============
if ($method === 'GET' && $action === 'categories') {
    // Auto-seed categories if table is empty
    $stmt = $pdo->query("SELECT COUNT(*) FROM forum_categories");
    if ($stmt->fetchColumn() == 0) {
        $defaults = [
            [1, '综合讨论', '什么都可以聊', '💬', 1],
            [2, '技术交流', '技术分享与讨论', '💻', 2],
            [3, '生活随笔', '分享生活中的点滴', '🌸', 3],
            [4, '公告新闻', '重要公告和资讯', '📢', 4],
            [5, '求助问答', '有问题就问，有问应答', '❓', 5],
            [6, '娱乐休闲', '轻松一刻，休闲娱乐', '🎮', 6],
        ];
        foreach ($defaults as $c) {
            $pdo->prepare("INSERT IGNORE INTO forum_categories (id, name, description, icon, sort_order) VALUES (?, ?, ?, ?, ?)")
                ->execute($c);
        }
    }
    $stmt = $pdo->query("SELECT * FROM forum_categories ORDER BY sort_order ASC, id ASC");
    $cats = $stmt->fetchAll();
    json_response(['categories' => $cats]);
}

// ============ GET: List posts ============
if ($method === 'GET' && $action === 'list') {
    $category_id = (int)($_GET['category_id'] ?? 0);
    $page = max(1, (int)($_GET['page'] ?? 1));
    $per_page = 20;
    $search = trim($_GET['search'] ?? '');
    $offset = ($page - 1) * $per_page;

    $where = [];
    $params = [];

    if ($category_id > 0) {
        $where[] = "p.category_id = ?";
        $params[] = $category_id;
    }
    if ($search !== '') {
        $where[] = "(p.title LIKE ? OR p.content LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    $where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $total = $pdo->prepare("SELECT COUNT(*) FROM forum_posts p $where_sql");
    $total->execute($params);
    $total_count = (int)$total->fetchColumn();

    $sql = "SELECT p.*, u.username, u.nickname, u.avatar,
                   c.name as category_name, c.icon as category_icon,
                   (SELECT COUNT(*) FROM forum_reactions fr WHERE fr.target_type = 'post' AND fr.target_id = p.id) as reaction_count,
                   (SELECT GROUP_CONCAT(t.name SEPARATOR ', ') FROM forum_post_tags fpt JOIN forum_tags t ON t.id = fpt.tag_id WHERE fpt.post_id = p.id) as tag_names,
                   (SELECT id FROM forum_polls WHERE post_id = p.id) as poll_id
            FROM forum_posts p
            JOIN users u ON u.id = p.user_id
            JOIN forum_categories c ON c.id = p.category_id
            $where_sql
            ORDER BY p.is_pinned DESC, p.created_at DESC
            LIMIT $per_page OFFSET $offset";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $posts = $stmt->fetchAll();

    $pages = (int)ceil($total_count / $per_page);

    json_response([
        'posts' => $posts,
        'page' => $page,
        'pages' => $pages,
        'total' => $total_count
    ]);
}

// ============ GET: Single post ============
if ($method === 'GET' && $action === 'post') {
    $post_id = (int)($_GET['id'] ?? 0);
    if ($post_id <= 0) json_response(['error' => '无效的文章ID'], 400);

    $stmt = $pdo->prepare("SELECT p.*, u.username, u.nickname, u.avatar,
                    c.name as category_name, c.icon as category_icon
                    FROM forum_posts p
                    JOIN users u ON u.id = p.user_id
                    JOIN forum_categories c ON c.id = p.category_id
                    WHERE p.id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();
    if (!$post) json_response(['error' => '文章不存在'], 404);

    // Check if current user liked
    $stmt = $pdo->prepare("SELECT 1 FROM forum_likes WHERE post_id = ? AND user_id = ?");
    $stmt->execute([$post_id, $user['id']]);
    $post['liked'] = (bool)$stmt->fetch();

    // Get comments
    $stmt = $pdo->prepare("SELECT cm.*, u.username, u.nickname, u.avatar,
                   (SELECT COUNT(*) FROM forum_likes WHERE comment_id = cm.id AND type = 'comment') as comment_likes_count,
                   (SELECT COUNT(*) FROM forum_comments WHERE parent_id = cm.id) as reply_count
            FROM forum_comments cm
            JOIN users u ON u.id = cm.user_id
            WHERE cm.post_id = ?
            ORDER BY cm.created_at ASC");
    $stmt->execute([$post_id]);
    $comments = $stmt->fetchAll();

    // Check liked status for each comment
    $comment_ids = array_column($comments, 'id');
    $liked_map = [];
    if (!empty($comment_ids)) {
        $placeholders = implode(',', array_fill(0, count($comment_ids), '?'));
        $stmt = $pdo->prepare("SELECT comment_id, user_id FROM forum_likes WHERE comment_id IN ($placeholders) AND type = 'comment' AND user_id = ?");
        $stmt->execute(array_merge($comment_ids, [$user['id']]));
        foreach ($stmt->fetchAll() as $row) {
            $liked_map[(int)$row['comment_id']] = true;
        }
    }
    foreach ($comments as &$c) {
        $c['liked'] = isset($liked_map[(int)$c['id']]);
    }
    unset($c);

    // Get post reactions
    $stmt = $pdo->prepare("SELECT emoji, COUNT(*) as count FROM forum_reactions WHERE target_type = 'post' AND target_id = ? GROUP BY emoji ORDER BY count DESC");
    $stmt->execute([$post_id]);
    $reactions = $stmt->fetchAll();
    $stmt = $pdo->prepare("SELECT emoji FROM forum_reactions WHERE target_type = 'post' AND target_id = ? AND user_id = ?");
    $stmt->execute([$post_id, $user['id']]);
    $my_reactions = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Get post tags
    $stmt = $pdo->prepare("SELECT t.* FROM forum_tags t JOIN forum_post_tags fpt ON fpt.tag_id = t.id WHERE fpt.post_id = ? ORDER BY t.sort_order ASC");
    $stmt->execute([$post_id]);
    $tags = $stmt->fetchAll();

    // Get poll
    $poll = null;
    $stmt = $pdo->prepare("SELECT fp.*, po.id as option_id, po.text as option_text,
                   COALESCE((SELECT COUNT(*) FROM forum_poll_votes WHERE option_id = po.id), 0) as votes,
                   (SELECT COUNT(*) FROM forum_poll_votes WHERE poll_id = fp.id) as total_votes
            FROM forum_polls fp
            JOIN forum_poll_options po ON po.poll_id = fp.id
            WHERE fp.post_id = ?
            ORDER BY po.sort_order ASC");
    $stmt->execute([$post_id]);
    $poll_rows = $stmt->fetchAll();
    if (!empty($poll_rows)) {
        $poll = [
            'id' => (int)$poll_rows[0]['id'],
            'question' => $poll_rows[0]['question'],
            'total_votes' => (int)$poll_rows[0]['total_votes'],
            'options' => array_map(function($r) {
                return ['id' => (int)$r['option_id'], 'text' => $r['option_text'], 'votes' => (int)$r['votes']];
            }, $poll_rows)
        ];
        $stmt = $pdo->prepare("SELECT option_id FROM forum_poll_votes WHERE poll_id = ? AND user_id = ?");
        $stmt->execute([$poll['id'], $user['id']]);
        $poll['my_vote'] = $stmt->fetchColumn() ?: null;
    }

    json_response(['post' => $post, 'comments' => $comments, 'reactions' => $reactions, 'my_reactions' => $my_reactions, 'tags' => $tags, 'poll' => $poll]);
}

// ============ POST: Increment view count ============
if ($method === 'POST' && $action === 'view_post') {
    $input = forum_input();
    $post_id = (int)($input['post_id'] ?? 0);
    if ($post_id <= 0) json_response(['error' => '无效的文章ID'], 400);
    $stmt = $pdo->prepare("SELECT id FROM forum_posts WHERE id = ?");
    $stmt->execute([$post_id]);
    if (!$stmt->fetch()) json_response(['error' => '文章不存在'], 404);
    $pdo->prepare("UPDATE forum_posts SET view_count = view_count + 1 WHERE id = ?")->execute([$post_id]);
    json_response(['success' => true]);
}

// ============ POST: Submit report ============
if ($method === 'POST' && $action === 'report') {
    $input = forum_input();
    $target_type = $input['target_type'] ?? '';
    $target_id = (int)($input['target_id'] ?? 0);
    $reason = trim($input['reason'] ?? '');
    if ($target_type !== 'post' && $target_type !== 'comment') json_response(['error' => '无效的目标类型'], 400);
    if ($target_id <= 0) json_response(['error' => '无效的目标ID'], 400);
    if ($reason === '') json_response(['error' => '请填写举报原因'], 422);
    if (mb_strlen($reason) > 255) json_response(['error' => '举报原因过长'], 422);
    // Verify target exists
    if ($target_type === 'post') {
        $stmt = $pdo->prepare("SELECT id FROM forum_posts WHERE id = ?");
    } else {
        $stmt = $pdo->prepare("SELECT id FROM forum_comments WHERE id = ?");
    }
    $stmt->execute([$target_id]);
    if (!$stmt->fetch()) json_response(['error' => '举报目标不存在或已被删除'], 404);
    // Check duplicate report
    $stmt = $pdo->prepare("SELECT 1 FROM forum_reports WHERE reporter_id = ? AND target_type = ? AND target_id = ? AND status = 'pending'");
    $stmt->execute([$user['id'], $target_type, $target_id]);
    if ($stmt->fetch()) json_response(['error' => '您已举报过该内容'], 422);
    $pdo->prepare("INSERT INTO forum_reports (reporter_id, target_type, target_id, reason) VALUES (?, ?, ?, ?)")->execute([$user['id'], $target_type, $target_id, $reason]);
    json_response(['success' => true, 'message' => '举报已提交，管理员将尽快处理']);
}

// ============ GET: Admin reports list ============
if ($method === 'GET' && $action === 'admin_reports') {
    require_forum_admin($user);
    $page = max(1, (int)($_GET['page'] ?? 1));
    $per_page = 30;
    $offset = ($page - 1) * $per_page;
    $status = $_GET['status'] ?? '';
    $where = '';
    $params = [];
    if (in_array($status, ['pending','resolved','dismissed'])) {
        $where = "WHERE r.status = ?";
        $params[] = $status;
    }
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM forum_reports r $where");
    $stmt->execute($params);
    $total = (int)$stmt->fetchColumn();
    $sql = "SELECT r.*, ur.nickname as reporter_nickname, ur.avatar as reporter_avatar,
                   CASE r.target_type WHEN 'post' THEN (SELECT title FROM forum_posts WHERE id = r.target_id)
                        WHEN 'comment' THEN (SELECT LEFT(content, 100) FROM forum_comments WHERE id = r.target_id) END as target_preview
            FROM forum_reports r
            JOIN users ur ON ur.id = r.reporter_id
            $where
            ORDER BY r.created_at DESC
            LIMIT $per_page OFFSET $offset";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $reports = $stmt->fetchAll();
    json_response(['reports' => $reports, 'total' => $total, 'page' => $page, 'pages' => (int)ceil($total / $per_page)]);
}

// ============ GET: Admin analytics data ============
if ($method === 'GET' && $action === 'admin_analytics') {
    require_forum_admin($user);
    $topViewed = $pdo->query("SELECT p.id, p.title, p.view_count, u.nickname
                     FROM forum_posts p
                     JOIN users u ON u.id = p.user_id
                     WHERE p.is_archived = 0
                     ORDER BY p.view_count DESC
                     LIMIT 5")->fetchAll();
    $topReacted = $pdo->query("SELECT p.id, p.title,
                     COALESCE((SELECT COUNT(*) FROM forum_reactions WHERE target_type='post' AND target_id=p.id), 0) as reaction_count,
                     p.likes_count, u.nickname
                     FROM forum_posts p
                     JOIN users u ON u.id = p.user_id
                     WHERE p.is_archived = 0
                     ORDER BY (COALESCE((SELECT COUNT(*) FROM forum_reactions WHERE target_type='post' AND target_id=p.id), 0) + p.likes_count) DESC
                     LIMIT 5")->fetchAll();
    $topCommenters = $pdo->query("SELECT u.nickname, COUNT(*) as comment_count
                     FROM forum_comments cm
                     JOIN users u ON u.id = cm.user_id
                     GROUP BY cm.user_id
                     ORDER BY comment_count DESC
                     LIMIT 5")->fetchAll();
    $topContributors = $pdo->query("SELECT u.nickname, COUNT(*) as post_count
                     FROM forum_posts p
                     JOIN users u ON u.id = p.user_id
                     GROUP BY p.user_id
                     ORDER BY post_count DESC
                     LIMIT 5")->fetchAll();
    json_response(['top_viewed' => $topViewed, 'top_reacted' => $topReacted, 'top_commenters' => $topCommenters, 'top_contributors' => $topContributors]);
}

// ============ POST: Admin resolve report ============
if ($method === 'POST' && $action === 'admin_resolve_report') {
    require_forum_admin($user);
    $input = forum_input();
    $report_id = (int)($input['report_id'] ?? 0);
    $action_type = $input['action'] ?? '';
    if ($report_id <= 0) json_response(['error' => '无效的举报ID'], 400);
    if (!in_array($action_type, ['resolved','dismissed'])) json_response(['error' => '无效的操作'], 400);
    $stmt = $pdo->prepare("SELECT status FROM forum_reports WHERE id = ?");
    $stmt->execute([$report_id]);
    $report = $stmt->fetch();
    if (!$report) json_response(['error' => '举报不存在'], 404);
    if ($report['status'] !== 'pending') json_response(['error' => '该举报已处理'], 422);
    $pdo->prepare("UPDATE forum_reports SET status = ?, resolved_by = ?, resolved_at = NOW() WHERE id = ?")->execute([$action_type, $user['id'], $report_id]);
    json_response(['success' => true, 'message' => $action_type === 'resolved' ? '举报已处理' : '举报已驳回']);
}

// ============ POST: Create post ============
if ($method === 'POST' && $action === 'create') {
    $input = forum_input();
    $title = trim($input['title'] ?? '');
    $content = trim($input['content'] ?? '');
    $category_id = (int)($input['category_id'] ?? 1);

    if ($title === '') json_response(['error' => '标题不能为空'], 422);
    if (mb_strlen($title) < 4) json_response(['error' => '标题至少4个字符'], 422);
    if ($content === '') json_response(['error' => '内容不能为空'], 422);

    // Verify category exists
    $stmt = $pdo->prepare("SELECT id FROM forum_categories WHERE id = ?");
    $stmt->execute([$category_id]);
    if (!$stmt->fetch()) $category_id = 1;

    $stmt = $pdo->prepare("INSERT INTO forum_posts (user_id, title, content, category_id) VALUES (?, ?, ?, ?)");
    $stmt->execute([$user['id'], $title, $content, $category_id]);
    $post_id = $pdo->lastInsertId();

    json_response(['success' => true, 'id' => (int)$post_id, 'message' => '文章已发布']);
}

// ============ POST: Add comment ============
if ($method === 'POST' && $action === 'comment') {
    $input = forum_input();
    $post_id = (int)($input['post_id'] ?? 0);
    $parent_id = (int)($input['parent_id'] ?? 0);
    $content = trim($input['content'] ?? '');

    if ($post_id <= 0) json_response(['error' => '无效的文章ID'], 400);
    if ($content === '') json_response(['error' => '评论内容不能为空'], 422);

    // Verify post exists
    $stmt = $pdo->prepare("SELECT id, is_archived FROM forum_posts WHERE id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();
    if (!$post) json_response(['error' => '文章不存在'], 404);
    if ($post['is_archived']) json_response(['error' => '文章已归档，不再接受评论'], 422);

    $stmt = $pdo->prepare("INSERT INTO forum_comments (post_id, user_id, parent_id, content) VALUES (?, ?, ?, ?)");
    $stmt->execute([$post_id, $user['id'], $parent_id ?: null, $content]);

    json_response(['success' => true, 'message' => '评论已发布']);
}

// ============ POST: Like / Unlike ============
if ($method === 'POST' && $action === 'like') {
    $input = forum_input();
    $type = $input['type'] ?? 'post'; // post or comment
    $target_id = (int)($input['target_id'] ?? 0);

    if ($target_id <= 0) json_response(['error' => '无效的目标ID'], 400);

    if ($type === 'post') {
        $stmt = $pdo->prepare("SELECT 1 FROM forum_likes WHERE post_id = ? AND user_id = ? AND type = 'post'");
        $stmt->execute([$target_id, $user['id']]);
        $exists = $stmt->fetch();
        if ($exists) {
            // Unlike
            $pdo->prepare("DELETE FROM forum_likes WHERE post_id = ? AND user_id = ? AND type = 'post'")->execute([$target_id, $user['id']]);
            $pdo->prepare("UPDATE forum_posts SET likes_count = GREATEST(likes_count - 1, 0) WHERE id = ?")->execute([$target_id]);
            $stmt = $pdo->prepare("SELECT likes_count FROM forum_posts WHERE id = ?");
            $stmt->execute([$target_id]);
            json_response(['success' => true, 'liked' => false, 'count' => (int)$stmt->fetchColumn()]);
        } else {
            // Like
            $pdo->prepare("INSERT INTO forum_likes (post_id, user_id, type) VALUES (?, ?, 'post')")->execute([$target_id, $user['id']]);
            $pdo->prepare("UPDATE forum_posts SET likes_count = likes_count + 1 WHERE id = ?")->execute([$target_id]);
            $stmt = $pdo->prepare("SELECT likes_count FROM forum_posts WHERE id = ?");
            $stmt->execute([$target_id]);
            json_response(['success' => true, 'liked' => true, 'count' => (int)$stmt->fetchColumn()]);
        }
    } else {
        // Comment like
        $stmt = $pdo->prepare("SELECT 1 FROM forum_likes WHERE comment_id = ? AND user_id = ? AND type = 'comment'");
        $stmt->execute([$target_id, $user['id']]);
        $exists = $stmt->fetch();
        if ($exists) {
            $pdo->prepare("DELETE FROM forum_likes WHERE comment_id = ? AND user_id = ? AND type = 'comment'")->execute([$target_id, $user['id']]);
            $pdo->prepare("UPDATE forum_comments SET likes_count = GREATEST(likes_count - 1, 0) WHERE id = ?")->execute([$target_id]);
            $stmt = $pdo->prepare("SELECT likes_count FROM forum_comments WHERE id = ?");
            $stmt->execute([$target_id]);
            json_response(['success' => true, 'liked' => false, 'count' => (int)$stmt->fetchColumn()]);
        } else {
            $pdo->prepare("INSERT INTO forum_likes (comment_id, user_id, type) VALUES (?, ?, 'comment')")->execute([$target_id, $user['id']]);
            $pdo->prepare("UPDATE forum_comments SET likes_count = likes_count + 1 WHERE id = ?")->execute([$target_id]);
            $stmt = $pdo->prepare("SELECT likes_count FROM forum_comments WHERE id = ?");
            $stmt->execute([$target_id]);
            json_response(['success' => true, 'liked' => true, 'count' => (int)$stmt->fetchColumn()]);
        }
    }
}

// ============ POST: Delete post (own or admin) ============
if ($method === 'POST' && $action === 'delete_post') {
    $input = forum_input();
    $post_id = (int)($input['post_id'] ?? 0);
    if ($post_id <= 0) json_response(['error' => '无效的文章ID'], 400);

    $stmt = $pdo->prepare("SELECT user_id FROM forum_posts WHERE id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();
    if (!$post) json_response(['error' => '文章不存在'], 404);

    if ((int)$post['user_id'] !== (int)$user['id']) {
        if (!has_admin_permission($user, 'manage_forum')) {
            json_response(['error' => '没有权限'], 403);
        }
    }

    $pdo->beginTransaction();
    $pdo->prepare("DELETE FROM forum_likes WHERE post_id = ?")->execute([$post_id]);
    $pdo->prepare("DELETE FROM forum_reactions WHERE target_type = 'post' AND target_id = ?")->execute([$post_id]);
    $pdo->prepare("DELETE FROM forum_post_tags WHERE post_id = ?")->execute([$post_id]);
    $pdo->prepare("DELETE FROM forum_poll_votes WHERE poll_id IN (SELECT id FROM forum_polls WHERE post_id = ?)")->execute([$post_id]);
    $pdo->prepare("DELETE FROM forum_poll_options WHERE poll_id IN (SELECT id FROM forum_polls WHERE post_id = ?)")->execute([$post_id]);
    $pdo->prepare("DELETE FROM forum_polls WHERE post_id = ?")->execute([$post_id]);
    $pdo->prepare("DELETE FROM forum_comments WHERE post_id = ?")->execute([$post_id]);
    $pdo->prepare("DELETE FROM forum_posts WHERE id = ?")->execute([$post_id]);
    $pdo->commit();

    json_response(['success' => true, 'message' => '文章已删除']);
}

// ============ GET: User posts (for profile) ============
if ($method === 'GET' && $action === 'user_posts') {
    $target_user_id = (int)($_GET['user_id'] ?? 0);
    $page = max(1, (int)($_GET['page'] ?? 1));
    $per_page = 10;
    $offset = ($page - 1) * $per_page;

    if ($target_user_id <= 0) json_response(['error' => '无效的用户ID'], 400);

    $stmt = $pdo->prepare("SELECT p.*, c.name as category_name, c.icon as category_icon
                    FROM forum_posts p
                    JOIN forum_categories c ON c.id = p.category_id
                    WHERE p.user_id = ?
                    ORDER BY p.created_at DESC
                    LIMIT $per_page OFFSET $offset");
    $stmt->execute([$target_user_id]);
    $posts = $stmt->fetchAll();

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM forum_posts WHERE user_id = ?");
    $stmt->execute([$target_user_id]);
    $total = (int)$stmt->fetchColumn();

    json_response(['posts' => $posts, 'total' => $total, 'page' => $page]);
}

// ============ GET: Hot posts ============
if ($method === 'GET' && $action === 'hot') {
    $stmt = $pdo->query("SELECT p.*, u.username, u.nickname, u.avatar,
                   c.name as category_name, c.icon as category_icon
            FROM forum_posts p
            JOIN users u ON u.id = p.user_id
            JOIN forum_categories c ON c.id = p.category_id
            WHERE p.is_archived = 0
            ORDER BY (p.likes_count * 2 + p.replies_count * 3 + CASE WHEN p.is_pinned = 1 THEN 100 ELSE 0 END) DESC
            LIMIT 10");
    $posts = $stmt->fetchAll();
    json_response(['posts' => $posts]);
}

// ============ 管理员接口 ============

function require_forum_admin($user) {
    require_admin_permission($user, 'manage_forum');
}

// GET: Admin stats
if ($method === 'GET' && $action === 'admin_stats') {
    require_forum_admin($user);
    $stats = [
        'posts' => (int)$pdo->query("SELECT COUNT(*) FROM forum_posts")->fetchColumn(),
        'comments' => (int)$pdo->query("SELECT COUNT(*) FROM forum_comments")->fetchColumn(),
        'categories' => (int)$pdo->query("SELECT COUNT(*) FROM forum_categories")->fetchColumn(),
        'tags' => (int)$pdo->query("SELECT COUNT(*) FROM forum_tags")->fetchColumn(),
        'pinned' => (int)$pdo->query("SELECT COUNT(*) FROM forum_posts WHERE is_pinned = 1")->fetchColumn(),
        'archived' => (int)$pdo->query("SELECT COUNT(*) FROM forum_posts WHERE is_archived = 1")->fetchColumn(),
        'total_reactions' => (int)$pdo->query("SELECT COUNT(*) FROM forum_reactions")->fetchColumn(),
        'total_likes' => (int)$pdo->query("SELECT COALESCE(SUM(likes_count),0) FROM forum_posts")->fetchColumn(),
        'posts_today' => (int)$pdo->query("SELECT COUNT(*) FROM forum_posts WHERE DATE(created_at) = CURDATE()")->fetchColumn(),
        'posts_week' => (int)$pdo->query("SELECT COUNT(*) FROM forum_posts WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)")->fetchColumn(),
    ];
    json_response(['stats' => $stats]);
}

// GET: Admin posts list
if ($method === 'GET' && $action === 'admin_posts') {
    require_forum_admin($user);
    $page = max(1, (int)($_GET['page'] ?? 1));
    $per_page = 30;
    $offset = ($page - 1) * $per_page;
    $search = trim($_GET['search'] ?? '');
    $category_id = (int)($_GET['category_id'] ?? 0);

    $where = [];
    $params = [];
    if ($search !== '') {
        $where[] = "(p.title LIKE ? OR p.content LIKE ? OR u.nickname LIKE ? OR u.username LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    if ($category_id > 0) {
        $where[] = "p.category_id = ?";
        $params[] = $category_id;
    }
    $filter = $_GET['filter'] ?? '';
    if ($filter === 'pinned') {
        $where[] = "p.is_pinned = 1";
    } elseif ($filter === 'archived') {
        $where[] = "p.is_archived = 1";
    }
    $where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM forum_posts p JOIN users u ON u.id = p.user_id $where_sql");
    $stmt->execute($params);
    $total = (int)$stmt->fetchColumn();

    $sql = "SELECT p.*, u.username, u.nickname, u.avatar,
                   c.name as category_name, c.icon as category_icon,
                   (SELECT GROUP_CONCAT(t.name SEPARATOR ', ') FROM forum_post_tags fpt JOIN forum_tags t ON t.id = fpt.tag_id WHERE fpt.post_id = p.id) as tag_names
            FROM forum_posts p
            JOIN users u ON u.id = p.user_id
            JOIN forum_categories c ON c.id = p.category_id
            $where_sql
            ORDER BY p.created_at DESC
            LIMIT $per_page OFFSET $offset";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $posts = $stmt->fetchAll();

    json_response(['posts' => $posts, 'total' => $total, 'page' => $page, 'pages' => (int)ceil($total / $per_page)]);
}

// GET: Admin comments list
if ($method === 'GET' && $action === 'admin_comments') {
    require_forum_admin($user);
    $page = max(1, (int)($_GET['page'] ?? 1));
    $per_page = 50;
    $offset = ($page - 1) * $per_page;

    $sql = "SELECT cm.*, p.title as post_title,
                   u.username, u.nickname, u.avatar
            FROM forum_comments cm
            JOIN forum_posts p ON p.id = cm.post_id
            JOIN users u ON u.id = cm.user_id
            ORDER BY cm.created_at DESC
            LIMIT $per_page OFFSET $offset";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $comments = $stmt->fetchAll();

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM forum_comments");
    $stmt->execute();
    $total = (int)$stmt->fetchColumn();

    json_response(['comments' => $comments, 'total' => $total, 'page' => $page, 'pages' => (int)ceil($total / $per_page)]);
}

// GET: Admin categories
if ($method === 'GET' && $action === 'admin_categories') {
    require_forum_admin($user);
    $stmt = $pdo->query("SELECT fc.*, (SELECT COUNT(*) FROM forum_posts WHERE category_id = fc.id) as post_count
                    FROM forum_categories fc ORDER BY fc.sort_order ASC, fc.id ASC");
    json_response(['categories' => $stmt->fetchAll()]);
}

// POST: Admin create category
if ($method === 'POST' && $action === 'admin_create_category') {
    require_forum_admin($user);
    $input = forum_input();
    $name = trim($input['name'] ?? '');
    $description = trim($input['description'] ?? '');
    $icon = trim($input['icon'] ?? '📁');
    $sort_order = (int)($input['sort_order'] ?? 0);
    if ($name === '') json_response(['error' => '分类名称不能为空'], 422);
    $stmt = $pdo->prepare("INSERT INTO forum_categories (name, description, icon, sort_order) VALUES (?, ?, ?, ?)");
    $stmt->execute([$name, $description, $icon, $sort_order]);
    json_response(['success' => true, 'message' => '分类已创建']);
}

// POST: Admin update category
if ($method === 'POST' && $action === 'admin_update_category') {
    require_forum_admin($user);
    $input = forum_input();
    $id = (int)($input['id'] ?? 0);
    $name = trim($input['name'] ?? '');
    $description = trim($input['description'] ?? '');
    $icon = trim($input['icon'] ?? '📁');
    $sort_order = (int)($input['sort_order'] ?? 0);
    if ($id <= 0) json_response(['error' => '无效的分类ID'], 400);
    if ($name === '') json_response(['error' => '分类名称不能为空'], 422);
    $stmt = $pdo->prepare("UPDATE forum_categories SET name = ?, description = ?, icon = ?, sort_order = ? WHERE id = ?");
    $stmt->execute([$name, $description, $icon, $sort_order, $id]);
    json_response(['success' => true, 'message' => '分类已更新']);
}

// POST: Admin delete category
if ($method === 'POST' && $action === 'admin_delete_category') {
    require_forum_admin($user);
    $input = forum_input();
    $id = (int)($input['id'] ?? 0);
    if ($id <= 0) json_response(['error' => '无效的分类ID'], 400);
    // Check if category has posts
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM forum_posts WHERE category_id = ?");
    $stmt->execute([$id]);
    if ($stmt->fetchColumn() > 0) {
        json_response(['error' => '该分类下有文章，无法删除。请先转移或删除文章。'], 422);
    }
    $pdo->prepare("DELETE FROM forum_categories WHERE id = ?")->execute([$id]);
    json_response(['success' => true, 'message' => '分类已删除']);
}

// POST: Admin toggle pin
if ($method === 'POST' && $action === 'admin_toggle_pin') {
    require_forum_admin($user);
    $input = forum_input();
    $post_id = (int)($input['post_id'] ?? 0);
    if ($post_id <= 0) json_response(['error' => '无效的文章ID'], 400);
    $stmt = $pdo->prepare("SELECT is_pinned FROM forum_posts WHERE id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();
    if (!$post) json_response(['error' => '文章不存在'], 404);
    $new_val = $post['is_pinned'] ? 0 : 1;
    $pdo->prepare("UPDATE forum_posts SET is_pinned = ? WHERE id = ?")->execute([$new_val, $post_id]);
    json_response(['success' => true, 'message' => $new_val ? '已置顶' : '已取消置顶', 'is_pinned' => $new_val]);
}

// POST: Admin delete comment
if ($method === 'POST' && $action === 'admin_delete_comment') {
    require_forum_admin($user);
    $input = forum_input();
    $comment_id = (int)($input['comment_id'] ?? 0);
    if ($comment_id <= 0) json_response(['error' => '无效的评论ID'], 400);
    $stmt = $pdo->prepare("SELECT post_id FROM forum_comments WHERE id = ?");
    $stmt->execute([$comment_id]);
    $comment = $stmt->fetch();
    if (!$comment) json_response(['error' => '评论不存在'], 404);
    // Also delete replies to this comment and their likes
    $stmt = $pdo->prepare("SELECT id FROM forum_comments WHERE parent_id = ?");
    $stmt->execute([$comment_id]);
    $reply_ids = array_column($stmt->fetchAll(), 'id');
    if (!empty($reply_ids)) {
        $ph = implode(',', array_fill(0, count($reply_ids), '?'));
        $pdo->prepare("DELETE FROM forum_likes WHERE comment_id IN ($ph)")->execute($reply_ids);
        $pdo->prepare("DELETE FROM forum_reactions WHERE target_type = 'comment' AND target_id IN ($ph)")->execute($reply_ids);
        $pdo->prepare("DELETE FROM forum_comments WHERE parent_id = ?")->execute([$comment_id]);
    } else {
        $pdo->prepare("DELETE FROM forum_comments WHERE parent_id = ?")->execute([$comment_id]);
    }
    $pdo->prepare("DELETE FROM forum_likes WHERE comment_id = ?")->execute([$comment_id]);
    $pdo->prepare("DELETE FROM forum_reactions WHERE target_type = 'comment' AND target_id = ?")->execute([$comment_id]);
    $pdo->prepare("DELETE FROM forum_comments WHERE id = ?")->execute([$comment_id]);
    // Update reply count
    $pdo->prepare("UPDATE forum_posts SET replies_count = (SELECT COUNT(*) FROM forum_comments WHERE post_id = ?) WHERE id = ?")->execute([$comment['post_id'], $comment['post_id']]);
    json_response(['success' => true, 'message' => '评论已删除']);
}

// POST: Admin edit post
if ($method === 'POST' && $action === 'admin_edit_post') {
    require_forum_admin($user);
    $input = forum_input();
    $post_id = (int)($input['post_id'] ?? 0);
    $title = trim($input['title'] ?? '');
    $content = $input['content'] ?? null;
    if ($content !== null) $content = trim($content);
    $category_id = (int)($input['category_id'] ?? 0);
    if ($post_id <= 0) json_response(['error' => '无效的文章ID'], 400);
    if ($title === '') json_response(['error' => '标题不能为空'], 422);
    if ($content !== null && $content === '') json_response(['error' => '内容不能为空'], 422);
    $sets = "title = ?";
    $params = [$title];
    if ($content !== null && $content !== '') {
        $sets .= ", content = ?";
        $params[] = $content;
    }
    if ($category_id > 0) {
        $stmt = $pdo->prepare("SELECT id FROM forum_categories WHERE id = ?");
        $stmt->execute([$category_id]);
        if ($stmt->fetch()) {
            $sets .= ", category_id = ?";
            $params[] = $category_id;
        }
    }
    $params[] = $post_id;
    $stmt = $pdo->prepare("UPDATE forum_posts SET $sets WHERE id = ?");
    $stmt->execute($params);
    json_response(['success' => true, 'message' => '文章已更新']);
}

// ============ POST: Toggle emoji reaction ============
if ($method === 'POST' && $action === 'react') {
    $input = forum_input();
    $target_type = $input['target_type'] ?? 'post';
    $target_id = (int)($input['target_id'] ?? 0);
    $emoji = trim($input['emoji'] ?? '');
    if ($target_type !== 'post' && $target_type !== 'comment') json_response(['error' => '无效的目标类型'], 400);
    if ($target_id <= 0) json_response(['error' => '无效的目标ID'], 400);
    if ($emoji === '') json_response(['error' => '表情不能为空'], 422);
    $stmt = $pdo->prepare("SELECT 1 FROM forum_reactions WHERE target_type = ? AND target_id = ? AND user_id = ? AND emoji = ?");
    $stmt->execute([$target_type, $target_id, $user['id'], $emoji]);
    $exists = $stmt->fetch();
    if ($exists) {
        $pdo->prepare("DELETE FROM forum_reactions WHERE target_type = ? AND target_id = ? AND user_id = ? AND emoji = ?")->execute([$target_type, $target_id, $user['id'], $emoji]);
        $json_response = ['success' => true, 'liked' => false, 'count' => 0];
    } else {
        $pdo->prepare("INSERT INTO forum_reactions (target_type, target_id, user_id, emoji) VALUES (?, ?, ?, ?)")->execute([$target_type, $target_id, $user['id'], $emoji]);
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM forum_reactions WHERE target_type = ? AND target_id = ? AND emoji = ?");
        $stmt->execute([$target_type, $target_id, $emoji]);
        $json_response = ['success' => true, 'liked' => true, 'count' => (int)$stmt->fetchColumn()];
    }
    json_response($json_response);
}

// ============ GET: List tags ============
if ($method === 'GET' && $action === 'tags') {
    $stmt = $pdo->query("SELECT t.*, (SELECT COUNT(*) FROM forum_post_tags WHERE tag_id = t.id) as post_count
                 FROM forum_tags t ORDER BY t.sort_order ASC, t.name ASC");
    json_response(['tags' => $stmt->fetchAll()]);
}

// ============ POST: Create tag (admin) ============
if ($method === 'POST' && $action === 'admin_create_tag') {
    require_forum_admin($user);
    $input = forum_input();
    $name = trim($input['name'] ?? '');
    $color = trim($input['color'] ?? '#667eea');
    $sort_order = (int)($input['sort_order'] ?? 0);
    if ($name === '') json_response(['error' => '标签名称不能为空'], 422);
    $stmt = $pdo->prepare("INSERT INTO forum_tags (name, color, sort_order) VALUES (?, ?, ?)");
    $stmt->execute([$name, $color, $sort_order]);
    json_response(['success' => true, 'message' => '标签已创建']);
}

// ============ POST: Delete tag (admin) ============
if ($method === 'POST' && $action === 'admin_delete_tag') {
    require_forum_admin($user);
    $input = forum_input();
    $tag_id = (int)($input['tag_id'] ?? 0);
    if ($tag_id <= 0) json_response(['error' => '无效的标签ID'], 400);
    $stmt = $pdo->prepare("SELECT COUNT(*) as cnt FROM forum_post_tags WHERE tag_id = ?");
    $stmt->execute([$tag_id]);
    $cnt = (int)$stmt->fetchColumn();
    if ($cnt > 0) json_response(['error' => '该标签已被 ' . $cnt . ' 篇文章使用，无法删除'], 422);
    $stmt = $pdo->prepare("DELETE FROM forum_tags WHERE id = ?");
    $stmt->execute([$tag_id]);
    json_response(['success' => true, 'message' => '标签已删除']);
}

// ============ POST: Add tag to post ============
if ($method === 'POST' && $action === 'add_tag') {
    $input = forum_input();
    $post_id = (int)($input['post_id'] ?? 0);
    $tag_id = (int)($input['tag_id'] ?? 0);
    if ($post_id <= 0 || $tag_id <= 0) json_response(['error' => '无效的参数'], 400);
    $stmt = $pdo->prepare("SELECT id FROM forum_posts WHERE id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();
    if (!$post) json_response(['error' => '文章不存在'], 404);
    if ((int)$post['user_id'] !== (int)$user['id']) {
        if (!has_admin_permission($user, 'manage_forum')) json_response(['error' => '没有权限'], 403);
    }
    $stmt = $pdo->prepare("SELECT id FROM forum_tags WHERE id = ?");
    $stmt->execute([$tag_id]);
    if (!$stmt->fetch()) json_response(['error' => '标签不存在'], 404);
    $pdo->prepare("INSERT IGNORE INTO forum_post_tags (post_id, tag_id) VALUES (?, ?)")->execute([$post_id, $tag_id]);
    json_response(['success' => true, 'message' => '标签已添加']);
}

// ============ POST: Remove tag from post ============
if ($method === 'POST' && $action === 'remove_tag') {
    $input = forum_input();
    $post_id = (int)($input['post_id'] ?? 0);
    $tag_id = (int)($input['tag_id'] ?? 0);
    if ($post_id <= 0 || $tag_id <= 0) json_response(['error' => '无效的参数'], 400);
    $stmt = $pdo->prepare("SELECT id FROM forum_posts WHERE id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();
    if (!$post) json_response(['error' => '文章不存在'], 404);
    if ((int)$post['user_id'] !== (int)$user['id']) {
        if (!has_admin_permission($user, 'manage_forum')) json_response(['error' => '没有权限'], 403);
    }
    $pdo->prepare("DELETE FROM forum_post_tags WHERE post_id = ? AND tag_id = ?")->execute([$post_id, $tag_id]);
    json_response(['success' => true, 'message' => '标签已移除']);
}

// ============ POST: Toggle archive ============
if ($method === 'POST' && $action === 'toggle_archive') {
    $input = forum_input();
    $post_id = (int)($input['post_id'] ?? 0);
    if ($post_id <= 0) json_response(['error' => '无效的文章ID'], 400);
    $stmt = $pdo->prepare("SELECT user_id, is_archived FROM forum_posts WHERE id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();
    if (!$post) json_response(['error' => '文章不存在'], 404);
    if ((int)$post['user_id'] !== (int)$user['id']) {
        if (!has_admin_permission($user, 'manage_forum')) json_response(['error' => '没有权限'], 403);
    }
    $new_val = $post['is_archived'] ? 0 : 1;
    $pdo->prepare("UPDATE forum_posts SET is_archived = ? WHERE id = ?")->execute([$new_val, $post_id]);
    json_response(['success' => true, 'message' => $new_val ? '已归档' : '已取消归档', 'is_archived' => $new_val]);
}

// ============ POST: Create poll ============
if ($method === 'POST' && $action === 'create_poll') {
    $input = forum_input();
    $post_id = (int)($input['post_id'] ?? 0);
    $question = trim($input['question'] ?? '');
    $options = $input['options'] ?? [];
    if ($post_id <= 0) json_response(['error' => '无效的文章ID'], 400);
    if ($question === '') json_response(['error' => '投票问题不能为空'], 422);
    $options = array_filter(array_map('trim', $options), function($v) { return $v !== ''; });
    if (count($options) < 2) json_response(['error' => '至少需要2个选项'], 422);
    $stmt = $pdo->prepare("SELECT user_id, is_archived FROM forum_posts WHERE id = ?");
    $stmt->execute([$post_id]);
    $post = $stmt->fetch();
    if (!$post) json_response(['error' => '文章不存在'], 404);
    if ((int)$post['user_id'] !== (int)$user['id'] && !has_admin_permission($user, 'manage_forum')) {
        json_response(['error' => '没有权限'], 403);
    }
    if ($post['is_archived']) json_response(['error' => '已归档的文章无法创建投票'], 422);
    $stmt = $pdo->prepare("SELECT id FROM forum_polls WHERE post_id = ?");
    $stmt->execute([$post_id]);
    if ($stmt->fetch()) json_response(['error' => '该文章已有投票'], 422);
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("INSERT INTO forum_polls (post_id, question) VALUES (?, ?)");
    $stmt->execute([$post_id, $question]);
    $poll_id = $pdo->lastInsertId();
    $stmt = $pdo->prepare("INSERT INTO forum_poll_options (poll_id, text, sort_order) VALUES (?, ?, ?)");
    foreach ($options as $i => $opt) {
        $stmt->execute([$poll_id, $opt, $i]);
    }
    $pdo->commit();
    json_response(['success' => true, 'message' => '投票已创建', 'poll_id' => (int)$poll_id]);
}

// ============ POST: Vote on poll ============
if ($method === 'POST' && $action === 'vote_poll') {
    $input = forum_input();
    $poll_id = (int)($input['poll_id'] ?? 0);
    $option_id = (int)($input['option_id'] ?? 0);
    if ($poll_id <= 0 || $option_id <= 0) json_response(['error' => '无效的参数'], 400);
    $stmt = $pdo->prepare("SELECT id FROM forum_poll_options WHERE id = ? AND poll_id = ?");
    $stmt->execute([$option_id, $poll_id]);
    if (!$stmt->fetch()) json_response(['error' => '选项不存在'], 404);
    $stmt = $pdo->prepare("SELECT 1 FROM forum_poll_votes WHERE poll_id = ? AND user_id = ?");
    $stmt->execute([$poll_id, $user['id']]);
    if ($stmt->fetch()) json_response(['error' => '您已经投过票了'], 422);
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("INSERT INTO forum_poll_votes (poll_id, option_id, user_id) VALUES (?, ?, ?)");
    $stmt->execute([$poll_id, $option_id, $user['id']]);
    $pdo->commit();
    json_response(['success' => true, 'message' => '投票成功']);
}

// ============ GET: Filter posts by tag ============
if ($method === 'GET' && $action === 'list_by_tag') {
    $tag_id = (int)($_GET['tag_id'] ?? 0);
    $page = max(1, (int)($_GET['page'] ?? 1));
    $per_page = 20;
    $offset = ($page - 1) * $per_page;
    if ($tag_id <= 0) json_response(['error' => '无效的标签ID'], 400);
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM forum_post_tags fpt WHERE fpt.tag_id = ?");
    $stmt->execute([$tag_id]);
    $total = (int)$stmt->fetchColumn();
    $stmt = $pdo->prepare("SELECT p.*, u.username, u.nickname, u.avatar,
                   c.name as category_name, c.icon as category_icon
            FROM forum_posts p
            JOIN forum_post_tags fpt ON fpt.post_id = p.id
            JOIN users u ON u.id = p.user_id
            JOIN forum_categories c ON c.id = p.category_id
            WHERE fpt.tag_id = ?
            ORDER BY p.is_pinned DESC, p.created_at DESC
            LIMIT $per_page OFFSET $offset");
    $stmt->execute([$tag_id, $tag_id]);
    $posts = $stmt->fetchAll();
    $pages = (int)ceil($total / $per_page);
    json_response(['posts' => $posts, 'total' => $total, 'page' => $page, 'pages' => $pages]);
}

// ============ 帖子订阅 ============
// 确保订阅表存在
$stmt = $pdo->query("SHOW TABLES LIKE 'post_subscriptions'");
if (!$stmt->fetch()) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS post_subscriptions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        post_id INT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_sub (user_id, post_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (post_id) REFERENCES forum_posts(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

if ($method === 'POST' && $action === 'subscribe') {
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $post_id = (int)($in['post_id'] ?? 0);
    if ($post_id <= 0) json_response(['error' => '无效帖子'], 400);
    $pdo->prepare("INSERT IGNORE INTO post_subscriptions (user_id, post_id) VALUES (?, ?)")->execute([$user['id'], $post_id]);
    json_response(['success' => true]);
}

if ($method === 'POST' && $action === 'unsubscribe') {
    $in = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $post_id = (int)($in['post_id'] ?? 0);
    $pdo->prepare("DELETE FROM post_subscriptions WHERE user_id = ? AND post_id = ?")->execute([$user['id'], $post_id]);
    json_response(['success' => true]);
}

if ($method === 'GET' && $action === 'subscribed_posts') {
    $stmt = $pdo->prepare("SELECT p.*, u.nickname, u.avatar, ps.created_at as sub_at,
        (SELECT COUNT(*) FROM forum_comments WHERE post_id = p.id) as comment_count,
        (SELECT MAX(created_at) FROM forum_comments WHERE post_id = p.id) as last_comment_at
        FROM post_subscriptions ps
        JOIN forum_posts p ON p.id = ps.post_id
        JOIN users u ON u.id = p.user_id
        WHERE ps.user_id = ?
        ORDER BY ps.created_at DESC LIMIT 50");
    $stmt->execute([$user['id']]);
    json_response(['posts' => $stmt->fetchAll()]);
}

// 检查是否已订阅
if ($method === 'GET' && $action === 'is_subscribed') {
    $post_id = (int)($_GET['post_id'] ?? 0);
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM post_subscriptions WHERE user_id = ? AND post_id = ?");
    $stmt->execute([$user['id'], $post_id]);
    json_response(['subscribed' => $stmt->fetchColumn() > 0]);
}

json_response(['error' => '未知操作'], 400);
