<?php
require_once __DIR__ . '/../functions.php';
$pdo = db_connect();
$user = require_auth();

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET' && $action === 'list') {
    // Groups I own or am member of
    $stmt = $pdo->prepare("
        SELECT g.id, g.name, g.avatar, g.description, g.owner_id,
               gm.role, gm.joined_at,
               (SELECT content FROM messages WHERE group_id = g.id ORDER BY created_at DESC LIMIT 1) as last_msg,
               (SELECT created_at FROM messages WHERE group_id = g.id ORDER BY created_at DESC LIMIT 1) as last_time,
               (SELECT COUNT(*) FROM messages m WHERE m.group_id = g.id AND m.sender_id != ? AND m.is_read = 0) as unread_cnt
        FROM `groups` g
        JOIN group_members gm ON gm.group_id = g.id
        WHERE gm.user_id = ?
        ORDER BY last_time DESC
    ");
    $stmt->execute([$user['id'], $user['id']]);
    $groups = [];
    while ($row = $stmt->fetch()) {
        $groups[] = [
            'id' => (int)$row['id'],
            'name' => $row['name'],
            'avatar' => $row['avatar'],
            'description' => $row['description'],
            'owner_id' => (int)$row['owner_id'],
            'role' => $row['role'],
            'joined_at' => $row['joined_at'],
            'last_message' => $row['last_msg'] ?: '暂无消息',
            'last_time' => $row['last_time'] ? format_message_time($row['last_time']) : '',
            'unread' => (int)$row['unread_cnt']
        ];
    }
    json_response(['groups' => $groups]);
}

if ($method === 'GET' && $action === 'members') {
    $group_id = (int)($_GET['group_id'] ?? 0);
    $stmt = $pdo->prepare("SELECT role FROM group_members WHERE group_id = ? AND user_id = ?");
    $stmt->execute([$group_id, $user['id']]);
    if (!$stmt->fetch()) {
        json_response(['error' => '无权访问'], 403);
    }

    $stmt = $pdo->prepare("
        SELECT u.id, u.username, u.nickname, u.avatar, u.status, gm.role, gm.joined_at, gm.permissions, gm.muted_until
        FROM group_members gm
        JOIN users u ON u.id = gm.user_id
        WHERE gm.group_id = ?
        ORDER BY CASE gm.role WHEN 'owner' THEN 1 WHEN 'admin' THEN 2 ELSE 3 END, u.nickname
    ");
    $stmt->execute([$group_id]);
    $members = [];
    while ($row = $stmt->fetch()) {
        $permissions = [];
        if ($row['permissions']) {
            $permissions = json_decode($row['permissions'], true) ?: [];
        }
        $members[] = [
            'id' => (int)$row['id'],
            'username' => $row['username'],
            'nickname' => $row['nickname'],
            'avatar' => $row['avatar'],
            'status' => $row['status'],
            'role' => $row['role'],
            'joined_at' => $row['joined_at'],
            'permissions' => $permissions,
            'muted_until' => $row['muted_until'] ?: null
        ];
    }
    json_response(['members' => $members]);
}

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;

    if ($action === 'create') {
        $name = trim($input['name'] ?? '');
        $description = trim($input['description'] ?? '');
        $member_ids = $input['members'] ?? [];

        if (mb_strlen($name, 'UTF-8') < 2) {
            json_response(['error' => '群名称至少2个字符'], 400);
        }
        if (mb_strlen($name, 'UTF-8') > 50) {
            json_response(['error' => '群名称不能超过50个字符'], 400);
        }

        $pdo->beginTransaction();
        $stmt = $pdo->prepare("INSERT INTO `groups` (name, owner_id, description) VALUES (?, ?, ?)");
        $stmt->execute([$name, $user['id'], $description]);
        $group_id = $pdo->lastInsertId();

        // Add owner
        $stmt = $pdo->prepare("INSERT INTO group_members (group_id, user_id, role) VALUES (?, ?, 'owner')");
        $stmt->execute([$group_id, $user['id']]);

        // Add members
        if (!empty($member_ids) && is_array($member_ids)) {
            $stmt = $pdo->prepare("INSERT INTO group_members (group_id, user_id, role) VALUES (?, ?, 'member')");
            foreach ($member_ids as $mid) {
                $mid = (int)$mid;
                if ($mid > 0 && $mid != $user['id']) {
                    // Verify friendship
                    $stmt2 = $pdo->prepare("SELECT id FROM friendships WHERE ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)) AND status = 'accepted' LIMIT 1");
                    $stmt2->execute([$user['id'], $mid, $mid, $user['id']]);
                    if ($stmt2->fetch()) {
                        try {
                            $stmt->execute([$group_id, $mid]);
                        } catch (Exception $e) {
                            // ignore duplicate
                        }
                    }
                }
            }
        }

        $pdo->commit();

        $stmt = $pdo->prepare("SELECT * FROM `groups` WHERE id = ?");
        $stmt->execute([$group_id]);
        $group = $stmt->fetch();

        json_response(['group' => [
            'id' => (int)$group['id'],
            'name' => $group['name'],
            'description' => $group['description'],
            'owner_id' => (int)$group['owner_id']
        ]]);
    }

    if ($action === 'join') {
        $group_id = (int)($input['group_id'] ?? 0);
        $stmt = $pdo->prepare("SELECT id FROM `groups` WHERE id = ?");
        $stmt->execute([$group_id]);
        if (!$stmt->fetch()) {
            json_response(['error' => '群组不存在'], 404);
        }

        $stmt = $pdo->prepare("INSERT IGNORE INTO group_members (group_id, user_id, role) VALUES (?, ?, 'member')");
        $stmt->execute([$group_id, $user['id']]);
        json_response(['success' => true, 'message' => '已加入群组']);
    }

    if ($action === 'leave') {
        $group_id = (int)($input['group_id'] ?? 0);
        $stmt = $pdo->prepare("SELECT owner_id FROM `groups` WHERE id = ?");
        $stmt->execute([$group_id]);
        $group = $stmt->fetch();
        if (!$group) {
            json_response(['error' => '群组不存在'], 404);
        }
        if ($group['owner_id'] == $user['id']) {
            json_response(['error' => '群主不能退出群组，请先转让群主'], 403);
        }

        $stmt = $pdo->prepare("DELETE FROM group_members WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$group_id, $user['id']]);
        json_response(['success' => true, 'message' => '已退出群组']);
    }

    if ($action === 'dismiss') {
        $group_id = (int)($input['group_id'] ?? 0);
        $stmt = $pdo->prepare("SELECT owner_id FROM `groups` WHERE id = ?");
        $stmt->execute([$group_id]);
        $group = $stmt->fetch();
        if (!$group || $group['owner_id'] != $user['id']) {
            json_response(['error' => '无权操作'], 403);
        }

        $pdo->beginTransaction();
        $stmt = $pdo->prepare("DELETE FROM group_members WHERE group_id = ?");
        $stmt->execute([$group_id]);
        $stmt = $pdo->prepare("DELETE FROM `groups` WHERE id = ?");
        $stmt->execute([$group_id]);
        $pdo->commit();
        json_response(['success' => true, 'message' => '群组已解散']);
    }

    if ($action === 'upload_avatar') {
        $group_id = (int)($_POST['group_id'] ?? 0);
        if ($group_id <= 0) json_response(['error' => '无效的群组ID'], 400);
        $stmt = $pdo->prepare("SELECT owner_id FROM `groups` WHERE id = ?");
        $stmt->execute([$group_id]);
        $group = $stmt->fetch();
        if (!$group || $group['owner_id'] != $user['id']) json_response(['error' => '无权修改群头像'], 403);
        if (!isset($_FILES['avatar'])) json_response(['error' => '请选择图片文件'], 400);
        $file = $_FILES['avatar'];
        if ($file['error'] !== UPLOAD_ERR_OK) json_response(['error' => '文件上传失败'], 400);
        $allowed = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        if (!in_array($mime, $allowed, true)) json_response(['error' => '仅支持 JPG/PNG/GIF/WebP 格式'], 400);
        if ($file['size'] > 2 * 1024 * 1024) json_response(['error' => '图片大小不能超过 2MB'], 400);
        $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp'][$mime];
        $filename = 'group_' . $group_id . '_' . time() . '.' . $ext;
        $dst = __DIR__ . '/../uploads/groups/' . $filename;
        if (!move_uploaded_file($file['tmp_name'], $dst)) json_response(['error' => '文件保存失败'], 500);
        $stmt = $pdo->prepare("UPDATE `groups` SET avatar = ? WHERE id = ?");
        $stmt->execute([$filename, $group_id]);
        json_response(['avatar' => 'uploads/groups/' . $filename, 'message' => '群头像已更新']);
    }

    if ($action === 'invite') {
        $group_id = (int)($input['group_id'] ?? 0);
        $target_id = (int)($input['user_id'] ?? 0);

        if ($group_id <= 0 || $target_id <= 0) {
            json_response(['error' => '参数无效'], 400);
        }

        $stmt = $pdo->prepare("SELECT gm.role, gm.permissions FROM group_members WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$group_id, $user['id']]);
        $me = $stmt->fetch();
        if (!$me) {
            json_response(['error' => '无权邀请成员'], 403);
        }
        $allowed = $me['role'] === 'owner' || (($me['permissions'] ? json_decode($me['permissions'], true) : [])['invite'] ?? false);
        if (!$allowed) {
            json_response(['error' => '无权邀请成员'], 403);
        }

        $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
        $stmt->execute([$target_id]);
        if (!$stmt->fetch()) {
            json_response(['error' => '用户不存在'], 404);
        }

        $stmt = $pdo->prepare("SELECT id FROM group_members WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$group_id, $target_id]);
        if ($stmt->fetch()) {
            json_response(['error' => '该用户已在群组中'], 400);
        }

        $stmt = $pdo->prepare("SELECT max_members, (SELECT COUNT(*) FROM group_members WHERE group_id = ?) as cnt FROM `groups` WHERE id = ?");
        $stmt->execute([$group_id, $group_id]);
        $row = $stmt->fetch();
        if ($row && $row['max_members'] > 0 && $row['cnt'] >= $row['max_members']) {
            json_response(['error' => '群组已满'], 400);
        }

        $stmt = $pdo->prepare("INSERT INTO group_members (group_id, user_id, role) VALUES (?, ?, 'member')");
        $stmt->execute([$group_id, $target_id]);
        json_response(['success' => true, 'message' => '邀请成功']);
    }

    if ($action === 'kick') {
        $group_id = (int)($input['group_id'] ?? 0);
        $target_id = (int)($input['user_id'] ?? 0);

        if ($group_id <= 0 || $target_id <= 0) {
            json_response(['error' => '参数无效'], 400);
        }

        $stmt = $pdo->prepare("SELECT gm.role, gm.permissions, gm2.role as target_role FROM group_members gm JOIN group_members gm2 ON gm2.group_id = gm.group_id AND gm2.user_id = ? WHERE gm.group_id = ? AND gm.user_id = ?");
        $stmt->execute([$target_id, $group_id, $user['id']]);
        $me = $stmt->fetch();
        if (!$me) {
            json_response(['error' => '无权操作'], 403);
        }
        $allowed = $me['role'] === 'owner' || (($me['permissions'] ? json_decode($me['permissions'], true) : [])['kick'] ?? false);
        if (!$allowed || ($me['role'] === 'admin' && $me['target_role'] === 'admin')) {
            json_response(['error' => '无权操作'], 403);
        }

        if ($me['target_role'] === 'owner') {
            json_response(['error' => '不能踢出群主'], 400);
        }

        $stmt = $pdo->prepare("DELETE FROM group_members WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$group_id, $target_id]);
        json_response(['success' => true, 'message' => '已踢出群组']);
    }

    if ($action === 'set_group_admin') {
        $group_id = (int)($input['group_id'] ?? 0);
        $target_id = (int)($input['user_id'] ?? 0);
        $make_admin = !empty($input['make_admin']);

        if ($group_id <= 0 || $target_id <= 0) {
            json_response(['error' => '参数无效'], 400);
        }

        $stmt = $pdo->prepare("SELECT role FROM `groups` WHERE id = ?");
        $stmt->execute([$group_id]);
        $group = $stmt->fetch();
        if (!$group || $group['owner_id'] != $user['id']) {
            json_response(['error' => '仅群主可设置管理员'], 403);
        }

        $stmt = $pdo->prepare("SELECT role FROM group_members WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$group_id, $target_id]);
        $targetRole = $stmt->fetchColumn();
        if (!$targetRole || $targetRole === 'owner') {
            json_response(['error' => '目标用户不在群组中'], 404);
        }

        $newRole = $make_admin ? 'admin' : 'member';
        $permissions = null;
        if ($make_admin) {
            $permissions = json_encode(['kick' => true, 'mute' => true, 'invite' => true], JSON_UNESCAPED_UNICODE);
        }
        $stmt = $pdo->prepare("UPDATE group_members SET role = ?, permissions = ? WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$newRole, $permissions, $group_id, $target_id]);
        json_response(['success' => true, 'message' => $make_admin ? '已设为管理员' : '已取消管理员']);
    }

    if ($action === 'set_group_admin_permissions') {
        $group_id = (int)($input['group_id'] ?? 0);
        $target_id = (int)($input['user_id'] ?? 0);
        $permissions = $input['permissions'] ?? [];

        if ($group_id <= 0 || $target_id <= 0) {
            json_response(['error' => '参数无效'], 400);
        }

        $stmt = $pdo->prepare("SELECT role FROM `groups` WHERE id = ?");
        $stmt->execute([$group_id]);
        $group = $stmt->fetch();
        if (!$group || $group['owner_id'] != $user['id']) {
            json_response(['error' => '仅群主可配置管理员权限'], 403);
        }

        $stmt = $pdo->prepare("SELECT role FROM group_members WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$group_id, $target_id]);
        $targetRole = $stmt->fetchColumn();
        if ($targetRole !== 'admin') {
            json_response(['error' => '仅可配置群管理员权限'], 400);
        }

        $allowedKeys = ['kick', 'mute', 'invite'];
        $final = [];
        foreach ($allowedKeys as $key) {
            $final[$key] = in_array($key, $permissions, true);
        }
        $json = json_encode($final, JSON_UNESCAPED_UNICODE);
        $stmt = $pdo->prepare("UPDATE group_members SET permissions = ? WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$json, $group_id, $target_id]);
        json_response(['success' => true, 'message' => '管理员权限已更新']);
    }

    if ($action === 'mute_user') {
        $group_id = (int)($input['group_id'] ?? 0);
        $target_id = (int)($input['user_id'] ?? 0);
        $minutes = (int)($input['minutes'] ?? 0);

        if ($group_id <= 0 || $target_id <= 0 || $minutes <= 0) {
            json_response(['error' => '参数无效'], 400);
        }

        $stmt = $pdo->prepare("SELECT gm.role, gm.permissions, gm2.role as target_role FROM group_members gm JOIN group_members gm2 ON gm2.group_id = gm.group_id AND gm2.user_id = ? WHERE gm.group_id = ? AND gm.user_id = ?");
        $stmt->execute([$target_id, $group_id, $user['id']]);
        $me = $stmt->fetch();
        if (!$me) {
            json_response(['error' => '无权操作'], 403);
        }
        $allowed = $me['role'] === 'owner' || (($me['permissions'] ? json_decode($me['permissions'], true) : [])['mute'] ?? false);
        if (!$allowed || $me['target_role'] === 'owner') {
            json_response(['error' => '无权操作'], 403);
        }

        $until = date('Y-m-d H:i:s', time() + $minutes * 60);
        $stmt = $pdo->prepare("UPDATE group_members SET muted_until = ? WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$until, $group_id, $target_id]);
        json_response(['success' => true, 'message' => '已禁言', 'muted_until' => $until]);
    }

    if ($action === 'unmute_user') {
        $group_id = (int)($input['group_id'] ?? 0);
        $target_id = (int)($input['user_id'] ?? 0);

        if ($group_id <= 0 || $target_id <= 0) {
            json_response(['error' => '参数无效'], 400);
        }

        $stmt = $pdo->prepare("SELECT gm.role, gm.permissions FROM group_members gm WHERE gm.group_id = ? AND gm.user_id = ?");
        $stmt->execute([$group_id, $user['id']]);
        $me = $stmt->fetch();
        if (!$me) {
            json_response(['error' => '无权操作'], 403);
        }
        $allowed = $me['role'] === 'owner' || (($me['permissions'] ? json_decode($me['permissions'], true) : [])['mute'] ?? false);
        if (!$allowed) {
            json_response(['error' => '无权操作'], 403);
        }

        $stmt = $pdo->prepare("UPDATE group_members SET muted_until = NULL WHERE group_id = ? AND user_id = ?");
        $stmt->execute([$group_id, $target_id]);
        json_response(['success' => true, 'message' => '已解除禁言']);
    }

    json_response(['error' => '未知操作'], 400);
}

json_response(['error' => '未知操作'], 400);
