<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../functions.php';
$pdo = db_connect();

$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;

    if ($action === 'register') {
        $username = trim($input['username'] ?? '');
        $password = trim($input['password'] ?? '');
        $nickname = trim($input['nickname'] ?? '');

        if (!valid_username($username)) {
            json_response(['error' => '用户名只能包含字母、数字、下划线或中文，长度3-20位'], 400);
        }
        if (!valid_password($password)) {
            json_response(['error' => '密码长度至少6位'], 400);
        }

        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            json_response(['error' => '用户名已被占用'], 409);
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $nickname = $nickname ?: $username;

        $stmt = $pdo->prepare("INSERT INTO users (username, password, nickname) VALUES (?, ?, ?)");
        $stmt->execute([$username, $hash, $nickname]);
        $user_id = $pdo->lastInsertId();

        $token = create_token($user_id);
        json_response(['token' => $token, 'user' => ['id' => $user_id, 'username' => $username, 'nickname' => $nickname]]);
    }

    if ($action === 'login') {
        $username = trim($input['username'] ?? '');
        $password = trim($input['password'] ?? '');

        if (empty($username) || empty($password)) {
            json_response(['error' => '请输入用户名和密码'], 400);
        }

        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password'])) {
            json_response(['error' => '用户名或密码错误'], 401);
        }

        $token = create_token($user['id']);
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
        // 登录日志：字段不存在时降级跳过，避免登录整体失败
        try {
            $stmt = $pdo->prepare("INSERT INTO login_logs (user_id, username, ip, user_agent, status, created_at) VALUES (?, ?, ?, ?, 'success', NOW())");
            $stmt->execute([$user['id'], $user['username'], $ip, $ua]);
        } catch (Exception $e) {}
        record_task($pdo, $user['id'], 'signin');
        json_response(['token' => $token, 'user' => [
            'id' => $user['id'],
            'username' => $user['username'],
            'nickname' => $user['nickname'],
            'avatar' => $user['avatar'],
            'status' => $user['status']
        ]]);
    }

    if ($action === 'logout') {
        // Destroy web session if present
        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION = [];
            if (ini_get('session.use_cookies')) {
                setcookie(session_name(), '', time() - 3600, '/');
            }
            session_destroy();
        }

        // Remove API token if provided
        $token = $_SERVER['HTTP_X_AUTH_TOKEN'] ?? ($_COOKIE['auth_token'] ?? '');
        if (!empty($token)) {
            $stmt = $pdo->prepare("DELETE FROM sessions WHERE token = ?");
            $stmt->execute([$token]);
        }
        json_response(['success' => true]);
    }

    if ($action === 'profile') {
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $field = $input['field'] ?? '';
        $value = trim($input['value'] ?? '');

        if (!$field) {
            json_response(['error' => '缺少字段'], 400);
        }

        $allowed = ['nickname', 'password', 'bio', 'signature'];
        if (!in_array($field, $allowed, true)) {
            json_response(['error' => '不允许修改该字段'], 403);
        }

        if ($field === 'nickname') {
            if (mb_strlen($value, 'UTF-8') < 2 || mb_strlen($value, 'UTF-8') > 50) {
                json_response(['error' => '昵称长度2-50个字符'], 400);
            }
            $stmt = $pdo->prepare("UPDATE users SET nickname = ? WHERE id = ?");
            $stmt->execute([$value, $user['id']]);
            json_response(['success' => true, 'message' => '昵称已更新']);
        }

        if ($field === 'password') {
            if (mb_strlen($value, 'UTF-8') < 6) {
                json_response(['error' => '密码长度至少6位'], 400);
            }
            $hash = password_hash($value, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hash, $user['id']]);
            json_response(['success' => true, 'message' => '密码已更新']);
        }

        if ($field === 'bio') {
            if (mb_strlen($value, 'UTF-8') > 500) {
                json_response(['error' => '简介不能超过500个字符'], 400);
            }
            $stmt = $pdo->prepare("UPDATE users SET bio = ? WHERE id = ?");
            $stmt->execute([$value ?: null, $user['id']]);
            json_response(['success' => true, 'message' => '简介已更新']);
        }

        if ($field === 'signature') {
            if (mb_strlen($value, 'UTF-8') > 255) {
                json_response(['error' => '签名不能超过255个字符'], 400);
            }
            $stmt = $pdo->prepare("UPDATE users SET signature = ? WHERE id = ?");
            $stmt->execute([$value ?: null, $user['id']]);
            json_response(['success' => true, 'message' => '签名已更新']);
        }
    }

    json_response(['error' => '未知操作'], 400);
}

// GET methods
if ($action === 'me') {
    // Try PHP session first (web session)
    if (isset($_SESSION['user_id'])) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        if ($user) {
            json_response(['user' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'nickname' => $user['nickname'],
                'avatar' => $user['avatar'],
                'status' => $user['status'],
                'role' => $user['role'] ?? 'user'
            ]]);
        }
    }

    // Try token (API / persisted session)
    $token = $_SERVER['HTTP_X_AUTH_TOKEN'] ?? ($_COOKIE['auth_token'] ?? '');
    $user = get_user_by_token($token);
    if (!$user) {
        json_response(['error' => '未授权'], 401);
    }
    json_response(['user' => [
        'id' => $user['id'],
        'username' => $user['username'],
        'nickname' => $user['nickname'],
        'avatar' => $user['avatar'],
        'status' => $user['status'],
        'role' => $user['role'] ?? 'user'
    ]]);
}



if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'profile') {
    $current_user = require_auth();
    $user_id = (int)($_GET['user_id'] ?? 0);
    if ($user_id <= 0) {
        json_response(['error' => '无效的用户ID'], 400);
    }

    $stmt = $pdo->prepare("SELECT id, username, nickname, avatar, bio, signature, status, last_seen, created_at FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $u = $stmt->fetch();
    if (!$u) {
        json_response(['error' => '用户不存在'], 404);
    }

    $is_friend = false;
    $request_sent = false;
    if ($current_user['id'] != $user_id) {
        $stmt = $pdo->prepare("SELECT status FROM friendships WHERE ((user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)) LIMIT 1");
        $stmt->execute([$current_user['id'], $user_id, $user_id, $current_user['id']]);
        $rel = $stmt->fetch();
        if ($rel) {
            $is_friend = ($rel['status'] === 'accepted');
            $request_sent = ($rel['status'] === 'pending');
        }
    }

    json_response(['user' => [
        'id' => (int)$u['id'],
        'username' => $u['username'],
        'nickname' => $u['nickname'],
        'avatar' => $u['avatar'],
        'bio' => $u['bio'],
        'signature' => $u['signature'],
        'status' => $u['status'],
        'last_seen' => format_time($u['last_seen']),
        'created_at' => $u['created_at'],
        'is_friend' => $is_friend,
        'request_sent' => $request_sent
    ]]);
}

json_response(['error' => '未知操作'], 400);
