<?php
session_start();
require_once __DIR__ . '/functions.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = trim($_POST['host'] ?? '');
    $db_user = trim($_POST['db_user'] ?? '');
    $db_pass = trim($_POST['db_pass'] ?? '');
    $db_name = trim($_POST['db_name'] ?? '');
    if (!$host || !$db_user || !$db_name) {
        $error = '数据库主机、用户名和数据库名不能为空';
    } else {
        $config_content = "<?php\n";
        $config_content .= "define('DB_HOST', '" . addslashes($host) . "');\n";
        $config_content .= "define('DB_USER', '" . addslashes($db_user) . "');\n";
        $config_content .= "define('DB_PASS', '" . addslashes($db_pass) . "');\n";
        $config_content .= "define('DB_NAME', '" . addslashes($db_name) . "');\n";
        $config_content .= "?>\n";
        if (file_put_contents(__DIR__ . '/config.php', $config_content)) {
            $success = '数据库配置已更新，正在重连...';
            echo "<script>setTimeout(function(){ window.location.reload(); }, 1500);</script>";
        } else {
            $error = '无法写入 config.php，请检查目录权限';
        }
    }
}
// Load current config
$current = [
    'host' => defined('DB_HOST') ? DB_HOST : 'localhost',
    'db_user' => defined('DB_USER') ? DB_USER : 'root',
    'db_pass' => defined('DB_PASS') ? DB_PASS : '',
    'db_name' => defined('DB_NAME') ? DB_NAME : 'chatx'
];
// Test connection
try {
    $pdo = db_connect();
    $test_msg = '数据库连接正常';
} catch (Exception $e) {
    $test_msg = '连接失败: ' . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ChatX - 数据库配置</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .config-container { max-width: 600px; margin: 40px auto; background: #fff; border-radius: 16px; box-shadow: var(--shadow); padding: 40px; }
        .config-header { text-align: center; margin-bottom: 30px; }
        .config-header h1 { color: var(--primary); }
        .status-badge { display: inline-block; padding: 6px 14px; border-radius: 20px; font-size: 13px; margin-bottom: 20px; }
        .status-ok { background: #d4edda; color: #155724; }
        .status-err { background: #f8d7da; color: #721c24; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
        .form-group.full { grid-column: 1 / -1; }
        @media (max-width: 600px) { .form-row { grid-template-columns: 1fr; } }
    </style>
</head>
<body class="auth-page">
    <div class="config-container">
        <div class="config-header">
            <h1>ChatX 数据库配置</h1>
            <p>修改数据库连接参数，更改将立即生效</p>
        </div>
        <div style="text-align:center;">
            <span class="status-badge <?php echo strpos($test_msg, '正常') !== false ? 'status-ok' : 'status-err'; ?>">
                <?php echo h($test_msg); ?>
            </span>
        </div>
        <?php if ($error): ?>
        <div class="alert error" style="margin-bottom:18px;"><?php echo h($error); ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
        <div class="alert success" style="margin-bottom:18px;"><?php echo h($success); ?></div>
        <?php endif; ?>
        <form method="post" action="">
            <div class="form-row">
                <div class="form-group">
                    <label>数据库主机</label>
                    <input type="text" name="host" value="<?php echo h($current['host']); ?>" placeholder="通常为 localhost">
                </div>
                <div class="form-group">
                    <label>数据库名称</label>
                    <input type="text" name="db_name" value="<?php echo h($current['db_name']); ?>" placeholder="例如 chatx">
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>数据库用户名</label>
                    <input type="text" name="db_user" value="<?php echo h($current['db_user']); ?>" placeholder="通常为 root">
                </div>
                <div class="form-group">
                    <label>数据库密码</label>
                    <input type="password" name="db_pass" value="<?php echo h($current['db_pass']); ?>" placeholder="数据库密码">
                </div>
            </div>
            <button type="submit" class="btn-primary" style="width:100%;margin-top:8px;">保存配置并重连</button>
        </form>
        <div style="margin-top:24px;text-align:center;">
            <a href="chat.php" class="btn btn-secondary" style="text-decoration:none;">返回聊天</a>
        </div>
    </div>
</body>
</html>
