<?php
// ChatX Core Functions
// Version: 1.0

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!defined('DB_HOST') || !defined('DB_USER') || !defined('DB_NAME')) {
    $config_path = __DIR__ . '/config.php';
    if (is_file($config_path)) {
        require_once $config_path;
    }
}

// API 模式：关闭错误显示，确保始终返回纯 JSON
ini_set('display_errors', 0);
error_reporting(E_ALL & ~E_DEPRECATED);

// 全局异常捕获：API 遇到未捕获异常时返回 JSON 而非 HTML 崩溃页
set_exception_handler(function ($e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => get_class($e) . ': ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
    exit;
});

// Database connection
function db_connect() {
    static $pdo = null;
    if ($pdo === null) {
        if (!defined('DB_HOST') || !defined('DB_USER') || !defined('DB_NAME')) {
            if (strpos($_SERVER['REQUEST_URI'], '/api/') !== false) {
                json_response(['error' => '数据库未配置，请先运行 install.php'], 500);
            }
            die("数据库未配置，请先运行 <a href='install.php'>install.php</a> 进行配置。");
        }
        try {
            $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4", DB_USER, DB_PASS);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            // Auto clean expired sessions (lightweight)
            $pdo->exec("DELETE FROM sessions WHERE expires_at < NOW() LIMIT 100");
        } catch (Exception $e) {
            if (strpos($_SERVER['REQUEST_URI'], '/api/') !== false) {
                json_response(['error' => '数据库连接失败，请运行 install.php'], 500);
            }
            die("数据库连接失败，请运行 <a href='install.php'>install.php</a> 进行配置。");
        }
    }
    return $pdo;
}

// JSON response helper
function json_response($data, $code = 200) {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Require authentication
function require_auth() {
    // Try session first (web pages)
    if (isset($_SESSION['user_id'])) {
        $pdo = db_connect();
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();
        if ($user) return $user;
    }

    // Try token (API)
    $token = $_SERVER['HTTP_X_AUTH_TOKEN'] ?? ($_COOKIE['auth_token'] ?? '');
    if (!empty($token)) {
        $user = get_user_by_token($token);
        if ($user) return $user;
    }

    json_response(['error' => '未授权，请先登录'], 401);
}

// Check if user is super admin
function is_super_admin($user) {
    return ($user['role'] ?? 'user') === 'super_admin';
}

// Check if user has admin permission
function has_admin_permission($user, $permission) {
    $role = $user['role'] ?? 'user';
    if ($role === 'super_admin') {
        return true;
    }
    if ($role === 'admin') {
        $pdo = db_connect();
        $stmt = $pdo->prepare("SELECT 1 FROM admin_permissions WHERE user_id = ? AND permission = ?");
        $stmt->execute([$user['id'], $permission]);
        return (bool)$stmt->fetchColumn();
    }
    return false;
}

// Require admin permission or return 403
function require_admin_permission($user, $permission) {
    if (!has_admin_permission($user, $permission)) {
        json_response(['error' => '无权访问'], 403);
    }
}

// Get user by token
function get_user_by_token($token) {
    if (empty($token)) return null;
    $pdo = db_connect();
    $stmt = $pdo->prepare("SELECT u.* FROM users u JOIN sessions s ON u.id = s.user_id WHERE s.token = ? AND s.expires_at > NOW()");
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    if ($user) {
        // Update last activity
        $stmt = $pdo->prepare("UPDATE sessions SET last_activity = NOW() WHERE token = ?");
        $stmt->execute([$token]);
    }
    return $user ?: null;
}

// Create session token
function create_token($user_id) {
    $pdo = db_connect();
    $token = bin2hex(random_bytes(32));
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $expires = date('Y-m-d H:i:s', time() + 30 * 24 * 60 * 60); // 30 days

    $stmt = $pdo->prepare("INSERT INTO sessions (user_id, token, ip, user_agent, expires_at) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $token, $ip, $ua, $expires]);

    // Clean old sessions
    $stmt = $pdo->prepare("DELETE FROM sessions WHERE user_id = ? AND token != ?");
    $stmt->execute([$user_id, $token]);

    return $token;
}

// Clean old sessions (cron-like)
function clean_sessions() {
    $pdo = db_connect();
    $pdo->exec("DELETE FROM sessions WHERE expires_at < NOW()");
}

// Format time
function format_time($datetime) {
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;

    if ($diff < 60) return '刚刚';
    if ($diff < 3600) return floor($diff / 60) . '分钟前';
    if ($diff < 86400) return floor($diff / 3600) . '小时前';
    if ($diff < 604800) return floor($diff / 86400) . '天前';

    return date('Y-m-d', $time);
}

// Format message time
function format_message_time($datetime) {
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;

    if ($diff < 86400 && date('Y-m-d', $time) === date('Y-m-d', $now)) {
        return date('H:i', $time);
    }
    if ($diff < 172800 && date('Y-m-d', $time) === date('Y-m-d', $now - 86400)) {
        return '昨天 ' . date('H:i', $time);
    }
    return date('m-d H:i', $time);
}

// Escape HTML
function h($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

// Generate avatar
function avatar($user, $size = 40) {
    $name = $user['nickname'] ?: $user['username'];
    $hash = md5($name);
    $bg = '#' . substr($hash, 0, 6);
    $letter = mb_substr($name, 0, 1, 'UTF-8');
    return "<div class='avatar' style='width:{$size}px;height:{$size}px;background:{$bg};color:#fff;display:flex;align-items:center;justify-content:center;border-radius:50%;font-size:" . ($size * 0.4) . "px;font-weight:600;flex-shrink:0;'>" . h($letter) . "</div>";
}

// Pagination helper
function paginate($page = 1, $per_page = 20) {
    $page = max(1, (int)$page);
    $offset = ($page - 1) * $per_page;
    return [$page, $per_page, $offset];
}

// Validate username
function valid_username($username) {
    return preg_match('/^[a-zA-Z0-9_\x{4e00}-\x{9fa5}]{3,20}$/u', $username);
}

// Validate password
function valid_password($password) {
    return strlen($password) >= 6;
}

// Get unread count
function get_unread_count($pdo, $user_id) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0");
    $stmt->execute([$user_id]);
    return (int)$stmt->fetchColumn();
}

// Get last message
function get_last_message($pdo, $type, $id, $other_id = null) {
    if ($type === 'private') {
        $stmt = $pdo->prepare("SELECT content, created_at FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY created_at DESC LIMIT 1");
        $stmt->execute([$id, $other_id, $other_id, $id]);
    } else {
        $stmt = $pdo->prepare("SELECT content, created_at FROM messages WHERE group_id = ? ORDER BY created_at DESC LIMIT 1");
        $stmt->execute([$id]);
    }
    return $stmt->fetch();
}

// Record daily task progress
function record_task($pdo, $uid, $task_key, $count = 1) {
    $today = date('Y-m-d');
    // Ensure daily_tasks table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'daily_tasks'");
    if (!$stmt->fetch()) {
        $pdo->exec("CREATE TABLE IF NOT EXISTS daily_tasks (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            task_key VARCHAR(50) NOT NULL,
            completed_at DATETIME NOT NULL,
            task_date DATE NOT NULL,
            UNIQUE KEY uniq_task (user_id, task_key, task_date),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            INDEX idx_user_date (user_id, task_date)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM daily_tasks WHERE user_id = ? AND task_key = ? AND task_date = ?");
    $stmt->execute([$uid, $task_key, $today]);
    $existing = (int)$stmt->fetchColumn();
    if ($existing >= $count) return false;
    $pdo->prepare("INSERT INTO daily_tasks (user_id, task_key, completed_at, task_date) VALUES (?, ?, NOW(), ?)")->execute([$uid, $task_key, $today]);
    return true;
}
